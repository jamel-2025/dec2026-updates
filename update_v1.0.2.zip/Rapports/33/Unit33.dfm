﻿object Form33: TForm33
  Left = 0
  Top = 0
  Caption = 'Form33'
  ClientHeight = 553
  ClientWidth = 915
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  WindowState = wsMaximized
  OnActivate = FormActivate
  TextHeight = 15
  object scGPLabel22: TscGPLabel
    Left = 0
    Top = 0
    Width = 915
    Height = 58
    Align = alTop
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -21
    Font.Name = 'Segoe UI'
    Font.Style = [fsBold]
    ParentFont = False
    FluentUIOpaque = False
    TabOrder = 0
    StyleName = 'copper'
    DragForm = False
    DragTopForm = True
    DrawTextMode = scdtmGDI
    ContentMarginLeft = 5
    ContentMarginRight = 5
    ContentMarginTop = 5
    ContentMarginBottom = 5
    DisabledFontColor = clNone
    FrameWidth = 0
    FillColor = 10502192
    FillColorAlpha = 240
    FillColor2 = 7352320
    FillColor2Alpha = 240
    FillGradientAngle = 90
    FrameColor = clBtnText
    FrameColorAlpha = 0
    FrameRadius = 0
    GlowEffect.Enabled = True
    GlowEffect.Color = clBtnShadow
    GlowEffect.AlphaValue = 180
    GlowEffect.GlowSize = 5
    GlowEffect.Offset = 1
    GlowEffect.Intensive = True
    GlowEffect.StyleColors = True
    AutoSize = False
    Alignment = taCenter
    VertAlignment = scvtaCenter
    Caption = 'G50  Mois de :'
    ExplicitWidth = 913
  end
  object frxPreview1: TfrxPreview
    Left = 0
    Top = 107
    Width = 915
    Height = 446
    Align = alClient
    OutlineVisible = False
    OutlineWidth = 120
    ThumbnailVisible = False
    FindFmVisible = False
    UseReportHints = True
    OutlineTreeSortType = dtsUnsorted
    HideScrolls = False
    ExplicitWidth = 913
    ExplicitHeight = 442
  end
  object Panel5: TPanel
    Left = 0
    Top = 58
    Width = 915
    Height = 49
    Align = alTop
    TabOrder = 2
    ExplicitWidth = 913
    DesignSize = (
      915
      49)
    object SpeedButton8: TSpeedButton
      Left = 700
      Top = 5
      Width = 55
      Height = 41
      Anchors = [akTop, akRight]
      Caption = 'Exp PDF'
      ImageIndex = 80
      Images = DM.Smal
      Flat = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Arial'
      Font.Style = []
      Layout = blGlyphTop
      Margin = 1
      ParentFont = False
      PressedImageIndex = 84
      Spacing = 0
      StyleName = 'clear day se'
      ExplicitLeft = 836
    end
    object SpeedButton9: TSpeedButton
      Left = 767
      Top = 5
      Width = 55
      Height = 41
      Anchors = [akTop, akRight]
      Caption = 'Exp Excel'
      ImageIndex = 14
      Images = DM.Smal
      Flat = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Arial'
      Font.Style = []
      Layout = blGlyphTop
      Margin = 1
      ParentFont = False
      PressedImageIndex = 83
      Spacing = 0
      StyleName = 'clear day se'
      ExplicitLeft = 903
    end
    object SpeedButton12: TSpeedButton
      Left = 626
      Top = 5
      Width = 55
      Height = 41
      Anchors = [akTop, akRight]
      Caption = 'Imp Etat'
      ImageIndex = 13
      Images = DM.Smal
      Flat = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Arial'
      Font.Style = []
      Layout = blGlyphTop
      Margin = 1
      ParentFont = False
      PressedImageIndex = 11
      Spacing = 0
      StyleName = 'clear day se'
      OnClick = SpeedButton12Click
      ExplicitLeft = 762
    end
    object SpeedButton1: TSpeedButton
      Left = 840
      Top = 5
      Width = 49
      Height = 38
      Anchors = [akTop, akRight]
      Caption = 'Retour'
      ImageIndex = 82
      Images = DM.Smal
      Flat = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Arial'
      Font.Style = []
      Layout = blGlyphTop
      Margin = 1
      ParentFont = False
      PressedImageIndex = 73
      Spacing = 0
      StyleName = 'clear day se'
      ExplicitLeft = 976
    end
    object ma: TscGPLabel
      Left = 5
      Top = 1
      Width = 604
      Height = 46
      Anchors = [akLeft, akTop, akRight, akBottom]
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBtnText
      Font.Height = -19
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      FluentUIOpaque = False
      TabOrder = 0
      StyleName = 'copper'
      DragForm = False
      DragTopForm = True
      DrawTextMode = scdtmGDI
      ContentMarginLeft = 5
      ContentMarginRight = 5
      ContentMarginTop = 5
      ContentMarginBottom = 5
      DisabledFontColor = clNone
      FrameWidth = 1
      FillColor = clSkyBlue
      FillColorAlpha = 10
      FillColor2 = clNone
      FillColor2Alpha = 180
      FillGradientAngle = 0
      FrameColor = clNone
      FrameColorAlpha = 40
      FrameRadius = 5
      GlowEffect.Enabled = True
      GlowEffect.Color = clBtnShadow
      GlowEffect.AlphaValue = 255
      GlowEffect.GlowSize = 7
      GlowEffect.Offset = 0
      GlowEffect.Intensive = True
      GlowEffect.StyleColors = True
      AutoSize = False
      Alignment = taCenter
      VertAlignment = scvtaCenter
      ExplicitWidth = 602
    end
  end
  object VirtualQuery1: TVirtualQuery
    Active = True
    Constraints = <
      item
        FromDictionary = False
      end>
    DetailFields = 'Idg50'
    SourceDataSets = <
      item
        DataSet = qTVA
      end
      item
        DataSet = qRef
      end>
    SQL.Strings = (
      'SELECT '
      '    qRef.CODE, '
      '    qRef.nature, '
      '    qRef.OP'#201'RATIONS, '
      '    qTVA.Idg50, -- '#1607#1584#1575' '#1575#1604#1581#1602#1604' '#1607#1608' '#1605#1601#1578#1575#1581' '#1575#1604#1581#1604
      '    qTVA.CAG, '
      '    qTVA.CAI, '
      '    qTVA.CAE, '
      '    qTVA.TAUX, '
      '    qTVA.DROITS'
      'FROM '
      '    qRef '
      'LEFT JOIN '
      '    qTVA ON qRef.CODE = qTVA.CODE')
    Left = 696
    Top = 138
    object VirtualQuery1CODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object VirtualQuery1OPÉRATIONS: TWideStringField
      FieldName = 'OP'#201'RATIONS'
      Size = 255
    end
    object VirtualQuery1CAG: TIntegerField
      FieldName = 'CAG'
      ReadOnly = True
    end
    object VirtualQuery1CAI: TFloatField
      FieldName = 'CAI'
      ReadOnly = True
    end
    object VirtualQuery1CAE: TFloatField
      FieldName = 'CAE'
      ReadOnly = True
    end
    object VirtualQuery1TAUX: TFloatField
      FieldName = 'TAUX'
      ReadOnly = True
    end
    object VirtualQuery1DROITS: TFloatField
      FieldName = 'DROITS'
      ReadOnly = True
    end
    object VirtualQuery1Idg50: TIntegerField
      FieldName = 'Idg50'
    end
    object VirtualQuery1nature: TWideStringField
      FieldName = 'nature'
      Size = 255
    end
  end
  object qTVA: TUniQuery
    Connection = DM.UniConnection
    SQL.Strings = (
      
        'SELECT Idg50, [Ann'#233'e], CODE, CAG, CAI, CAE, TAUX, DROITS FROM TV' +
        'A')
    Active = True
    Left = 752
    Top = 194
    object qTVAIdg50: TIntegerField
      FieldName = 'Idg50'
    end
    object qTVAAnnée: TWideStringField
      FieldName = 'Ann'#233'e'
      Size = 50
    end
    object qTVACODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object qTVACAG: TIntegerField
      FieldName = 'CAG'
    end
    object qTVACAI: TFloatField
      FieldName = 'CAI'
    end
    object qTVACAE: TFloatField
      FieldName = 'CAE'
    end
    object qTVATAUX: TFloatField
      FieldName = 'TAUX'
    end
    object qTVADROITS: TFloatField
      FieldName = 'DROITS'
    end
  end
  object qRef: TUniQuery
    Connection = DM.UniCRef
    SQL.Strings = (
      'SELECT CODE, [OP'#201'RATIONS],nature FROM TVAref')
    Active = True
    Left = 704
    Top = 194
    object qRefCODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object qRefOPÉRATIONS: TWideStringField
      FieldName = 'OP'#201'RATIONS'
      Size = 255
    end
  end
  object UniDataSource1: TUniDataSource
    DataSet = VirtualQuery1
    Left = 776
    Top = 136
  end
  object RG50: TfrxReport
    Version = '6.9.14'
    DotMatrixReport = False
    IniFile = '\Software\Fast Reports'
    Preview = frxPreview1
    PreviewOptions.Buttons = [pbPrint, pbLoad, pbSave, pbExport, pbZoom, pbFind, pbOutline, pbPageSetup, pbTools, pbEdit, pbNavigator, pbExportQuick, pbCopy, pbSelection]
    PreviewOptions.Zoom = 1.000000000000000000
    PrintOptions.Printer = 'Default'
    PrintOptions.PrintOnSheet = 0
    ReportOptions.CreateDate = 46127.819362569400000000
    ReportOptions.LastChange = 46129.534888055600000000
    ScriptLanguage = 'PascalScript'
    ScriptText.Strings = (
      'begin'
      ''
      'end.')
    Left = 312
    Top = 56
    Datasets = <
      item
        DataSet = DBG50
        DataSetName = 'DBG50'
      end
      item
        DataSet = DBsalaires
        DataSetName = 'DBsalaires'
      end
      item
        DataSet = Form20.DBSociete
        DataSetName = 'DBSociete'
      end
      item
        DataSet = DBtap
        DataSetName = 'DBtap'
      end
      item
        DataSet = DBtva
        DataSetName = 'DBtva'
      end>
    Variables = <>
    Style = <>
    object Data: TfrxDataPage
      Height = 1000.000000000000000000
      Width = 1000.000000000000000000
    end
    object Page1: TfrxReportPage
      Orientation = poLandscape
      PaperWidth = 297.000000000000000000
      PaperHeight = 210.000000000000000000
      PaperSize = 9
      LeftMargin = 5.000000000000000000
      RightMargin = 5.000000000000000000
      TopMargin = 10.000000000000000000
      BottomMargin = 10.000000000000000000
      Frame.Typ = []
      MirrorMode = []
      object PageHeader2: TfrxPageHeader
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 168.279530000000000000
        Top = 18.897650000000000000
        Width = 1084.725110000000000000
        object TableObject5: TfrxTableObject
          AllowVectorExport = True
          object TableColumn25: TfrxTableColumn
            Width = 60.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn26: TfrxTableColumn
            Width = 105.500000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn27: TfrxTableColumn
            Width = 24.500000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn28: TfrxTableColumn
            Width = 20.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn29: TfrxTableColumn
            Width = 82.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn30: TfrxTableColumn
            Width = 17.500000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn31: TfrxTableColumn
            Width = 593.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn32: TfrxTableColumn
            Width = 29.500000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn33: TfrxTableColumn
            Width = 140.166666666667000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn34: TfrxTableColumn
            Width = 13.500000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn35: TfrxTableColumn
            Width = 0.500000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow13: TfrxTableRow
            Height = 14.000000000000000000
            object TableCell136: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              Memo.UTF8W = (
                #1575#1604#1605#1583#1610#1585#1610#1577' '#1575#1604#1593#1575#1605#1577' '#1604#1604#1590#1585#1575#1574#1576)
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell137: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell138: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell139: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              Memo.UTF8W = (
                '.........................: '#1575#1604#1588#1607#1585)
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell140: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell141: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell142: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop]
              Frame.Width = 2.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                #1575#1604#1590#1585#1575#1574#1576' '#1608' '#1575#1604#1585#1587#1608#1605' '#1575#1604#1605#1581#1589#1604#1577' '#1601#1608#1585#1575' '#1571#1608' '#1593#1606' '#1591#1585#1610#1602' '#1575#1604#1573#1602#1578#1591#1575#1593' '#1605#1606' '#1575#1604#1605#1589#1583#1585)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell143: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell144: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              Memo.UTF8W = (
                'S'#233'rie G n'#176'50 (2025)')
              ParentFont = False
            end
            object TableCell145: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -6
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell146: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow14: TfrxTableRow
            Height = 14.000000000000000000
            object TableCell147: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              Memo.UTF8W = (
                'DIRECTION GENERALE DES IMPOTS')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell148: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell149: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell150: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              Memo.UTF8W = (
                '.........................: '#1575#1604#1601#1589#1604)
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell151: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell152: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell153: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              Frame.Width = 2.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                #1578#1589#1585#1610#1581' '#1610#1602#1608#1605' '#1605#1602#1575#1605' '#1581#1575#1601#1592#1577' '#1573#1588#1593#1575#1585' '#1576#1575#1604#1578#1587#1583#1610#1583)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell154: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell155: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop]
              HAlign = haRight
              Memo.UTF8W = (
                
                  #1607#1575#1605' : '#1607#1584#1575' '#1575#1604#1578#1589#1585#1610#1581' '#1610#1580#1576' '#1571#1606' '#1610#1608#1590#1593' '#1601#1610' '#1602#1576#1575#1590#1577' '#1575#1604#1590#1585#1575#1574#1576' '#1582#1604#1575#1604' '#1575#1604#1593#1588#1585#1610#1606' '#1610#1608#1605' ' +
                  #1575#1604#1571#1608#1604#1609' '#1605#1606' '#1575#1604#1588#1607#1585'.')
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
            object TableCell156: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -6
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell157: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
          end
          object TableRow15: TfrxTableRow
            Height = 14.000000000000000000
            object TableCell158: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              Memo.UTF8W = (
                '..................................:. '#1605#1583#1610#1585#1610#1577' ')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell159: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell160: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell161: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              Memo.UTF8W = (
                '.........................: '#1575#1604#1587#1606#1577)
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell162: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell163: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell164: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              Frame.Width = 2.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                'IMPOTS ET TAXES PER'#199'US AU COMPTANT OU PAR VOIE')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell165: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell166: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell167: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -6
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell168: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow16: TfrxTableRow
            Height = 14.000000000000000000
            object TableCell169: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'DIRECTION : ................................')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell170: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell171: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell172: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'Mois de ...............')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell173: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell174: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell175: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              Frame.Width = 2.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                'DE RETENUE A LA SOURCE')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell176: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell177: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Memo.UTF8W = (
                
                  'Important : La d'#233'claration doit '#234'tre d'#233'pos'#233'e '#224' la recette des im' +
                  'p'#244'ts dans les vingt premiers jours du mois.')
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
            object TableCell178: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -6
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell179: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
          end
          object TableRow17: TfrxTableRow
            Height = 16.000000000000000000
            object TableCell180: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              Memo.UTF8W = (
                ' ...........................................: '#1605#1589#1604#1581#1577' '#1575#1604#1590#1585#1575#1574#1576' '#1604#1600)
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell181: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell182: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell183: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'Trimestre :.......................')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell184: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell185: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell186: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.Width = 2.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                'DECLARATION TENANT LIEU DE BORDEREAU - AVIS DE VERSEMENT')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell187: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell188: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell189: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -6
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell190: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow18: TfrxTableRow
            Height = 14.000000000000000000
            object TableCell191: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'STRUCTURE :..............................................')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell192: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell193: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell194: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'Ann'#233'e :.......................')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell195: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell196: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell197: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell198: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell199: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell200: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell201: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow19: TfrxTableRow
            Height = 18.000000000000000000
            object TableCell202: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                #1602#1576#1575#1590#1577' '#1575#1604#1590#1585#1575#1574#1576' : .............................................')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 3
            end
            object TableCell203: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell204: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell205: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell206: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell207: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell208: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop]
              Frame.Width = 2.000000000000000000
              Memo.UTF8W = (
                'M :     [DBSociete."rs"]')
              ParentFont = False
              VAlign = vaBottom
            end
            object TableCell209: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell210: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell211: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell212: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow20: TfrxTableRow
            Height = 14.000000000000000000
            object TableCell213: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'RECETTE DES IMPOTS DE : ..................................')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell214: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell215: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell216: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'A RAPPELER'
                'OBLIGATOIREMENT')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
              RowSpan = 2
            end
            object TableCell217: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell218: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -6
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell219: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              Frame.Width = 2.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                '('#1575#1604#1575#1587#1605'/'#1575#1604#1604#1602#1576' - '#1575#1604#1575#1587#1605' '#1608' '#1575#1604#1604#1602#1576')  (sociale raison - nom et pr'#233'nom)')
              ParentFont = False
              VAlign = vaBottom
            end
            object TableCell220: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell221: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell87: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell88: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow21: TfrxTableRow
            Height = 14.000000000000000000
            object TableCell89: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              Memo.UTF8W = (
                
                  'COMMUNE DE : ................................................. '#1576 +
                  #1604#1583#1610#1577)
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell90: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell91: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell92: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell93: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell94: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell95: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              Frame.Width = 2.000000000000000000
              Memo.UTF8W = (
                'Profession/Activit'#233':       [DBSociete."activit'#233'"]')
              ParentFont = False
              VAlign = vaBottom
            end
            object TableCell96: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell97: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell98: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -6
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell99: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow22: TfrxTableRow
            Height = 17.000000000000000000
            object TableCell100: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'NIN : ')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell101: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell102: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell103: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell104: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell105: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell106: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              Frame.Width = 2.000000000000000000
              Memo.UTF8W = (
                'Adresse :    [DBSociete."adresse"]')
              ParentFont = False
              VAlign = vaBottom
            end
            object TableCell107: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell108: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell109: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell110: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow23: TfrxTableRow
            Height = 9.500000000000000000
            object TableCell111: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DisplayFormat.FormatStr = ' | | | | | | | | | | | | | | | | | | | | | |'
              DisplayFormat.Kind = fkBoolean
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'NIF : ')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 3
            end
            object TableCell112: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell113: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell114: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              Memo.UTF8W = (
                'F. J.')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell115: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell116: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell117: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.Width = 2.000000000000000000
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell118: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell119: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell120: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell121: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow24: TfrxTableRow
            Height = 10.000000000000000000
            object TableCell122: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'Article d'#8217'imposition : ')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 3
            end
            object TableCell123: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell124: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell125: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell126: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell127: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 6
            end
            object TableCell128: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell129: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell130: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell131: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell132: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
      object GroupFooter2: TfrxGroupFooter
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 18.897650000000000000
        Top = 351.496290000000000000
        Width = 1084.725110000000000000
        object TableObject6: TfrxTableObject
          AllowVectorExport = True
          object TableColumn44: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn45: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn46: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn47: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn48: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn49: TfrxTableColumn
            Width = 166.257266666667000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow25: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell247: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -15
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                '1')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell248: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 5.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                'Total')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell249: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtap."CAbrut">,MasterData3)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell250: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtap."Caimposable">,MasterData3)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell251: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell252: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtap."Droits">,MasterData3)]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
      object MasterData3: TfrxMasterData
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 18.897637800000000000
        Top = 309.921460000000000000
        Width = 1084.725110000000000000
        DataSet = DBtap
        DataSetName = 'DBtap'
        RowCount = 0
        object TableObject12: TfrxTableObject
          AllowVectorExport = True
          object TableColumn77: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn78: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn79: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn80: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn81: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn82: TfrxTableColumn
            Width = 166.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow32: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell270: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'CODE'
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBtap."CODE"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell271: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'IMPOTS'
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                '[DBtap."IMPOTS"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell272: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtap."CAbrut"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell273: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtap."Caimposable"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell274: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'tauxtap'
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBtap."tauxtap"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell275: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'Droits'
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              Frame.RightLine.Style = fsSolid
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtap."Droits"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
      object GroupHeader2: TfrxGroupHeader
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 37.795287800000000000
        Top = 249.448980000000000000
        Width = 1084.725110000000000000
        Condition = 'DBG50."idg50"'
        object TableObject10: TfrxTableObject
          AllowVectorExport = True
          object TableColumn43: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn65: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn66: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn67: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn68: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn69: TfrxTableColumn
            Width = 166.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow28: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell235: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Taxe sur L'#39'Activit'#233' Professionnelle')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 6
            end
            object TableCell236: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 5
            end
            object TableCell237: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell238: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell239: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell240: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow29: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell241: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Code')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell242: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Op'#233'rations imposables')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell243: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Chiffre d'#39'affaires Brut')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell244: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Chiffre d'#39'affaires Imposable')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell245: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Taux')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell246: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Montant '#224' payer ')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
      object TableObject7: TfrxTableObject
        AllowVectorExport = True
        object TableColumn50: TfrxTableColumn
          Width = 52.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn51: TfrxTableColumn
          Width = 416.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn52: TfrxTableColumn
          Width = 201.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn53: TfrxTableColumn
          Width = 186.090600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn54: TfrxTableColumn
          Width = 50.090600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn55: TfrxTableColumn
          Width = 166.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableRow30: TfrxTableRow
          Height = 18.897650000000000000
          object TableCell253: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            Memo.UTF8W = (
              'Taxe sur L'#39'Activit'#233' Professionnelle')
            ParentFont = False
            VAlign = vaCenter
            ColSpan = 6
          end
          object TableCell254: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            ParentFont = False
            VAlign = vaCenter
            ColSpan = 5
          end
          object TableCell255: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell256: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell257: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell258: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            ParentFont = False
            VAlign = vaCenter
          end
        end
        object TableRow31: TfrxTableRow
          Height = 18.897650000000000000
          object TableCell259: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            Memo.UTF8W = (
              'Code')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell260: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            Memo.UTF8W = (
              'Op'#233'rations imposables')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell261: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            Memo.UTF8W = (
              'Chiffre d'#39'affaires Brut')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell262: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            Memo.UTF8W = (
              'Chiffre d'#39'affaires Imposable')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell263: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            Memo.UTF8W = (
              'Taux')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell264: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlue
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
            HAlign = haCenter
            Memo.UTF8W = (
              'Droits')
            ParentFont = False
            VAlign = vaCenter
          end
        end
      end
      object MasterData5: TfrxMasterData
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 18.897650000000000000
        Top = 453.543600000000000000
        Width = 1084.725110000000000000
        DataSet = DBsalaires
        DataSetName = 'DBsalaires'
        RowCount = 0
      end
      object TableObject15: TfrxTableObject
        AllowVectorExport = True
        Left = -3.779530000000000000
        Top = 453.543600000000000000
        object TableColumn94: TfrxTableColumn
          Width = 52.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn95: TfrxTableColumn
          Width = 416.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn96: TfrxTableColumn
          Width = 201.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn97: TfrxTableColumn
          Width = 186.090600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn98: TfrxTableColumn
          Width = 50.090600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableColumn99: TfrxTableColumn
          Width = 166.590600000000000000
          MaxWidth = 75.590600000000000000
        end
        object TableRow39: TfrxTableRow
          Height = 18.897650000000000000
          object TableCell307: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            DataSet = DBtap
            DataSetName = 'DBtap'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlack
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Style = fsDot
            Frame.Typ = [ftLeft, ftRight, ftBottom]
            Frame.LeftLine.Style = fsSolid
            HAlign = haCenter
            Memo.UTF8W = (
              '[DBsalaires."CODE"]')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell308: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            DataSet = DBtap
            DataSetName = 'DBtap'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlack
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Style = fsDot
            Frame.Typ = [ftLeft, ftRight, ftBottom]
            Frame.LeftLine.Style = fsSolid
            GapX = 5.000000000000000000
            Memo.UTF8W = (
              '[DBsalaires."IMPOTS"]')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell309: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            DataSet = DBtap
            DataSetName = 'DBtap'
            DisplayFormat.FormatStr = '%2.0n'
            DisplayFormat.Kind = fkNumeric
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlack
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Style = fsDot
            Frame.Typ = [ftLeft, ftRight, ftBottom]
            Frame.LeftLine.Style = fsSolid
            GapX = 8.000000000000000000
            HAlign = haRight
            Memo.UTF8W = (
              '[DBsalaires."Revenusimposables"]')
            ParentFont = False
            VAlign = vaCenter
            ColSpan = 2
          end
          object TableCell310: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            DataSet = DBtap
            DataSetName = 'DBtap'
            DisplayFormat.FormatStr = '%2.0n'
            DisplayFormat.Kind = fkNumeric
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlack
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Style = fsDot
            Frame.Typ = [ftLeft, ftRight, ftBottom]
            Frame.LeftLine.Style = fsSolid
            GapX = 8.000000000000000000
            HAlign = haRight
            Memo.UTF8W = (
              '[DBtap."Caimposable"]')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell311: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            DataSet = DBtap
            DataSetName = 'DBtap'
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlack
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Style = fsDot
            Frame.Typ = [ftLeft, ftRight, ftBottom]
            Frame.LeftLine.Style = fsSolid
            HAlign = haCenter
            Memo.UTF8W = (
              '[DBsalaires."taux"]')
            ParentFont = False
            VAlign = vaCenter
          end
          object TableCell312: TfrxTableCell
            AllowVectorExport = True
            Restrictions = [rfDontDelete]
            DataSet = DBtap
            DataSetName = 'DBtap'
            DisplayFormat.FormatStr = '%2.0n'
            DisplayFormat.Kind = fkNumeric
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBlack
            Font.Height = -11
            Font.Name = 'Arial'
            Font.Style = []
            Frame.Color = clBlue
            Frame.Style = fsDot
            Frame.Typ = [ftLeft, ftRight, ftBottom]
            Frame.LeftLine.Style = fsSolid
            Frame.RightLine.Style = fsSolid
            GapX = 8.000000000000000000
            HAlign = haRight
            Memo.UTF8W = (
              '[DBsalaires."Droits"]')
            ParentFont = False
            VAlign = vaCenter
          end
        end
      end
      object GroupHeader5: TfrxGroupHeader
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 37.795300000000000000
        Top = 393.071120000000000000
        Width = 1084.725110000000000000
        Condition = 'DBG50."idg50"'
        object TableObject14: TfrxTableObject
          AllowVectorExport = True
          object TableColumn88: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn89: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn90: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn91: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn92: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn93: TfrxTableColumn
            Width = 166.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow37: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell295: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'IRG / Traitements et salaires et autres retenues '#224' la source    ')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 6
            end
            object TableCell296: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 5
            end
            object TableCell297: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell298: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell299: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell300: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow38: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell301: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Code')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell302: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Cat'#233'gories de revenus soumis '#224' une retenue '#224' la source IRG')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell303: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Base imposable')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell304: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Chiffre d'#39'affaires Imposable')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell305: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Taux')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell306: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Montant '#224' payer ')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
      object GroupFooter4: TfrxGroupFooter
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 18.897650000000000000
        Top = 495.118430000000000000
        Width = 1084.725110000000000000
        object TableObject17: TfrxTableObject
          AllowVectorExport = True
          object TableColumn100: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn101: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn102: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn103: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn104: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn105: TfrxTableColumn
            Width = 166.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow40: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell313: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBsalaires."CODE"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell314: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                '[DBsalaires."IMPOTS"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell315: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBsalaires."Revenusimposables"]')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell316: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtap."Caimposable"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell317: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBsalaires."taux"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell318: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBsalaires."Droits"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
    end
    object Page11: TfrxReportPage
      Orientation = poLandscape
      PaperWidth = 297.000000000000000000
      PaperHeight = 210.000000000000000000
      PaperSize = 9
      LeftMargin = 5.000000000000000000
      RightMargin = 5.000000000000000000
      TopMargin = 10.000000000000000000
      BottomMargin = 10.000000000000000000
      Frame.Typ = []
      MirrorMode = []
      object PageHeader1: TfrxPageHeader
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 90.000000000000000000
        Top = 18.897650000000000000
        Width = 1084.725110000000000000
        object TableObject1: TfrxTableObject
          AllowVectorExport = True
          Restrictions = [rfDontModify, rfDontSize, rfDontMove, rfDontEdit]
          object TableColumnP4_1: TfrxTableColumn
            Width = 54.964452559055100000
            MaxWidth = 75.590600000000000000
          end
          object TableColumnP4_2: TfrxTableColumn
            Width = 359.964452559055000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumnP4_3: TfrxTableColumn
            Width = 154.964452559055000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumnP4_4: TfrxTableColumn
            Width = 154.964452559055000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumnP4_5: TfrxTableColumn
            Width = 149.964452559055000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumnP4_6: TfrxTableColumn
            Width = 29.964452559055100000
            MaxWidth = 75.590600000000000000
          end
          object TableColumnP4_7: TfrxTableColumn
            Width = 155.894452559055000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn12: TfrxTableColumn
            Width = 24.555052559055100000
            MaxWidth = 75.590600000000000000
          end
          object TableRowP4_1: TfrxTableRow
            Height = 40.000000000000000000
            object TableCellP4_1: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              Memo.UTF8W = (
                'Les chiffres d'#39'affaires et les recettes'
                'professionnelles sont inscrits en dinars,'
                'le dernier chiffre '#233'tant ramen'#233' au z'#233'ro.'
                '(Exemple : 325.626 DA => 325.620 DA)')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCellP4_2: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_3: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -10
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                #1575#1604#1585#1587#1605' '#1593#1604#1609' '#1575#1604#1602#1610#1605#1577' '#1575#1604#1605#1590#1575#1601#1577
                'TAXE SUR LA VALEUR AJOUTEE')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 3
            end
            object TableCellP4_4: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_5: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_6: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haRight
              Memo.UTF8W = (
                #1578#1587#1580#1604' '#1571#1585#1602#1575#1605' '#1575#1604#1571#1593#1605#1575#1604' '#1608' '#1575#1604#1573#1610#1585#1575#1583#1575#1578' '#1575#1604#1605#1607#1606#1610#1577' '#1576#1575#1604#1583#1610#1606#1575#1585
                #1608' '#1575#1604#1593#1583#1583' '#1575#1604#1571#1582#1610#1585' '#1610#1585#1575#1580#1593' '#1573#1604#1609' '#1575#1604#1589#1601#1585'.'
                '('#1605#1579#1575#1604': 325.626 = 325.620 '#1583#1580')')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCellP4_7: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell133: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
            end
          end
          object TableRowP4_8: TfrxTableRow
            Height = 22.000000000000000000
            object TableCellP4_8: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = []
              HAlign = haCenter
              Memo.UTF8W = (
                
                  'A / Chiffres d'#39'affaires imposables      '#1571' - '#1585#1602#1605' '#1575#1604#1571#1593#1605#1575#1604' '#1575#1604#1582#1575#1590#1593' '#1604 +
                  #1604#1590#1585#1610#1576#1577)
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 7
            end
            object TableCellP4_9: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_10: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_11: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_12: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_13: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_14: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell134: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = []
              ParentFont = False
            end
          end
          object TableRowP4_15: TfrxTableRow
            Height = 28.000000000000000000
            object TableCellP4_15: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                #1575#1604#1585#1605#1586
                'Code')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_16: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Op'#233'rations assujetties '#224' la TVA'
                #1575#1604#1593#1605#1604#1610#1575#1578' '#1575#1604#1582#1575#1590#1593#1577' '#1604#1604#1585#1587#1605' '#1593#1604#1609' '#1575#1604#1602#1610#1605#1577' '#1575#1604#1605#1590#1575#1601#1577)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_17: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                #1605#1580#1605#1608#1593' '#1585#1602#1605' '#1575#1604#1571#1593#1605#1575#1604
                'Chiffre d'#39'affaires total')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_18: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                #1585#1602#1605' '#1575#1604#1571#1593#1605#1575#1604' '#1575#1604#1605#1593#1601#1609
                'Chiffre d'#39'affaires exon'#233'r'#233)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_19: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                #1585#1602#1605' '#1575#1604#1571#1593#1605#1575#1604' '#1575#1604#1582#1575#1590#1593' '#1604#1604#1590#1585#1610#1576#1577
                'Chiffre d'#39'affaires imposable')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_20: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Taux'
                #1575#1604#1605#1593#1583#1604)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCellP4_21: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                #1575#1604#1605#1576#1604#1594' '#1575#1604#1605#1583#1601#1608#1593' '#1576#1600' ('#1583#1580')'
                'Montant des droits (en DA)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell135: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontModify, rfDontSize, rfDontMove, rfDontDelete, rfDontEdit]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              ParentFont = False
            end
          end
        end
      end
      object MasterData1: TfrxMasterData
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 18.897637800000000000
        Top = 192.756030000000000000
        Width = 1084.725110000000000000
        DataSet = DBtva
        DataSetName = 'DBtva'
        RowCount = 0
        object TableObject2: TfrxTableObject
          AllowVectorExport = True
          Restrictions = [rfDontModify, rfDontSize, rfDontEdit]
          object TableColumn1: TfrxTableColumn
            Width = 55.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn2: TfrxTableColumn
            Width = 360.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn3: TfrxTableColumn
            Width = 155.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn4: TfrxTableColumn
            Width = 155.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn5: TfrxTableColumn
            Width = 150.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn6: TfrxTableColumn
            Width = 30.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn7: TfrxTableColumn
            Width = 155.930000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn8: TfrxTableColumn
            Width = 23.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow1: TfrxTableRow
            Height = 18.897637795275600000
            object TableCell1: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'CODE'
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBtva."CODE"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell2: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'OP'#201'RATIONS'
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.Width = 0.500000000000000000
              Frame.TopLine.Style = fsDot
              Frame.BottomLine.Style = fsDot
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                '[DBtva."OP'#201'RATIONS"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell3: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'CAG'
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              Frame.Width = 0.500000000000000000
              Frame.TopLine.Style = fsDot
              Frame.BottomLine.Style = fsDot
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtva."CAG"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell4: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'CAE'
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.Width = 0.500000000000000000
              Frame.TopLine.Style = fsDot
              Frame.BottomLine.Style = fsDot
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtva."CAE"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell5: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'CAI'
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.2n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.Width = 0.500000000000000000
              Frame.LeftLine.Style = fsSolid
              Frame.RightLine.Style = fsSolid
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtva."CAI"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell6: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'TAUX'
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.TopLine.Style = fsDot
              Frame.BottomLine.Style = fsDot
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBtva."TAUX"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell7: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'DROITS'
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.TopLine.Style = fsDot
              Frame.BottomLine.Style = fsDot
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtva."DROITS"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell8: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              ParentFont = False
            end
          end
        end
      end
      object MasterData2: TfrxMasterData
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 218.666666670000000000
        Top = 279.685220000000000000
        Width = 1084.725110000000000000
        DataSet = DBG50
        DataSetName = 'DBG50'
        RowCount = 0
        object TableObject4: TfrxTableObject
          AllowVectorExport = True
          object TableColumn9: TfrxTableColumn
            Width = 55.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn10: TfrxTableColumn
            Width = 360.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn11: TfrxTableColumn
            Width = 120.333333333333000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn13: TfrxTableColumn
            Width = 35.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn14: TfrxTableColumn
            Width = 59.333333333333300000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn15: TfrxTableColumn
            Width = 247.333333333333000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn16: TfrxTableColumn
            Width = 206.930000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow2: TfrxTableRow
            Height = 20.666666666666700000
            object TableCell9: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
            object TableCell10: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = [fsBold, fsUnderline]
              Frame.Color = clBlue
              Frame.Typ = [ftTop]
              Memo.UTF8W = (
                'B / D'#233'ductions '#224' op'#233'rer')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell11: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = [fsBold, fsUnderline]
              Frame.Color = clBlue
              Frame.Typ = [ftTop]
              HAlign = haCenter
              Memo.UTF8W = (
                ' '#1576' - '#1575#1604#1581#1587#1608#1605#1575#1578' '#1575#1604#1605#1580#1586#1575#1577)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell12: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftTop]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell13: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftTop]
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell14: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = [fsBold, fsUnderline]
              Frame.Color = clBlue
              Frame.Typ = [ftTop]
              Memo.UTF8W = (
                '    C / TVA '#224' payer       ')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell15: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = [fsBold, fsUnderline]
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftTop]
              HAlign = haCenter
              Memo.UTF8W = (
                ' '#1578' - '#1585'.'#1602'.'#1605' '#1575#1604#1608#1575#1580#1576' '#1583#1601#1593#1607)
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow3: TfrxTableRow
            Height = 18.333333333333300000
            object TableCell16: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell17: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Nature des d'#233'ductions')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell18: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Montant')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell19: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell20: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell21: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop]
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell22: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow4: TfrxTableRow
            Height = 22.166666666666700000
            object TableCell23: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E3 B91')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell24: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'Pr'#233'compte ant'#233'rieurs (mois pr'#233'c'#233'dent)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell25: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'Pr'#233'compte_ant'#233'rieur'
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."Pr'#233'compte_ant'#233'rieur"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell26: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 8
            end
            object TableCell27: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'C')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell28: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                '- Total des droits dus.')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell29: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."Totaldroits_dus"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow5: TfrxTableRow
            Height = 18.666666666666700000
            object TableCell30: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E3 B92')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell31: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'TVA sur achats de biens, mati'#232'res et services (art. 29 C.TCA)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell32: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'TTVAachatMatieres'
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."TTVAachatMatieres"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell33: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell34: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E 3B97')
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
            object TableCell35: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'R'#233'gularisation du prorata (art. 40 C. TCA)'
                '(+) d'#233'duction exc'#233'dentaire')
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
            object TableCell36: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."d'#233'duction_exc'#233'dentaire"]')
              ParentFont = False
              VAlign = vaCenter
              RowSpan = 2
            end
          end
          object TableRow6: TfrxTableRow
            Height = 18.666666666666700000
            object TableCell37: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E3 B93')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell38: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'TVA sur achats de biens amortissables (art. 38 C.TCA)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell39: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'TVAbiensamortissables'
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."TVAbiensamortissables"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell40: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell41: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftRight]
              Frame.Width = 0.500000000000000000
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell42: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell43: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow7: TfrxTableRow
            Height = 25.333333333333300000
            object TableCell44: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E3 B94')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell45: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                
                  'R'#233'gularisation du prorata (d'#233'duction compl'#233'mentaire) (art. 40 C.' +
                  ' TCA)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell46: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'd'#233'ductioncompl'#233'mentaire'
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."d'#233'ductioncompl'#233'mentaire"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell47: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell48: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E 3B98')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell49: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'Reversement de la d'#233'duction (art. 38 CTCA)(+)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell50: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."Reversement_de_la_d'#233'duction"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow8: TfrxTableRow
            Height = 23.000000000000000000
            object TableCell51: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E3 B95')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell52: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                
                  'TVA '#224' r'#233'cup'#233'rer sur factures annul'#233'es ou impay'#233'es (art. 18 C. TC' +
                  'A)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell53: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."TVAfacturesannul'#233'es"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell54: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell55: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'B')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell56: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'TOTAL A RAPPELER (C) '#1605#1580#1605#1608#1593' '#1575#1604#1605#1587#1578#1581#1602#1575)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell57: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."TOTALaRAPPELER"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow9: TfrxTableRow
            Height = 24.000000000000000000
            object TableCell58: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E3 B96')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell59: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'Autres d'#233'ductions (notification de pr'#233'compte, TVA omise etc.)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell60: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."Autres_d'#233'ductions"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell61: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell62: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E 3B00')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell63: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                '-Total des d'#233'ductions '#224' op'#233'rer (B)(-)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell64: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."Total_des_d'#233'ductions"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow10: TfrxTableRow
            Height = 23.333333333333300000
            object TableCell65: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell66: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              Memo.UTF8W = (
                
                  '              NB : Joindre un '#233'tat d'#233'taill'#233' des fournisseurs con' +
                  'form'#233'ment '#224' l'#39'article 29 du C.TCA.')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell67: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              GapX = 8.000000000000000000
              HAlign = haRight
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell68: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell69: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight]
              HAlign = haCenter
              Memo.UTF8W = (
                'E 3B99')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell70: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'TVA '#224' payer au titre du mois (C-B)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell71: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftRight, ftBottom]
              Frame.BottomLine.Style = fsDot
              Frame.BottomLine.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."TVA_'#224'_payer"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow11: TfrxTableRow
            Height = 22.500000000000000000
            object TableCell72: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -8
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell73: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              HAlign = haRight
              Memo.UTF8W = (
                'Total des d'#233'ductions '#224' op'#233'rer (B)        '#1605#1580#1605#1608#1593' '#1575#1604#1581#1587#1608#1605#1575#1578' '#1575#1604#1605#1580#1585#1575#1577)
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell74: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'Total_des_d'#233'ductions'
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."Total_des_d'#233'ductions"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell75: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell76: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell77: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                'Pr'#233'compte '#224' reporter sur le mois suivant (B-C)')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell78: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBG50
              DataSetName = 'DBG50'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBG50."Pr'#233'compte_'#224'_reporter"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
      object GroupFooter1: TfrxGroupFooter
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 22.677180000000000000
        Top = 234.330860000000000000
        Width = 1084.725110000000000000
        object TableObject3: TfrxTableObject
          AllowVectorExport = True
          Restrictions = [rfDontModify, rfDontSize, rfDontEdit]
          object TableColumn17: TfrxTableColumn
            Width = 55.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn18: TfrxTableColumn
            Width = 360.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn19: TfrxTableColumn
            Width = 155.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn20: TfrxTableColumn
            Width = 155.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn21: TfrxTableColumn
            Width = 150.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn22: TfrxTableColumn
            Width = 30.000000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn23: TfrxTableColumn
            Width = 155.930000000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn24: TfrxTableColumn
            Width = 24.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow12: TfrxTableRow
            Height = 21.779527559055100000
            object TableCell79: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              Frame.Width = 0.500000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                #1575#1604#1600#1600#1600#1600#1605#1600#1600#1600#1600#1580#1600#1600#1600#1605#1600#1600#1600#1600#1608#1593' '#1575#1604#1593#1600#1600#1600#1600#1575#1605' '#1604#1600#1600#1600#1600#1585#1602#1600#1600#1600#1605' '#1575#1604#1571#1593#1600#1600#1600#1600#1600#1600#1605#1600#1600#1600#1600#1575#1604
                'TOTAL GENERAL DES CHIFFRES D'#39'AFFAIRES')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 2
            end
            object TableCell80: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'OP'#201'RATIONS'
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              Frame.Width = 0.500000000000000000
              Memo.UTF8W = (
                '[DBtva."OP'#201'RATIONS"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell81: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              Frame.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtva."CAG">,MasterData1)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell82: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              Frame.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtva."CAE">,MasterData1)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell83: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              Frame.Width = 0.500000000000000000
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtva."CAI">,MasterData1)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell84: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -9
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell85: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtva."DROITS">,MasterData1)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell86: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtva
              DataSetName = 'DBtva'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -7
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              ParentFont = False
            end
          end
        end
      end
      object GroupHeader1: TfrxGroupHeader
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Top = 170.078850000000000000
        Width = 1084.725110000000000000
        Condition = 'DBG50."Idg50"'
      end
    end
    object Page2: TfrxReportPage
      Orientation = poLandscape
      PaperWidth = 297.000000000000000000
      PaperHeight = 210.000000000000000000
      PaperSize = 9
      LeftMargin = 10.000000000000000000
      RightMargin = 10.000000000000000000
      TopMargin = 10.000000000000000000
      BottomMargin = 10.000000000000000000
      Frame.Typ = []
      MirrorMode = []
      object GroupHeader3: TfrxGroupHeader
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 37.795300000000000000
        Top = 18.897650000000000000
        Width = 1046.929810000000000000
        Condition = 'DBG50."idg50"'
        object TableObject11: TfrxTableObject
          AllowVectorExport = True
          object TableColumn56: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn57: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn58: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn59: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn60: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn61: TfrxTableColumn
            Width = 166.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow33: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell265: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Acompte / Solde de liquidation')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 6
            end
            object TableCell266: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 5
            end
            object TableCell267: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell268: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell269: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell276: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
          end
          object TableRow34: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell277: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Code')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell278: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Acompte /solde de liquidation ')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell279: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'D'#233'termination de l'#8217'acompte provisionnel/ solde de liquidation')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 3
            end
            object TableCell280: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Chiffre d'#39'affaires Imposable')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell281: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Taux')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell282: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlue
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                'Montant '#224' payer ')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
        object TableObject13: TfrxTableObject
          AllowVectorExport = True
          Top = 7.559059999999990000
          object TableColumn70: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn71: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn72: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn73: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn74: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn75: TfrxTableColumn
            Width = 166.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow35: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell283: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'CODE'
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBtap."CODE"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell284: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'IMPOTS'
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              GapX = 5.000000000000000000
              Memo.UTF8W = (
                '[DBtap."IMPOTS"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell285: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtap."CAbrut"]')
              ParentFont = False
              VAlign = vaCenter
              ColSpan = 3
            end
            object TableCell286: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtap."Caimposable"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell287: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'tauxtap'
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              HAlign = haCenter
              Memo.UTF8W = (
                '[DBtap."tauxtap"]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell288: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataField = 'Droits'
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Style = fsDot
              Frame.Typ = [ftLeft, ftRight, ftBottom]
              Frame.LeftLine.Style = fsSolid
              Frame.RightLine.Style = fsSolid
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[DBtap."Droits"]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
        object TableObject16: TfrxTableObject
          AllowVectorExport = True
          object TableColumn76: TfrxTableColumn
            Width = 52.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn83: TfrxTableColumn
            Width = 416.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn84: TfrxTableColumn
            Width = 201.590600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn85: TfrxTableColumn
            Width = 186.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn86: TfrxTableColumn
            Width = 50.090600000000000000
            MaxWidth = 75.590600000000000000
          end
          object TableColumn87: TfrxTableColumn
            Width = 166.257266666667000000
            MaxWidth = 75.590600000000000000
          end
          object TableRow36: TfrxTableRow
            Height = 18.897650000000000000
            object TableCell289: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -15
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              Memo.UTF8W = (
                '1')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell290: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 5.000000000000000000
              HAlign = haCenter
              Memo.UTF8W = (
                'Total')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell291: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtap."CAbrut">,MasterData3)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell292: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtap."Caimposable">,MasterData3)]')
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell293: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -11
              Font.Name = 'Arial'
              Font.Style = []
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              HAlign = haCenter
              ParentFont = False
              VAlign = vaCenter
            end
            object TableCell294: TfrxTableCell
              AllowVectorExport = True
              Restrictions = [rfDontDelete]
              DataSet = DBtap
              DataSetName = 'DBtap'
              DisplayFormat.FormatStr = '%2.0n'
              DisplayFormat.Kind = fkNumeric
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBlack
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Frame.Color = clBlue
              Frame.Typ = [ftLeft, ftRight, ftTop, ftBottom]
              GapX = 8.000000000000000000
              HAlign = haRight
              Memo.UTF8W = (
                '[SUM(<DBtap."Droits">,MasterData3)]')
              ParentFont = False
              VAlign = vaCenter
            end
          end
        end
      end
      object MasterData4: TfrxMasterData
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 26.456710000000000000
        Top = 79.370130000000000000
        Width = 1046.929810000000000000
        RowCount = 0
      end
      object GroupFooter3: TfrxGroupFooter
        FillType = ftBrush
        FillGap.Top = 0
        FillGap.Left = 0
        FillGap.Bottom = 0
        FillGap.Right = 0
        Frame.Typ = []
        Height = 18.897650000000000000
        Top = 128.504020000000000000
        Width = 1046.929810000000000000
      end
    end
  end
  object DBtva: TfrxDBDataset
    UserName = 'DBtva'
    CloseDataSource = False
    FieldAliases.Strings = (
      'CODE=CODE'
      'OP'#201'RATIONS=OP'#201'RATIONS'
      'CAG=CAG'
      'CAI=CAI'
      'CAE=CAE'
      'TAUX=TAUX'
      'DROITS=DROITS'
      'Idg50=Idg50'
      'nature=nature')
    DataSet = VirtualQuery1
    BCDToCurrency = False
    Left = 760
    Top = 256
  end
  object DBG50: TfrxDBDataset
    RangeBegin = rbCurrent
    RangeEnd = reCurrent
    UserName = 'DBG50'
    CloseDataSource = False
    DataSet = Form20.TG50
    BCDToCurrency = False
    Left = 360
    Top = 64
  end
  object QTap: TUniQuery
    Connection = DM.UniConnection
    SQL.Strings = (
      
        'SELECT TAP.Idg50, TAP.code, TAP.CAbrut, TAP.CAexo, TAP.Caimposab' +
        'le, TAP.tauxtap, TAP.Droits'
      'FROM TAP;')
    Active = True
    Left = 544
    Top = 216
    object QTapIdg50: TIntegerField
      FieldName = 'Idg50'
    end
    object QTapcode: TWideStringField
      FieldName = 'code'
      Size = 255
    end
    object QTapCAbrut: TFloatField
      FieldName = 'CAbrut'
    end
    object QTapCAexo: TFloatField
      FieldName = 'CAexo'
    end
    object QTapCaimposable: TFloatField
      FieldName = 'Caimposable'
    end
    object QTaptauxtap: TFloatField
      FieldName = 'tauxtap'
    end
    object QTapDroits: TFloatField
      FieldName = 'Droits'
    end
  end
  object QReftap: TUniQuery
    Connection = DM.UniCRef
    SQL.Strings = (
      'SELECT TAPRef.N, TAPRef.CODE, TAPRef.IMPOTS'
      'FROM TAPRef'
      'ORDER BY TAPRef.N;')
    Active = True
    Left = 472
    Top = 200
    object QReftapN: TFloatField
      FieldName = 'N'
    end
    object QReftapCODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object QReftapIMPOTS: TWideStringField
      FieldName = 'IMPOTS'
      Size = 255
    end
  end
  object VTap: TVirtualQuery
    SourceDataSets = <
      item
        DataSet = QReftap
      end
      item
        DataSet = QTap
      end>
    SQL.Strings = (
      'SELECT '
      '    qReftap.CODE, '
      '    qReftap.n, '
      '    qReftap.IMPOTS, '
      '    qTap.Idg50,'
      '    qTap.CAbrut, '
      '    qTap.CAexo, '
      '    qTap.Caimposable, '
      '    qTap.tauxtap, '
      '    qTap.Droits'
      'FROM '
      '    qReftap '
      'LEFT JOIN '
      '    qTap ON qReftap.IMPOTS = qTap.impots')
    Left = 504
    Top = 160
    object VTapCODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object VTapN: TFloatField
      FieldName = 'N'
    end
    object VTapIMPOTS: TWideStringField
      FieldName = 'IMPOTS'
      Size = 255
    end
    object VTapIdg50: TIntegerField
      FieldName = 'Idg50'
      ReadOnly = True
    end
    object VTapCAbrut: TFloatField
      FieldName = 'CAbrut'
      ReadOnly = True
    end
    object VTapCAexo: TFloatField
      FieldName = 'CAexo'
      ReadOnly = True
    end
    object VTapCaimposable: TFloatField
      FieldName = 'Caimposable'
      ReadOnly = True
    end
    object VTaptauxtap: TFloatField
      FieldName = 'tauxtap'
      ReadOnly = True
    end
    object VTapDroits: TFloatField
      FieldName = 'Droits'
      ReadOnly = True
    end
  end
  object DBtap: TfrxDBDataset
    UserName = 'DBtap'
    CloseDataSource = False
    FieldAliases.Strings = (
      'CODE=CODE'
      'N=N'
      'IMPOTS=IMPOTS'
      'Idg50=Idg50'
      'CAbrut=CAbrut'
      'CAexo=CAexo'
      'Caimposable=Caimposable'
      'tauxtap=tauxtap'
      'Droits=Droits')
    DataSet = VTap
    BCDToCurrency = False
    Left = 488
    Top = 304
  end
  object VSalaires: TVirtualQuery
    Active = True
    SourceDataSets = <
      item
        DataSet = QSalairesRef
      end
      item
        DataSet = Qsalaires
      end>
    SQL.Strings = (
      'SELECT '
      '    QSalairesRef.CODE, '
      '    QSalairesRef.n, '
      '    QSalairesRef.IMPOTS, '
      '    Qsalaires.Idg50,'
      '    Qsalaires.Revenusimposables,'
      '    Qsalaires.taux,'
      '    Qsalaires.droits'
      'FROM '
      '    QSalairesRef'
      'LEFT JOIN '
      '    Qsalaires ON QSalairesRef.CODE = Qsalaires.Code'
      ''
      '')
    Left = 360
    Top = 160
    object VSalairesCODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object VSalairesN: TIntegerField
      FieldName = 'N'
    end
    object VSalairesIMPOTS: TWideMemoField
      FieldName = 'IMPOTS'
      BlobType = ftWideMemo
    end
    object VSalairesIdg50: TIntegerField
      FieldName = 'Idg50'
      ReadOnly = True
    end
    object VSalairesRevenusimposables: TFloatField
      FieldName = 'Revenusimposables'
      ReadOnly = True
    end
    object VSalairestaux: TWideStringField
      FieldName = 'taux'
      ReadOnly = True
      Size = 50
    end
    object VSalairesdroits: TFloatField
      FieldName = 'droits'
      ReadOnly = True
    end
  end
  object QSalairesRef: TUniQuery
    Connection = DM.UniCRef
    SQL.Strings = (
      
        'SELECT IRGIBSRef.N, IRGIBSRef.CODE, IRGIBSRef.IMPOTS, IRGIBSRef.' +
        'TAUX'
      'FROM IRGIBSRef'
      'ORDER BY IRGIBSRef.N, IRGIBSRef.CODE;')
    Active = True
    Left = 328
    Top = 216
    object QSalairesRefN: TIntegerField
      FieldName = 'N'
    end
    object QSalairesRefCODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object QSalairesRefIMPOTS: TWideMemoField
      FieldName = 'IMPOTS'
      BlobType = ftWideMemo
    end
    object QSalairesRefTAUX: TWideStringField
      FieldName = 'TAUX'
      Size = 50
    end
  end
  object Qsalaires: TUniQuery
    Connection = DM.UniConnection
    SQL.Strings = (
      
        'SELECT IRGSalaires.Idg50, IRGSalaires.impots, IRGSalaires.code, ' +
        'IRGSalaires.Revenusimposables, IRGSalaires.taux, IRGSalaires.dro' +
        'its'
      'FROM IRGSalaires;')
    Active = True
    Left = 400
    Top = 216
    object QsalairesIdg50: TIntegerField
      FieldName = 'Idg50'
    end
    object Qsalairesimpots: TWideMemoField
      FieldName = 'impots'
      BlobType = ftWideMemo
    end
    object Qsalairescode: TWideStringField
      FieldName = 'code'
      Size = 255
    end
    object QsalairesRevenusimposables: TFloatField
      FieldName = 'Revenusimposables'
    end
    object Qsalairestaux: TWideStringField
      FieldName = 'taux'
      Size = 50
    end
    object Qsalairesdroits: TFloatField
      FieldName = 'droits'
    end
  end
  object DBsalaires: TfrxDBDataset
    UserName = 'DBsalaires'
    CloseDataSource = False
    FieldAliases.Strings = (
      'CODE=CODE'
      'N=N'
      'IMPOTS=IMPOTS'
      'Idg50=Idg50'
      'Revenusimposables=Revenusimposables'
      'taux=taux'
      'droits=Droits')
    DataSet = VSalaires
    BCDToCurrency = False
    Left = 360
    Top = 296
  end
end
