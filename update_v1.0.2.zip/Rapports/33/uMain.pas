﻿unit uMain;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,Winapi.ShellAPI, System.IOUtils,
  System.Classes, Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs,
  Vcl.Menus, Vcl.ComCtrls, Vcl.ExtCtrls, Vcl.StdCtrls, Data.DB, MemDS, DBAccess,
  Uni, Vcl.Mask, Vcl.DBCtrls, Vcl.WinXPanels, scControls, scGPExtControls,
  scGPDBControls, scGPControls, RzTabs, DBGridEhGrouping, ToolCtrlsEh,
  DBGridEhToolCtrls, DynVarsEh, sPanel, AdvGlowButton, Vcl.Grids, Vcl.DBGrids,
  scDBControls, EhLibVCL, GridsEh, DBAxisGridsEh, DBGridEh,System.DateUtils,
  RzButton, Vcl.Buttons, AdvMetroPanel, GDIPCustomItem, GDIPTextItem,
  GDIPImageTextItem, GDIPGraphicItem, GDIPCheckItem, CustomItemsContainer,uOpenSociete,
  AdvVerticalPolyList, AdvSmoothLabel, AdvSmoothTabPager, scAdvancedPager,frxClass,
  frxPreview, frxExportBaseDialog, frxExportXLSX, frxExportXLS, frxExportPDF,
  scExtControls, scToolPager, Vcl.WinXCtrls, Winapi.ActiveX, System.Generics.Collections, System.Math,
  scGPPagers, scModernControls, AdvSmoothGauge, AdvGaugeCircle;

type
  TfrmMain = class(TForm)
    MainMenu1: TMainMenu;
    mnuFichier: TMenuItem;
    mnuNouveau: TMenuItem;
    mnuOuvrir: TMenuItem;
    mnuSep1: TMenuItem;
    mnuSociete: TMenuItem;
    mnuSep2: TMenuItem;
    mnuQuitter: TMenuItem;
    StatusBar1: TStatusBar;
    mnuBatchGen: TMenuItem;
    cp: TCardPanel;
    Card1: TCard;
    pnlMain: TPanel;
    lblWelcome: TLabel;
    lblInfo: TLabel;
    Card2: TCard;
    scPanel1: TscPanel;
    SauvgareretRestaurer1: TMenuItem;
    DExercices: TUniDataSource;
    TExercices: TUniTable;
    TG50: TUniTable;
    TG50IDNewG50: TWideStringField;
    TG50IDclients: TIntegerField;
    TG50rs: TWideStringField;
    TG50Mois: TFloatField;
    TG50st1: TFloatField;
    TG50st2: TFloatField;
    TG50st31: TFloatField;
    TG50st4: TFloatField;
    TG50st5: TFloatField;
    TG50st32: TFloatField;
    TG50totalgeneral: TFloatField;
    TG50IDDEC: TWideStringField;
    TG50idg50: TIntegerField;
    TG50ma: TWideStringField;
    TG50leMois: TWideStringField;
    TG50lieuced: TWideStringField;
    TG50DAtedEC: TDateTimeField;
    TG50st33: TFloatField;
    TG50tvastsG: TFloatField;
    TG50tvastsI: TFloatField;
    TG50st6: TFloatField;
    TG50tvastse: TFloatField;
    TG50tvastsd: TFloatField;
    TG50moisg50: TWideStringField;
    TG50moisg50anteriur: TWideStringField;
    TG50anneeclient: TWideStringField;
    TG50TTVAachatMatieres: TFloatField;
    TG50TVAbiensamortissables: TFloatField;
    TG50Totaldroits_dus: TFloatField;
    TG50TOTALaRAPPELER: TFloatField;
    TG50E3B96: TFloatField;
    TG50moisg50anteriuriDclient: TWideStringField;
    TG50moisg50iDclient: TWideStringField;
    TG50PRA: TFloatField;
    TG50NatureRC: TWideStringField;
    TG50VPDF: TBlobField;
    DG50: TUniDataSource;
    QUnionG50: TUniQuery;
    DunionG50: TUniDataSource;
    QUnionG50IDg50: TIntegerField;
    QUnionG50CODE: TWideStringField;
    QUnionG50Caimposable: TFloatField;
    QUnionG50TAUXTAP: TWideStringField;
    QUnionG50Droits: TFloatField;
    UniQuery1: TUniQuery;
    QUnionG50Nt: TWideStringField;
    T1: TMenuItem;
    Pg1: TscAdvancedPager;
    scAdvancedPagerPage2: TscAdvancedPagerPage;
    scAdvancedPagerPage3: TscAdvancedPagerPage;
    scAdvancedPagerPage1: TscAdvancedPagerPage;
    DBGrid6: TDBGrid;
    Panel2: TPanel;
    scGPLabel5: TscGPLabel;
    QUnionG50Nat: TStringField;
    QUnionG50impots: TWideMemoField;
    Panel4: TPanel;
    Panel3: TPanel;
    MA: TLabel;
    MoisG50: TscGPDBEdit;
    Panel6: TPanel;
    Shape1: TShape;
    Label4: TLabel;
    Label6: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    Label5: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label8: TLabel;
    Label18: TLabel;
    Label19: TLabel;
    Label20: TLabel;
    E3B90: TscGPDBEdit;
    E3B91: TscGPDBEdit;
    E3B92: TscGPDBEdit;
    E3B93: TscGPDBEdit;
    E3B94: TscGPDBEdit;
    E3B97: TscGPDBEdit;
    E3B99: TscGPDBEdit;
    Panel7: TPanel;
    E3B110: TscGPDBEdit;
    Panel8: TPanel;
    E3B100: TscGPDBEdit;
    E3B95: TscGPDBEdit;
    Panel12: TPanel;
    E3B96: TscGPDBEdit;
    E3B120: TscGPDBEdit;
    E3B130: TscGPDBEdit;
    DBGridEh4: TDBGridEh;
    AdvGlowButton1: TAdvGlowButton;
    scAdvancedPagerPage4: TscAdvancedPagerPage;
    frxPreview1: TfrxPreview;
    Panel5: TPanel;
    AdvGlowButton2: TAdvGlowButton;
    AdvGlowButton4: TAdvGlowButton;
    DBma: TDBEdit;
    frxXLSXExport1: TfrxXLSXExport;
    SpeedButton3: TSpeedButton;
    SpeedButton4: TSpeedButton;
    SpeedButton5: TSpeedButton;
    SpeedButton6: TSpeedButton;
    scAdvancedPagerPage5: TscAdvancedPagerPage;
    scAdvancedPagerPage6: TscAdvancedPagerPage;
    SpeedButton8: TSpeedButton;
    SpeedButton9: TSpeedButton;
    SpeedButton12: TSpeedButton;
    SpeedButton13: TSpeedButton;
    ProgressBar1: TProgressBar;
    SpeedButton14: TSpeedButton;
    SpeedButton15: TSpeedButton;
    Panel10: TPanel;
    scGPGroupBox1: TscGPGroupBox;
    scGPLabel9: TscGPLabel;
    RS: TscGPDBEdit;
    scGPLabel1: TscGPLabel;
    scGPDBEdit8: TscGPDBEdit;
    scGPLabel10: TscGPLabel;
    Act: TscGPDBEdit;
    scGPLabel12: TscGPLabel;
    Adr: TscGPDBEdit;
    Edit1: TEdit;
    SpeedButton16: TSpeedButton;
    scAdvancedPagerPage7: TscAdvancedPagerPage;
    frxPDFExport1: TfrxPDFExport;
    Panel11: TPanel;
    Panel13: TPanel;
    SpeedButton23: TSpeedButton;
    scGPLabel22: TscGPLabel;
    Panel14: TPanel;
    SpeedButton17: TSpeedButton;
    SpeedButton18: TSpeedButton;
    SpeedButton19: TSpeedButton;
    scGPLabel3: TscGPLabel;
    DBGridEh1: TDBGridEh;
    Panel15: TPanel;
    ExIBS: TscDBEdit;
    DBacompte: TDBEdit;
    bibs: TButton;
    Panel16: TPanel;
    Panel17: TPanel;
    ExIrg: TscDBEdit;
    Panel18: TPanel;
    SpeedButton20: TSpeedButton;
    SpeedButton21: TSpeedButton;
    SpeedButton22: TSpeedButton;
    scGPLabel6: TscGPLabel;
    DBGridEh2: TDBGridEh;
    DBacompte1: TDBEdit;
    Panel19: TPanel;
    SpeedButton26: TSpeedButton;
    SpeedButton27: TSpeedButton;
    SpeedButton28: TSpeedButton;
    scGPLabel7: TscGPLabel;
    Button1: TButton;
    DBGridEh5: TDBGridEh;
    DBGridEh6: TDBGridEh;
    DBGridEh3: TDBGridEh;
    SpeedButton29: TSpeedButton;
    SpeedButton25: TSpeedButton;
    SpeedButton24: TSpeedButton;
    SpeedButton30: TSpeedButton;
    Panel22: TPanel;
    Panel23: TPanel;
    scDBEdit1: TscDBEdit;
    SpeedButton32: TSpeedButton;
    SpeedButton33: TSpeedButton;
    SpeedButton34: TSpeedButton;
    DBGridEh7: TDBGridEh;
    SpeedButton31: TSpeedButton;
    Panel20: TPanel;
    Panel21: TPanel;
    Panel24: TPanel;
    scPanel4: TscPanel;
    scGPLabel15: TscGPLabel;
    Panel25: TPanel;
    Shape2: TShape;
    scGPLabel23: TscGPLabel;
    scGPLabel24: TscGPLabel;
    F1: TscGPDBEdit;
    scGPLabel25: TscGPLabel;
    F2: TscGPDBEdit;
    scGPLabel26: TscGPLabel;
    F3: TscGPDBEdit;
    scGPLabel27: TscGPLabel;
    F4: TscGPDBEdit;
    scGPLabel28: TscGPLabel;
    F5: TscGPDBEdit;
    scGPLabel29: TscGPLabel;
    scGPDBEdit1: TscGPDBEdit;
    scGPLabel11: TscGPLabel;
    scGPLabel13: TscGPLabel;
    SpeedButton35: TSpeedButton;
    SpeedButton36: TSpeedButton;
    SpeedButton37: TSpeedButton;
    DBText1: TDBText;
    Panel26: TPanel;
    Panel27: TPanel;
    Panel28: TPanel;
    scAdvancedPagerPage8: TscAdvancedPagerPage;
    Panel32: TPanel;
    SpeedButton55: TSpeedButton;
    SpeedButton51: TSpeedButton;
    Panel31: TPanel;
    SpeedButton54: TSpeedButton;
    SpeedButton56: TSpeedButton;
    SpeedButton401: TSpeedButton;
    SpeedButton38: TSpeedButton;
    SearchBox2: TSearchBox;
    boxProj: TscDBLookupComboBox;
    SpeedButton40: TSpeedButton;
    scGPCheckBox1: TscGPCheckBox;
    N1: TMenuItem;
    G501: TMenuItem;
    N2: TMenuItem;
    S1: TMenuItem;
    Panel33: TPanel;
    SpeedButton41: TSpeedButton;
    SpeedButton44: TSpeedButton;
    SpeedButton52: TSpeedButton;
    SpeedButton47: TSpeedButton;
    Card3: TCard;
    T2: TMenuItem;
    Label1: TLabel;
    Label2: TLabel;
    ableaudeBord1: TMenuItem;
    pnlDashMain: TPanel;
    pnlChartsRow: TPanel;
    TimerDash: TTimer;
    D1: TMenuItem;
    O1: TMenuItem;
    N3: TMenuItem;
    P1: TMenuItem;
    SpeedButton39: TSpeedButton;
    scGPDBEdit2: TscGPDBEdit;
    Panel37: TPanel;
    dbann1: TscDBEdit;
    SpeedButton11: TSpeedButton;
    scGPLabel18: TscGPLabel;
    scGPLabel2: TscGPLabel;
    scGPLabel4: TscGPLabel;
    scGPLabel20: TscGPLabel;
    scGPLabel21: TscGPLabel;
    scGPLabel8: TscGPLabel;
    BtnOpen: TButton;
    Panel1: TPanel;
    scGPLabel17: TscGPLabel;
    SpeedButton1: TSpeedButton;
    scGPLabel16: TscGPLabel;
    scAdvancedPagerPage9: TscAdvancedPagerPage;
    dbann: TscDBText;
    T3: TMenuItem;
    pnlCardsRow: TscGridPanel;
    scGridPanel1: TscGridPanel;
    AdvMetroPanel1: TAdvMetroPanel;
    Shape3: TShape;
    scGPLabel14: TscGPLabel;
    scGPLabel19: TscGPLabel;
    AdvMetroPanel2: TAdvMetroPanel;
    Shape4: TShape;
    scGPLabel30: TscGPLabel;
    AdvMetroPanel3: TAdvMetroPanel;
    Shape5: TShape;
    scGPLabel32: TscGPLabel;
    AdvMetroPanel4: TAdvMetroPanel;
    Shape6: TShape;
    scGPLabel34: TscGPLabel;
    Panel9: TPanel;
    pnlAlertCard: TAdvMetroPanel;
    shpAlert: TShape;
    lblAlertDays: TscGPLabel;
    lblAlertClock: TscGPLabel;
    pbAlert: TProgressBar;
    AdvMetroPanel5: TAdvMetroPanel;
    Shape7: TShape;
    lblIBSAlertDays: TscGPLabel;
    lblIBSAlertClock: TscGPLabel;
    pbIBSAlert: TProgressBar;
    AdvMetroPanel6: TAdvMetroPanel;
    Shape8: TShape;
    lblIRGAlertDays: TscGPLabel;
    lblIRGAlertClock: TscGPLabel;
    pbIRGAlert: TProgressBar;
    SpeedButton2: TSpeedButton;
    pbGaugeG50: TAdvGaugeCircle;
    pbGaugeIBS: TAdvGaugeCircle;
    pbGaugeIRG: TAdvGaugeCircle;
    pbGaugeTAPP: TAdvGaugeCircle;
    scGPLabel31: TscGPLabel;
    scGPLabel33: TscGPLabel;
    scGPLabel35: TscGPLabel;
    SpeedButton7: TSpeedButton;
    Bg50: TAdvGlowButton;
    procedure ChargerStatistiques;
    procedure FormCreate(Sender: TObject);
    procedure mnuNouveauClick(Sender: TObject);
    procedure mnuOuvrirClick(Sender: TObject);
    procedure mnuSocieteClick(Sender: TObject);
    procedure mnuImportHFSQLClick(Sender: TObject);
    procedure mnuBatchGenClick(Sender: TObject);
    procedure mnuQuitterClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure SauvgareretRestaurer1Click(Sender: TObject);
    procedure AdvSmoothTabPager11Show(Sender: TObject);
    procedure BtnOpenClick(Sender: TObject);
    procedure SpeedButton11Click(Sender: TObject);
    procedure DBGrid6CellClick(Column: TColumn);
    procedure AdvGlowButton29Click(Sender: TObject);
    procedure T1Click(Sender: TObject);
    procedure SpeedButton39Click(Sender: TObject);
    procedure AdvGlowButton1Click(Sender: TObject);
    procedure SpeedButton10Click(Sender: TObject);
    procedure AdvGlowButton2Click(Sender: TObject);
    procedure Bg50Click(Sender: TObject);
    procedure AdvGlowButton4Click(Sender: TObject);
    procedure AdvGlowButton5Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);
    procedure SpeedButton5Click(Sender: TObject);
    procedure PG50Click(Sender: TObject);
    procedure SpeedButton8Click(Sender: TObject);
    procedure SpeedButton13Click(Sender: TObject);
    procedure SpeedButton14Click(Sender: TObject);
    procedure SpeedButton15Click(Sender: TObject);
    procedure SpeedButton16Click(Sender: TObject);
    procedure SpeedButton17Click(Sender: TObject);
    procedure SpeedButton18Click(Sender: TObject);
    procedure SpeedButton23Click(Sender: TObject);
    procedure SpeedButton19Click(Sender: TObject);
    procedure SpeedButton25Click(Sender: TObject);
    procedure scAdvancedPager1ChangePage(Sender: TObject);
    procedure SpeedButton24Click(Sender: TObject);
    procedure SpeedButton20Click(Sender: TObject);
    procedure SpeedButton21Click(Sender: TObject);
    procedure SpeedButton22Click(Sender: TObject);
    procedure SpeedButton26Click(Sender: TObject);
    procedure SpeedButton27Click(Sender: TObject);
    procedure SpeedButton28Click(Sender: TObject);
    procedure SpeedButton29Click(Sender: TObject);
    procedure SpeedButton30Click(Sender: TObject);
    procedure SpeedButton32Click(Sender: TObject);
    procedure SpeedButton31Click(Sender: TObject);
    procedure SpeedButton34Click(Sender: TObject);
    procedure SpeedButton33Click(Sender: TObject);
    procedure SpeedButton37Click(Sender: TObject);
    procedure SpeedButton36Click(Sender: TObject);
    procedure SpeedButton35Click(Sender: TObject);
    procedure SpeedButton381Click(Sender: TObject);
    procedure SpeedButton401Click(Sender: TObject);
    procedure SpeedButton51Click(Sender: TObject);
    procedure SearchBox2Change(Sender: TObject);
    procedure boxProjCloseUp(Sender: TObject);
    procedure scGPCheckBox1Click(Sender: TObject);
    procedure SpeedButton40Click(Sender: TObject);
    procedure SpeedButton56Click(Sender: TObject);
    procedure SpeedButton54Click(Sender: TObject);
    procedure mnuMissingG50Click(Sender: TObject);
    procedure G501Click(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure S1Click(Sender: TObject);
    procedure SpeedButton41Click(Sender: TObject);
    procedure SpeedButton44Click(Sender: TObject);
    procedure SpeedButton47Click(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure T2Click(Sender: TObject);
    procedure TimerDashTimer(Sender: TObject);
    procedure N3Click(Sender: TObject);
    procedure O1Click(Sender: TObject);
    procedure P1Click(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure T3Click(Sender: TObject);
    procedure SpeedButton52Click(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton7Click(Sender: TObject);
  private
    FCompanyConnected: Boolean;
    FStatsLoaded: Boolean;
    FAllCompanies: TList<uOpenSociete.TCompanyInfo>;
    // Dashboard visual enhancement fields
    FPerc: array[0..3] of Integer;
    FDashSetup: Boolean;
    AdvGauges: array[0..3] of TAdvGaugeCircle;
    FStatLabels: array[0..3, 0..2] of TLabel;
    FStatValues: array[0..3, 0..2] of TLabel;
    lblJoursText, lblIBSJoursText, lblIRGJoursText: TLabel;
    lblHeaderTime, lblHeaderDate: TLabel;
    procedure UpdateUI;
    procedure LoadAllCompanyInfo;
    procedure DashUpdateStats(const Category, Period: string; Fait, Total: Integer);
    procedure SetupDashboardCards;
  public
  end;

var
  frmMain: TfrmMain;

implementation

{$R *.dfm}

uses
  uDataModule, uNewSociete,  uSocieteEdit, uImportHFSQL, uBatchGen,
  Unit1, Unit22, Unit13,unit20,unit23, Unit15, Unit2, UnitThemes, Unit3, Unit5,
  Unit6, Unit7, Unit27, Unit45, Unit8, Unit9, Unit11, Unit12, Unit14, Unit16,
  Unit17, Unit18, Unit19, uMissingG50, UmmingTAPP, UmissingIBS, UmissingIRG,
  Unit21, Unit28, AccessUniProvider, Unit10, Unit29, Unit30, Unit33;

procedure TfrmMain.LoadAllCompanyInfo;
var
  AppPath, Line: string;
  Info: uOpenSociete.TCompanyInfo;
  Files: TStringList;
  Parts: TArray<string>;
begin
  if not Assigned(FAllCompanies) then
    FAllCompanies := TList<uOpenSociete.TCompanyInfo>.Create;

  FAllCompanies.Clear;
  AppPath := ExtractFilePath(ParamStr(0));

  if FileExists(AppPath + 'companies.dat') then
  begin
    Files := TStringList.Create;
    try
      Files.LoadFromFile(AppPath + 'companies.dat', TEncoding.UTF8);
      for Line in Files do
      begin
        Parts := Line.Split(['|']);
        if Length(Parts) >= 3 then
        begin
          Info.FolderName := Parts[0];
          Info.RS := Parts[1];
          Info.NIF := Parts[2];
          Info.DbPath := AppPath + 'Dossiers\' + Info.FolderName + '\G50.mdb';
          if FileExists(Info.DbPath) then
            FAllCompanies.Add(Info);
        end;
      end;
    finally
      Files.Free;
    end;
  end;
end;



procedure TfrmMain.ChargerStatistiques;
var
  V_Year, V_Month: string;
  G50Month: Integer;
  G50Year: string;
begin
  V_Year := FormatDateTime('yyyy', Now);
  V_Month := IntToStr(MonthOf(Now));

  // G50: الشهر المعني هو الشهر السابق
  G50Month := MonthOf(Now) - 1;
  G50Year := V_Year;
  if G50Month = 0 then
  begin
    G50Month := 12;
    G50Year := IntToStr(YearOf(Now) - 1);
  end;

  pnlAlertCard.Caption := '  Analyse des dossiers en cours...';

  TThread.CreateAnonymousThread(
    procedure
    var
      fG50, tG50, fIBS, tIBS, fIRG, tIRG, fTAPP, tTAPP: Integer;
      AppPath, DBPath, PrevYear, SemesterText: string;
      MonthVal: Double;
      CacheList: TStringList;
      Parts: TArray<string>;
      i, CurrentMonth: Integer;
      TempConn: TUniConnection;
      TempQuery: TUniQuery;
      FJ_Value: string;
    begin
      CurrentMonth := MonthOf(Now);
      MonthVal := G50Month;
      PrevYear := IntToStr(StrToIntDef(V_Year, 2026) - 1);

      if CurrentMonth <= 6 then
        SemesterText := '1er Semestre'
      else
        SemesterText := '2'#233'me Semestre';

      fG50 := 0; tG50 := 0;
      fIBS := 0; tIBS := 0;
      fIRG := 0; tIRG := 0;
      fTAPP := 0; tTAPP := 0;

      AppPath := IncludeTrailingPathDelimiter(ExtractFilePath(Application.ExeName));

      CacheList := TStringList.Create;
      try
        if not FileExists(AppPath + 'companies.dat') then
        begin
          TThread.Synchronize(nil,
            procedure begin
              pnlAlertCard.Caption := '  Fichier companies.dat introuvable.';
            end);
          Exit;
        end;

        CacheList.LoadFromFile(AppPath + 'companies.dat', TEncoding.UTF8);

        if CacheList.Count = 0 then
        begin
          TThread.Synchronize(nil, procedure begin pnlAlertCard.Caption := '  Aucune soci'#233't'#233' trouv'#233'e.'; end);
          Exit;
        end;

        for i := 0 to CacheList.Count - 1 do
        begin
          if Application.Terminated then Break;

          Parts := CacheList[i].Split(['|']);
          if Length(Parts) < 1 then Continue;

          DBPath := AppPath + 'Dossiers\' + Parts[0] + '\G50.mdb';
          if not FileExists(DBPath) then Continue;

          TempConn := TUniConnection.Create(nil);
          try
            TempConn.ProviderName := 'Access';
            TempConn.Database := DBPath;
            TempConn.LoginPrompt := False;

            try
              TempConn.Connect;

              // ====== 1. G50 ======
              Inc(tG50);
              TempQuery := TUniQuery.Create(nil);
              try
                TempQuery.Connection := TempConn;
                TempQuery.SQL.Text := 'SELECT COUNT(*) FROM G50 WHERE Mois = :M AND Ann'#233'e = :Y';
                TempQuery.ParamByName('M').AsFloat := MonthVal;
                TempQuery.ParamByName('Y').AsString := G50Year;
                TempQuery.Open;
                if TempQuery.Fields[0].AsInteger > 0 then
                  Inc(fG50);
              finally
                TempQuery.Free;
              end;

              // ====== 2. IBS ======
              TempQuery := TUniQuery.Create(nil);
              try
                TempQuery.Connection := TempConn;
                TempQuery.SQL.Text := 'SELECT FJ FROM clients';
                TempQuery.Open;
                if not TempQuery.Eof then
                begin
                  FJ_Value := UpperCase(Trim(TempQuery.FieldByName('FJ').AsString));
                  if (FJ_Value = 'SARL') or (FJ_Value = 'EURL') or (FJ_Value = 'SPA') then
                  begin
                    Inc(tIBS);
                    TempQuery.Close;
                    TempQuery.SQL.Text := 'SELECT Exercice FROM IBSsolde';
                    TempQuery.Open;
                    while not TempQuery.Eof do
                    begin
                      if Trim(TempQuery.FieldByName('Exercice').AsString) = Trim(PrevYear) then
                      begin
                        Inc(fIBS);
                        Break;
                      end;
                      TempQuery.Next;
                    end;
                  end;
                end;
              finally
                TempQuery.Free;
              end;

              // ====== 3. IRG ======
              TempQuery := TUniQuery.Create(nil);
              try
                TempQuery.Connection := TempConn;
                TempQuery.SQL.Text := 'SELECT FJ FROM clients';
                TempQuery.Open;
                if not TempQuery.Eof then
                begin
                  FJ_Value := UpperCase(Trim(TempQuery.FieldByName('FJ').AsString));
                  if (Pos('PERSONNE', FJ_Value) > 0) and (Pos('PHYSIQU', FJ_Value) > 0) then
                  begin
                    Inc(tIRG);
                    TempQuery.Close;
                    TempQuery.SQL.Text := 'SELECT exercice FROM IRGsolde';
                    TempQuery.Open;
                    while not TempQuery.Eof do
                    begin
                      if Trim(TempQuery.FieldByName('exercice').AsString) = Trim(PrevYear) then
                      begin
                        Inc(fIRG);
                        Break;
                      end;
                      TempQuery.Next;
                    end;
                  end;
                end;
              finally
                TempQuery.Free;
              end;

              // ====== 4. TAPP ======
              Inc(tTAPP);
              TempQuery := TUniQuery.Create(nil);
              try
                TempQuery.Connection := TempConn;
                TempQuery.SQL.Text := 'SELECT COUNT(*) FROM DeclarationTAPP WHERE Exercice = :E AND ClientExercice = :S';
                TempQuery.ParamByName('E').AsString := V_Year;
                TempQuery.ParamByName('S').AsString := SemesterText;
                TempQuery.Open;
                if TempQuery.Fields[0].AsInteger > 0 then
                  Inc(fTAPP);
              finally
                TempQuery.Free;
              end;

            except
            end;
          finally
            TempConn.Free;
          end;

          TThread.Synchronize(nil,
            procedure begin
              if not Application.Terminated then
              begin
                  pnlAlertCard.Caption := '  Traitement: ' + Parts[0];

                DashUpdateStats('G50',  'Mois ' + IntToStr(G50Month) + '/' + G50Year, fG50, tG50);
                DashUpdateStats('IBS',  'Exercice ' + PrevYear, fIBS, tIBS);
                DashUpdateStats('IRG',  'Exercice ' + PrevYear, fIRG, tIRG);
                DashUpdateStats('TAPP', SemesterText + ' ' + V_Year, fTAPP, tTAPP);
              end;
            end);
        end;

        TThread.Synchronize(nil,
          procedure begin
            if not Application.Terminated then
            begin
              pnlAlertCard.Caption := '  D'#201'LAI FINAL : LE 20';
            end;
          end);

      finally
        CacheList.Free;
      end;
    end
  ).Start;
end;



procedure TfrmMain.AdvGlowButton1Click(Sender: TObject);
begin
form20.texercices.Close;
form20.texercices.open;
form20.texercices.Refresh;
form20.TG50.Open;
form20.Tnature.Open;
form20.Tmois.Open;

end;

procedure TfrmMain.AdvGlowButton29Click(Sender: TObject);
begin
form20.TG50.Edit;
form2.ShowModal ;
//form20.TTap.Open;

end;

procedure TfrmMain.AdvGlowButton2Click(Sender: TObject);
begin
form20.RetatTVA.Print
end;

procedure TfrmMain.Bg50Click(Sender: TObject);
begin
form33.ShowModal
end;

procedure TfrmMain.AdvGlowButton4Click(Sender: TObject);
var
  BasePath, TargetFolder, FullFileName: string;
  YearStr, MaStr: string;
begin
  // 1. Récupérer les valeurs de l'année et du mois
  YearStr := dbann.Caption;
  MaStr := DBma.Text;

  // 2. Construire le chemin du dossier cible (Rapports puis l'année)
  BasePath := Edit1.Text;
  TargetFolder := IncludeTrailingPathDelimiter(BasePath) + 'Rapports\' + YearStr;

  // 3. Créer les dossiers s'ils n'existent pas
  if not ForceDirectories(TargetFolder) then
  begin
    ShowMessage('Erreur : Impossible de créer le répertoire cible.');
    Exit;
  end;

  // 4. Construire le chemin complet du fichier avec son nom
  FullFileName := IncludeTrailingPathDelimiter(TargetFolder) + 'EtatTva ' + MaStr + '.xls';

  // 5. Configurer le composant d'exportation FastReport
  frxXLSXExport1.FileName := FullFileName;
  frxXLSXExport1.ShowDialog := False;   // Masquer la boîte de dialogue de sauvegarde
  frxXLSXExport1.ShowProgress := False; // Optionnel : Masquer la barre de progression

  // 6. Préparer et exporter le rapport
  form20.RetatTVA.PrepareReport(True);
  form20.RetatTVA.Export(frxXLSXExport1);

  // Afficher un message de succès
  ShowMessage('Exportation terminée avec succès vers :' + #13#10 + FullFileName);

  // 7. Ouvrir le dossier contenant le fichier exporté
  ShellExecute(0, 'open', PChar(TargetFolder), nil, nil, SW_SHOWNORMAL);
end;



procedure TfrmMain.AdvGlowButton5Click(Sender: TObject);
var
  i: Integer;
  Page: TfrxReportPage;
  BasePath, TargetFolder, FullFileName: string;
  YearStr: string;
begin
  // 1. إعداد وتحديث حالة ظهور الصفحات (منطقك الأصلي)
  if not form20.RecapTAP.DataSet.Active        then form20.RecapTAP.DataSet.Open;
  if not form20.RecapTVA.DataSet.Active        then form20.RecapTVA.DataSet.Open;
  if not form20.RecapIRGsalaire.DataSet.Active then form20.RecapIRGsalaire.DataSet.Open;
  if not form20.RecapTimbre.DataSet.Active     then form20.RecapTimbre.DataSet.Open;
  if not form20.RecapAutres.DataSet.Active     then form20.RecapAutres.DataSet.Open;

  for i := 0 to form20.RecapAnnee.PagesCount - 1 do
  begin
    if form20.RecapAnnee.Pages[i] is TfrxReportPage then
    begin
      Page := TfrxReportPage(form20.RecapAnnee.Pages[i]);
      if Page.Name = 'TAP'      then Page.Visible := not form20.RecapTAP.DataSet.IsEmpty;
      if Page.Name = 'TVA'      then Page.Visible := not form20.RecapTVA.DataSet.IsEmpty;
      if Page.Name = 'Salaires' then Page.Visible := not form20.RecapIRGsalaire.DataSet.IsEmpty;
      if Page.Name = 'Timbre'   then Page.Visible := not form20.RecapTimbre.DataSet.IsEmpty;
      if Page.Name = 'Autres'   then Page.Visible := not form20.RecapAutres.DataSet.IsEmpty;
    end;
  end;

  // 2. إعداد المسارات
  YearStr := dbann.Caption;
  BasePath := Edit1.Text;
  TargetFolder := IncludeTrailingPathDelimiter(BasePath) + 'Rapports\' + YearStr;
  ForceDirectories(TargetFolder);
  FullFileName := IncludeTrailingPathDelimiter(TargetFolder) + 'Recap Annee ' + YearStr + '.xls';

  // 3. إعدادات التصدير الجوهرية لحل مشكلة الأسماء
  frxXLSXExport1.FileName := FullFileName;
  frxXLSXExport1.ShowDialog := False;
  frxXLSXExport1.SingleSheet := False; // ليكون لكل صفحة ورقة مستقلة

  // تفعيل هذا الخيار ضروري جداً في بعض الإصدارات لنقل مسميات الصفحات
  frxXLSXExport1.UseFileCache := True;

  // 4. تنفيذ التصدير
  if form20.RecapAnnee.PrepareReport(True) then
  begin
    form20.RecapAnnee.Export(frxXLSXExport1);

    // رسالة نجاح بالفرنسية كما طلبت
    ShowMessage('Le récapitulatif annuel a été exporté avec succès :' + #13#10 + FullFileName);

    // 5. فتح المجلد تلقائياً
    ShellExecute(0, 'open', PChar(TargetFolder), nil, nil, SW_SHOWNORMAL);
  end;
end;

procedure TfrmMain.AdvSmoothTabPager11Show(Sender: TObject);
begin
  dm.texercices.open;
end;

procedure TfrmMain.boxProjCloseUp(Sender: TObject);
begin
if boxProj.Text='' then form20.TEncaissements.Filtered:=false
     else
   begin
   form20.TEncaissements.Filter:='Projet LIKE''%' + boxProj.text+ '%''';
   form20.TEncaissements.Filtered:= true;
     end ;
end;

procedure TfrmMain.BtnOpenClick(Sender: TObject);
begin
form20.texercices.open;
form20.TG50.Open;
form20.Tnature.Open;
form20.Tmois.Open;
end;

procedure TfrmMain.DBGrid6CellClick(Column: TColumn);
begin
QUnionG50.ExecSQL;
QUnionG50.open;
Form20.QEtatTVA.ExecSQL;
Form20.QEtatTVA.Open;
ma.Caption :=MoisG50.Text;
SpeedButton15.Visible:=true;

end;

procedure TfrmMain.FormActivate(Sender: TObject);
begin
scAdvancedPagerPage9.Visible :=false;
pg1.ActivePage := scAdvancedPagerPage1 ;
  cp.ActiveCardIndex := 2;
  SetupDashboardCards;
  if not FStatsLoaded then
  begin
    FStatsLoaded := True;
    TimerDash.Interval := 1000;
    TimerDash.Enabled := True;
    ChargerStatistiques;
  end;
end;

procedure TfrmMain.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
 FreeAndNil(TimerDash);  // احذفه نهائياً من الذاكرة
  CanClose := True;;
end;

procedure TfrmMain.FormCreate(Sender: TObject);
begin
  FCompanyConnected := False;
 // UpdateUI;

  if not Assigned(FAllCompanies) then
    FAllCompanies := TList<uOpenSociete.TCompanyInfo>.Create;
  LoadAllCompanyInfo;

  FStatsLoaded := False;
end;










procedure TfrmMain.UpdateUI;
begin
  if not Self.HandleAllocated then Exit;  // ← أضف هذا

  mnuSociete.Enabled := FCompanyConnected;

  if FCompanyConnected then
  begin
    if Assigned(StatusBar1) and (StatusBar1.Panels.Count > 0) then  // ← أضف هذا
      StatusBar1.Panels[0].Text := '  Connecté: ' + DM.CurrentDbPath;
    lblWelcome.Caption := 'Société Ouverte';
    lblInfo.Caption := 'Base de données: ' + ExtractFileName(DM.CurrentDbPath) +
      #13#10 + 'Dossier: ' + DM.CurrentFolder;
    edit1.Text := DM.CurrentFolder;
  end
  else
  begin
    if Assigned(StatusBar1) and (StatusBar1.Panels.Count > 0) then  // ← أضف هذا
      StatusBar1.Panels[0].Text := '  Aucune société ouverte';
    lblWelcome.Caption := 'Bienvenue - Multi-Sociétés 2026';
    lblInfo.Caption := 'Utilisez le menu Fichier pour créer ou ouvrir un dossier de société.';
  end;
end;

procedure TfrmMain.mnuNouveauClick(Sender: TObject);
var
  frm: TForm10;
begin
  frm := TForm10.Create(Self);
  try
    if frm.ShowModal = mrOk then
    begin
      FCompanyConnected := DM.UniConnection.Connected;
      UpdateUI;
      ShowMessage('Le dossier de la société a été créé avec succès !');
    end;
  finally
    frm.Free;
  end;
end;

procedure TfrmMain.mnuOuvrirClick(Sender: TObject);
var
  frm: TfrmOpenSociete;
begin
  frm := TfrmOpenSociete.Create(Self);
  try
    if frm.ShowModal = mrOk then
    begin
      FCompanyConnected := DM.UniConnection.Connected;
      UpdateUI;
    end;
  finally
    frm.Free;
  end;
end;

procedure TfrmMain.mnuSocieteClick(Sender: TObject);
var
  frm: TfrmSocieteEdit;
begin
  if not FCompanyConnected then
  begin
    ShowMessage('Veuillez d''abord ouvrir un dossier de société.');
    Exit;
  end;

  frm := TfrmSocieteEdit.Create(Self);
  try
    frm.ShowModal;
  finally
    frm.Free;
  end;
end;

procedure TfrmMain.N1Click(Sender: TObject);
var
  frm: TfrmMissingG50;
begin
  frm := TfrmMissingG50.Create(Self);
  try
    frm.ShowModal;
  finally
    frm.Free;
  end;

end;

procedure TfrmMain.N2Click(Sender: TObject);
var
  frm: TfrmMissingIBS;
begin
  frm := TfrmMissingIBS.Create(Self);
  try
    frm.ShowModal;
  finally
    frm.Free;
  end;
 end;

procedure TfrmMain.N3Click(Sender: TObject);
var
  frm: TForm10;
begin
  frm := TForm10.Create(Self);
  try
    if frm.ShowModal = mrOk then
    begin
      FCompanyConnected := DM.UniConnection.Connected;
      UpdateUI;
      ShowMessage('Le dossier de la société a été créé avec succès !');
    end;
  finally
    frm.Free;
  end;
end;

procedure TfrmMain.O1Click(Sender: TObject);
var
  frm: TfrmOpenSociete;
begin
  frm := TfrmOpenSociete.Create(Self);
  try
    if frm.ShowModal = mrOk then
    begin
      FCompanyConnected := DM.UniConnection.Connected;
      UpdateUI;
    end;
  finally
    frm.Free;
  end;

end;

procedure TfrmMain.P1Click(Sender: TObject);
var
  Dlg: TOpenDialog;
  DbPath: string;
begin
TimerDash.Enabled := False;  // أضف هذا
  Dlg := TOpenDialog.Create(nil);
  try
    Dlg.Title  := 'Sélectionner un dossier G50';
    Dlg.Filter := 'Base de données Access (G50.mdb)|G50.mdb';
    Dlg.Options := [ofFileMustExist, ofPathMustExist];

    if Dlg.Execute then
    begin
      DbPath := Dlg.FileName;

      try
        DM.ConnectToDatabase(DbPath);

        if not DM.UniConnection.Connected then Exit;

        if not DM.tclient.Active then
          DM.tclient.Open;

        form20.texercices.Close;
        form20.texercices.Open;
        form20.texercices.Refresh;
        form20.TG50.Open;
        form20.Tnature.Open;
        form20.Tmois.Open;
        form20.TacompteIBS.Open;
        form20.TIBS.Open;
        form20.TacompteIrg.Open;
        form20.TIrg.Open;
        form20.TTAPP.Open;
        form20.tpharma.Open;
        form14.TStation.Open;
        form20.Tproj.Open;
        form20.tencaissements.Open;

        cp.ActiveCardIndex := 1;

      except
        on E: Exception do
          ShowMessage('Erreur ouverture: ' + E.Message);
      end;
    end;
  finally
    Dlg.Free;
    TimerDash.Enabled := True;  // أضف هذا
  end;
end;


procedure TfrmMain.S1Click(Sender: TObject);
var
  frm:TfrmMissingIRG ;
begin
  frm := TfrmMissingIRG .Create(Self);
  try
    frm.ShowModal;
  finally
    frm.Free;
  end;
end;

procedure TfrmMain.SauvgareretRestaurer1Click(Sender: TObject);
begin
form1.ShowModal
end;

procedure TfrmMain.scAdvancedPager1ChangePage(Sender: TObject);
begin

if form20.Tibs.IsEmpty then
begin
 SpeedButton23.Enabled:=true;
 SpeedButton24.Enabled:=false;
  SpeedButton25.Enabled:=false;
end
else
 begin
  SpeedButton23.Enabled:=false;
 SpeedButton24.Enabled:=true;
  SpeedButton25.Enabled:=true;
end

end;

procedure TfrmMain.scGPCheckBox1Click(Sender: TObject);
begin
  if scGPCheckBox1.Checked then
  begin
    // 1. مسح نص البحث
    SearchBox2.Clear;

    // 2. تصفير اختيار الـ DBLookupComboBox
    // نستخدم Variants للسماح بقيمة Null
    boxProj.KeyValue := Null;

    // 3. إلغاء الفلترة في Form20
    if Assigned(Form20) then
    begin
      Form20.TEncaissements.Filtered := False;
      Form20.TEncaissements.Filter := '';
    end;

    // إرجاع الـ CheckBox لوضع غير المختار
    scGPCheckBox1.Checked := False;
  end;
end;



procedure TfrmMain.SearchBox2Change(Sender: TObject);
begin
if SearchBox2.Text='' then form20.TEncaissements.Filtered:=false
     else
   begin
   form20.TEncaissements.Filter:='client LIKE''%' + SearchBox2.text+ '%''';
   form20.TEncaissements.Filtered:= true;
     end ;
end;

procedure TfrmMain.SpeedButton10Click(Sender: TObject);
var
  i: Integer;
  Page: TfrxPage;
begin
  // افتح الجداول أولاً
  if not form20.RecapTAP.DataSet.Active        then form20.RecapTAP.DataSet.Open;
  if not form20.RecapTVA.DataSet.Active        then form20.RecapTVA.DataSet.Open;
  if not form20.RecapIRGsalaire.DataSet.Active then form20.RecapIRGsalaire.DataSet.Open;
  if not form20.RecapTimbre.DataSet.Active     then form20.RecapTimbre.DataSet.Open;
  if not form20.RecapAutres.DataSet.Active     then form20.RecapAutres.DataSet.Open;

  // ثم تحقق وأخفِ
  for i := 0 to form20.RecapAnnee.PagesCount - 1 do
  begin
    Page := form20.RecapAnnee.Pages[i];
    if Page.Name = 'TAP'      then Page.Visible := not form20.RecapTAP.DataSet.IsEmpty;
    if Page.Name = 'TVA'      then Page.Visible := not form20.RecapTVA.DataSet.IsEmpty;
    if Page.Name = 'Salaires' then Page.Visible := not form20.RecapIRGsalaire.DataSet.IsEmpty;
    if Page.Name = 'Timbre'   then Page.Visible := not form20.RecapTimbre.DataSet.IsEmpty;
    if Page.Name = 'Autres'   then Page.Visible := not form20.RecapAutres.DataSet.IsEmpty;
  end;
      form28.ShowModal
 // form20.RecapAnnee.ShowReport()

end;

procedure TfrmMain.SpeedButton11Click(Sender: TObject);
begin
FoExercice.ShowModal
end;

procedure TfrmMain.SpeedButton13Click(Sender: TObject);
var
  BasePath, TargetFolder, FullFileName: string;
  YearStr, MaStr: string;
  TotalRecords: Integer;
begin
  // 1. التأكد من وجود بيانات
  if form20.dg50.DataSet.IsEmpty then
  begin
    ShowMessage('Aucune donnée à exporter.');
    Exit;
  end;

  // 2. التحضير للمجلد
  BasePath := Edit1.Text;
  YearStr := dbann.Caption;
  TargetFolder := IncludeTrailingPathDelimiter(BasePath) + 'Rapports\' + YearStr+ '\' +'Etat TVA\';

  if not ForceDirectories(TargetFolder) then
  begin
    ShowMessage('Erreur : Impossible de créer le répertoire cible.');
    Exit;
  end;

  // 3. إعداد وإظهار شريط التقدم (ProgressBar)
  TotalRecords := form20.dg50.DataSet.RecordCount;
  ProgressBar1.Max := TotalRecords;
  ProgressBar1.Position := 0;

  ProgressBar1.Visible := True; // إظهار الشريط
  ProgressBar1.Update;         // إجبار البرنامج على رسم الشريط فوراً على الشاشة

  // تعطيل تحديث الواجهة لتسريع العملية ومنع الارتعاش
  form20.dg50.DataSet.DisableControls;
  try
    form20.dg50.DataSet.First;

    while not form20.dg50.DataSet.Eof do
    begin
      // تحديث قيمة شريط التقدم
      ProgressBar1.Position := ProgressBar1.Position + 1;

      // السماح للنظام بتحديث الرسائل (لكي لا يتجمد البرنامج)
      Application.ProcessMessages;

      // جلب القيمة من الحقل 'ma'
      MaStr := form20.dg50.DataSet.FieldByName('ma').AsString;
      FullFileName := IncludeTrailingPathDelimiter(TargetFolder) + 'EtatTva ' + MaStr + '.pdf';

      // إعداد مكون التصدير
      frxPDFExport1.FileName := FullFileName;
      frxPDFExport1.ShowDialog := False;
      frxPDFExport1.ShowProgress := False;
      frxPDFExport1.EmbeddedFonts := True;

      // التجهيز والتصدير
      if form20.RetatTVA.PrepareReport(True) then
      begin
        form20.RetatTVA.Export(frxPDFExport1);
      end;

      form20.dg50.DataSet.Next;
    end;

    ShowMessage('Exportation terminée avec succès !');
    ShellExecute(0, 'open', PChar(TargetFolder), nil, nil, SW_SHOWNORMAL);

  finally
    // 4. التنظيف وإخفاء الشريط في كل الأحوال (حتى لو حدث خطأ)
    ProgressBar1.Visible := False; // إخفاء الشريط بعد الانتهاء
    form20.dg50.DataSet.EnableControls;
  end;
end;



procedure TfrmMain.SpeedButton14Click(Sender: TObject);
var
  BasePath, TargetFolder, FullFileName: string;
  YearStr, MaStr: string;
  TotalRecords: Integer;
begin
  // 1. التحقق من وجود بيانات في الجدول
  if form20.dg50.DataSet.IsEmpty then
  begin
    ShowMessage('Aucune donnée à exporter.');
    Exit;
  end;

  // 2. تحضير المسارات (Rapports\Année)
  BasePath := Edit1.Text;
  YearStr := dbann.Caption;
   TargetFolder := IncludeTrailingPathDelimiter(BasePath) + 'Rapports\' + YearStr+ '\' +'Etat TVA\';

  if not ForceDirectories(TargetFolder) then
  begin
    ShowMessage('Erreur : Impossible de créer le répertoire cible.');
    Exit;
  end;

  // 3. إعداد شريط التقدم (ProgressBar)
  TotalRecords := form20.dg50.DataSet.RecordCount;
  ProgressBar1.Max := TotalRecords;
  ProgressBar1.Position := 0;
  ProgressBar1.Visible := True;
  ProgressBar1.Update;

  // 4. تعطيل تحديث الواجهة لتسريع العملية
  form20.dg50.DataSet.DisableControls;
  try
    form20.dg50.DataSet.First;

    while not form20.dg50.DataSet.Eof do
    begin
      // تحديث شريط التقدم ومعالجة رسائل النظام
      ProgressBar1.Position := ProgressBar1.Position + 1;
      Application.ProcessMessages;

      // جلب قيمة الشهر لتسمية الملف
      MaStr := form20.dg50.DataSet.FieldByName('ma').AsString;
      FullFileName := IncludeTrailingPathDelimiter(TargetFolder) + 'EtatTva ' + MaStr + '.xlsx';

      // 5. إعداد مكون تصدير إكسل (frxXLSXExport1)
      frxXLSXExport1.FileName := FullFileName;
      frxXLSXExport1.ShowDialog := False;   // تصدير صامت بدون نوافذ
      frxXLSXExport1.ShowProgress := False;
      frxXLSXExport1.OpenAfterExport := False;

      // 6. تجهيز وتصدير التقرير الحالي
      if form20.RetatTVA.PrepareReport(True) then
      begin
        form20.RetatTVA.Export(frxXLSXExport1);
      end;

      form20.dg50.DataSet.Next;
    end;

    ShowMessage('Exportation Excel terminée avec succès !');

    // 7. فتح المجلد لرؤية النتائج
    ShellExecute(0, 'open', PChar(TargetFolder), nil, nil, SW_SHOWNORMAL);

  finally
    // إخفاء الشريط وإعادة تمكين عناصر التحكم
    ProgressBar1.Visible := False;
    form20.dg50.DataSet.EnableControls;
  end;
end;
procedure TfrmMain.SpeedButton15Click(Sender: TObject);
begin
   form20.QEtatTVA.ExecSQL;
    form20.QEtatTVA.Open;
  if not form20.QEtatTVA.IsEmpty then
  begin

    form6.ShowModal;
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucune déduction effectuée ce mois-ci');
  end;
end;

procedure TfrmMain.SpeedButton16Click(Sender: TObject);
 begin
    ShellExecute(0, 'open', PChar(edit1.Text), nil, nil, SW_SHOWNORMAL) ;

end;

procedure TfrmMain.SpeedButton17Click(Sender: TObject);
begin
Form20.tacompteIBS.Append;
form7.Showmodal
end;

procedure TfrmMain.SpeedButton18Click(Sender: TObject);
begin
if not form20.tacompteIBS.IsEmpty then
  begin
   Form20.tacompteIBS.edit;
    form7.Showmodal
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun Acompte IBS à modifier');
  end;


end;

procedure TfrmMain.SpeedButton19Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
        Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer le :' +DBacompte.Field.Value +' '+ExIBS.Field.Value;
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.TacompteIBS.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.TacompteIBS.Delete;
            ShowMessage(DBacompte.Field.Value+ ' '+ ExIBS.Field.Value+ ' est supprimé');
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;
 end;

procedure TfrmMain.SpeedButton20Click(Sender: TObject);
begin
Form20.tacompteIrg.Append;
form8.Showmodal
end;

procedure TfrmMain.SpeedButton21Click(Sender: TObject);
begin
if not form20.tacompteIRG.IsEmpty then
  begin
   Form20.tacompteIrg.edit;
   form8.Showmodal
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun Acompte IRG à modifier');
  end;
end;

procedure TfrmMain.SpeedButton22Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
       // Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer le :' +DBacompte1.Field.Value +' '+ExIrg.Field.Value;
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.TacompteIrg.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.TacompteIrg.Delete;
            ShowMessage(DBacompte.Field.Value+ ' '+ ExIBS.Field.Value+ ' est supprimé');
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;
 end;



procedure TfrmMain.SpeedButton23Click(Sender: TObject);
begin
form20.Tibs.Append;
form45.Button1.Click;
form45.ShowModal;
end;

procedure TfrmMain.SpeedButton24Click(Sender: TObject);
begin
form20.Tibs.edit;
form45.ShowModal;
end;

procedure TfrmMain.SpeedButton25Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
       //88 Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer le Solde IBS :' +ExIBS.Field.Value;
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.TIBS.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.Tibs.Delete;
            ShowMessage( 'le Solde IBS '+ ExIBS.Field.Value+ ' est supprimé');
            bibs.Click
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;

end;

procedure TfrmMain.SpeedButton26Click(Sender: TObject);
begin
form20.Tirg.edit;
//form9.Button1.Click;
form9.ShowModal;
end;

procedure TfrmMain.SpeedButton27Click(Sender: TObject);
begin
form20.tirg.edit;
form9.ShowModal;
end;

procedure TfrmMain.SpeedButton28Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
       // Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer le Solde IRG :' +ExIBS.Field.Value;
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.TIRG.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.Tirg.Delete;
            ShowMessage( 'le Solde IRG '+ ExIBS.Field.Value+ ' est supprimé');
              end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;

end;



procedure TfrmMain.SpeedButton29Click(Sender: TObject);
begin
if not form20.Tibs.IsEmpty then
  begin
   form20.RIbs.ShowReport()
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun Solde IBS   à imprimer');
  end;
end;

procedure TfrmMain.SpeedButton2Click(Sender: TObject);
begin
if not form14.TStation.IsEmpty then
  begin
  //formf.
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun Etat  à imprimer');
  end;

end;

procedure TfrmMain.SpeedButton30Click(Sender: TObject);
begin
if not form20.Tirg.IsEmpty then
  begin
   form20.RIrg.ShowReport()
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun Solde IRG  à imprimer');
  end;
end;



procedure TfrmMain.SpeedButton31Click(Sender: TObject);
begin
form20.Ttapp.APPEND;
form11.ShowModal
end;

procedure TfrmMain.SpeedButton32Click(Sender: TObject);
begin
if not form20.Ttapp.IsEmpty then
  begin
   form20.Ttapp.Edit;
    form11.ShowModal ;
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun déclaration TAPP-TF à modifier');
  end;

end;

procedure TfrmMain.SpeedButton33Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
       // Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer Cette déclaraton  :';
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.TTaPP.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.TTAPP.Delete;
            ShowMessage(' La déclaraton est supprimée');
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;
 end;



procedure TfrmMain.SpeedButton34Click(Sender: TObject);
begin
if not form20.ttapp.IsEmpty then
  begin
  form20.rtapp.showreport
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucune Déclaration TAPP-TF à imprimer');
  end;


end;

procedure TfrmMain.SpeedButton35Click(Sender: TObject);
begin
if not form20.TPharma.IsEmpty then
  begin
  form20.rpharma.showreport
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucune Déclaration CA Pharma à imprimer');
  end;



end;

procedure TfrmMain.SpeedButton36Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
       // Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer Cette déclaraton  :';
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.TPharma.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.TPharma.Delete;
            ShowMessage(' La déclaraton est supprimée');
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;

end;

procedure TfrmMain.SpeedButton37Click(Sender: TObject);
begin
form20.TPharma.Edit;
form12.ShowModal ;
end;


procedure TfrmMain.SpeedButton381Click(Sender: TObject);
begin
  // 1. التأكد من أن الفورم موجود في الذاكرة
  if not Assigned(Form20) then
    Application.CreateForm(TForm20, Form20);

  // 2. التأكد من أن الجدول مفتوح قبل فحصه
  Form20.tproj.Open;

  // 3. الفحص والتحقق
  if Form20.tproj.IsEmpty then
  begin
    ShowMessage('La table des projets est vide.' + #13#10 +
                'Veuillez ajouter au moins un projet.');

    // فتح فورم إضافة المشاريع
    if not Assigned(Form17) then Application.CreateForm(TForm17, Form17);
    Form17.ShowModal;
  end
  else
  begin
    // إذا وجد مشاريع، نفذ الكود الخاص بك
    Form20.tencaissements.Append;
    Form18.ShowModal;
  end;
end;

procedure TfrmMain.SpeedButton39Click(Sender: TObject);
begin
dm.tclient.Edit;
form29.Showmodal
end;

procedure TfrmMain.SpeedButton3Click(Sender: TObject);
begin
form20.TG50.Append;
form23.ShowModal;
end;

procedure TfrmMain.SpeedButton401Click(Sender: TObject);
begin
if not form20.tencaissements.IsEmpty then
  begin
   Form20.tencaissements.edit;
form18.ShowModal
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun déclaration à modifier');
  end;

end;

procedure TfrmMain.SpeedButton40Click(Sender: TObject);
begin
form17.ShowModal
end;

procedure TfrmMain.SpeedButton41Click(Sender: TObject);
begin
form14.TStation.Append;
form14.ShowModal
end;

procedure TfrmMain.SpeedButton44Click(Sender: TObject);
begin
if not form14.TStation.IsEmpty then
  begin
   form14.TStation.Edit;
   form5.ShowModal
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun déclaration  modifier');
  end;

end;

procedure TfrmMain.SpeedButton47Click(Sender: TObject);
begin
if not form14.TStation.IsEmpty then
  begin
  form21.ShowModal;
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun Etat  à imprimer');
  end;


end;

procedure TfrmMain.SpeedButton4Click(Sender: TObject);
begin
 if not form20.TG50.IsEmpty then
  begin
   form20.TG50.Edit;
   form2.ShowModal ;
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucune G50 à modifier');
  end;
end;

procedure TfrmMain.SpeedButton51Click(Sender: TObject);
begin
form17.ShowModal
end;

procedure TfrmMain.SpeedButton52Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
       // Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer Cette  déclaration :';
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           form14.TStation.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           form14.TStation.Delete;
            ShowMessage(' la déclaration selectionnée est supprimée');
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;

end;

procedure TfrmMain.SpeedButton54Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
        Caption:= 'Table des Versements';
         Text:= 'Ete vous sure de supprimer cet versement:' +ma.Caption;
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.TEncaissements.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.TEncaissements.Delete;
            ShowMessage('le versement est supprimé');
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;


end;

procedure TfrmMain.SpeedButton56Click(Sender: TObject);
begin
if not form20.tencaissements.IsEmpty then
  begin
  form20.Rencaissem.PrepareReport() ;
form19.ShowModal
  end
  else
  begin
    // إظهار الرسالة في حال كان الاستعلام فارغاً
    ShowMessage('Aucun Etat  à imprimer');
  end;

end;

procedure TfrmMain.SpeedButton5Click(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);

  try
    with Dlg do
      begin
        CommonButtons:= [];
        Caption:= 'Table des Clients';
         Text:= 'Ete vous sure de supprimer la déclararion G50 :' +ma.Caption;
             with Buttons.Add do
          begin
            Caption:= 'Oui';
            ModalResult:= mrYes;
             end;
        with Buttons.Add do
          begin
            Caption:= 'Non';
           Form20.tg50.Cancel;

          end;
        if Execute then
        begin
         case ModalResult of
           mrYes:
           begin
           Form20.tg50.Delete;
            ShowMessage('la déclararion G50 :' +ma.Caption+ ' est supprimée');
            end;
             end;
        end;
          end;
  finally
    Dlg.Free;
  end;

end;

procedure TfrmMain.SpeedButton7Click(Sender: TObject);
begin
  form33.qTVA.Close;
  form33.qTVA.SQL.Text := 'SELECT * FROM TVA WHERE Idg50 = ' + form20.TG50.FieldByName('Idg50').AsString;
  form33.qTVA.Open;
  form33.qRef.Open;
  form33.VirtualQuery1.Close;
  form33.VirtualQuery1.Open;

  form33.qTap.Close;
  form33.qTap.SQL.Text := 'SELECT * FROM Tap WHERE Idg50 = ' + form20.TG50.FieldByName('Idg50').AsString;
  form33.qTap.Open;
  form33.qReftap.Open;
  form33.Vtap.Close;
  form33.vtap.Open;


  form33.Qsalaires.Close;
  form33.Qsalaires.SQL.Text := 'SELECT * FROM IRGSalaires WHERE Idg50 = ' + form20.TG50.FieldByName('Idg50').AsString;
  form33.Qsalaires.Open;
  form33.QSalairesRef.Open;
  form33.VSalaires.Close;
  form33.VSalaires.Open;




  form33.ShowModal;
end;

procedure TfrmMain.PG50Click(Sender: TObject);
var
  i: Integer;
  Page: TfrxReportPage;
  BasePath, TargetFolder, FullFileName: string;
  YearStr: string;
begin
  // 1. إعداد وتحديث حالة ظهور الصفحات (منطقك الأصلي)
  if not form20.RecapTAP.DataSet.Active        then form20.RecapTAP.DataSet.Open;
  if not form20.RecapTVA.DataSet.Active        then form20.RecapTVA.DataSet.Open;
  if not form20.RecapIRGsalaire.DataSet.Active then form20.RecapIRGsalaire.DataSet.Open;
  if not form20.RecapTimbre.DataSet.Active     then form20.RecapTimbre.DataSet.Open;
  if not form20.RecapAutres.DataSet.Active     then form20.RecapAutres.DataSet.Open;

  for i := 0 to form20.RecapAnnee.PagesCount - 1 do
  begin
    if form20.RecapAnnee.Pages[i] is TfrxReportPage then
    begin
      Page := TfrxReportPage(form20.RecapAnnee.Pages[i]);
      if Page.Name = 'TAP'      then Page.Visible := not form20.RecapTAP.DataSet.IsEmpty;
      if Page.Name = 'TVA'      then Page.Visible := not form20.RecapTVA.DataSet.IsEmpty;
      if Page.Name = 'Salaires' then Page.Visible := not form20.RecapIRGsalaire.DataSet.IsEmpty;
      if Page.Name = 'Timbre'   then Page.Visible := not form20.RecapTimbre.DataSet.IsEmpty;
      if Page.Name = 'Autres'   then Page.Visible := not form20.RecapAutres.DataSet.IsEmpty;
    end;
  end;

  // 2. إعداد المسارات (تغيير الامتداد إلى .pdf)
  YearStr := dbann.Caption;
  BasePath := Edit1.Text;
  TargetFolder := IncludeTrailingPathDelimiter(BasePath) + 'Rapports\' + YearStr;
  ForceDirectories(TargetFolder);
  FullFileName := IncludeTrailingPathDelimiter(TargetFolder) + 'Recap Annee ' + YearStr + '.pdf';

  // 3. إعدادات مكون التصدير PDF
  frxPDFExport1.FileName := FullFileName;
  frxPDFExport1.ShowDialog := False;    // إخفاء نافذة الإعدادات
  frxPDFExport1.OpenAfterExport := False; // لا يفتح الملف تلقائياً (سنفتحه بالمجلد لاحقاً)
  frxPDFExport1.EmbeddedFonts := True;   // تضمين الخطوط لضمان ظهور العربية/الفرنسية بشكل صحيح في أي جهاز
  frxPDFExport1.PrintOptimized := True;  // تحسين الجودة للطباعة

  // 4. تنفيذ التصدير
  if form20.RecapAnnee.PrepareReport(True) then
  begin
    form20.RecapAnnee.Export(frxPDFExport1);

    // رسالة نجاح بالفرنسية
    ShowMessage('Le récapitulatif annuel a été exporté en PDF avec succès :' + #13#10 + FullFileName);

    // 5. فتح المجلد تلقائياً
    ShellExecute(0, 'open', PChar(TargetFolder), nil, nil, SW_SHOWNORMAL);
  end;
end;

procedure TfrmMain.SpeedButton8Click(Sender: TObject);
var
  BasePath, TargetFolder, FullFileName: string;
  YearStr, MaStr: string;
begin
  // 1. Récupérer les valeurs de l'année et du mois (ou DBma)
  YearStr := dbann.Caption;
  MaStr := DBma.Text;

  // 2. Construire le chemin du dossier cible (Rapports\Année)
  BasePath := Edit1.Text;
  TargetFolder := IncludeTrailingPathDelimiter(BasePath) + 'Rapports\' + YearStr;

  // 3. Créer les dossiers s'ils n'existent pas
  if not ForceDirectories(TargetFolder) then
  begin
    ShowMessage('Erreur : Impossible de créer le répertoire cible.');
    Exit;
  end;

  // 4. Construire le chemin complet du fichier avec l'extension .pdf
  FullFileName := IncludeTrailingPathDelimiter(TargetFolder) + 'EtatTva ' + MaStr + '.pdf';

  // 5. Configurer le composant d'exportation PDF (frxPDFExport1)
  frxPDFExport1.FileName := FullFileName;
  frxPDFExport1.ShowDialog := False;    // Pas de fenêtre de configuration
  frxPDFExport1.ShowProgress := False;  // Masquer la barre de progression
  frxPDFExport1.EmbeddedFonts := True;   // Très important pour l'affichage des textes
  frxPDFExport1.PrintOptimized := True;  // Haute qualité

  // 6. Préparer et exporter le rapport RetatTVA
  if form20.RetatTVA.PrepareReport(True) then
  begin
    form20.RetatTVA.Export(frxPDFExport1);

    // Message de succès
    ShowMessage('L''exportation PDF est terminée avec succès :' + #13#10 + FullFileName);

    // 7. Ouvrir le dossier contenant le fichier PDF
    ShellExecute(0, 'open', PChar(TargetFolder), nil, nil, SW_SHOWNORMAL);
  end
  else
    ShowMessage('Erreur lors de la préparation du rapport.');
end;
procedure TfrmMain.T1Click(Sender: TObject);
begin
fthemes.ShowModal
end;

procedure TfrmMain.T2Click(Sender: TObject);
begin
  cp.ActiveCardIndex := 2; // Card3 - Dashboard
  ChargerStatistiques;
end;

procedure TfrmMain.T3Click(Sender: TObject);
var
  frm: TForm30;
 begin
  frm := TForm30.Create(Self);
  try
  Form20.TfournisseurTva.Open  ;
    frm.ShowModal;
  finally
    frm.Free;
  end;

end;

procedure TfrmMain.mnuImportHFSQLClick(Sender: TObject);
var
  frm: TfrmImportHFSQL;
begin
  if not FCompanyConnected then
  begin
    ShowMessage('Veuillez d''abord ouvrir un dossier de société (destination de l''import).');
    Exit;
  end;

  frm := TfrmImportHFSQL.Create(Self);
  try
    frm.ShowModal;
  finally
    frm.Free;
  end;
end;

procedure TfrmMain.mnuMissingG50Click(Sender: TObject);
begin
frmMissingG50.ShowModal
end;

procedure TfrmMain.FormShow(Sender: TObject);
begin
  TimerDash.Enabled := True;  // أضف في النهاية
   UpdateUI;
 cp.ActiveCardIndex :=0
end;

procedure TfrmMain.G501Click(Sender: TObject);
var
  frm: TfrmMissingTAPP;
begin
  frm := TfrmMissingTAPP.Create(Self);
  try
    frm.ShowModal;
  finally
    frm.Free;
  end;


end;

procedure TfrmMain.mnuBatchGenClick(Sender: TObject);
var
  frm: TfrmBatchGen;
begin
  frm := TfrmBatchGen.Create(Self);
  try
    frm.ShowModal;
  finally
    frm.Free;
  end;
end;

procedure TfrmMain.mnuQuitterClick(Sender: TObject);
var
  Dlg: TTaskDialog;
begin
  Dlg := TTaskDialog.Create(Self);
  try
    with Dlg do
    begin
      Caption := 'Quitter';
      Title := 'Confirmation'; // إضافة عنوان أجمل للنافذة
      Text := 'Êtes-vous sûr de vouloir quitter cette application ?';
      CommonButtons := []; // لإلغاء الأزرار الافتراضية واستخدام أزرارك الخاصة

      // إضافة زر "Oui"
      with Buttons.Add do
      begin
        Caption := 'Oui';
        ModalResult := mrYes;
      end;

      // إضافة زر "Non"
      with Buttons.Add do
      begin
        Caption := 'Non';
        ModalResult := mrNo; // استخدام mrNo أفضل من mrCancel هنا
      end;

      // تنفيذ الحوار وفحص النتيجة
      if Execute then
      begin
        if ModalResult = mrYes then
        begin
          TimerDash.Enabled := False;
             try
    if Assigned(DM) and Assigned(DM.UniConnection) and DM.UniConnection.Connected then
      DM.Disconnect;
         ExitProcess(0);
  except
    // تجاهل أي خطأ عند الإغلاق
  end;
  //Application.Terminate;
        end;
      end;
    end;
  finally
    Dlg.Free; // تحرير الذاكرة مهما حدث
  end;
end;

procedure TfrmMain.SetupDashboardCards;
const
  CardColors: array[0..3] of TColor = ($002904D9, $00F6823B, $000B9EF5, $00F65C8B);
  StatNames: array[0..2] of string = ('TOTAL', 'FAIT', 'RESTE');
var
  Cards: array[0..3] of TAdvMetroPanel;
  Shapes: array[0..3] of TShape;
  ValLabels: array[0..3] of TscGPLabel;
  DetLabels: array[0..3] of TscGPLabel;
  i, j, DonutSize, CardW, StatAreaW, StatAreaLeft: Integer;
  sep: TShape;
begin
  if FDashSetup then Exit;
  LockWindowUpdate(Self.Handle);
  try
    FDashSetup := True;

  Cards[0] := AdvMetroPanel1; Cards[1] := AdvMetroPanel2; Cards[2] := AdvMetroPanel3; Cards[3] := AdvMetroPanel4;
  Shapes[0] := Shape3;        Shapes[1] := Shape4;        Shapes[2] := Shape5;        Shapes[3] := Shape6;
  ValLabels[0] := scGPLabel14;ValLabels[1] := scGPLabel30;ValLabels[2] := scGPLabel32;ValLabels[3] := scGPLabel34;
  DetLabels[0] := scGPLabel19;DetLabels[1] := scGPLabel31;DetLabels[2] := scGPLabel33;DetLabels[3] := scGPLabel35;

  DonutSize := 80;
  StatAreaW := 180;
  pnlDashMain.Color := $00F8F4F0;  // Light blue-gray background

  // === Top Header Improvements (Suivi Fiscal Professionnel) ===
  if Assigned(scGPLabel5) then
  begin
    scGPLabel5.Align := alLeft;
    scGPLabel5.Width := 400;
    scGPLabel5.Caption := '   Suivi Fiscal Professionnel';
    scGPLabel5.Alignment := taLeftJustify;
    scGPLabel5.Font.Size := 16;
    scGPLabel5.Font.Color := $003C2809; // Dark blue/black color from design
  end;

  // Add Date and Time labels to Panel2 if it exists
  if Assigned(Panel2) then
  begin
    Panel2.Color := clWhite;
    Panel2.Height := 50;

    // Time Box (aligned right)
    lblHeaderTime := TLabel.Create(Panel2);
    with lblHeaderTime do
    begin
      Parent := Panel2;
      AutoSize := False;
      Width := 100;
      Height := 30;
      Top := 10;
      Left := Panel2.Width - 120;
      Anchors := [akTop, akRight];
      Font.Name := 'Segoe UI';
      Font.Size := 10;
      Font.Style := [fsBold];
      Font.Color := $00B0502F; // Blue
      Alignment := taCenter;
      Layout := tlCenter;
      Caption := FormatDateTime('hh:nn:ss', Now);
      Color := $00FCF9F5; // Light gray/blue bg
      Transparent := False;
    end;

    // Date Box (aligned right next to time)
    lblHeaderDate := TLabel.Create(Panel2);
    with lblHeaderDate do
    begin
      Parent := Panel2;
      AutoSize := False;
      Width := 120;
      Height := 30;
      Top := 10;
      Left := Panel2.Width - 250;
      Anchors := [akTop, akRight];
      Font.Name := 'Segoe UI';
      Font.Size := 10;
      Font.Style := [fsBold];
      Font.Color := $00B0502F; // Blue
      Alignment := taCenter;
      Layout := tlCenter;
      Caption := FormatDateTime('dd/mm/yyyy', Now);
      Color := $00FCF9F5; // Light gray/blue bg
      Transparent := False;
    end;
  end;

  // Link DFM AdvGaugeCircles to array for runtime updates
  AdvGauges[0] := pbGaugeG50;
  AdvGauges[1] := pbGaugeIBS;
  AdvGauges[2] := pbGaugeIRG;
  AdvGauges[3] := pbGaugeTAPP;

  for i := 0 to 3 do
  begin
    CardW := Cards[i].ClientWidth;
    if CardW < 100 then CardW := 260;
    StatAreaLeft := (CardW - StatAreaW) div 2;

    // Update card header colors
    Cards[i].Appearance.Color := CardColors[i];
    Cards[i].Font.Color := clWhite;
    Cards[i].Font.Name := 'Segoe UI';
    Cards[i].Font.Size := 9;
    Cards[i].Font.Style := [fsBold];

    // Update color strip
    Shapes[i].Brush.Color := CardColors[i];
    Shapes[i].Height := 5;

    // Hide old detail label
    DetLabels[i].Visible := False;

    // Use percentage label logic or built-in Gauge digits
    ValLabels[i].Visible := False;


    // Remove percentage label as Gauge has built-in digits
    ValLabels[i].Visible := False;

    // Add separator line between gauge and stats
    sep := TShape.Create(Cards[i]);
    sep.Parent := Cards[i];
    sep.Shape := stRectangle;
    sep.Left := StatAreaLeft;
    sep.Top := 122;
    sep.Width := StatAreaW;
    sep.Height := 1;
    sep.Pen.Style := psClear;
    sep.Brush.Color := $00F0EDE8;
    sep.BringToFront;

    // Detail labels (scGPLabel19, 31, 33, 35) are now positioned in DFM
    DetLabels[i].Visible := True;
    DetLabels[i].BringToFront;
  end;

  // === Alert Card Improvements ===
  shpAlert.Brush.Color := $002904D9;
  shpAlert.Height := 5;

  // Reposition days number (centered, large)
  lblAlertDays.Font.Height := -56;
  lblAlertDays.Font.Color := $002904D9;
  lblAlertDays.Top := 30;
  lblAlertDays.Left := 10;
  lblAlertDays.Width := 220;
  lblAlertDays.Height := 70;
  lblAlertDays.FillColorAlpha := 0;
  lblAlertDays.FrameColorAlpha := 0;

  // Add 'JOURS RESTANTS' subtitle
  lblJoursText := TLabel.Create(pnlAlertCard);
  with lblJoursText do
  begin
    Parent := pnlAlertCard;
    AutoSize := False;
    Width := 220;
    Left := 10;
    Top := 105;
    Alignment := taCenter;
    Caption := 'JOURS RESTANTS';
    Font.Name := 'Segoe UI';
    Font.Size := 9;
    Font.Style := [fsBold];
    Font.Color := $00948C64;
  end;

  // Reposition progress bar
  pbAlert.Top := 145;
  pbAlert.Left := 15;
  pbAlert.Width := 195;

  // Style clock as dark pill
  lblAlertClock.Top := 175;
  lblAlertClock.Left := 35;
  lblAlertClock.Width := 140;
  lblAlertClock.Height := 32;
  lblAlertClock.Font.Height := -16;
  lblAlertClock.Font.Color := clWhite;
  lblAlertClock.Font.Name := 'Consolas';
  lblAlertClock.FillColor := $001E293B;
  lblAlertClock.FillColorAlpha := 255;
  lblAlertClock.FrameRadius := 10;
  lblAlertClock.FrameColorAlpha := 0;

  // === Unify Design For IBS Alert Card ===
  if Assigned(AdvMetroPanel5) then
  begin
    Shape7.Brush.Color := clRed;
    Shape7.Height := 5;

    lblIBSAlertDays.Font.Height := -56;
    lblIBSAlertDays.Font.Color := clRed;
    lblIBSAlertDays.Top := 30;
    lblIBSAlertDays.Left := 10;
    lblIBSAlertDays.Width := AdvMetroPanel5.ClientWidth - 20;
    lblIBSAlertDays.Height := 70;
    lblIBSAlertDays.FillColorAlpha := 0;
    lblIBSAlertDays.FrameColorAlpha := 0;

    lblIBSJoursText := TLabel.Create(AdvMetroPanel5);
    with lblIBSJoursText do
    begin
      Parent := AdvMetroPanel5;
      AutoSize := False;
      Width := AdvMetroPanel5.ClientWidth - 20;
      Left := 10;
      Top := 105;
      Alignment := taCenter;
      Caption := 'JOURS RESTANTS';
      Font.Name := 'Segoe UI';
      Font.Size := 9;
      Font.Style := [fsBold];
      Font.Color := $00948C64;
    end;

    pbIBSAlert.Top := 145;
    pbIBSAlert.Left := 15;
    pbIBSAlert.Width := AdvMetroPanel5.ClientWidth - 30;

    lblIBSAlertClock.Top := 175;
    lblIBSAlertClock.Left := (AdvMetroPanel5.ClientWidth - 140) div 2;
    lblIBSAlertClock.Width := 140;
    lblIBSAlertClock.Height := 32;
    lblIBSAlertClock.Font.Height := -16;
    lblIBSAlertClock.Font.Color := clWhite;
    lblIBSAlertClock.Font.Name := 'Consolas';
    lblIBSAlertClock.FillColor := $001E293B;
    lblIBSAlertClock.FillColorAlpha := 255;
    lblIBSAlertClock.FrameRadius := 10;
    lblIBSAlertClock.FrameColorAlpha := 0;
  end;

  // === Unify Design For IRG Alert Card ===
  if Assigned(AdvMetroPanel6) then
  begin
    Shape8.Brush.Color := clRed;
    Shape8.Height := 5;

    lblIRGAlertDays.Font.Height := -56;
    lblIRGAlertDays.Font.Color := clRed;
    lblIRGAlertDays.Top := 30;
    lblIRGAlertDays.Left := 10;
    lblIRGAlertDays.Width := AdvMetroPanel6.ClientWidth - 20;
    lblIRGAlertDays.Height := 70;
    lblIRGAlertDays.FillColorAlpha := 0;
    lblIRGAlertDays.FrameColorAlpha := 0;

    lblIRGJoursText := TLabel.Create(AdvMetroPanel6);
    with lblIRGJoursText do
    begin
      Parent := AdvMetroPanel6;
      AutoSize := False;
      Width := AdvMetroPanel6.ClientWidth - 20;
      Left := 10;
      Top := 105;
      Alignment := taCenter;
      Caption := 'JOURS RESTANTS';
      Font.Name := 'Segoe UI';
      Font.Size := 9;
      Font.Style := [fsBold];
      Font.Color := $00948C64;
    end;

    pbIRGAlert.Top := 145;
    pbIRGAlert.Left := 15;
    pbIRGAlert.Width := AdvMetroPanel6.ClientWidth - 30;

    lblIRGAlertClock.Top := 175;
    lblIRGAlertClock.Left := (AdvMetroPanel6.ClientWidth - 140) div 2;
    lblIRGAlertClock.Width := 140;
    lblIRGAlertClock.Height := 32;
    lblIRGAlertClock.Font.Height := -16;
    lblIRGAlertClock.Font.Color := clWhite;
    lblIRGAlertClock.Font.Name := 'Consolas';
    lblIRGAlertClock.FillColor := $001E293B;
    lblIRGAlertClock.FillColorAlpha := 255;
    lblIRGAlertClock.FrameRadius := 10;
    lblIRGAlertClock.FrameColorAlpha := 0;
  end;

  finally
    LockWindowUpdate(0);
  end;
end;



procedure TfrmMain.DashUpdateStats(const Category, Period: string; Fait, Total: Integer);
var
  Rest, Perc, Idx: Integer;
  sStats: string;
begin
  Rest := Total - Fait;
  if Total > 0 then Perc := Round((Fait / Total) * 100) else Perc := 0;

  Idx := -1;
  if Category = 'G50' then Idx := 0
  else if Category = 'IBS' then Idx := 1
  else if Category = 'IRG' then Idx := 2
  else if Category = 'TAPP' then Idx := 3;

  if (Idx >= 0) and (Idx <= 3) then
  begin
    FPerc[Idx] := Perc;
    if Assigned(AdvGauges[Idx]) then
    begin
       AdvGauges[Idx].Position := Perc;
    end;

    // Update card titles with month/year
    if Idx = 0 then
      AdvMetroPanel1.Caption := 'SUIVI G50  : ' + Period
    else if Idx = 1 then
      AdvMetroPanel2.Caption := 'SUIVI IBS  : ' + Period
    else if Idx = 2 then
      AdvMetroPanel3.Caption := 'SUIVI IRG  : ' + Period
    else if Idx = 3 then
      AdvMetroPanel4.Caption := 'SUIVI TAPP : ' + Period;

    // Update stat value labels using the DFM Detail Labels (Multiline)
    sStats := 'TOTAL :   ' + IntToStr(Total) + #13#10 +
              'FAIT  :   ' + IntToStr(Fait) + #13#10 +
              'RESTE :   ' + IntToStr(Rest);
              
    if Idx = 0 then scGPLabel19.Caption := sStats
    else if Idx = 1 then scGPLabel31.Caption := sStats
    else if Idx = 2 then scGPLabel33.Caption := sStats
    else if Idx = 3 then scGPLabel35.Caption := sStats;
  end;
end;

procedure TfrmMain.TimerDashTimer(Sender: TObject);
var
  Now_, D20: TDateTime;
  Days: Integer;
  DiffSec: Int64;
  HH, MM, SS, ProgPct: Integer;
begin
  try
    if (csDestroying in ComponentState) or (not Self.Visible) then Exit;
    if not Assigned(lblAlertDays) then Exit;
    if not Assigned(lblAlertClock) then Exit;
    if not Assigned(lblAlertDays.Parent) then Exit;
    if not lblAlertDays.Parent.Visible then Exit;

    Now_ := Now;
    D20 := EncodeDate(YearOf(Now_), MonthOf(Now_), 20);
    if DayOf(Now_) > 20 then D20 := IncMonth(D20, 1);

    Days := Trunc(D20 - Now_);
    DiffSec := SecondsBetween(Now_, D20);
    HH := (DiffSec div 3600) mod 24;
    MM := (DiffSec div 60) mod 60;
    SS := DiffSec mod 60;

    lblAlertDays.Caption  := IntToStr(Days);
    lblAlertClock.Caption := Format('%.2d:%.2d:%.2d', [HH, MM, SS]);

    if Days <= 30 then ProgPct := Round(((30 - Days) / 30) * 100)
    else ProgPct := 0;

    if Assigned(pbAlert)  then pbAlert.Position     := ProgPct;
    if Assigned(shpAlert) then
      if Days <= 5 then shpAlert.Brush.Color := clRed
      else              shpAlert.Brush.Color := 2688217;

    // === Update IBS and IRG Alert Cards (Created via DFM) ===
    if Assigned(lblIBSAlertDays) then
    begin
      D20 := EncodeDate(YearOf(Now_), 5, 20);  // deadline May 20
      if Now_ > D20 then D20 := EncodeDate(YearOf(Now_) + 1, 5, 20);
      Days := Trunc(D20 - Now_);
      DiffSec := SecondsBetween(Now_, D20);
      HH := (DiffSec div 3600) mod 24;
      MM := (DiffSec div 60) mod 60;
      SS := DiffSec mod 60;

      lblIBSAlertDays.Caption := IntToStr(Days);
      if Assigned(lblIBSAlertClock) then
        lblIBSAlertClock.Caption := Format('%.2d:%.2d:%.2d', [HH, MM, SS]);

      if Days <= 90 then ProgPct := Round(((90 - Days) / 90) * 100) else ProgPct := 0;
      if Assigned(pbIBSAlert) then pbIBSAlert.Position := ProgPct;

      if Assigned(Shape7) then
        if Days <= 10 then Shape7.Brush.Color := clRed else Shape7.Brush.Color := $00F6823B;
    end;

    if Assigned(lblIRGAlertDays) then
    begin
      // Same logic for IRG
      lblIRGAlertDays.Caption := IntToStr(Days);
      if Assigned(lblIRGAlertClock) then
        lblIRGAlertClock.Caption := Format('%.2d:%.2d:%.2d', [HH, MM, SS]);

      if Assigned(pbIRGAlert) then pbIRGAlert.Position := ProgPct;

      if Assigned(Shape8) then
        if Days <= 10 then Shape8.Brush.Color := clRed else Shape8.Brush.Color := $000B9EF5;
    end;

    // Update clock in header
    if Assigned(lblHeaderTime) then
      lblHeaderTime.Caption := FormatDateTime('hh:nn:ss', Now_);

  except
   if Assigned(TimerDash) then
      TimerDash.Enabled := False
  end;
end;

end.
