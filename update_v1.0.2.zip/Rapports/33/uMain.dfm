object frmMain: TfrmMain
  Left = 0
  Top = 0
  Caption = 'Multi-Soci'#233't'#233's 2026'
  ClientHeight = 733
  ClientWidth = 1097
  Color = clWhite
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Menu = MainMenu1
  Position = poScreenCenter
  WindowState = wsMaximized
  OnActivate = FormActivate
  OnCloseQuery = FormCloseQuery
  OnCreate = FormCreate
  OnShow = FormShow
  TextHeight = 15
  object Label1: TLabel
    Left = 760
    Top = 616
    Width = 34
    Height = 15
    Caption = 'Label1'
    Visible = False
  end
  object Label2: TLabel
    Left = 19
    Top = 19
    Width = 176
    Height = 18
    Caption = 'B/ D'#233'ductions '#224' Op'#233'rer'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'Tahoma'
    Font.Style = [fsBold, fsUnderline]
    ParentFont = False
  end
  object StatusBar1: TStatusBar
    Left = 0
    Top = 699
    Width = 1097
    Height = 34
    Panels = <
      item
        Text = '  Aucune soci'#233't'#233' ouverte'
        Width = 600
      end
      item
        Width = 50
      end>
    ExplicitTop = 695
    ExplicitWidth = 1095
  end
  object cp: TCardPanel
    Left = 0
    Top = 35
    Width = 1097
    Height = 647
    Align = alClient
    ActiveCard = Card2
    Caption = 'CP'
    TabOrder = 1
    ExplicitWidth = 1095
    ExplicitHeight = 643
    object Card1: TCard
      Left = 1
      Top = 1
      Width = 1095
      Height = 645
      Caption = 'Card1'
      CardIndex = 0
      TabOrder = 0
      object pnlMain: TPanel
        Left = 0
        Top = 0
        Width = 1095
        Height = 645
        Align = alClient
        BevelOuter = bvNone
        Color = clWhite
        ParentBackground = False
        TabOrder = 0
        object lblWelcome: TLabel
          Left = 120
          Top = 116
          Width = 800
          Height = 40
          Alignment = taCenter
          AutoSize = False
          Caption = 'Bienvenue - Dec G50  2026'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clNavy
          Font.Height = -24
          Font.Name = 'Segoe UI Semibold'
          Font.Style = []
          ParentFont = False
        end
        object lblInfo: TLabel
          Left = 136
          Top = 186
          Width = 800
          Height = 60
          Alignment = taCenter
          AutoSize = False
          Caption = 
            'Utilisez le menu Fichier pour cr'#233'er ou ouvrir un dossier de soci' +
            #233't'#233'.'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clGray
          Font.Height = -14
          Font.Name = 'Segoe UI'
          Font.Style = []
          ParentFont = False
          WordWrap = True
        end
      end
    end
    object Card2: TCard
      Left = 1
      Top = 1
      Width = 1095
      Height = 645
      Caption = 'Card2'
      CardIndex = 1
      TabOrder = 1
      ExplicitWidth = 1093
      ExplicitHeight = 641
      object scPanel1: TscPanel
        Left = 0
        Top = 0
        Width = 1095
        Height = 645
        Align = alClient
        FluentUIOpaque = False
        TabOrder = 0
        CustomImageIndex = -1
        DragForm = False
        DragTopForm = True
        StyleKind = scpsPanel
        ShowCaption = False
        BorderStyle = scpbsBottomBevel
        WallpaperIndex = -1
        LightBorderColor = clBtnHighlight
        ShadowBorderColor = clBtnShadow
        CaptionGlowEffect.Enabled = False
        CaptionGlowEffect.Color = clBtnShadow
        CaptionGlowEffect.AlphaValue = 255
        CaptionGlowEffect.GlowSize = 7
        CaptionGlowEffect.Offset = 0
        CaptionGlowEffect.Intensive = True
        CaptionGlowEffect.StyleColors = True
        Color = clBtnFace
        Caption = 'scPanel1'
        StorePaintBuffer = False
        WordWrap = False
        ExplicitWidth = 1093
        ExplicitHeight = 641
        DesignSize = (
          1095
          645)
        object SpeedButton6: TSpeedButton
          Left = 1012
          Top = 252
          Width = 48
          Height = 30
          Anchors = [akTop, akRight]
          ImageIndex = 49
          Images = DM.Smal
          Flat = True
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = [fsBold]
          Layout = blGlyphTop
          Margin = 1
          ParentFont = False
          PressedImageIndex = 0
          Spacing = 0
          Transparent = False
          StyleName = 'clear day se'
          OnClick = Bg50Click
          ExplicitLeft = 1101
        end
        object Pg1: TscAdvancedPager
          Left = 113
          Top = 105
          Width = 982
          Height = 538
          Align = alClient
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
          FluentUIOpaque = False
          TabOrder = 0
          EnableDragReorderTabs = False
          TransparentBackground = False
          BorderStyle = scapbsFrame
          MouseWheelSupport = False
          ShowFocusRect = True
          ShowInActiveTab = True
          ShowCloseButtons = False
          TabsLeftOffset = 15
          TabsRightOffset = 15
          TabGlowEffect.Enabled = False
          TabGlowEffect.Color = clHighlight
          TabGlowEffect.AlphaValue = 255
          TabGlowEffect.GlowSize = 7
          TabGlowEffect.Offset = 0
          TabGlowEffect.Intensive = True
          TabGlowEffect.StyleColors = True
          TabGlowEffect.HotColor = clNone
          TabGlowEffect.PressedColor = clNone
          TabGlowEffect.FocusedColor = clNone
          TabGlowEffect.PressedGlowSize = 7
          TabGlowEffect.PressedAlphaValue = 255
          TabGlowEffect.States = [scsHot, scsPressed, scsFocused]
          WallpaperIndex = -1
          CustomBackgroundImageIndex = -1
          TabSpacing = 10
          TabMargin = 10
          ScrollButtonWidth = 15
          CustomOverContentImageIndex = -1
          TabHeight = 30
          Tabs = <
            item
              Page = scAdvancedPagerPage1
              Visible = True
              Enabled = True
              ImageIndex = -1
              Caption = 'D'#233'clarations G50'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage4
              Visible = False
              Enabled = True
              ImageIndex = -1
              Caption = 'Etat TVA'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage2
              Visible = True
              Enabled = True
              ImageIndex = -1
              Caption = 'IBS'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage7
              Visible = True
              Enabled = True
              ImageIndex = -1
              Caption = 'IRG'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage3
              Visible = True
              Enabled = True
              ImageIndex = -1
              Caption = 'TAPP-TFP'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage5
              Visible = True
              Enabled = True
              ImageIndex = -1
              Caption = 'Activit'#233' Pharma'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage6
              Visible = True
              Enabled = True
              ImageIndex = -1
              Caption = 'CA Station de Services'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage8
              Visible = True
              Enabled = True
              ImageIndex = -1
              Caption = 'Suivi des Encaissemnts'
              ShowCloseButton = True
            end
            item
              Page = scAdvancedPagerPage9
              Visible = False
              Enabled = True
              ImageIndex = -1
              Caption = 'TscAdvancedPagerTab9'
              ShowCloseButton = True
            end>
          TabIndex = 0
          ActivePage = scAdvancedPagerPage1
          StorePaintBuffer = False
          FreeOnClose = False
          ExplicitLeft = 288
          ExplicitTop = 216
          ExplicitWidth = 807
          ExplicitHeight = 427
          object scAdvancedPagerPage4: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1015
            Height = 437
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 3
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            object frxPreview1: TfrxPreview
              Left = 0
              Top = 49
              Width = 1015
              Height = 388
              Align = alClient
              FrameColor = clSilver
              OutlineVisible = False
              OutlineWidth = 120
              ThumbnailVisible = False
              FindFmVisible = False
              UseReportHints = False
              OutlineTreeSortType = dtsUnsorted
              HideScrolls = False
            end
            object Panel5: TPanel
              Left = 0
              Top = 0
              Width = 1015
              Height = 49
              Align = alTop
              TabOrder = 1
              DesignSize = (
                1015
                49)
              object SpeedButton8: TSpeedButton
                Left = 857
                Top = 5
                Width = 74
                Height = 41
                Anchors = [akTop, akRight]
                Caption = 'Exp PDF'
                ImageIndex = 80
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton8Click
              end
              object SpeedButton9: TSpeedButton
                Left = 941
                Top = 5
                Width = 74
                Height = 41
                Anchors = [akTop, akRight]
                Caption = 'Exp Etat'
                ImageIndex = 14
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = []
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = AdvGlowButton4Click
              end
              object SpeedButton12: TSpeedButton
                Left = 780
                Top = 5
                Width = 74
                Height = 41
                Anchors = [akTop, akRight]
                Caption = 'Imp Etat'
                ImageIndex = 11
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = []
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = AdvGlowButton2Click
              end
              object AdvGlowButton2: TAdvGlowButton
                Left = 586
                Top = 8
                Width = 49
                Height = 35
                Hint = 'Nouveau G50'
                Margins.Left = 0
                Margins.Right = 1
                ParentCustomHint = False
                Anchors = [akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Tahoma'
                Font.Style = []
                ImageIndex = 11
                Images = DM.Smal
                MarginVert = 0
                MarginHorz = 0
                NotesFont.Charset = DEFAULT_CHARSET
                NotesFont.Color = clWindowText
                NotesFont.Height = -11
                NotesFont.Name = 'Tahoma'
                NotesFont.Style = []
                ParentFont = False
                Rounded = True
                Spacing = -2
                ParentShowHint = False
                ShowHint = True
                TabOrder = 0
                Visible = False
                OnClick = AdvGlowButton2Click
                Appearance.BorderColor = 11382963
                Appearance.BorderColorHot = 11565130
                Appearance.BorderColorCheckedHot = 11565130
                Appearance.BorderColorDown = 11565130
                Appearance.BorderColorChecked = 13744549
                Appearance.BorderColorDisabled = 13948116
                Appearance.Color = clWhite
                Appearance.ColorTo = clWhite
                Appearance.ColorChecked = 13744549
                Appearance.ColorCheckedTo = 13744549
                Appearance.ColorDisabled = clWhite
                Appearance.ColorDisabledTo = clNone
                Appearance.ColorDown = 11565130
                Appearance.ColorDownTo = 11565130
                Appearance.ColorHot = 16444643
                Appearance.ColorHotTo = 16444643
                Appearance.ColorMirror = clWhite
                Appearance.ColorMirrorTo = clWhite
                Appearance.ColorMirrorHot = 16444643
                Appearance.ColorMirrorHotTo = 16444643
                Appearance.ColorMirrorDown = 11565130
                Appearance.ColorMirrorDownTo = 11565130
                Appearance.ColorMirrorChecked = 13744549
                Appearance.ColorMirrorCheckedTo = 13744549
                Appearance.ColorMirrorDisabled = clWhite
                Appearance.ColorMirrorDisabledTo = clNone
                Appearance.GradientHot = ggVertical
                Appearance.GradientMirrorHot = ggVertical
                Appearance.GradientDown = ggVertical
                Appearance.GradientMirrorDown = ggVertical
                Appearance.GradientChecked = ggVertical
                Appearance.TextColorChecked = 3750459
                Appearance.TextColorDown = 2303013
                Appearance.TextColorHot = 2303013
                Appearance.TextColorDisabled = 13948116
              end
              object AdvGlowButton4: TAdvGlowButton
                Left = 680
                Top = 8
                Width = 49
                Height = 35
                Hint = 'Nouveau G50'
                Margins.Left = 0
                Margins.Right = 1
                ParentCustomHint = False
                Anchors = [akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Tahoma'
                Font.Style = []
                ImageIndex = 14
                Images = DM.Smal
                MarginVert = 0
                MarginHorz = 0
                NotesFont.Charset = DEFAULT_CHARSET
                NotesFont.Color = clWindowText
                NotesFont.Height = -11
                NotesFont.Name = 'Tahoma'
                NotesFont.Style = []
                ParentFont = False
                Rounded = True
                Spacing = -2
                ParentShowHint = False
                ShowHint = True
                TabOrder = 1
                Visible = False
                OnClick = AdvGlowButton4Click
                Appearance.BorderColor = 11382963
                Appearance.BorderColorHot = 11565130
                Appearance.BorderColorCheckedHot = 11565130
                Appearance.BorderColorDown = 11565130
                Appearance.BorderColorChecked = 13744549
                Appearance.BorderColorDisabled = 13948116
                Appearance.Color = clWhite
                Appearance.ColorTo = clWhite
                Appearance.ColorChecked = 13744549
                Appearance.ColorCheckedTo = 13744549
                Appearance.ColorDisabled = clWhite
                Appearance.ColorDisabledTo = clNone
                Appearance.ColorDown = 11565130
                Appearance.ColorDownTo = 11565130
                Appearance.ColorHot = 16444643
                Appearance.ColorHotTo = 16444643
                Appearance.ColorMirror = clWhite
                Appearance.ColorMirrorTo = clWhite
                Appearance.ColorMirrorHot = 16444643
                Appearance.ColorMirrorHotTo = 16444643
                Appearance.ColorMirrorDown = 11565130
                Appearance.ColorMirrorDownTo = 11565130
                Appearance.ColorMirrorChecked = 13744549
                Appearance.ColorMirrorCheckedTo = 13744549
                Appearance.ColorMirrorDisabled = clWhite
                Appearance.ColorMirrorDisabledTo = clNone
                Appearance.GradientHot = ggVertical
                Appearance.GradientMirrorHot = ggVertical
                Appearance.GradientDown = ggVertical
                Appearance.GradientMirrorDown = ggVertical
                Appearance.GradientChecked = ggVertical
                Appearance.TextColorChecked = 3750459
                Appearance.TextColorDown = 2303013
                Appearance.TextColorHot = 2303013
                Appearance.TextColorDisabled = 13948116
              end
            end
          end
          object DBGridEh5: TDBGridEh
            Left = 5
            Top = 320
            Width = 932
            Height = 114
            DataSource = Form20.Dibs
            DrawMemoText = True
            DynProps = <>
            Flat = True
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -13
            Font.Name = 'Segoe UI'
            Font.Style = []
            FooterRowCount = 1
            FooterParams.FillStyle = cfstThemedEh
            FooterParams.Font.Charset = DEFAULT_CHARSET
            FooterParams.Font.Color = clWindowText
            FooterParams.Font.Height = -13
            FooterParams.Font.Name = 'Segoe UI'
            FooterParams.Font.Style = [fsBold]
            FooterParams.ParentFont = False
            FooterParams.RowHeight = 20
            GridLineParams.ColorScheme = glcsThemedEh
            GridLineParams.DataHorzColor = clBtnShadow
            GridLineParams.DataVertColor = clBtnShadow
            GridLineParams.GridBoundaries = True
            GridLineParams.VertEmptySpaceStyle = dessNonEh
            Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit]
            OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghDialogFind, dghColumnResize, dghColumnMove]
            ParentFont = False
            SumList.Active = True
            TabOrder = 7
            TitleParams.BorderInFillStyle = True
            TitleParams.HorzLineColor = clGradientActiveCaption
            TitleParams.MultiTitle = True
            TitleParams.RowHeight = 20
            TitleParams.RowLines = 2
            OnDblClick = SpeedButton24Click
            Columns = <
              item
                Alignment = taCenter
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Activit'#233'sproductionBase'
                Footers = <>
                Title.Caption = 'Base Activit'#233's Production'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Activit'#233'b'#226'timentBase'
                Footers = <>
                Title.Caption = 'Base Activit'#233' de b'#226'timent'
                Width = 100
              end
              item
                Alignment = taLeftJustify
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Activit'#233'scommerceBase'
                Footers = <>
                ShowImageAndText = True
                Title.Caption = 'Base Activit'#233's de commerce et de service'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Exc'#233'dentant'#233'rieur'
                Footers = <>
                Title.Caption = 'Exc'#233'dent de versement ant'#233'rieur'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Acompte1'
                Footer.ValueType = fvtSum
                Footers = <>
                Title.Caption = '1er acompte'
                Width = 100
              end
              item
                Alignment = taCenter
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Acompte2'
                Footer.FieldName = 'Tdeductions'
                Footers = <>
                Title.Caption = '2'#232'me acompte'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Acompte3'
                Footers = <>
                Title.Caption = '3'#232'me acompte'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Creditimp'#244't'
                Footers = <>
                Title.Caption = 'Cr'#233'dit d'#8217'imp'#244't '
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Montantglobald'#233'duire'
                Footers = <>
                Title.Caption = 'Montant global '#224' d'#233'duire'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Soldedeliquidation'
                Footers = <>
                Title.Caption = 'Solde de liquidation'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'Exc'#233'dentversement'
                Footers = <>
                Title.Caption = 'Exc'#233'dent de versemen'
                Width = 100
              end
              item
                CellButtons = <>
                DynProps = <>
                EditButtons = <>
                FieldName = 'MinimumImposition'
                Footers = <>
                Title.Caption = 'Minimum d'#8217'Impositio'
                Width = 100
              end>
            object RowDetailData: TRowDetailPanelControlEh
            end
          end
          object scAdvancedPagerPage9: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1180
            Height = 383
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 9
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
          end
          object scAdvancedPagerPage7: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1180
            Height = 457
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 6
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            DesignSize = (
              1180
              457)
            object Panel16: TPanel
              Left = 0
              Top = 0
              Width = 1180
              Height = 41
              Align = alTop
              Enabled = False
              TabOrder = 0
              object Panel17: TPanel
                Left = 9
                Top = 0
                Width = 128
                Height = 41
                BevelOuter = bvNone
                Enabled = False
                TabOrder = 0
              end
              object ExIrg: TscDBEdit
                Left = 639
                Top = 0
                Width = 116
                Height = 41
                FluentUIOpaque = False
                UseFontColorToStyleColor = False
                ContentMarginLeft = 0
                ContentMarginRight = 0
                ContentMarginTop = 0
                ContentMarginBottom = 0
                CustomBackgroundImageNormalIndex = -1
                CustomBackgroundImageHotIndex = -1
                CustomBackgroundImageDisabledIndex = -1
                PromptTextColor = clNone
                HideMaskWithEmptyText = False
                HidePromptTextIfFocused = False
                WallpaperIndex = -1
                LeftButton.ComboButton = False
                LeftButton.Enabled = True
                LeftButton.Visible = False
                LeftButton.ShowHint = False
                LeftButton.ShowEllipses = False
                LeftButton.StyleKind = scbsPushButton
                LeftButton.Width = 18
                LeftButton.ImageIndex = -1
                LeftButton.ImageHotIndex = -1
                LeftButton.ImagePressedIndex = -1
                LeftButton.RepeatClick = False
                LeftButton.RepeatClickInterval = 200
                LeftButton.CustomImageNormalIndex = -1
                LeftButton.CustomImageHotIndex = -1
                LeftButton.CustomImagePressedIndex = -1
                LeftButton.CustomImageDisabledIndex = -1
                RightButton.ComboButton = False
                RightButton.Enabled = True
                RightButton.Visible = False
                RightButton.ShowHint = False
                RightButton.ShowEllipses = False
                RightButton.StyleKind = scbsToolButtonTransparent
                RightButton.Width = 18
                RightButton.ImageIndex = -1
                RightButton.ImageHotIndex = -1
                RightButton.ImagePressedIndex = -1
                RightButton.RepeatClick = False
                RightButton.RepeatClickInterval = 200
                RightButton.CustomImageNormalIndex = -1
                RightButton.CustomImageHotIndex = -1
                RightButton.CustomImagePressedIndex = -1
                RightButton.CustomImageDisabledIndex = -1
                Transparent = True
                BorderKind = scebBottomActiveLine
                CustomDraw = False
                FrameColor = clNone
                FrameActiveColor = clHighlight
                Text = 'ExIrg'
                Alignment = taCenter
                AutoSelect = False
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -27
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                HideSelection = False
                ParentFont = False
                ReadOnly = True
                TabOrder = 1
                Visible = False
                DataField = 'Ann'#233'e'
                DataSource = Form20.DExercices
              end
              object scGPLabel4: TscGPLabel
                Left = 1
                Top = 1
                Width = 1178
                Height = 39
                Align = alClient
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBtnText
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = True
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 0
                FillColor = clNone
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 3
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                VertAlignment = scvtaCenter
                Caption = 'D'#233'claration IRG'
              end
            end
            object Panel18: TPanel
              Left = 0
              Top = 41
              Width = 1180
              Height = 416
              Align = alClient
              TabOrder = 1
              DesignSize = (
                1180
                416)
              object SpeedButton20: TSpeedButton
                Left = 1032
                Top = 47
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 15
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton20Click
                ExplicitLeft = 943
              end
              object SpeedButton21: TSpeedButton
                Left = 1032
                Top = 78
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 3
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton21Click
              end
              object SpeedButton22: TSpeedButton
                Left = 1032
                Top = 112
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 5
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton22Click
                ExplicitLeft = 943
              end
              object scGPLabel6: TscGPLabel
                Left = 1
                Top = 1
                Width = 1178
                Height = 40
                Align = alTop
                Font.Charset = DEFAULT_CHARSET
                Font.Color = -1
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                StyleName = 'copper'
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clSkyBlue
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                VertAlignment = scvtaCenter
                Caption = 'Acomptes'
              end
              object DBGridEh2: TDBGridEh
                Left = 5
                Top = 47
                Width = 1021
                Height = 173
                Anchors = [akLeft, akTop, akRight, akBottom]
                Color = clInactiveBorder
                DataSource = Form20.DacompteIRG
                DrawMemoText = True
                DynProps = <>
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -13
                Font.Name = 'Segoe UI'
                Font.Style = []
                FooterRowCount = 1
                FooterParams.FillStyle = cfstThemedEh
                FooterParams.Font.Charset = DEFAULT_CHARSET
                FooterParams.Font.Color = clWindowText
                FooterParams.Font.Height = -13
                FooterParams.Font.Name = 'Segoe UI'
                FooterParams.Font.Style = [fsBold]
                FooterParams.ParentFont = False
                FooterParams.RowHeight = 20
                GridLineParams.ColorScheme = glcsThemedEh
                GridLineParams.DataHorzColor = clBtnShadow
                GridLineParams.DataVertColor = clBtnShadow
                GridLineParams.GridBoundaries = True
                GridLineParams.VertEmptySpaceStyle = dessNonEh
                Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
                OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghDialogFind, dghColumnResize, dghColumnMove]
                ParentFont = False
                SumList.Active = True
                TabOrder = 1
                TitleParams.BorderInFillStyle = True
                TitleParams.HorzLineColor = clGradientActiveCaption
                TitleParams.MultiTitle = True
                TitleParams.RowHeight = 20
                TitleParams.RowLines = 2
                OnDblClick = SpeedButton18Click
                Columns = <
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'code'
                    Footers = <>
                    Title.Caption = 'Code'
                    Width = 60
                  end
                  item
                    Alignment = taLeftJustify
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'impots'
                    Footers = <>
                    ShowImageAndText = True
                    Title.Caption = 'Op'#233'rations imposables'
                    Width = 500
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Revenusimposables'
                    Footer.ValueType = fvtSum
                    Footers = <>
                    Title.Caption = 'Base Imposable'
                    Width = 130
                  end
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'taux'
                    Footers = <>
                    Title.Caption = 'Taux '
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'droits'
                    Footer.ValueType = fvtSum
                    Footers = <>
                    Width = 120
                  end>
                object RowDetailData: TRowDetailPanelControlEh
                end
              end
              object DBacompte1: TDBEdit
                Left = 943
                Top = 148
                Width = 121
                Height = 23
                DataField = 'impots'
                DataSource = Form20.DacompteIRG
                TabOrder = 2
                Visible = False
              end
            end
            object Panel19: TPanel
              Left = 0
              Top = 247
              Width = 1180
              Height = 210
              Anchors = [akLeft, akTop, akRight, akBottom]
              TabOrder = 2
              DesignSize = (
                1180
                210)
              object SpeedButton26: TSpeedButton
                Left = 1017
                Top = 47
                Width = 50
                Height = 30
                ImageIndex = 15
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                Visible = False
                StyleName = 'clear day se'
                OnClick = SpeedButton26Click
              end
              object SpeedButton27: TSpeedButton
                Left = 1048
                Top = 47
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 3
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton27Click
                ExplicitLeft = 959
              end
              object SpeedButton28: TSpeedButton
                Left = 1048
                Top = 83
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 5
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton28Click
                ExplicitLeft = 959
              end
              object SpeedButton30: TSpeedButton
                Left = 1048
                Top = 119
                Width = 41
                Height = 29
                Anchors = [akTop, akRight]
                ImageIndex = 13
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 11
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton30Click
                ExplicitLeft = 959
              end
              object scGPLabel7: TscGPLabel
                Left = 1
                Top = 1
                Width = 1178
                Height = 39
                Align = alTop
                Font.Charset = DEFAULT_CHARSET
                Font.Color = -1
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                StyleName = 'copper'
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clSkyBlue
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                VertAlignment = scvtaCenter
                Caption = 'Solde'
              end
              object Button1: TButton
                Left = 1015
                Top = 72
                Width = 75
                Height = 25
                Caption = 'Bibs'
                TabOrder = 1
              end
              object DBGridEh6: TDBGridEh
                Left = 5
                Top = 47
                Width = 1021
                Height = 157
                Anchors = [akLeft, akTop, akRight, akBottom]
                DataSource = Form20.Dirg
                DrawMemoText = True
                DynProps = <>
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -13
                Font.Name = 'Segoe UI'
                Font.Style = []
                FooterRowCount = 1
                FooterParams.FillStyle = cfstThemedEh
                FooterParams.Font.Charset = DEFAULT_CHARSET
                FooterParams.Font.Color = clWindowText
                FooterParams.Font.Height = -13
                FooterParams.Font.Name = 'Segoe UI'
                FooterParams.Font.Style = [fsBold]
                FooterParams.ParentFont = False
                FooterParams.RowHeight = 20
                GridLineParams.ColorScheme = glcsThemedEh
                GridLineParams.DataHorzColor = clBtnShadow
                GridLineParams.DataVertColor = clBtnShadow
                GridLineParams.GridBoundaries = True
                GridLineParams.VertEmptySpaceStyle = dessNonEh
                Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
                OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghDialogFind, dghColumnResize, dghColumnMove]
                ParentFont = False
                SumList.Active = True
                TabOrder = 2
                TitleParams.BorderInFillStyle = True
                TitleParams.HorzLineColor = clGradientActiveCaption
                TitleParams.MultiTitle = True
                TitleParams.RowHeight = 20
                TitleParams.RowLines = 2
                OnDblClick = SpeedButton27Click
                Columns = <
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'R'#233'sultat_taxable'
                    Footers = <>
                    Title.Caption = 'R'#233'sultat taxable'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Acompte1'
                    Footer.ValueType = fvtSum
                    Footers = <>
                    Title.Caption = '1er acompte'
                    Width = 100
                  end
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Acompte2'
                    Footer.FieldName = 'Tdeductions'
                    Footers = <>
                    Title.Caption = '2'#232'me acompte'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Credit_imp'#244't'
                    Footers = <>
                    Title.Caption = 'Cr'#233'dit d'#8217'imp'#244't '
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Montantglobald'#233'duire'
                    Footers = <>
                    Title.Caption = 'Montant global '#224' d'#233'duire'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Soldedeliquidation'
                    Footers = <>
                    Title.Caption = 'Solde de liquidation'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Exc'#233'dentversement'
                    Footers = <>
                    Title.Caption = 'Exc'#233'dent de versemen'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'ilm'
                    Footers = <>
                    Title.Caption = 'Minimum d'#8217'Impositio'
                    Width = 100
                  end>
                object RowDetailData: TRowDetailPanelControlEh
                end
              end
            end
          end
          object scAdvancedPagerPage3: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1091
            Height = 366
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 2
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            DesignSize = (
              1091
              366)
            object SpeedButton32: TSpeedButton
              Left = 1050
              Top = 87
              Width = 50
              Height = 30
              Anchors = [akTop, akRight]
              ImageIndex = 3
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton32Click
            end
            object SpeedButton33: TSpeedButton
              Left = 1050
              Top = 123
              Width = 50
              Height = 30
              Anchors = [akTop, akRight]
              ImageIndex = 5
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton33Click
            end
            object SpeedButton34: TSpeedButton
              Left = 1050
              Top = 167
              Width = 41
              Height = 29
              Anchors = [akTop, akRight]
              ImageIndex = 13
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 11
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton34Click
            end
            object SpeedButton31: TSpeedButton
              Left = 1050
              Top = 55
              Width = 50
              Height = 30
              Anchors = [akTop, akRight]
              ImageIndex = 15
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton31Click
            end
            object Panel22: TPanel
              Left = 0
              Top = 0
              Width = 1091
              Height = 39
              Align = alTop
              Enabled = False
              TabOrder = 0
              object Panel23: TPanel
                Left = 9
                Top = 0
                Width = 128
                Height = 41
                BevelOuter = bvNone
                Enabled = False
                TabOrder = 0
              end
              object scDBEdit1: TscDBEdit
                Left = 639
                Top = 0
                Width = 116
                Height = 41
                FluentUIOpaque = False
                UseFontColorToStyleColor = False
                ContentMarginLeft = 0
                ContentMarginRight = 0
                ContentMarginTop = 0
                ContentMarginBottom = 0
                CustomBackgroundImageNormalIndex = -1
                CustomBackgroundImageHotIndex = -1
                CustomBackgroundImageDisabledIndex = -1
                PromptTextColor = clNone
                HideMaskWithEmptyText = False
                HidePromptTextIfFocused = False
                WallpaperIndex = -1
                LeftButton.ComboButton = False
                LeftButton.Enabled = True
                LeftButton.Visible = False
                LeftButton.ShowHint = False
                LeftButton.ShowEllipses = False
                LeftButton.StyleKind = scbsPushButton
                LeftButton.Width = 18
                LeftButton.ImageIndex = -1
                LeftButton.ImageHotIndex = -1
                LeftButton.ImagePressedIndex = -1
                LeftButton.RepeatClick = False
                LeftButton.RepeatClickInterval = 200
                LeftButton.CustomImageNormalIndex = -1
                LeftButton.CustomImageHotIndex = -1
                LeftButton.CustomImagePressedIndex = -1
                LeftButton.CustomImageDisabledIndex = -1
                RightButton.ComboButton = False
                RightButton.Enabled = True
                RightButton.Visible = False
                RightButton.ShowHint = False
                RightButton.ShowEllipses = False
                RightButton.StyleKind = scbsToolButtonTransparent
                RightButton.Width = 18
                RightButton.ImageIndex = -1
                RightButton.ImageHotIndex = -1
                RightButton.ImagePressedIndex = -1
                RightButton.RepeatClick = False
                RightButton.RepeatClickInterval = 200
                RightButton.CustomImageNormalIndex = -1
                RightButton.CustomImageHotIndex = -1
                RightButton.CustomImagePressedIndex = -1
                RightButton.CustomImageDisabledIndex = -1
                Transparent = True
                BorderKind = scebBottomActiveLine
                CustomDraw = False
                FrameColor = clNone
                FrameActiveColor = clHighlight
                Text = 'scDBEdit1'
                Alignment = taCenter
                AutoSelect = False
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -27
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                HideSelection = False
                ParentFont = False
                ReadOnly = True
                TabOrder = 1
                Visible = False
                DataField = 'Ann'#233'e'
                DataSource = Form20.DExercices
              end
              object scGPLabel20: TscGPLabel
                Left = 1
                Top = 1
                Width = 1089
                Height = 37
                Align = alClient
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBtnText
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = True
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 0
                FillColor = clNone
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 3
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                VertAlignment = scvtaCenter
                Caption = 'D'#233'claration  TAPP-TFP'
              end
            end
            object DBGridEh7: TDBGridEh
              Left = 13
              Top = 55
              Width = 1031
              Height = 289
              Anchors = [akLeft, akTop, akRight, akBottom]
              DataSource = Form20.DTTAPP
              DrawMemoText = True
              DynProps = <>
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -13
              Font.Name = 'Segoe UI'
              Font.Style = []
              FooterRowCount = 1
              FooterParams.FillStyle = cfstThemedEh
              FooterParams.Font.Charset = DEFAULT_CHARSET
              FooterParams.Font.Color = clWindowText
              FooterParams.Font.Height = -13
              FooterParams.Font.Name = 'Segoe UI'
              FooterParams.Font.Style = [fsBold]
              FooterParams.ParentFont = False
              FooterParams.RowHeight = 20
              GridLineParams.ColorScheme = glcsThemedEh
              GridLineParams.DataHorzColor = clBtnShadow
              GridLineParams.DataVertColor = clBtnShadow
              GridLineParams.GridBoundaries = True
              GridLineParams.VertEmptySpaceStyle = dessNonEh
              Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
              OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghDialogFind, dghColumnResize, dghColumnMove]
              ParentFont = False
              SumList.Active = True
              TabOrder = 1
              TitleParams.BorderInFillStyle = True
              TitleParams.HorzLineColor = clGradientActiveCaption
              TitleParams.MultiTitle = True
              TitleParams.RowHeight = 20
              TitleParams.RowLines = 2
              OnDblClick = SpeedButton32Click
              Columns = <
                item
                  Alignment = taCenter
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'ClientExercice'
                  Footers = <>
                  Title.Caption = 'Semestre'
                  Width = 120
                end
                item
                  Alignment = taCenter
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Exercice'
                  Footers = <>
                  Title.Caption = 'Ann'#233'e'
                  Width = 100
                end
                item
                  Alignment = taCenter
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'NbreSalaries'
                  Footer.FieldName = 'TotalANNEXE2'
                  Footers = <>
                  Title.Caption = 'Nbre Salaries'
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'MasseSalaire'
                  Footers = <>
                  Title.Caption = 'Masse Salairiale globale'
                  Width = 120
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TotalANNEXE2'
                  Footers = <>
                  Title.Caption = 'Total Anexe II'
                  Width = 120
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TotalANNEXE3'
                  Footers = <>
                  Title.Caption = 'Total Anexe III'
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'RatioTAPP'
                  Footers = <>
                  Width = 120
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'RatioTF'
                  Footers = <>
                  Width = 120
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TauxTAAP'
                  Footers = <>
                  Title.Caption = 'Taux TAPP'
                  Width = 120
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TauxTF'
                  Footers = <>
                  Title.Caption = 'Taux TF'
                  Width = 120
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Totaldroits'
                  Footers = <>
                  Title.Caption = 'Total  droits'
                end>
              object RowDetailData: TRowDetailPanelControlEh
              end
            end
          end
          object scAdvancedPagerPage8: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1091
            Height = 366
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 8
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            object Panel28: TPanel
              Left = 0
              Top = 0
              Width = 1091
              Height = 39
              Align = alTop
              TabOrder = 0
              object Panel30: TPanel
                Left = 9
                Top = 0
                Width = 128
                Height = 41
                BevelOuter = bvNone
                Enabled = False
                TabOrder = 0
              end
              object scGPLabel16: TscGPLabel
                Left = 1
                Top = 1
                Width = 1089
                Height = 37
                Align = alClient
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBtnText
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = True
                TabOrder = 1
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 0
                FillColor = clNone
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 3
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                VertAlignment = scvtaCenter
                Caption = 
                  'Suivi des Encaissements des Clients : Activit'#233'  de Promotion imm' +
                  'obiliere'
              end
            end
            object DBGridEh9: TDBGridEh
              Left = 0
              Top = 80
              Width = 1091
              Height = 286
              Align = alClient
              DataSource = Form20.DEncaissements
              DynProps = <>
              FooterRowCount = 1
              FooterParams.FillStyle = cfstThemedEh
              FooterParams.Font.Charset = DEFAULT_CHARSET
              FooterParams.Font.Color = clWindowText
              FooterParams.Font.Height = -12
              FooterParams.Font.Name = 'Segoe UI'
              FooterParams.Font.Style = [fsBold]
              FooterParams.ParentFont = False
              FooterParams.RowHeight = 15
              FooterParams.RowLines = 1
              GridLineParams.GridBoundaries = True
              IndicatorOptions = [gioShowRowIndicatorEh, gioShowRecNoEh]
              Options = [dgTitles, dgIndicator, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
              OptionsEh = [dghFixed3D, dghHighlightFocus, dghEnterAsTab, dghRowHighlight, dghDialogFind, dghShowRecNo, dghExtendVertLines]
              SumList.Active = True
              TabOrder = 1
              TitleParams.FillStyle = cfstThemedEh
              TitleParams.MultiTitle = True
              OnDblClick = SpeedButton401Click
              Columns = <
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'DateOP'
                  Footers = <>
                  Title.Caption = 'Date Vers'
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Annee'
                  Footers = <>
                  Visible = False
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Client'
                  Footer.ValueType = fvtCount
                  Footers = <>
                  Width = 300
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'MontantTTC'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  ReadOnly = True
                  Title.Caption = 'Montant TTC'
                  Width = 110
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TauxTva'
                  Footers = <>
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TVA'
                  Footers = <>
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'HT'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'ModeReg'
                  Footers = <>
                  Title.Caption = 'Mode de Reglement'
                  Width = 150
                end
                item
                  Alignment = taCenter
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Projet'
                  Footers = <>
                  Width = 200
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'obs'
                  Footers = <>
                  ReadOnly = True
                  Title.Caption = 'Obs'
                  Width = 300
                end>
              object RowDetailData: TRowDetailPanelControlEh
              end
            end
            object Panel32: TPanel
              Left = 0
              Top = 80
              Width = 1091
              Height = 0
              Align = alTop
              TabOrder = 2
              Visible = False
              DesignSize = (
                1091
                0)
              object SpeedButton55: TSpeedButton
                Left = -133
                Top = 5
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 5
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton33Click
                ExplicitLeft = 142
              end
              object SpeedButton51: TSpeedButton
                Left = 1017
                Top = 5
                Width = 66
                Height = 30
                Hint = 'Projets'
                ImageIndex = 78
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 72
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton51Click
              end
            end
            object Panel31: TPanel
              Left = 0
              Top = 39
              Width = 1091
              Height = 41
              Align = alTop
              TabOrder = 3
              DesignSize = (
                1091
                41)
              object SpeedButton54: TSpeedButton
                Left = 157
                Top = 7
                Width = 66
                Height = 30
                ImageIndex = 5
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton54Click
              end
              object SpeedButton56: TSpeedButton
                Left = 229
                Top = 8
                Width = 50
                Height = 29
                ImageIndex = 13
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 11
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton56Click
              end
              object SpeedButton401: TSpeedButton
                Left = 77
                Top = 7
                Width = 66
                Height = 30
                ImageIndex = 3
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton401Click
              end
              object SpeedButton38: TSpeedButton
                Left = 5
                Top = 7
                Width = 66
                Height = 30
                ImageIndex = 15
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton381Click
              end
              object SpeedButton40: TSpeedButton
                Left = 1029
                Top = 5
                Width = 54
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 78
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 72
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton40Click
              end
              object SearchBox2: TSearchBox
                Left = 449
                Top = 6
                Width = 216
                Height = 24
                Anchors = [akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -13
                Font.Name = 'Tahoma'
                Font.Style = []
                ParentFont = False
                TabOrder = 0
                TextHint = 'Recherche Client'
                OnChange = SearchBox2Change
              end
              object boxProj: TscDBLookupComboBox
                Left = 671
                Top = 6
                Width = 257
                Height = 23
                Anchors = [akTop, akRight]
                KeyField = 'Projet'
                ListField = 'Projet'
                ListFieldIndex = -1
                ListSource = Form20.Dproj
                TabOrder = 1
                SelectionStyle = scstColor
                OnCloseUp = boxProjCloseUp
              end
              object scGPCheckBox1: TscGPCheckBox
                Left = 934
                Top = 0
                Width = 100
                Height = 35
                Anchors = [akTop, akRight]
                FluentUIOpaque = False
                TabOrder = 2
                TabStop = True
                OnClick = scGPCheckBox1Click
                Animation = False
                Caption = 'D'#233'ctiver filter'
                CanFocused = True
                Spacing = 1
                Layout = blGlyphLeft
                ImageIndex = -1
                GlowEffect.Enabled = False
                GlowEffect.Color = clHighlight
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                GlowEffect.HotColor = clNone
                GlowEffect.PressedColor = clNone
                GlowEffect.FocusedColor = clNone
                GlowEffect.PressedGlowSize = 7
                GlowEffect.PressedAlphaValue = 255
                GlowEffect.States = [scsHot, scsPressed, scsFocused]
                ImageGlow = True
                DrawTextMode = scdtmGDI
                DisabledFontColor = clNone
                Options.NormalColor = clWindow
                Options.HotColor = clWindow
                Options.PressedColor = clWindow
                Options.DisabledColor = clWindow
                Options.NormalColorAlpha = 255
                Options.HotColorAlpha = 255
                Options.PressedColorAlpha = 200
                Options.DisabledColorAlpha = 125
                Options.FrameNormalColor = clBtnShadow
                Options.FrameHotColor = clHighlight
                Options.FramePressedColor = clHighlight
                Options.FrameDisabledColor = clBtnShadow
                Options.FrameWidth = 2
                Options.FrameNormalColorAlpha = 255
                Options.FrameHotColorAlpha = 255
                Options.FramePressedColorAlpha = 255
                Options.FrameDisabledColorAlpha = 255
                Options.CheckMarkNormalColor = clWindowText
                Options.CheckMarkHotColor = clWindowText
                Options.CheckMarkPressedColor = clWindowText
                Options.CheckMarkDisabledColor = clWindowText
                Options.CheckMarkNormalColorAlpha = 255
                Options.CheckMarkHotColorAlpha = 255
                Options.CheckMarkPressedColorAlpha = 255
                Options.CheckMarkDisabledColorAlpha = 125
                Options.ShapeSize = 20
                Options.ShapeCornerRadius = 0
                Options.CheckMarkThickness = 2
                Options.StyleColors = True
                OptionsChecked.NormalColor = clWindow
                OptionsChecked.HotColor = clWindow
                OptionsChecked.PressedColor = clWindow
                OptionsChecked.DisabledColor = clWindow
                OptionsChecked.NormalColorAlpha = 255
                OptionsChecked.HotColorAlpha = 255
                OptionsChecked.PressedColorAlpha = 200
                OptionsChecked.DisabledColorAlpha = 125
                OptionsChecked.FrameNormalColor = clBtnShadow
                OptionsChecked.FrameHotColor = clHighlight
                OptionsChecked.FramePressedColor = clHighlight
                OptionsChecked.FrameDisabledColor = clBtnShadow
                OptionsChecked.FrameWidth = 2
                OptionsChecked.FrameNormalColorAlpha = 255
                OptionsChecked.FrameHotColorAlpha = 255
                OptionsChecked.FramePressedColorAlpha = 255
                OptionsChecked.FrameDisabledColorAlpha = 255
                OptionsChecked.CheckMarkNormalColor = clWindowText
                OptionsChecked.CheckMarkHotColor = clWindowText
                OptionsChecked.CheckMarkPressedColor = clWindowText
                OptionsChecked.CheckMarkDisabledColor = clWindowText
                OptionsChecked.CheckMarkNormalColorAlpha = 255
                OptionsChecked.CheckMarkHotColorAlpha = 255
                OptionsChecked.CheckMarkPressedColorAlpha = 255
                OptionsChecked.CheckMarkDisabledColorAlpha = 125
                OptionsChecked.ShapeSize = 20
                OptionsChecked.ShapeCornerRadius = 0
                OptionsChecked.CheckMarkThickness = 2
                OptionsChecked.StyleColors = True
                Checked = False
                ScaleFrameWidth = True
                ScaleCheckMarkThickness = True
                ShowFocusRect = True
                UseFontColorToStyleColor = False
              end
            end
          end
          object scAdvancedPagerPage2: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1091
            Height = 366
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 1
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            object Panel11: TPanel
              Left = 0
              Top = 0
              Width = 1091
              Height = 41
              Align = alTop
              Enabled = False
              TabOrder = 0
              object Panel15: TPanel
                Left = 9
                Top = 0
                Width = 128
                Height = 41
                BevelOuter = bvNone
                Enabled = False
                TabOrder = 0
              end
              object ExIBS: TscDBEdit
                Left = 639
                Top = 0
                Width = 116
                Height = 41
                FluentUIOpaque = False
                UseFontColorToStyleColor = False
                ContentMarginLeft = 0
                ContentMarginRight = 0
                ContentMarginTop = 0
                ContentMarginBottom = 0
                CustomBackgroundImageNormalIndex = -1
                CustomBackgroundImageHotIndex = -1
                CustomBackgroundImageDisabledIndex = -1
                PromptTextColor = clNone
                HideMaskWithEmptyText = False
                HidePromptTextIfFocused = False
                WallpaperIndex = -1
                LeftButton.ComboButton = False
                LeftButton.Enabled = True
                LeftButton.Visible = False
                LeftButton.ShowHint = False
                LeftButton.ShowEllipses = False
                LeftButton.StyleKind = scbsPushButton
                LeftButton.Width = 18
                LeftButton.ImageIndex = -1
                LeftButton.ImageHotIndex = -1
                LeftButton.ImagePressedIndex = -1
                LeftButton.RepeatClick = False
                LeftButton.RepeatClickInterval = 200
                LeftButton.CustomImageNormalIndex = -1
                LeftButton.CustomImageHotIndex = -1
                LeftButton.CustomImagePressedIndex = -1
                LeftButton.CustomImageDisabledIndex = -1
                RightButton.ComboButton = False
                RightButton.Enabled = True
                RightButton.Visible = False
                RightButton.ShowHint = False
                RightButton.ShowEllipses = False
                RightButton.StyleKind = scbsToolButtonTransparent
                RightButton.Width = 18
                RightButton.ImageIndex = -1
                RightButton.ImageHotIndex = -1
                RightButton.ImagePressedIndex = -1
                RightButton.RepeatClick = False
                RightButton.RepeatClickInterval = 200
                RightButton.CustomImageNormalIndex = -1
                RightButton.CustomImageHotIndex = -1
                RightButton.CustomImagePressedIndex = -1
                RightButton.CustomImageDisabledIndex = -1
                Transparent = True
                BorderKind = scebBottomActiveLine
                CustomDraw = False
                FrameColor = clNone
                FrameActiveColor = clHighlight
                Text = 'ExIBS'
                Alignment = taCenter
                AutoSelect = False
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -27
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                HideSelection = False
                ParentFont = False
                ReadOnly = True
                TabOrder = 1
                Visible = False
                DataField = 'Ann'#233'e'
                DataSource = Form20.DExercices
              end
              object scGPLabel2: TscGPLabel
                Left = 1
                Top = 1
                Width = 500
                Height = 39
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBtnText
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = True
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 0
                FillColor = clNone
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 3
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                VertAlignment = scvtaCenter
                Caption = 'D'#233'claration IBS'
              end
            end
            object Panel13: TPanel
              Left = 0
              Top = 231
              Width = 1091
              Height = 135
              Align = alBottom
              Anchors = [akLeft, akTop, akRight, akBottom]
              TabOrder = 1
              DesignSize = (
                1091
                135)
              object SpeedButton23: TSpeedButton
                Left = 1029
                Top = 103
                Width = 50
                Height = 30
                ImageIndex = 15
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                Visible = False
                StyleName = 'clear day se'
                OnClick = SpeedButton23Click
              end
              object SpeedButton29: TSpeedButton
                Left = 1016
                Top = 111
                Width = 41
                Height = 29
                Anchors = [akTop, akRight]
                ImageIndex = 13
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 11
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton29Click
              end
              object SpeedButton25: TSpeedButton
                Left = 1014
                Top = 75
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 5
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton25Click
              end
              object SpeedButton24: TSpeedButton
                Left = 1014
                Top = 39
                Width = 50
                Height = 30
                Anchors = [akTop, akRight]
                ImageIndex = 3
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton24Click
              end
              object scGPLabel22: TscGPLabel
                Left = 1
                Top = 1
                Width = 1089
                Height = 32
                Align = alTop
                Font.Charset = DEFAULT_CHARSET
                Font.Color = -1
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                StyleName = 'copper'
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clSkyBlue
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                VertAlignment = scvtaCenter
                Caption = 'Solde'
              end
              object bibs: TButton
                Left = 1015
                Top = 72
                Width = 75
                Height = 25
                Caption = 'Bibs'
                TabOrder = 1
                Visible = False
              end
              object DBGridEh3: TDBGridEh
                Left = 5
                Top = 39
                Width = 1005
                Height = 82
                Anchors = [akLeft, akTop, akRight, akBottom]
                DataSource = Form20.Dibs
                DrawMemoText = True
                DynProps = <>
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -13
                Font.Name = 'Segoe UI'
                Font.Style = []
                FooterRowCount = 1
                FooterParams.FillStyle = cfstThemedEh
                FooterParams.Font.Charset = DEFAULT_CHARSET
                FooterParams.Font.Color = clWindowText
                FooterParams.Font.Height = -13
                FooterParams.Font.Name = 'Segoe UI'
                FooterParams.Font.Style = [fsBold]
                FooterParams.ParentFont = False
                FooterParams.RowHeight = 20
                GridLineParams.ColorScheme = glcsThemedEh
                GridLineParams.DataHorzColor = clBtnShadow
                GridLineParams.DataVertColor = clBtnShadow
                GridLineParams.GridBoundaries = True
                GridLineParams.VertEmptySpaceStyle = dessNonEh
                Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
                OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghDialogFind, dghColumnResize, dghColumnMove]
                ParentFont = False
                SumList.Active = True
                TabOrder = 2
                TitleParams.BorderInFillStyle = True
                TitleParams.HorzLineColor = clGradientActiveCaption
                TitleParams.MultiTitle = True
                TitleParams.RowHeight = 20
                TitleParams.RowLines = 2
                OnDblClick = SpeedButton24Click
                Columns = <
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Activit'#233'sproductionBase'
                    Footers = <>
                    Title.Caption = 'Base Activit'#233's Production'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Activit'#233'b'#226'timentBase'
                    Footers = <>
                    Title.Caption = 'Base Activit'#233' de b'#226'timent'
                    Width = 100
                  end
                  item
                    Alignment = taLeftJustify
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Activit'#233'scommerceBase'
                    Footers = <>
                    ShowImageAndText = True
                    Title.Caption = 'Base Activit'#233's de commerce et de service'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Exc'#233'dentant'#233'rieur'
                    Footers = <>
                    Title.Caption = 'Exc'#233'dent de versement ant'#233'rieur'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Acompte1'
                    Footer.ValueType = fvtSum
                    Footers = <>
                    Title.Caption = '1er acompte'
                    Width = 100
                  end
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Acompte2'
                    Footer.FieldName = 'Tdeductions'
                    Footers = <>
                    Title.Caption = '2'#232'me acompte'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Acompte3'
                    Footers = <>
                    Title.Caption = '3'#232'me acompte'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Creditimp'#244't'
                    Footers = <>
                    Title.Caption = 'Cr'#233'dit d'#8217'imp'#244't '
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Montantglobald'#233'duire'
                    Footers = <>
                    Title.Caption = 'Montant global '#224' d'#233'duire'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Soldedeliquidation'
                    Footers = <>
                    Title.Caption = 'Solde de liquidation'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Exc'#233'dentversement'
                    Footers = <>
                    Title.Caption = 'Exc'#233'dent de versemen'
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'MinimumImposition'
                    Footers = <>
                    Title.Caption = 'Minimum d'#8217'Impositio'
                    Width = 100
                  end>
                object RowDetailData: TRowDetailPanelControlEh
                end
              end
            end
            object Panel14: TPanel
              Left = 0
              Top = 41
              Width = 1091
              Height = 184
              Align = alTop
              TabOrder = 2
              DesignSize = (
                1091
                184)
              object SpeedButton17: TSpeedButton
                Left = 959
                Top = 47
                Width = 50
                Height = 30
                ImageIndex = 15
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton17Click
              end
              object SpeedButton18: TSpeedButton
                Left = 959
                Top = 83
                Width = 50
                Height = 30
                ImageIndex = 3
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton18Click
              end
              object SpeedButton19: TSpeedButton
                Left = 959
                Top = 119
                Width = 50
                Height = 30
                ImageIndex = 5
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton19Click
              end
              object scGPLabel3: TscGPLabel
                Left = 2
                Top = 2
                Width = 1085
                Height = 23
                Anchors = [akLeft, akTop, akRight, akBottom]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = -1
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                StyleName = 'copper'
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clSkyBlue
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                VertAlignment = scvtaCenter
                Caption = 'Acomptes'
              end
              object DBGridEh1: TDBGridEh
                Left = 5
                Top = 47
                Width = 932
                Height = 130
                Color = clInactiveBorder
                DataSource = Form20.DacompteIBS
                DrawMemoText = True
                DynProps = <>
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -13
                Font.Name = 'Segoe UI'
                Font.Style = []
                FooterRowCount = 1
                FooterParams.FillStyle = cfstThemedEh
                FooterParams.Font.Charset = DEFAULT_CHARSET
                FooterParams.Font.Color = clWindowText
                FooterParams.Font.Height = -13
                FooterParams.Font.Name = 'Segoe UI'
                FooterParams.Font.Style = [fsBold]
                FooterParams.ParentFont = False
                FooterParams.RowHeight = 20
                GridLineParams.ColorScheme = glcsThemedEh
                GridLineParams.DataHorzColor = clBtnShadow
                GridLineParams.DataVertColor = clBtnShadow
                GridLineParams.GridBoundaries = True
                GridLineParams.VertEmptySpaceStyle = dessNonEh
                Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
                OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghDialogFind, dghColumnResize, dghColumnMove]
                ParentFont = False
                SumList.Active = True
                TabOrder = 1
                TitleParams.BorderInFillStyle = True
                TitleParams.HorzLineColor = clGradientActiveCaption
                TitleParams.MultiTitle = True
                TitleParams.RowHeight = 20
                TitleParams.RowLines = 2
                OnDblClick = SpeedButton18Click
                Columns = <
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'code'
                    Footers = <>
                    Title.Caption = 'Code'
                    Width = 60
                  end
                  item
                    Alignment = taLeftJustify
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'impots'
                    Footers = <>
                    ShowImageAndText = True
                    Title.Caption = 'Op'#233'rations imposables'
                    Width = 500
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'Revenusimposables'
                    Footer.ValueType = fvtSum
                    Footers = <>
                    Title.Caption = 'Base Imposable'
                    Width = 130
                  end
                  item
                    Alignment = taCenter
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'taux'
                    Footers = <>
                    Title.Caption = 'Taux '
                    Width = 100
                  end
                  item
                    CellButtons = <>
                    DynProps = <>
                    EditButtons = <>
                    FieldName = 'droits'
                    Footer.ValueType = fvtSum
                    Footers = <>
                    Width = 120
                  end>
                object RowDetailData: TRowDetailPanelControlEh
                end
              end
              object DBacompte: TDBEdit
                Left = 1032
                Top = 46
                Width = 121
                Height = 23
                DataField = 'impots'
                DataSource = Form20.DacompteIBS
                TabOrder = 2
                Visible = False
              end
            end
          end
          object scAdvancedPagerPage5: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1091
            Height = 366
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 4
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            object SpeedButton35: TSpeedButton
              Left = 652
              Top = 135
              Width = 50
              Height = 29
              ImageIndex = 13
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 11
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton35Click
            end
            object SpeedButton36: TSpeedButton
              Left = 652
              Top = 86
              Width = 50
              Height = 30
              ImageIndex = 5
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton36Click
            end
            object SpeedButton37: TSpeedButton
              Left = 652
              Top = 47
              Width = 50
              Height = 30
              ImageIndex = 3
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton37Click
            end
            object Panel20: TPanel
              Left = 0
              Top = 0
              Width = 1074
              Height = 41
              Align = alTop
              Enabled = False
              TabOrder = 0
              object Panel21: TPanel
                Left = 9
                Top = 0
                Width = 128
                Height = 41
                BevelOuter = bvNone
                Enabled = False
                TabOrder = 0
              end
              object scGPLabel21: TscGPLabel
                Left = 1
                Top = 1
                Width = 1072
                Height = 39
                Align = alClient
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBtnText
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = True
                TabOrder = 1
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 0
                FillColor = clNone
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 3
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                VertAlignment = scvtaCenter
                Caption = 'Etat d'#233'taillant le chiffre d'#8217'affaires : Activit'#233's Pharmacie'
              end
            end
            object Panel24: TPanel
              Left = 3
              Top = 47
              Width = 630
              Height = 346
              Enabled = False
              TabOrder = 1
              object scPanel4: TscPanel
                Left = 1
                Top = 1
                Width = 628
                Height = 35
                Align = alTop
                FluentUIOpaque = False
                TabOrder = 0
                CustomImageIndex = -1
                DragForm = False
                DragTopForm = True
                StyleKind = scpsPanel
                ShowCaption = False
                BorderStyle = scpbsBottomBevel
                WallpaperIndex = -1
                LightBorderColor = clBtnHighlight
                ShadowBorderColor = clBtnShadow
                CaptionGlowEffect.Enabled = False
                CaptionGlowEffect.Color = clBtnShadow
                CaptionGlowEffect.AlphaValue = 255
                CaptionGlowEffect.GlowSize = 7
                CaptionGlowEffect.Offset = 0
                CaptionGlowEffect.Intensive = True
                CaptionGlowEffect.StyleColors = True
                Color = clBtnFace
                Caption = 'scPanel1'
                StorePaintBuffer = False
                WordWrap = False
                object DBText1: TDBText
                  Left = 308
                  Top = 10
                  Width = 133
                  Height = 17
                  Alignment = taCenter
                  DataField = 'DAtedEC'
                  DataSource = Form20.DPharma
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -16
                  Font.Name = 'Segoe UI'
                  Font.Style = [fsBold]
                  ParentFont = False
                end
                object scGPLabel15: TscGPLabel
                  Left = 169
                  Top = 9
                  Width = 133
                  Height = 18
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 0
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = 'Date de D'#233'claration :'
                end
              end
              object Panel25: TPanel
                Left = 1
                Top = 36
                Width = 628
                Height = 309
                Align = alClient
                TabOrder = 1
                object Shape2: TShape
                  Left = 15
                  Top = 175
                  Width = 585
                  Height = 1
                  Brush.Color = clNone
                end
                object scGPLabel23: TscGPLabel
                  Left = 16
                  Top = 16
                  Width = 465
                  Height = 22
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold, fsUnderline]
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 5
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = 'Chiffre d'#8217'affaires'
                end
                object scGPLabel24: TscGPLabel
                  Left = 305
                  Top = 47
                  Width = 176
                  Height = 18
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 6
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = '- Vente de M'#233'dicaments :'
                end
                object F1: TscGPDBEdit
                  Left = 500
                  Top = 45
                  Width = 104
                  Height = 20
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 12779261
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessLineRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnFace
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Arial'
                  Font.Style = []
                  ParentFont = False
                  TabOrder = 0
                  DataField = 'CA1'
                  DataSource = Form20.DPharma
                end
                object scGPLabel25: TscGPLabel
                  Left = 305
                  Top = 73
                  Width = 176
                  Height = 18
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 7
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = '- Incitation (Majorations ) :'
                end
                object F2: TscGPDBEdit
                  Left = 500
                  Top = 71
                  Width = 104
                  Height = 20
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 12779261
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessLineRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnFace
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Arial'
                  Font.Style = []
                  ParentFont = False
                  TabOrder = 1
                  DataField = 'CA2'
                  DataSource = Form20.DPharma
                end
                object scGPLabel26: TscGPLabel
                  Left = 17
                  Top = 99
                  Width = 464
                  Height = 18
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 8
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = '-Chiffre d'#8217'affaires : Vente de Produits Parapharmaceutiques :'
                end
                object F3: TscGPDBEdit
                  Left = 500
                  Top = 97
                  Width = 104
                  Height = 20
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 12779261
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessLineRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnFace
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Arial'
                  Font.Style = []
                  ParentFont = False
                  TabOrder = 2
                  DataField = 'CA3'
                  DataSource = Form20.DPharma
                end
                object scGPLabel27: TscGPLabel
                  Left = 17
                  Top = 125
                  Width = 464
                  Height = 18
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 9
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = 
                    '-Autre Prestations de Services (Formalit'#233's administratives et el' +
                    'ectroniques) :'
                end
                object F4: TscGPDBEdit
                  Left = 500
                  Top = 123
                  Width = 104
                  Height = 20
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 12779261
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessLineRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnFace
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Arial'
                  Font.Style = []
                  ParentFont = False
                  TabOrder = 3
                  DataField = 'CA4'
                  DataSource = Form20.DPharma
                end
                object scGPLabel28: TscGPLabel
                  Left = 17
                  Top = 151
                  Width = 464
                  Height = 18
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 10
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = '-Autre Op'#233'rations :'
                end
                object F5: TscGPDBEdit
                  Left = 500
                  Top = 149
                  Width = 104
                  Height = 20
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 12779261
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessLineRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnFace
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Arial'
                  Font.Style = []
                  ParentFont = False
                  TabOrder = 4
                  DataField = 'CA5'
                  DataSource = Form20.DPharma
                end
                object scGPLabel29: TscGPLabel
                  Left = 17
                  Top = 183
                  Width = 464
                  Height = 18
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 11
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  Caption = 'Total  :'
                end
                object scGPDBEdit1: TscGPDBEdit
                  Left = 500
                  Top = 181
                  Width = 104
                  Height = 20
                  TabStop = False
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 12779261
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessLineRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnFace
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Arial'
                  Font.Style = []
                  ParentFont = False
                  ReadOnly = True
                  TabOrder = 12
                  DataField = 'Totalca'
                  DataSource = Form20.DPharma
                end
                object scGPLabel11: TscGPLabel
                  Left = 17
                  Top = 47
                  Width = 282
                  Height = 46
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 13
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  VertAlignment = scvtaCenter
                  WordWrap = True
                  Caption = 
                    '-Chiffre d'#8217'affaires : Vente de m'#233'dicaments a usage de la m'#233'decin' +
                    'e humaine :'
                end
                object scGPLabel13: TscGPLabel
                  Left = 500
                  Top = 16
                  Width = 104
                  Height = 22
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clBtnText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold, fsUnderline]
                  ParentFont = False
                  FluentUIOpaque = False
                  TabOrder = 14
                  DragForm = False
                  DragTopForm = True
                  DrawTextMode = scdtmGDI
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  DisabledFontColor = clNone
                  FrameWidth = 1
                  FillColor = clBtnText
                  FillColorAlpha = 20
                  FillColor2 = clNone
                  FillColor2Alpha = 255
                  FillGradientAngle = 0
                  FrameColor = clBtnText
                  FrameColorAlpha = 40
                  FrameRadius = 2
                  GlowEffect.Enabled = False
                  GlowEffect.Color = clBtnShadow
                  GlowEffect.AlphaValue = 255
                  GlowEffect.GlowSize = 7
                  GlowEffect.Offset = 0
                  GlowEffect.Intensive = True
                  GlowEffect.StyleColors = True
                  AutoSize = False
                  Alignment = taCenter
                  VertAlignment = scvtaCenter
                  Caption = 'Montant'
                end
              end
            end
          end
          object scAdvancedPagerPage6: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 1091
            Height = 366
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 5
            Visible = False
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            object Panel26: TPanel
              Left = 0
              Top = 0
              Width = 1091
              Height = 41
              Align = alTop
              Enabled = False
              TabOrder = 0
              object Panel27: TPanel
                Left = 9
                Top = 0
                Width = 128
                Height = 41
                BevelOuter = bvNone
                Enabled = False
                TabOrder = 0
              end
              object scDBEdit3: TscDBEdit
                Left = 639
                Top = 0
                Width = 116
                Height = 41
                FluentUIOpaque = False
                UseFontColorToStyleColor = False
                ContentMarginLeft = 0
                ContentMarginRight = 0
                ContentMarginTop = 0
                ContentMarginBottom = 0
                CustomBackgroundImageNormalIndex = -1
                CustomBackgroundImageHotIndex = -1
                CustomBackgroundImageDisabledIndex = -1
                PromptTextColor = clNone
                HideMaskWithEmptyText = False
                HidePromptTextIfFocused = False
                WallpaperIndex = -1
                LeftButton.ComboButton = False
                LeftButton.Enabled = True
                LeftButton.Visible = False
                LeftButton.ShowHint = False
                LeftButton.ShowEllipses = False
                LeftButton.StyleKind = scbsPushButton
                LeftButton.Width = 18
                LeftButton.ImageIndex = -1
                LeftButton.ImageHotIndex = -1
                LeftButton.ImagePressedIndex = -1
                LeftButton.RepeatClick = False
                LeftButton.RepeatClickInterval = 200
                LeftButton.CustomImageNormalIndex = -1
                LeftButton.CustomImageHotIndex = -1
                LeftButton.CustomImagePressedIndex = -1
                LeftButton.CustomImageDisabledIndex = -1
                RightButton.ComboButton = False
                RightButton.Enabled = True
                RightButton.Visible = False
                RightButton.ShowHint = False
                RightButton.ShowEllipses = False
                RightButton.StyleKind = scbsToolButtonTransparent
                RightButton.Width = 18
                RightButton.ImageIndex = -1
                RightButton.ImageHotIndex = -1
                RightButton.ImagePressedIndex = -1
                RightButton.RepeatClick = False
                RightButton.RepeatClickInterval = 200
                RightButton.CustomImageNormalIndex = -1
                RightButton.CustomImageHotIndex = -1
                RightButton.CustomImagePressedIndex = -1
                RightButton.CustomImageDisabledIndex = -1
                Transparent = True
                BorderKind = scebBottomActiveLine
                CustomDraw = False
                FrameColor = clNone
                FrameActiveColor = clHighlight
                Text = 'scDBEdit3'
                Alignment = taCenter
                AutoSelect = False
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -27
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                HideSelection = False
                ParentFont = False
                ReadOnly = True
                TabOrder = 1
                Visible = False
                DataField = 'Ann'#233'e'
                DataSource = Form20.DExercices
              end
              object scGPLabel8: TscGPLabel
                Left = 1
                Top = 1
                Width = 1089
                Height = 39
                Align = alClient
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBtnText
                Font.Height = -20
                Font.Name = 'Tahoma'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = True
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 0
                FillColor = clNone
                FillColorAlpha = 10
                FillColor2 = clNone
                FillColor2Alpha = 180
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 3
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                VertAlignment = scvtaCenter
                Caption = 'Etat d'#233'taillant le chiffre d'#8217'affaires : Station de Services'
              end
            end
            object DBGridEh8: TDBGridEh
              Left = 0
              Top = 82
              Width = 1091
              Height = 284
              Align = alClient
              DataSource = Form14.UniDataSource1
              DynProps = <>
              FooterRowCount = 1
              FooterParams.FillStyle = cfstThemedEh
              FooterParams.Font.Charset = DEFAULT_CHARSET
              FooterParams.Font.Color = clWindowText
              FooterParams.Font.Height = -12
              FooterParams.Font.Name = 'Segoe UI'
              FooterParams.Font.Style = [fsBold]
              FooterParams.ParentFont = False
              FooterParams.RowHeight = 15
              FooterParams.RowLines = 1
              GridLineParams.GridBoundaries = True
              IndicatorOptions = [gioShowRowIndicatorEh, gioShowRecNoEh]
              Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
              OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghEnterAsTab, dghRowHighlight, dghDialogFind, dghShowRecNo, dghColumnResize, dghColumnMove, dghExtendVertLines]
              SumList.Active = True
              TabOrder = 1
              TitleParams.FillStyle = cfstThemedEh
              TitleParams.MultiTitle = True
              OnDblClick = SpeedButton44Click
              Columns = <
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'leMois'
                  Footers = <>
                  Title.Caption = 'Mois'
                  Width = 120
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Mois'
                  Footers = <>
                  Visible = False
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Annee'
                  Footers = <>
                  Visible = False
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'SecteurpetrolierCA'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  Title.Caption = 'CA|Secteur P'#233'trolier'
                  Width = 110
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'ReventeCA'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  ReadOnly = True
                  Title.Caption = 'CA|Revente'
                  Width = 110
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'PrestationCA'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  Title.Caption = 'CA|Restaurant'
                  Width = 110
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'ReventeTVA'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  ReadOnly = True
                  Title.Caption = 'TVA|Revente'
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'PrestationTVA'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  Title.Caption = 'TVA|Prestation'
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TotalCA'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  Title.Caption = 'Total CA'
                  Width = 100
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TotalTVA'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  ReadOnly = True
                  Title.Caption = 'Total TVA'
                  Width = 100
                end>
              object RowDetailData: TRowDetailPanelControlEh
              end
            end
            object Panel33: TPanel
              Left = 0
              Top = 41
              Width = 1091
              Height = 41
              Align = alTop
              TabOrder = 2
              object SpeedButton41: TSpeedButton
                Left = -3
                Top = 6
                Width = 66
                Height = 30
                ImageIndex = 15
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton41Click
              end
              object SpeedButton44: TSpeedButton
                Left = 69
                Top = 6
                Width = 66
                Height = 30
                ImageIndex = 3
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton44Click
              end
              object SpeedButton52: TSpeedButton
                Left = 141
                Top = 5
                Width = 66
                Height = 30
                ImageIndex = 5
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton52Click
              end
              object SpeedButton47: TSpeedButton
                Left = 213
                Top = 6
                Width = 50
                Height = 29
                ImageIndex = 13
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 11
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton47Click
              end
              object SpeedButton2: TSpeedButton
                Left = 317
                Top = 6
                Width = 50
                Height = 29
                ImageIndex = 13
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = [fsBold]
                Layout = blGlyphTop
                Margin = 1
                ParentFont = False
                PressedImageIndex = 11
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton2Click
              end
            end
          end
          object scAdvancedPagerPage1: TscAdvancedPagerPage
            Left = 2
            Top = 32
            Width = 978
            Height = 504
            HorzScrollBar.Tracking = True
            VertScrollBar.Tracking = True
            BorderStyle = bsNone
            Color = clBtnFace
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentColor = False
            ParentFont = False
            TabOrder = 0
            WallpaperIndex = -1
            CustomBackgroundImageIndex = -1
            FullUpdate = True
            FluentUIOpaque = False
            StorePaintBuffer = False
            MouseWheelSupport = False
            BackgroundStyle = scsbsTabSheet
            DesignSize = (
              978
              504)
            object SpeedButton3: TSpeedButton
              Left = 178
              Top = 65
              Width = 66
              Height = 30
              ImageIndex = 15
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton3Click
            end
            object SpeedButton4: TSpeedButton
              Left = 178
              Top = 101
              Width = 66
              Height = 30
              ImageIndex = 3
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton4Click
            end
            object SpeedButton5: TSpeedButton
              Left = 178
              Top = 139
              Width = 66
              Height = 30
              ImageIndex = 5
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton5Click
            end
            object SpeedButton13: TSpeedButton
              Left = 167
              Top = 313
              Width = 66
              Height = 50
              Caption = #201'tats TVA'
              ImageIndex = 80
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton13Click
            end
            object SpeedButton14: TSpeedButton
              Left = 169
              Top = 255
              Width = 82
              Height = 52
              Caption = #201'tats TVA'
              ImageIndex = 14
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = []
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton14Click
            end
            object SpeedButton7: TSpeedButton
              Left = 175
              Top = 203
              Width = 66
              Height = 46
              Caption = 'G50'
              ImageIndex = 11
              Images = DM.Smal
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              Layout = blGlyphTop
              Margin = 1
              ParentFont = False
              PressedImageIndex = 0
              Spacing = 0
              StyleName = 'clear day se'
              OnClick = SpeedButton7Click
            end
            object DBGrid6: TDBGrid
              AlignWithMargins = True
              Left = 3
              Top = 63
              Width = 158
              Height = 431
              Anchors = [akLeft, akTop, akBottom]
              DataSource = Form20.DG50
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -13
              Font.Name = 'Tahoma'
              Font.Style = []
              Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
              ParentColor = True
              ParentFont = False
              ReadOnly = True
              TabOrder = 0
              TitleFont.Charset = DEFAULT_CHARSET
              TitleFont.Color = clWindowText
              TitleFont.Height = -13
              TitleFont.Name = 'Tahoma'
              TitleFont.Style = []
              OnCellClick = DBGrid6CellClick
              OnDblClick = AdvGlowButton29Click
              Columns = <
                item
                  Expanded = False
                  FieldName = 'idg50'
                  Visible = False
                end
                item
                  Expanded = False
                  FieldName = 'Ann'#233'e'
                  Visible = False
                end
                item
                  Expanded = False
                  FieldName = 'Mois'
                  Visible = False
                end
                item
                  Expanded = False
                  FieldName = 'leMois'
                  Title.Alignment = taCenter
                  Title.Caption = 'P'#233'riode'
                  Title.Color = clInactiveCaption
                  Width = 160
                  Visible = True
                end
                item
                  Expanded = False
                  FieldName = 'ma'
                  Visible = False
                end>
            end
            object Panel4: TPanel
              Left = 255
              Top = 57
              Width = 721
              Height = 438
              Anchors = [akLeft, akTop, akRight, akBottom]
              TabOrder = 1
              ExplicitWidth = 832
              ExplicitHeight = 370
              DesignSize = (
                721
                438)
              object Panel6: TPanel
                Left = 2
                Top = 158
                Width = 818
                Height = 280
                Anchors = [akLeft, akTop, akRight, akBottom]
                TabOrder = 1
                ExplicitWidth = 929
                ExplicitHeight = 212
                object Shape1: TShape
                  Left = 433
                  Top = 153
                  Width = 413
                  Height = 3
                end
                object Label4: TLabel
                  Left = 10
                  Top = 38
                  Width = 121
                  Height = 14
                  Caption = '- Pr'#233'compte ant'#233'rieur'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                end
                object Label6: TLabel
                  Left = 10
                  Top = 63
                  Width = 260
                  Height = 14
                  Caption = '- T.V.A sur achat de biens, mati'#232'res et services'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  WordWrap = True
                end
                object Label9: TLabel
                  Left = 10
                  Top = 116
                  Width = 303
                  Height = 14
                  Caption = '- R'#233'gularisation du prorata (d'#233'duction compl'#233'mentaire)'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  WordWrap = True
                end
                object Label10: TLabel
                  Left = 11
                  Top = 90
                  Width = 242
                  Height = 14
                  Caption = '- T.V.A sur achat de biens (art.38 C/T.C.A) '
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                end
                object Label11: TLabel
                  Left = 10
                  Top = 138
                  Width = 249
                  Height = 28
                  Caption = '- T.V.A '#224' r'#233'cup'#233'rer sur factures annul'#233'es ou    impay'#233'es (art.18'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  WordWrap = True
                end
                object Label5: TLabel
                  Left = 10
                  Top = 172
                  Width = 299
                  Height = 14
                  Caption = '- Autres d'#233'ductions (Notification de pr'#233'compte, etc.) '
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                end
                object Label12: TLabel
                  Left = 434
                  Top = 38
                  Width = 116
                  Height = 14
                  Caption = '- Total des droits dus'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                end
                object Label13: TLabel
                  Left = 434
                  Top = 63
                  Width = 249
                  Height = 28
                  Caption = 
                    '- R'#233'gularisation du prorata (art.40 C/ T.C.A.)     (+)(D'#233'duction' +
                    ' exc'#233'dentaire)'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                  WordWrap = True
                end
                object Label15: TLabel
                  Left = 449
                  Top = 125
                  Width = 118
                  Height = 14
                  Caption = 'Total '#224' rappeler (C)'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold]
                  ParentFont = False
                  WordWrap = True
                end
                object Label16: TLabel
                  Left = 14
                  Top = 202
                  Width = 205
                  Height = 14
                  Caption = 'Total des d'#233'ductions '#224' op'#233'rer (B)'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold]
                  ParentFont = False
                end
                object Label17: TLabel
                  Left = 435
                  Top = 92
                  Width = 280
                  Height = 16
                  Caption = '- Reversement de la d'#233'duction (art.38 C/ T.C.A.)'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Tahoma'
                  Font.Style = []
                  ParentFont = False
                end
                object Label8: TLabel
                  Left = 11
                  Top = 11
                  Width = 176
                  Height = 18
                  Caption = 'B/ D'#233'ductions '#224' Op'#233'rer'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold, fsUnderline]
                  ParentFont = False
                end
                object Label18: TLabel
                  Left = 449
                  Top = 11
                  Width = 113
                  Height = 18
                  Caption = 'C/ TVA '#224' Payer'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold, fsUnderline]
                  ParentFont = False
                end
                object Label19: TLabel
                  Left = 433
                  Top = 170
                  Width = 218
                  Height = 14
                  Caption = 'TVA '#224' payer au titre du mois (C - B)'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold]
                  ParentFont = False
                  WordWrap = True
                end
                object Label20: TLabel
                  Left = 433
                  Top = 196
                  Width = 285
                  Height = 14
                  Caption = 'Pr'#233'compte '#224' reporter sur le mois suivant (B-C)'
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Tahoma'
                  Font.Style = [fsBold]
                  ParentFont = False
                  WordWrap = True
                end
                object E3B90: TscGPDBEdit
                  Left = 316
                  Top = 33
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 0
                  DataField = 'Pr'#233'compte_ant'#233'rieur'
                  DataSource = Form20.DG50
                end
                object E3B91: TscGPDBEdit
                  Left = 316
                  Top = 60
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 1
                  DataField = 'TTVAachatMatieres'
                  DataSource = Form20.DG50
                end
                object E3B92: TscGPDBEdit
                  Left = 316
                  Top = 86
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 2
                  DataField = 'TVAbiensamortissables'
                  DataSource = Form20.DG50
                end
                object E3B93: TscGPDBEdit
                  Left = 316
                  Top = 112
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 3
                  DataField = 'd'#233'ductioncompl'#233'mentaire'
                  DataSource = Form20.DG50
                end
                object E3B94: TscGPDBEdit
                  Left = 316
                  Top = 138
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 4
                  DataField = 'TVAfacturesannul'#233'es'
                  DataSource = Form20.DG50
                end
                object E3B97: TscGPDBEdit
                  Left = 744
                  Top = 60
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 6
                  DataField = 'd'#233'duction_exc'#233'dentaire'
                  DataSource = Form20.DG50
                end
                object E3B99: TscGPDBEdit
                  Left = 744
                  Top = 88
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 7
                  DataField = 'Reversement_de_la_d'#233'duction'
                  DataSource = Form20.DG50
                end
                object Panel7: TPanel
                  Left = 316
                  Top = 194
                  Width = 100
                  Height = 24
                  Color = clWhite
                  DoubleBuffered = True
                  Enabled = False
                  ParentBackground = False
                  ParentDoubleBuffered = False
                  TabOrder = 8
                  object E3B110: TscGPDBEdit
                    Left = 0
                    Top = 0
                    Width = 100
                    Height = 24
                    TabStop = False
                    FluentUIOpaque = False
                    Options.NormalColor = clWindow
                    Options.HotColor = clWindow
                    Options.FocusedColor = 9240058
                    Options.DisabledColor = clWindow
                    Options.NormalColorAlpha = 200
                    Options.HotColorAlpha = 255
                    Options.FocusedColorAlpha = 255
                    Options.DisabledColorAlpha = 150
                    Options.FrameNormalColor = clBtnText
                    Options.FrameHotColor = clHighlight
                    Options.FrameFocusedColor = clHighlight
                    Options.FrameDisabledColor = clBtnText
                    Options.FrameWidth = 1
                    Options.FrameNormalColorAlpha = 100
                    Options.FrameHotColorAlpha = 255
                    Options.FrameFocusedColorAlpha = 255
                    Options.FrameDisabledColorAlpha = 50
                    Options.FontNormalColor = clWindowText
                    Options.FontHotColor = clWindowText
                    Options.FontFocusedColor = clWindowText
                    Options.FontDisabledColor = clGrayText
                    Options.FocusedLineColor = 12779261
                    Options.FocusedLineWidth = 0
                    Options.ShapeFillGradientAngle = 90
                    Options.ShapeCornerRadius = 10
                    Options.ShapeStyle = scgpessRect
                    Options.ScaleFrameWidth = False
                    Options.StyleColors = True
                    ContentMarginLeft = 5
                    ContentMarginRight = 5
                    ContentMarginTop = 3
                    ContentMarginBottom = 3
                    HideMaskWithEmptyText = False
                    HidePromptTextIfFocused = False
                    PromptTextColor = clNone
                    Transparent = False
                    LeftButton.Kind = scgpebCustom
                    LeftButton.Enabled = True
                    LeftButton.Visible = False
                    LeftButton.ImageIndex = -1
                    LeftButton.ImageHotIndex = -1
                    LeftButton.ImagePressedIndex = -1
                    LeftButton.RepeatClick = False
                    LeftButton.RepeatClickInterval = 200
                    LeftButton.ShowHint = False
                    LeftButton.GlyphColor = clWindowText
                    LeftButton.GlyphColorAlpha = 180
                    LeftButton.GlyphColorHotAlpha = 240
                    LeftButton.GlyphColorPressedAlpha = 150
                    LeftButton.GlyphThickness = 2
                    LeftButton.GlyphSize = 0
                    LeftButton.Width = 0
                    RightButton.Kind = scgpebCustom
                    RightButton.Enabled = True
                    RightButton.Visible = False
                    RightButton.ImageIndex = -1
                    RightButton.ImageHotIndex = -1
                    RightButton.ImagePressedIndex = -1
                    RightButton.RepeatClick = False
                    RightButton.RepeatClickInterval = 200
                    RightButton.ShowHint = False
                    RightButton.GlyphColor = clWindowText
                    RightButton.GlyphColorAlpha = 180
                    RightButton.GlyphColorHotAlpha = 240
                    RightButton.GlyphColorPressedAlpha = 150
                    RightButton.GlyphThickness = 2
                    RightButton.GlyphSize = 0
                    RightButton.Width = 0
                    CustomDraw = False
                    Text = ''
                    Alignment = taRightJustify
                    Color = clBtnHighlight
                    Font.Charset = DEFAULT_CHARSET
                    Font.Color = 37632
                    Font.Height = -15
                    Font.Name = 'Arial'
                    Font.Style = [fsBold]
                    NumbersOnly = True
                    ParentFont = False
                    TabOrder = 0
                    DataField = 'Total_des_d'#233'ductions'
                    DataSource = Form20.DG50
                  end
                end
                object Panel8: TPanel
                  Left = 744
                  Top = 120
                  Width = 100
                  Height = 24
                  Enabled = False
                  TabOrder = 9
                  object E3B100: TscGPDBEdit
                    Left = 0
                    Top = 0
                    Width = 100
                    Height = 24
                    TabStop = False
                    FluentUIOpaque = False
                    Options.NormalColor = clWindow
                    Options.HotColor = clWindow
                    Options.FocusedColor = 9240058
                    Options.DisabledColor = clWindow
                    Options.NormalColorAlpha = 200
                    Options.HotColorAlpha = 255
                    Options.FocusedColorAlpha = 255
                    Options.DisabledColorAlpha = 150
                    Options.FrameNormalColor = clBtnText
                    Options.FrameHotColor = clHighlight
                    Options.FrameFocusedColor = clHighlight
                    Options.FrameDisabledColor = clBtnText
                    Options.FrameWidth = 1
                    Options.FrameNormalColorAlpha = 100
                    Options.FrameHotColorAlpha = 255
                    Options.FrameFocusedColorAlpha = 255
                    Options.FrameDisabledColorAlpha = 50
                    Options.FontNormalColor = clWindowText
                    Options.FontHotColor = clWindowText
                    Options.FontFocusedColor = clWindowText
                    Options.FontDisabledColor = clGrayText
                    Options.FocusedLineColor = 12779261
                    Options.FocusedLineWidth = 0
                    Options.ShapeFillGradientAngle = 90
                    Options.ShapeCornerRadius = 10
                    Options.ShapeStyle = scgpessRect
                    Options.ScaleFrameWidth = False
                    Options.StyleColors = True
                    ContentMarginLeft = 5
                    ContentMarginRight = 5
                    ContentMarginTop = 3
                    ContentMarginBottom = 3
                    HideMaskWithEmptyText = False
                    HidePromptTextIfFocused = False
                    PromptTextColor = clNone
                    Transparent = False
                    LeftButton.Kind = scgpebCustom
                    LeftButton.Enabled = True
                    LeftButton.Visible = False
                    LeftButton.ImageIndex = -1
                    LeftButton.ImageHotIndex = -1
                    LeftButton.ImagePressedIndex = -1
                    LeftButton.RepeatClick = False
                    LeftButton.RepeatClickInterval = 200
                    LeftButton.ShowHint = False
                    LeftButton.GlyphColor = clWindowText
                    LeftButton.GlyphColorAlpha = 180
                    LeftButton.GlyphColorHotAlpha = 240
                    LeftButton.GlyphColorPressedAlpha = 150
                    LeftButton.GlyphThickness = 2
                    LeftButton.GlyphSize = 0
                    LeftButton.Width = 0
                    RightButton.Kind = scgpebCustom
                    RightButton.Enabled = True
                    RightButton.Visible = False
                    RightButton.ImageIndex = -1
                    RightButton.ImageHotIndex = -1
                    RightButton.ImagePressedIndex = -1
                    RightButton.RepeatClick = False
                    RightButton.RepeatClickInterval = 200
                    RightButton.ShowHint = False
                    RightButton.GlyphColor = clWindowText
                    RightButton.GlyphColorAlpha = 180
                    RightButton.GlyphColorHotAlpha = 240
                    RightButton.GlyphColorPressedAlpha = 150
                    RightButton.GlyphThickness = 2
                    RightButton.GlyphSize = 0
                    RightButton.Width = 0
                    CustomDraw = False
                    Text = ''
                    Alignment = taRightJustify
                    Color = clBtnHighlight
                    Font.Charset = DEFAULT_CHARSET
                    Font.Color = 37632
                    Font.Height = -15
                    Font.Name = 'Arial'
                    Font.Style = [fsBold]
                    ParentFont = False
                    TabOrder = 0
                    DataField = 'TOTALaRAPPELER'
                    DataSource = Form20.DG50
                  end
                end
                object E3B95: TscGPDBEdit
                  Left = 316
                  Top = 164
                  Width = 100
                  Height = 24
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 5
                  DataField = 'Autres_d'#233'ductions'
                  DataSource = Form20.DG50
                end
                object Panel12: TPanel
                  Left = 744
                  Top = 31
                  Width = 100
                  Height = 24
                  Enabled = False
                  TabOrder = 10
                  object E3B96: TscGPDBEdit
                    Left = 0
                    Top = 0
                    Width = 100
                    Height = 24
                    FluentUIOpaque = False
                    Options.NormalColor = clWindow
                    Options.HotColor = clWindow
                    Options.FocusedColor = 9240058
                    Options.DisabledColor = clWindow
                    Options.NormalColorAlpha = 200
                    Options.HotColorAlpha = 255
                    Options.FocusedColorAlpha = 255
                    Options.DisabledColorAlpha = 150
                    Options.FrameNormalColor = clBtnText
                    Options.FrameHotColor = clHighlight
                    Options.FrameFocusedColor = clHighlight
                    Options.FrameDisabledColor = clBtnText
                    Options.FrameWidth = 1
                    Options.FrameNormalColorAlpha = 100
                    Options.FrameHotColorAlpha = 255
                    Options.FrameFocusedColorAlpha = 255
                    Options.FrameDisabledColorAlpha = 50
                    Options.FontNormalColor = clWindowText
                    Options.FontHotColor = clWindowText
                    Options.FontFocusedColor = clWindowText
                    Options.FontDisabledColor = clGrayText
                    Options.FocusedLineColor = 12779261
                    Options.FocusedLineWidth = 0
                    Options.ShapeFillGradientAngle = 90
                    Options.ShapeCornerRadius = 10
                    Options.ShapeStyle = scgpessRect
                    Options.ScaleFrameWidth = False
                    Options.StyleColors = True
                    ContentMarginLeft = 5
                    ContentMarginRight = 5
                    ContentMarginTop = 3
                    ContentMarginBottom = 3
                    HideMaskWithEmptyText = False
                    HidePromptTextIfFocused = False
                    PromptTextColor = clNone
                    Transparent = False
                    LeftButton.Kind = scgpebCustom
                    LeftButton.Enabled = True
                    LeftButton.Visible = False
                    LeftButton.ImageIndex = -1
                    LeftButton.ImageHotIndex = -1
                    LeftButton.ImagePressedIndex = -1
                    LeftButton.RepeatClick = False
                    LeftButton.RepeatClickInterval = 200
                    LeftButton.ShowHint = False
                    LeftButton.GlyphColor = clWindowText
                    LeftButton.GlyphColorAlpha = 180
                    LeftButton.GlyphColorHotAlpha = 240
                    LeftButton.GlyphColorPressedAlpha = 150
                    LeftButton.GlyphThickness = 2
                    LeftButton.GlyphSize = 0
                    LeftButton.Width = 0
                    RightButton.Kind = scgpebCustom
                    RightButton.Enabled = True
                    RightButton.Visible = False
                    RightButton.ImageIndex = -1
                    RightButton.ImageHotIndex = -1
                    RightButton.ImagePressedIndex = -1
                    RightButton.RepeatClick = False
                    RightButton.RepeatClickInterval = 200
                    RightButton.ShowHint = False
                    RightButton.GlyphColor = clWindowText
                    RightButton.GlyphColorAlpha = 180
                    RightButton.GlyphColorHotAlpha = 240
                    RightButton.GlyphColorPressedAlpha = 150
                    RightButton.GlyphThickness = 2
                    RightButton.GlyphSize = 0
                    RightButton.Width = 0
                    CustomDraw = False
                    Text = ''
                    Alignment = taRightJustify
                    Color = clBtnHighlight
                    Font.Charset = DEFAULT_CHARSET
                    Font.Color = clWindowText
                    Font.Height = -15
                    Font.Name = 'Arial'
                    Font.Style = [fsBold]
                    ParentFont = False
                    ReadOnly = True
                    TabOrder = 0
                    DataField = 'Totaldroits_dus'
                    DataSource = Form20.DG50
                  end
                end
                object E3B120: TscGPDBEdit
                  Left = 746
                  Top = 159
                  Width = 100
                  Height = 24
                  TabStop = False
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clRed
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 11
                  DataField = 'TVA_'#224'_payer'
                  DataSource = Form20.DG50
                end
                object E3B130: TscGPDBEdit
                  Left = 745
                  Top = 189
                  Width = 100
                  Height = 24
                  TabStop = False
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 9240058
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 3
                  ContentMarginBottom = 3
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Alignment = taRightJustify
                  Color = clBtnHighlight
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clRed
                  Font.Height = -15
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 12
                  DataField = 'Pr'#233'compte_'#224'_reporter'
                  DataSource = Form20.DG50
                end
              end
              object Panel3: TPanel
                Left = 1
                Top = 1
                Width = 719
                Height = 35
                Align = alTop
                TabOrder = 0
                ExplicitWidth = 830
                DesignSize = (
                  719
                  35)
                object MA: TLabel
                  Left = 1
                  Top = 1
                  Width = 717
                  Height = 29
                  Align = alTop
                  Alignment = taCenter
                  AutoSize = False
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -27
                  Font.Name = 'Segoe UI'
                  Font.Style = [fsBold]
                  GlowSize = 1
                  ParentFont = False
                  Layout = tlCenter
                  ExplicitLeft = -1
                  ExplicitTop = -8
                  ExplicitWidth = 600
                end
                object SpeedButton15: TSpeedButton
                  Left = 622
                  Top = 6
                  Width = 100
                  Height = 25
                  Anchors = [akTop, akRight]
                  Caption = '   Etat TVA'
                  ImageIndex = 36
                  Images = DM.Smal
                  Flat = True
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -12
                  Font.Name = 'Arial'
                  Font.Style = []
                  Margin = 1
                  ParentFont = False
                  PressedImageIndex = 0
                  Spacing = 0
                  Visible = False
                  StyleName = 'clear day se'
                  OnClick = SpeedButton15Click
                  ExplicitLeft = 659
                end
                object MoisG50: TscGPDBEdit
                  Left = 56
                  Top = 11
                  Width = 130
                  Height = 20
                  FluentUIOpaque = False
                  Options.NormalColor = clWindow
                  Options.HotColor = clWindow
                  Options.FocusedColor = 12779261
                  Options.DisabledColor = clWindow
                  Options.NormalColorAlpha = 200
                  Options.HotColorAlpha = 255
                  Options.FocusedColorAlpha = 255
                  Options.DisabledColorAlpha = 150
                  Options.FrameNormalColor = clBtnText
                  Options.FrameHotColor = clHighlight
                  Options.FrameFocusedColor = clHighlight
                  Options.FrameDisabledColor = clBtnText
                  Options.FrameWidth = 1
                  Options.FrameNormalColorAlpha = 100
                  Options.FrameHotColorAlpha = 255
                  Options.FrameFocusedColorAlpha = 255
                  Options.FrameDisabledColorAlpha = 50
                  Options.FontNormalColor = clWindowText
                  Options.FontHotColor = clWindowText
                  Options.FontFocusedColor = clWindowText
                  Options.FontDisabledColor = clGrayText
                  Options.FocusedLineColor = 12779261
                  Options.FocusedLineWidth = 0
                  Options.ShapeFillGradientAngle = 90
                  Options.ShapeCornerRadius = 10
                  Options.ShapeStyle = scgpessLineRect
                  Options.ScaleFrameWidth = False
                  Options.StyleColors = True
                  ContentMarginLeft = 5
                  ContentMarginRight = 5
                  ContentMarginTop = 2
                  ContentMarginBottom = 2
                  HideMaskWithEmptyText = False
                  HidePromptTextIfFocused = False
                  PromptTextColor = clNone
                  Transparent = False
                  LeftButton.Kind = scgpebCustom
                  LeftButton.Enabled = True
                  LeftButton.Visible = False
                  LeftButton.ImageIndex = -1
                  LeftButton.ImageHotIndex = -1
                  LeftButton.ImagePressedIndex = -1
                  LeftButton.RepeatClick = False
                  LeftButton.RepeatClickInterval = 200
                  LeftButton.ShowHint = False
                  LeftButton.GlyphColor = clWindowText
                  LeftButton.GlyphColorAlpha = 180
                  LeftButton.GlyphColorHotAlpha = 240
                  LeftButton.GlyphColorPressedAlpha = 150
                  LeftButton.GlyphThickness = 2
                  LeftButton.GlyphSize = 0
                  LeftButton.Width = 0
                  RightButton.Kind = scgpebCustom
                  RightButton.Enabled = True
                  RightButton.Visible = False
                  RightButton.ImageIndex = -1
                  RightButton.ImageHotIndex = -1
                  RightButton.ImagePressedIndex = -1
                  RightButton.RepeatClick = False
                  RightButton.RepeatClickInterval = 200
                  RightButton.ShowHint = False
                  RightButton.GlyphColor = clWindowText
                  RightButton.GlyphColorAlpha = 180
                  RightButton.GlyphColorHotAlpha = 240
                  RightButton.GlyphColorPressedAlpha = 150
                  RightButton.GlyphThickness = 2
                  RightButton.GlyphSize = 0
                  RightButton.Width = 0
                  CustomDraw = False
                  Text = ''
                  Color = clBtnFace
                  Font.Charset = DEFAULT_CHARSET
                  Font.Color = clWindowText
                  Font.Height = -13
                  Font.Name = 'Arial'
                  Font.Style = [fsBold]
                  ParentFont = False
                  TabOrder = 0
                  Visible = False
                  DataField = 'MoisAnn'#233'e'
                  DataSource = Form20.DG50
                end
              end
            end
            object DBGridEh4: TDBGridEh
              Left = 259
              Top = 95
              Width = 719
              Height = 114
              Anchors = [akLeft, akTop, akRight]
              AutoFitColWidths = True
              DataSource = DunionG50
              DrawMemoText = True
              DynProps = <>
              FixedColor = clBtnHighlight
              Flat = True
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = []
              FooterRowCount = 1
              FooterParams.FillStyle = cfstThemedEh
              FooterParams.Font.Charset = DEFAULT_CHARSET
              FooterParams.Font.Color = clWindowText
              FooterParams.Font.Height = -13
              FooterParams.Font.Name = 'Arial'
              FooterParams.Font.Style = [fsBold]
              FooterParams.ParentFont = False
              FooterParams.RowHeight = 10
              FooterParams.RowLines = 1
              GridLineParams.ColorScheme = glcsFlatEh
              OddRowColor = clWindow
              Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit]
              OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghDialogFind, dghColumnResize, dghColumnMove, dghAutoFitRowHeight, dghExtendVertLines]
              ParentFont = False
              RowDetailPanel.Color = clBtnFace
              SumList.Active = True
              TabOrder = 2
              Columns = <
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Nat'
                  Footers = <>
                  Title.Alignment = taCenter
                  Title.Caption = 'Nature '
                  Width = 120
                  WordWrap = False
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'CODE'
                  Footers = <>
                  Title.Alignment = taCenter
                  Title.Caption = 'Code'
                  Width = 70
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'impots'
                  Footers = <>
                  Title.Alignment = taCenter
                  Title.Caption = 'Impots et Taxes'
                  Width = 257
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Caimposable'
                  Footers = <>
                  Title.Alignment = taCenter
                  Title.Caption = 'Base Imposable'
                  Width = 100
                end
                item
                  Alignment = taCenter
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'TAUXTAP'
                  Footers = <>
                  Title.Alignment = taCenter
                  Title.Caption = 'Taux'
                  Width = 90
                end
                item
                  CellButtons = <>
                  DynProps = <>
                  EditButtons = <>
                  FieldName = 'Droits'
                  Footer.ValueType = fvtSum
                  Footers = <>
                  Title.Alignment = taCenter
                  Width = 90
                end>
              object RowDetailData: TRowDetailPanelControlEh
              end
            end
            object AdvGlowButton1: TAdvGlowButton
              Left = 185
              Top = 369
              Width = 48
              Height = 24
              Hint = 'Supprimer G50'
              Caption = 'G50'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Tahoma'
              Font.Style = []
              ImageIndex = 11
              Images = DM.Smal
              NotesFont.Charset = DEFAULT_CHARSET
              NotesFont.Color = clWindowText
              NotesFont.Height = -11
              NotesFont.Name = 'Tahoma'
              NotesFont.Style = []
              ParentFont = False
              Rounded = True
              Spacing = -2
              WordWrap = False
              ParentShowHint = False
              ShowHint = True
              TabOrder = 3
              Visible = False
              OnClick = AdvGlowButton1Click
              Appearance.BorderColor = 11382963
              Appearance.BorderColorHot = 11565130
              Appearance.BorderColorCheckedHot = 11565130
              Appearance.BorderColorDown = 11565130
              Appearance.BorderColorChecked = 13744549
              Appearance.BorderColorDisabled = 13948116
              Appearance.Color = clWhite
              Appearance.ColorTo = clWhite
              Appearance.ColorChecked = 13744549
              Appearance.ColorCheckedTo = 13744549
              Appearance.ColorDisabled = clWhite
              Appearance.ColorDisabledTo = clNone
              Appearance.ColorDown = 11565130
              Appearance.ColorDownTo = 11565130
              Appearance.ColorHot = 16444643
              Appearance.ColorHotTo = 16444643
              Appearance.ColorMirror = clWhite
              Appearance.ColorMirrorTo = clWhite
              Appearance.ColorMirrorHot = 16444643
              Appearance.ColorMirrorHotTo = 16444643
              Appearance.ColorMirrorDown = 11565130
              Appearance.ColorMirrorDownTo = 11565130
              Appearance.ColorMirrorChecked = 13744549
              Appearance.ColorMirrorCheckedTo = 13744549
              Appearance.ColorMirrorDisabled = clWhite
              Appearance.ColorMirrorDisabledTo = clNone
              Appearance.GradientHot = ggVertical
              Appearance.GradientMirrorHot = ggVertical
              Appearance.GradientDown = ggVertical
              Appearance.GradientMirrorDown = ggVertical
              Appearance.GradientChecked = ggVertical
              Appearance.TextColorChecked = 3750459
              Appearance.TextColorDown = 2303013
              Appearance.TextColorHot = 2303013
              Appearance.TextColorDisabled = 13948116
            end
            object DBma: TDBEdit
              Left = 199
              Top = 328
              Width = 52
              Height = 23
              DataField = 'ma'
              DataSource = Form20.DG50
              TabOrder = 4
              Visible = False
            end
            object Panel1: TPanel
              Left = 0
              Top = 0
              Width = 978
              Height = 41
              Align = alTop
              TabOrder = 5
              ExplicitWidth = 1089
              DesignSize = (
                978
                41)
              object SpeedButton1: TSpeedButton
                Tag = 1
                Left = 896
                Top = 2
                Width = 79
                Height = 36
                Anchors = [akTop, akRight]
                Caption = '  R'#233'cap'
                ImageIndex = 11
                Images = DM.Smal
                Flat = True
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clWindowText
                Font.Height = -12
                Font.Name = 'Arial'
                Font.Style = []
                Margin = 1
                ParentFont = False
                PressedImageIndex = 0
                Spacing = 0
                StyleName = 'clear day se'
                OnClick = SpeedButton10Click
                ExplicitLeft = 1098
              end
              object scGPLabel17: TscGPLabel
                Left = 1
                Top = 1
                Width = 889
                Height = 39
                Anchors = [akLeft, akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBtnText
                Font.Height = -20
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clWhite
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                VertAlignment = scvtaCenter
                Caption = 'D'#233'clarations Mensuelles G50'
                ExplicitWidth = 1000
              end
            end
            object Bg50: TAdvGlowButton
              Left = 183
              Top = 408
              Width = 48
              Height = 24
              Hint = 'Supprimer G50'
              Caption = 'G50'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Tahoma'
              Font.Style = []
              ImageIndex = 11
              Images = DM.Smal
              NotesFont.Charset = DEFAULT_CHARSET
              NotesFont.Color = clWindowText
              NotesFont.Height = -11
              NotesFont.Name = 'Tahoma'
              NotesFont.Style = []
              ParentFont = False
              Rounded = True
              Spacing = -2
              WordWrap = False
              ParentShowHint = False
              ShowHint = True
              TabOrder = 6
              Visible = False
              OnClick = Bg50Click
              Appearance.BorderColor = 11382963
              Appearance.BorderColorHot = 11565130
              Appearance.BorderColorCheckedHot = 11565130
              Appearance.BorderColorDown = 11565130
              Appearance.BorderColorChecked = 13744549
              Appearance.BorderColorDisabled = 13948116
              Appearance.Color = clWhite
              Appearance.ColorTo = clWhite
              Appearance.ColorChecked = 13744549
              Appearance.ColorCheckedTo = 13744549
              Appearance.ColorDisabled = clWhite
              Appearance.ColorDisabledTo = clNone
              Appearance.ColorDown = 11565130
              Appearance.ColorDownTo = 11565130
              Appearance.ColorHot = 16444643
              Appearance.ColorHotTo = 16444643
              Appearance.ColorMirror = clWhite
              Appearance.ColorMirrorTo = clWhite
              Appearance.ColorMirrorHot = 16444643
              Appearance.ColorMirrorHotTo = 16444643
              Appearance.ColorMirrorDown = 11565130
              Appearance.ColorMirrorDownTo = 11565130
              Appearance.ColorMirrorChecked = 13744549
              Appearance.ColorMirrorCheckedTo = 13744549
              Appearance.ColorMirrorDisabled = clWhite
              Appearance.ColorMirrorDisabledTo = clNone
              Appearance.GradientHot = ggVertical
              Appearance.GradientMirrorHot = ggVertical
              Appearance.GradientDown = ggVertical
              Appearance.GradientMirrorDown = ggVertical
              Appearance.GradientChecked = ggVertical
              Appearance.TextColorChecked = 3750459
              Appearance.TextColorDown = 2303013
              Appearance.TextColorHot = 2303013
              Appearance.TextColorDisabled = 13948116
            end
          end
        end
        object Panel10: TPanel
          Left = 0
          Top = 0
          Width = 1095
          Height = 105
          Align = alTop
          BevelOuter = bvSpace
          TabOrder = 1
          ExplicitWidth = 1093
          DesignSize = (
            1095
            105)
          object SpeedButton16: TSpeedButton
            Left = 1019
            Top = 61
            Width = 70
            Height = 41
            Anchors = [akTop, akRight]
            Caption = 'R'#233'pertoire'
            ImageIndex = 49
            Images = DM.Smal
            Flat = True
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Arial'
            Font.Style = []
            Layout = blGlyphTop
            Margin = 1
            ParentFont = False
            PressedImageIndex = 81
            Spacing = 0
            StyleName = 'clear day se'
            OnClick = SpeedButton16Click
            ExplicitLeft = 1108
          end
          object SpeedButton39: TSpeedButton
            Left = 1019
            Top = 14
            Width = 70
            Height = 41
            Anchors = [akTop, akRight]
            Caption = 'Midifier'
            ImageIndex = 72
            Images = DM.Smal
            Flat = True
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Arial'
            Font.Style = []
            Layout = blGlyphTop
            Margin = 1
            ParentFont = False
            PressedImageIndex = 81
            Spacing = 0
            StyleName = 'clear day se'
            OnClick = SpeedButton39Click
          end
          object scGPGroupBox1: TscGPGroupBox
            Left = 8
            Top = 8
            Width = 1005
            Height = 89
            Anchors = [akLeft, akTop, akRight]
            Enabled = False
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clBtnText
            Font.Height = -12
            Font.Name = 'Segoe UI'
            Font.Style = []
            ParentFont = False
            FluentUIOpaque = False
            TabOrder = 0
            Alignment = taLeftJustify
            Caption = 'Dossier'
            DrawTextMode = scdtmGDI
            ImageIndex = -1
            GlowEffect.Enabled = False
            GlowEffect.Color = clHighlight
            GlowEffect.AlphaValue = 255
            GlowEffect.GlowSize = 7
            GlowEffect.Offset = 0
            GlowEffect.Intensive = True
            GlowEffect.StyleColors = True
            ImageGlow = True
            FrameColor = clBtnText
            FrameColorAlpha = 50
            FrameRadius = 0
            FrameWidth = 2
            ScaleFrameWdith = False
            StorePaintBuffer = True
            ExplicitWidth = 1003
            object scGPLabel9: TscGPLabel
              Left = 11
              Top = 16
              Width = 190
              Height = 18
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBtnText
              Font.Height = -13
              Font.Name = 'Tahoma'
              Font.Style = []
              ParentFont = False
              FluentUIOpaque = False
              TabOrder = 0
              DragForm = False
              DragTopForm = True
              DrawTextMode = scdtmGDI
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              DisabledFontColor = clNone
              FrameWidth = 1
              FillColor = clBtnText
              FillColorAlpha = 20
              FillColor2 = clNone
              FillColor2Alpha = 255
              FillGradientAngle = 0
              FrameColor = clBtnText
              FrameColorAlpha = 40
              FrameRadius = 2
              GlowEffect.Enabled = False
              GlowEffect.Color = clBtnShadow
              GlowEffect.AlphaValue = 255
              GlowEffect.GlowSize = 7
              GlowEffect.Offset = 0
              GlowEffect.Intensive = True
              GlowEffect.StyleColors = True
              AutoSize = False
              VertAlignment = scvtaCenter
              Caption = 'Nom  Pr'#233'nom / Raison Sociale'
            end
            object RS: TscGPDBEdit
              Left = 207
              Top = 15
              Width = 576
              Height = 20
              FluentUIOpaque = False
              Options.NormalColor = clWindow
              Options.HotColor = clWindow
              Options.FocusedColor = 12779261
              Options.DisabledColor = clWindow
              Options.NormalColorAlpha = 200
              Options.HotColorAlpha = 255
              Options.FocusedColorAlpha = 255
              Options.DisabledColorAlpha = 150
              Options.FrameNormalColor = clBtnText
              Options.FrameHotColor = clHighlight
              Options.FrameFocusedColor = clHighlight
              Options.FrameDisabledColor = clBtnText
              Options.FrameWidth = 1
              Options.FrameNormalColorAlpha = 100
              Options.FrameHotColorAlpha = 255
              Options.FrameFocusedColorAlpha = 255
              Options.FrameDisabledColorAlpha = 50
              Options.FontNormalColor = clWindowText
              Options.FontHotColor = clWindowText
              Options.FontFocusedColor = clWindowText
              Options.FontDisabledColor = clGrayText
              Options.FocusedLineColor = 12779261
              Options.FocusedLineWidth = 0
              Options.ShapeFillGradientAngle = 90
              Options.ShapeCornerRadius = 10
              Options.ShapeStyle = scgpessLineRect
              Options.ScaleFrameWidth = False
              Options.StyleColors = True
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              HideMaskWithEmptyText = False
              HidePromptTextIfFocused = False
              PromptTextColor = clNone
              Transparent = False
              LeftButton.Kind = scgpebCustom
              LeftButton.Enabled = True
              LeftButton.Visible = False
              LeftButton.ImageIndex = -1
              LeftButton.ImageHotIndex = -1
              LeftButton.ImagePressedIndex = -1
              LeftButton.RepeatClick = False
              LeftButton.RepeatClickInterval = 200
              LeftButton.ShowHint = False
              LeftButton.GlyphColor = clWindowText
              LeftButton.GlyphColorAlpha = 180
              LeftButton.GlyphColorHotAlpha = 240
              LeftButton.GlyphColorPressedAlpha = 150
              LeftButton.GlyphThickness = 2
              LeftButton.GlyphSize = 0
              LeftButton.Width = 0
              RightButton.Kind = scgpebCustom
              RightButton.Enabled = True
              RightButton.Visible = False
              RightButton.ImageIndex = -1
              RightButton.ImageHotIndex = -1
              RightButton.ImagePressedIndex = -1
              RightButton.RepeatClick = False
              RightButton.RepeatClickInterval = 200
              RightButton.ShowHint = False
              RightButton.GlyphColor = clWindowText
              RightButton.GlyphColorAlpha = 180
              RightButton.GlyphColorHotAlpha = 240
              RightButton.GlyphColorPressedAlpha = 150
              RightButton.GlyphThickness = 2
              RightButton.GlyphSize = 0
              RightButton.Width = 0
              CustomDraw = False
              Text = 'SARL LN TRA '
              CharCase = ecUpperCase
              Color = clBtnFace
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -13
              Font.Name = 'Arial'
              Font.Style = [fsBold]
              ParentFont = False
              TabOrder = 1
              DataField = 'RS'
              DataSource = DM.dclient
            end
            object scGPLabel1: TscGPLabel
              Left = 789
              Top = 19
              Width = 37
              Height = 18
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBtnText
              Font.Height = -13
              Font.Name = 'Tahoma'
              Font.Style = []
              ParentFont = False
              FluentUIOpaque = False
              TabOrder = 2
              DragForm = False
              DragTopForm = True
              DrawTextMode = scdtmGDI
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              DisabledFontColor = clNone
              FrameWidth = 1
              FillColor = clBtnText
              FillColorAlpha = 20
              FillColor2 = clNone
              FillColor2Alpha = 255
              FillGradientAngle = 0
              FrameColor = clBtnText
              FrameColorAlpha = 40
              FrameRadius = 2
              GlowEffect.Enabled = False
              GlowEffect.Color = clBtnShadow
              GlowEffect.AlphaValue = 255
              GlowEffect.GlowSize = 7
              GlowEffect.Offset = 0
              GlowEffect.Intensive = True
              GlowEffect.StyleColors = True
              AutoSize = False
              VertAlignment = scvtaCenter
              Caption = 'NIF :'
            end
            object scGPDBEdit8: TscGPDBEdit
              Left = 832
              Top = 16
              Width = 183
              Height = 19
              FluentUIOpaque = False
              Options.NormalColor = clWindow
              Options.HotColor = clWindow
              Options.FocusedColor = 12779261
              Options.DisabledColor = clWindow
              Options.NormalColorAlpha = 200
              Options.HotColorAlpha = 255
              Options.FocusedColorAlpha = 255
              Options.DisabledColorAlpha = 150
              Options.FrameNormalColor = clBtnText
              Options.FrameHotColor = clHighlight
              Options.FrameFocusedColor = clHighlight
              Options.FrameDisabledColor = clBtnText
              Options.FrameWidth = 1
              Options.FrameNormalColorAlpha = 100
              Options.FrameHotColorAlpha = 255
              Options.FrameFocusedColorAlpha = 255
              Options.FrameDisabledColorAlpha = 50
              Options.FontNormalColor = clWindowText
              Options.FontHotColor = clWindowText
              Options.FontFocusedColor = clWindowText
              Options.FontDisabledColor = clGrayText
              Options.FocusedLineColor = 12779261
              Options.FocusedLineWidth = 0
              Options.ShapeFillGradientAngle = 90
              Options.ShapeCornerRadius = 10
              Options.ShapeStyle = scgpessLineRect
              Options.ScaleFrameWidth = False
              Options.StyleColors = True
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              HideMaskWithEmptyText = False
              HidePromptTextIfFocused = False
              PromptTextColor = clNone
              Transparent = False
              LeftButton.Kind = scgpebCustom
              LeftButton.Enabled = True
              LeftButton.Visible = False
              LeftButton.ImageIndex = -1
              LeftButton.ImageHotIndex = -1
              LeftButton.ImagePressedIndex = -1
              LeftButton.RepeatClick = False
              LeftButton.RepeatClickInterval = 200
              LeftButton.ShowHint = False
              LeftButton.GlyphColor = clWindowText
              LeftButton.GlyphColorAlpha = 180
              LeftButton.GlyphColorHotAlpha = 240
              LeftButton.GlyphColorPressedAlpha = 150
              LeftButton.GlyphThickness = 2
              LeftButton.GlyphSize = 0
              LeftButton.Width = 0
              RightButton.Kind = scgpebCustom
              RightButton.Enabled = True
              RightButton.Visible = False
              RightButton.ImageIndex = -1
              RightButton.ImageHotIndex = -1
              RightButton.ImagePressedIndex = -1
              RightButton.RepeatClick = False
              RightButton.RepeatClickInterval = 200
              RightButton.ShowHint = False
              RightButton.GlyphColor = clWindowText
              RightButton.GlyphColorAlpha = 180
              RightButton.GlyphColorHotAlpha = 240
              RightButton.GlyphColorPressedAlpha = 150
              RightButton.GlyphThickness = 2
              RightButton.GlyphSize = 0
              RightButton.Width = 0
              CustomDraw = False
              Text = '000719008699559'
              Alignment = taCenter
              Color = clBtnFace
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = []
              NumbersOnly = True
              ParentFont = False
              TabOrder = 3
              DataField = 'NIF'
              DataSource = DM.dclient
            end
            object scGPLabel10: TscGPLabel
              Left = 11
              Top = 38
              Width = 119
              Height = 18
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBtnText
              Font.Height = -13
              Font.Name = 'Tahoma'
              Font.Style = []
              ParentFont = False
              FluentUIOpaque = False
              TabOrder = 4
              DragForm = False
              DragTopForm = True
              DrawTextMode = scdtmGDI
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              DisabledFontColor = clNone
              FrameWidth = 1
              FillColor = clBtnText
              FillColorAlpha = 20
              FillColor2 = clNone
              FillColor2Alpha = 255
              FillGradientAngle = 0
              FrameColor = clBtnText
              FrameColorAlpha = 40
              FrameRadius = 2
              GlowEffect.Enabled = False
              GlowEffect.Color = clBtnShadow
              GlowEffect.AlphaValue = 255
              GlowEffect.GlowSize = 7
              GlowEffect.Offset = 0
              GlowEffect.Intensive = True
              GlowEffect.StyleColors = True
              AutoSize = False
              VertAlignment = scvtaCenter
              Caption = 'Activit'#233' :'
            end
            object Act: TscGPDBEdit
              Left = 136
              Top = 38
              Width = 657
              Height = 19
              FluentUIOpaque = False
              Options.NormalColor = clWindow
              Options.HotColor = clWindow
              Options.FocusedColor = 12779261
              Options.DisabledColor = clWindow
              Options.NormalColorAlpha = 200
              Options.HotColorAlpha = 255
              Options.FocusedColorAlpha = 255
              Options.DisabledColorAlpha = 150
              Options.FrameNormalColor = clBtnText
              Options.FrameHotColor = clHighlight
              Options.FrameFocusedColor = clHighlight
              Options.FrameDisabledColor = clBtnText
              Options.FrameWidth = 1
              Options.FrameNormalColorAlpha = 100
              Options.FrameHotColorAlpha = 255
              Options.FrameFocusedColorAlpha = 255
              Options.FrameDisabledColorAlpha = 50
              Options.FontNormalColor = clWindowText
              Options.FontHotColor = clWindowText
              Options.FontFocusedColor = clWindowText
              Options.FontDisabledColor = clGrayText
              Options.FocusedLineColor = 12779261
              Options.FocusedLineWidth = 0
              Options.ShapeFillGradientAngle = 90
              Options.ShapeCornerRadius = 10
              Options.ShapeStyle = scgpessLineRect
              Options.ScaleFrameWidth = False
              Options.StyleColors = True
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              HideMaskWithEmptyText = False
              HidePromptTextIfFocused = False
              PromptTextColor = clNone
              Transparent = False
              LeftButton.Kind = scgpebCustom
              LeftButton.Enabled = True
              LeftButton.Visible = False
              LeftButton.ImageIndex = -1
              LeftButton.ImageHotIndex = -1
              LeftButton.ImagePressedIndex = -1
              LeftButton.RepeatClick = False
              LeftButton.RepeatClickInterval = 200
              LeftButton.ShowHint = False
              LeftButton.GlyphColor = clWindowText
              LeftButton.GlyphColorAlpha = 180
              LeftButton.GlyphColorHotAlpha = 240
              LeftButton.GlyphColorPressedAlpha = 150
              LeftButton.GlyphThickness = 2
              LeftButton.GlyphSize = 0
              LeftButton.Width = 0
              RightButton.Kind = scgpebCustom
              RightButton.Enabled = True
              RightButton.Visible = False
              RightButton.ImageIndex = -1
              RightButton.ImageHotIndex = -1
              RightButton.ImagePressedIndex = -1
              RightButton.RepeatClick = False
              RightButton.RepeatClickInterval = 200
              RightButton.ShowHint = False
              RightButton.GlyphColor = clWindowText
              RightButton.GlyphColorAlpha = 180
              RightButton.GlyphColorHotAlpha = 240
              RightButton.GlyphColorPressedAlpha = 150
              RightButton.GlyphThickness = 2
              RightButton.GlyphSize = 0
              RightButton.Width = 0
              CustomDraw = False
              Text = 'TRVX D'#39'ELECTRICITE'
              CharCase = ecUpperCase
              Color = clBtnFace
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = []
              ParentFont = False
              TabOrder = 5
              DataField = 'activit'#233
              DataSource = DM.dclient
            end
            object scGPLabel12: TscGPLabel
              Left = 12
              Top = 63
              Width = 119
              Height = 18
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clBtnText
              Font.Height = -13
              Font.Name = 'Tahoma'
              Font.Style = []
              ParentFont = False
              FluentUIOpaque = False
              TabOrder = 6
              DragForm = False
              DragTopForm = True
              DrawTextMode = scdtmGDI
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              DisabledFontColor = clNone
              FrameWidth = 1
              FillColor = clBtnText
              FillColorAlpha = 20
              FillColor2 = clNone
              FillColor2Alpha = 255
              FillGradientAngle = 0
              FrameColor = clBtnText
              FrameColorAlpha = 40
              FrameRadius = 2
              GlowEffect.Enabled = False
              GlowEffect.Color = clBtnShadow
              GlowEffect.AlphaValue = 255
              GlowEffect.GlowSize = 7
              GlowEffect.Offset = 0
              GlowEffect.Intensive = True
              GlowEffect.StyleColors = True
              AutoSize = False
              VertAlignment = scvtaCenter
              Caption = 'Adresse :'
            end
            object Adr: TscGPDBEdit
              Left = 137
              Top = 60
              Width = 657
              Height = 19
              FluentUIOpaque = False
              Options.NormalColor = clWindow
              Options.HotColor = clWindow
              Options.FocusedColor = 12779261
              Options.DisabledColor = clWindow
              Options.NormalColorAlpha = 200
              Options.HotColorAlpha = 255
              Options.FocusedColorAlpha = 255
              Options.DisabledColorAlpha = 150
              Options.FrameNormalColor = clBtnText
              Options.FrameHotColor = clHighlight
              Options.FrameFocusedColor = clHighlight
              Options.FrameDisabledColor = clBtnText
              Options.FrameWidth = 1
              Options.FrameNormalColorAlpha = 100
              Options.FrameHotColorAlpha = 255
              Options.FrameFocusedColorAlpha = 255
              Options.FrameDisabledColorAlpha = 50
              Options.FontNormalColor = clWindowText
              Options.FontHotColor = clWindowText
              Options.FontFocusedColor = clWindowText
              Options.FontDisabledColor = clGrayText
              Options.FocusedLineColor = 12779261
              Options.FocusedLineWidth = 0
              Options.ShapeFillGradientAngle = 90
              Options.ShapeCornerRadius = 10
              Options.ShapeStyle = scgpessLineRect
              Options.ScaleFrameWidth = False
              Options.StyleColors = True
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              HideMaskWithEmptyText = False
              HidePromptTextIfFocused = False
              PromptTextColor = clNone
              Transparent = False
              LeftButton.Kind = scgpebCustom
              LeftButton.Enabled = True
              LeftButton.Visible = False
              LeftButton.ImageIndex = -1
              LeftButton.ImageHotIndex = -1
              LeftButton.ImagePressedIndex = -1
              LeftButton.RepeatClick = False
              LeftButton.RepeatClickInterval = 200
              LeftButton.ShowHint = False
              LeftButton.GlyphColor = clWindowText
              LeftButton.GlyphColorAlpha = 180
              LeftButton.GlyphColorHotAlpha = 240
              LeftButton.GlyphColorPressedAlpha = 150
              LeftButton.GlyphThickness = 2
              LeftButton.GlyphSize = 0
              LeftButton.Width = 0
              RightButton.Kind = scgpebCustom
              RightButton.Enabled = True
              RightButton.Visible = False
              RightButton.ImageIndex = -1
              RightButton.ImageHotIndex = -1
              RightButton.ImagePressedIndex = -1
              RightButton.RepeatClick = False
              RightButton.RepeatClickInterval = 200
              RightButton.ShowHint = False
              RightButton.GlyphColor = clWindowText
              RightButton.GlyphColorAlpha = 180
              RightButton.GlyphColorHotAlpha = 240
              RightButton.GlyphColorPressedAlpha = 150
              RightButton.GlyphThickness = 2
              RightButton.GlyphSize = 0
              RightButton.Width = 0
              CustomDraw = False
              Text = 'CITE ELHIDHAB 2TR N'#176'360 SETIF'
              Color = clBtnFace
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = []
              ParentFont = False
              TabOrder = 7
              DataField = 'ADRESSE'
              DataSource = DM.dclient
            end
            object Edit1: TEdit
              Left = 799
              Top = 68
              Width = 363
              Height = 23
              TabOrder = 8
              Text = 'Edit1'
              Visible = False
            end
            object scGPDBEdit2: TscGPDBEdit
              Left = 1016
              Top = 16
              Width = 57
              Height = 19
              FluentUIOpaque = False
              Options.NormalColor = clWindow
              Options.HotColor = clWindow
              Options.FocusedColor = 12779261
              Options.DisabledColor = clWindow
              Options.NormalColorAlpha = 200
              Options.HotColorAlpha = 255
              Options.FocusedColorAlpha = 255
              Options.DisabledColorAlpha = 150
              Options.FrameNormalColor = clBtnText
              Options.FrameHotColor = clHighlight
              Options.FrameFocusedColor = clHighlight
              Options.FrameDisabledColor = clBtnText
              Options.FrameWidth = 1
              Options.FrameNormalColorAlpha = 100
              Options.FrameHotColorAlpha = 255
              Options.FrameFocusedColorAlpha = 255
              Options.FrameDisabledColorAlpha = 50
              Options.FontNormalColor = clWindowText
              Options.FontHotColor = clWindowText
              Options.FontFocusedColor = clWindowText
              Options.FontDisabledColor = clGrayText
              Options.FocusedLineColor = 12779261
              Options.FocusedLineWidth = 0
              Options.ShapeFillGradientAngle = 90
              Options.ShapeCornerRadius = 10
              Options.ShapeStyle = scgpessLineRect
              Options.ScaleFrameWidth = False
              Options.StyleColors = True
              ContentMarginLeft = 5
              ContentMarginRight = 5
              ContentMarginTop = 2
              ContentMarginBottom = 2
              HideMaskWithEmptyText = False
              HidePromptTextIfFocused = False
              PromptTextColor = clNone
              Transparent = False
              LeftButton.Kind = scgpebCustom
              LeftButton.Enabled = True
              LeftButton.Visible = False
              LeftButton.ImageIndex = -1
              LeftButton.ImageHotIndex = -1
              LeftButton.ImagePressedIndex = -1
              LeftButton.RepeatClick = False
              LeftButton.RepeatClickInterval = 200
              LeftButton.ShowHint = False
              LeftButton.GlyphColor = clWindowText
              LeftButton.GlyphColorAlpha = 180
              LeftButton.GlyphColorHotAlpha = 240
              LeftButton.GlyphColorPressedAlpha = 150
              LeftButton.GlyphThickness = 2
              LeftButton.GlyphSize = 0
              LeftButton.Width = 0
              RightButton.Kind = scgpebCustom
              RightButton.Enabled = True
              RightButton.Visible = False
              RightButton.ImageIndex = -1
              RightButton.ImageHotIndex = -1
              RightButton.ImagePressedIndex = -1
              RightButton.RepeatClick = False
              RightButton.RepeatClickInterval = 200
              RightButton.ShowHint = False
              RightButton.GlyphColor = clWindowText
              RightButton.GlyphColorAlpha = 180
              RightButton.GlyphColorHotAlpha = 240
              RightButton.GlyphColorPressedAlpha = 150
              RightButton.GlyphThickness = 2
              RightButton.GlyphSize = 0
              RightButton.Width = 0
              CustomDraw = False
              Text = '00000'
              Alignment = taCenter
              Color = clBtnFace
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Arial'
              Font.Style = []
              NumbersOnly = True
              ParentFont = False
              TabOrder = 9
              DataField = 'NIF2'
              DataSource = DM.dclient
            end
          end
        end
        object Panel37: TPanel
          Left = 0
          Top = 105
          Width = 113
          Height = 538
          Align = alLeft
          BevelOuter = bvLowered
          TabOrder = 2
          ExplicitHeight = 537
          DesignSize = (
            113
            538)
          object SpeedButton11: TSpeedButton
            Left = 33
            Top = 112
            Width = 49
            Height = 42
            Hint = 'Table des Exercices'
            ImageIndex = 36
            Images = DM.Smal
            Flat = True
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -12
            Font.Name = 'Arial'
            Font.Style = [fsBold]
            Layout = blGlyphTop
            Margin = 1
            ParentFont = False
            PressedImageIndex = 0
            Spacing = 0
            StyleName = 'clear day se'
            OnClick = SpeedButton11Click
          end
          object dbann1: TscDBEdit
            Left = 907
            Top = 6
            Width = 0
            Height = 497
            FluentUIOpaque = False
            UseFontColorToStyleColor = True
            ContentMarginLeft = 0
            ContentMarginRight = 0
            ContentMarginTop = 0
            ContentMarginBottom = 0
            CustomBackgroundImageNormalIndex = -1
            CustomBackgroundImageHotIndex = -1
            CustomBackgroundImageDisabledIndex = -1
            PromptTextColor = clNone
            HideMaskWithEmptyText = False
            HidePromptTextIfFocused = False
            WallpaperIndex = -1
            LeftButton.ComboButton = False
            LeftButton.Enabled = True
            LeftButton.Visible = False
            LeftButton.ShowHint = False
            LeftButton.ShowEllipses = False
            LeftButton.StyleKind = scbsPushButton
            LeftButton.Width = 18
            LeftButton.ImageIndex = -1
            LeftButton.ImageHotIndex = -1
            LeftButton.ImagePressedIndex = -1
            LeftButton.RepeatClick = False
            LeftButton.RepeatClickInterval = 200
            LeftButton.CustomImageNormalIndex = -1
            LeftButton.CustomImageHotIndex = -1
            LeftButton.CustomImagePressedIndex = -1
            LeftButton.CustomImageDisabledIndex = -1
            RightButton.ComboButton = False
            RightButton.Enabled = True
            RightButton.Visible = False
            RightButton.ShowHint = False
            RightButton.ShowEllipses = False
            RightButton.StyleKind = scbsToolButtonTransparent
            RightButton.Width = 18
            RightButton.ImageIndex = -1
            RightButton.ImageHotIndex = -1
            RightButton.ImagePressedIndex = -1
            RightButton.RepeatClick = False
            RightButton.RepeatClickInterval = 200
            RightButton.CustomImageNormalIndex = -1
            RightButton.CustomImageHotIndex = -1
            RightButton.CustomImagePressedIndex = -1
            RightButton.CustomImageDisabledIndex = -1
            Transparent = True
            BorderKind = scebFrame
            CustomDraw = False
            FrameColor = clMenu
            FrameActiveColor = clHighlight
            Text = 'dbann1'
            Alignment = taCenter
            Anchors = [akLeft, akTop, akRight, akBottom]
            AutoSize = False
            BorderStyle = bsNone
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -24
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            ReadOnly = True
            TabOrder = 0
            Visible = False
            DataField = 'Ann'#233'e'
            DataSource = Form20.DExercices
            ExplicitWidth = 25
            ExplicitHeight = 23
          end
          object scGPLabel18: TscGPLabel
            Left = -1
            Top = 6
            Width = 113
            Height = 39
            Font.Charset = DEFAULT_CHARSET
            Font.Color = -1
            Font.Height = -21
            Font.Name = 'Tahoma'
            Font.Style = [fsBold]
            ParentFont = False
            FluentUIOpaque = False
            TabOrder = 1
            StyleName = 'copper'
            DragForm = False
            DragTopForm = True
            DrawTextMode = scdtmGDI
            ContentMarginLeft = 5
            ContentMarginRight = 5
            ContentMarginTop = 5
            ContentMarginBottom = 5
            DisabledFontColor = clNone
            FrameWidth = 1
            FillColor = clSkyBlue
            FillColorAlpha = 10
            FillColor2 = clNone
            FillColor2Alpha = 180
            FillGradientAngle = 0
            FrameColor = clNone
            FrameColorAlpha = 40
            FrameRadius = 5
            GlowEffect.Enabled = False
            GlowEffect.Color = clBtnShadow
            GlowEffect.AlphaValue = 255
            GlowEffect.GlowSize = 7
            GlowEffect.Offset = 0
            GlowEffect.Intensive = True
            GlowEffect.StyleColors = True
            AutoSize = False
            Alignment = taCenter
            VertAlignment = scvtaCenter
            Caption = 'Exercice :'
          end
          object BtnOpen: TButton
            Left = 752
            Top = 45
            Width = 75
            Height = 25
            Caption = 'Open tables'
            TabOrder = 2
            Visible = False
            OnClick = BtnOpenClick
          end
          object dbann: TscDBText
            Left = 8
            Top = 51
            Width = 113
            Height = 42
            Font.Charset = DEFAULT_CHARSET
            Font.Color = clWindowText
            Font.Height = -40
            Font.Name = 'Segoe UI'
            Font.Style = [fsBold]
            ParentFont = False
            FluentUIOpaque = False
            TabOrder = 3
            DragForm = False
            DragTopForm = True
            GlowEffect.Enabled = True
            GlowEffect.Color = clBtnShadow
            GlowEffect.AlphaValue = 255
            GlowEffect.GlowSize = 7
            GlowEffect.Offset = 0
            GlowEffect.Intensive = True
            GlowEffect.StyleColors = True
            AutoSize = False
            Alignment = taCenter
            VertAlignment = scvtaCenter
            ShowAccelChar = False
            UseFontColorToStyleColor = False
            Caption = 'dbann'
            DataField = 'Ann'#233'e'
            DataSource = Form20.DExercices
          end
        end
      end
    end
    object Card3: TCard
      Left = 1
      Top = 1
      Width = 1095
      Height = 645
      Caption = 'Card3'
      CardIndex = 2
      TabOrder = 2
      object pnlDashMain: TPanel
        Left = 0
        Top = 0
        Width = 1095
        Height = 645
        Align = alClient
        BevelOuter = bvNone
        Color = 16448250
        ParentBackground = False
        TabOrder = 0
        object pnlChartsRow: TPanel
          Left = 0
          Top = 0
          Width = 1095
          Height = 645
          Align = alClient
          BevelOuter = bvNone
          Padding.Left = 20
          Padding.Top = 20
          Padding.Right = 20
          Padding.Bottom = 20
          ParentBackground = False
          TabOrder = 0
          object pnlSidebar: TPanel
            Left = 20
            Top = 336
            Width = 250
            Height = 211
            BevelOuter = bvNone
            Padding.Left = 20
            Padding.Top = 20
            Padding.Right = 10
            Padding.Bottom = 20
            ParentBackground = False
            TabOrder = 0
          end
          object pnlCardsRow: TscGridPanel
            Left = 20
            Top = 249
            Width = 1055
            Height = 312
            Align = alTop
            FluentUIOpaque = False
            TabOrder = 1
            CustomImageIndex = -1
            DragForm = False
            DragTopForm = True
            StyleKind = scpsPanel
            ShowCaption = False
            BorderStyle = scpbsNone
            WallpaperIndex = -1
            LightBorderColor = clBtnHighlight
            ShadowBorderColor = clBtnShadow
            CaptionGlowEffect.Enabled = False
            CaptionGlowEffect.Color = clBtnShadow
            CaptionGlowEffect.AlphaValue = 255
            CaptionGlowEffect.GlowSize = 7
            CaptionGlowEffect.Offset = 0
            CaptionGlowEffect.Intensive = True
            CaptionGlowEffect.StyleColors = True
            Color = clBtnFace
            StorePaintBuffer = False
            WordWrap = False
            ColumnCollection = <
              item
                Value = 25.362009270101990000
              end
              item
                Value = 25.118865917507290000
              end
              item
                Value = 24.883484945533170000
              end
              item
                Value = 24.635639866857550000
              end>
            ControlCollection = <
              item
                Column = 0
                Control = pnlAlertCard
                Row = 0
              end
              item
                Column = 1
                Control = AdvMetroPanel5
                Row = 0
              end
              item
                Column = 2
                Control = AdvMetroPanel6
                Row = 0
              end>
            UseDockManager = False
            ParentBackground = False
            ParentColor = False
            RowCollection = <
              item
                Value = 100.000000000000000000
              end>
            object pnlAlertCard: TAdvMetroPanel
              Left = 0
              Top = 0
              Width = 267
              Height = 312
              Align = alClient
              Appearance.Color = 6579455
              Caption = '  DELAI FINAL : LE 20'
              TabOrder = 0
              TabStop = False
              Version = '1.0.0.1'
              object shpAlert: TShape
                Left = 0
                Top = 0
                Width = 267
                Height = 4
                Align = alTop
                Brush.Color = 2688217
                Pen.Style = psClear
                ExplicitWidth = 240
              end
              object lblAlertDays: TscGPLabel
                Left = 14
                Top = 40
                Width = 223
                Height = 105
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 2688217
                Font.Height = -53
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                Caption = '0'
              end
              object lblAlertClock: TscGPLabel
                Left = 0
                Top = 220
                Width = 220
                Height = 40
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 2688217
                Font.Height = -32
                Font.Name = 'Consolas'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 1
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                Caption = '00:00:00'
              end
              object pbAlert: TProgressBar
                Left = 20
                Top = 180
                Width = 180
                Height = 12
                TabOrder = 0
              end
            end
            object AdvMetroPanel5: TAdvMetroPanel
              Left = 267
              Top = 0
              Width = 265
              Height = 312
              Align = alClient
              Appearance.Color = 16759225
              Caption = '  DELAI FINAL : LE 20'
              TabOrder = 1
              TabStop = False
              Version = '1.0.0.1'
              object Shape7: TShape
                Left = 0
                Top = 0
                Width = 265
                Height = 4
                Align = alTop
                Brush.Color = 2688217
                Pen.Style = psClear
                ExplicitWidth = 240
              end
              object lblIBSAlertDays: TscGPLabel
                Left = 14
                Top = 40
                Width = 223
                Height = 105
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBlue
                Font.Height = -53
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                Caption = '0'
              end
              object lblIBSAlertClock: TscGPLabel
                Left = 0
                Top = 220
                Width = 220
                Height = 40
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBlue
                Font.Height = -32
                Font.Name = 'Consolas'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 1
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                Caption = '00:00:00'
              end
              object pbIBSAlert: TProgressBar
                Left = 20
                Top = 180
                Width = 180
                Height = 12
                TabOrder = 0
              end
            end
            object AdvMetroPanel6: TAdvMetroPanel
              Left = 532
              Top = 0
              Width = 262
              Height = 312
              Align = alClient
              Appearance.Color = 10473471
              Caption = '  DELAI FINAL : LE 20'
              TabOrder = 2
              TabStop = False
              Version = '1.0.0.1'
              object Shape8: TShape
                Left = 0
                Top = 0
                Width = 262
                Height = 4
                Align = alTop
                Brush.Color = 2688217
                Pen.Style = psClear
                ExplicitWidth = 240
              end
              object lblIRGAlertDays: TscGPLabel
                Left = 14
                Top = 40
                Width = 223
                Height = 105
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 33023
                Font.Height = -53
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                Caption = '0'
              end
              object lblIRGAlertClock: TscGPLabel
                Left = 0
                Top = 220
                Width = 220
                Height = 40
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 33023
                Font.Height = -32
                Font.Name = 'Consolas'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 1
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                Caption = '00:00:00'
              end
              object pbIRGAlert: TProgressBar
                Left = 20
                Top = 180
                Width = 180
                Height = 12
                TabOrder = 0
              end
            end
          end
          object scGridPanel1: TscGridPanel
            Left = 20
            Top = 20
            Width = 1055
            Height = 205
            Align = alTop
            FluentUIOpaque = False
            TabOrder = 2
            CustomImageIndex = -1
            DragForm = False
            DragTopForm = True
            StyleKind = scpsPanel
            ShowCaption = False
            BorderStyle = scpbsNone
            WallpaperIndex = -1
            LightBorderColor = clBtnHighlight
            ShadowBorderColor = clBtnShadow
            CaptionGlowEffect.Enabled = False
            CaptionGlowEffect.Color = clBtnShadow
            CaptionGlowEffect.AlphaValue = 255
            CaptionGlowEffect.GlowSize = 7
            CaptionGlowEffect.Offset = 0
            CaptionGlowEffect.Intensive = True
            CaptionGlowEffect.StyleColors = True
            Color = clBtnFace
            StorePaintBuffer = False
            WordWrap = False
            ColumnCollection = <
              item
                Value = 25.362009270101990000
              end
              item
                Value = 25.118865917507290000
              end
              item
                Value = 24.883484945533170000
              end
              item
                Value = 24.635639866857550000
              end>
            ControlCollection = <
              item
                Column = 0
                Control = AdvMetroPanel1
                Row = 0
              end
              item
                Column = 1
                Control = AdvMetroPanel2
                Row = 0
              end
              item
                Column = 2
                Control = AdvMetroPanel3
                Row = 0
              end
              item
                Column = 3
                Control = AdvMetroPanel4
                Row = 0
              end>
            UseDockManager = False
            ParentBackground = False
            ParentColor = False
            RowCollection = <
              item
                Value = 100.000000000000000000
              end>
            object AdvMetroPanel1: TAdvMetroPanel
              Left = 0
              Top = 0
              Width = 267
              Height = 205
              Align = alClient
              Appearance.Color = clRed
              Caption = '  SUIVI G50'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Segoe UI'
              Font.Style = [fsBold]
              TabOrder = 0
              TabStop = False
              Version = '1.0.0.1'
              DesignSize = (
                267
                205)
              object Shape3: TShape
                Left = 0
                Top = 0
                Width = 267
                Height = 4
                Align = alTop
                Brush.Color = 5424610
                Pen.Style = psClear
                ExplicitWidth = 250
              end
              object pbGaugeG50: TAdvGaugeCircle
                Left = 75
                Top = 30
                Width = 116
                Height = 110
                Anchors = [akLeft, akTop, akRight]
                Background.Color = clWhite
                Background.ColorTo = clWhite
                Background.ColorMirror = clNone
                Background.ColorMirrorTo = clNone
                Background.GradientType = gtVertical
                Background.GradientMirrorType = gtNone
                Background.HatchStyleMirror = HatchStyleShingle
                Background.BorderColor = clNone
                Background.BorderWidth = 0
                Background.Rounding = 0
                Background.ShadowColor = clNone
                Background.ShadowOffset = 0
                Background.Glow = gmNone
                CircleBackgroundColor = 14869218
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clRed
                Font.Height = -19
                Font.Name = 'Trebuchet Sans MS'
                Font.Style = [fsBold]
                Increment = 1.000000000000000000
                Maximum = 100.000000000000000000
                PictureUp.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB00000006624B474400FF00FF00FFA0BDA7930000052F49444154789CEDDD6B
                  88D45518C7F1EFEEBA5B5ED8B61B125D10430AA90896A2CB9261E0B2955150A0
                  5050912F8C0CB217BED47A255490518106451729830A42A1A028542ACB282251
                  A258BA60A68B9B77D7BDF5E29CBF6C3AB3FB9F99F39CFFCC99DF079E37EBEE9C
                  E732EECDE78C2022222222222222222222222222222222222222222222222222
                  222222222222529FA603EB80BD3E5EF46F9326701EB01D183F23B6039D05E625
                  115C047CCFD9C3CF62A77F1F49D025C02ECA0F3F8B5DFE7D252197017B987AF8
                  59ECF11F2309B812E827FFF0B3E807E61690AF04340FF883CA879FC5EFFE31A4
                  015D0BECA3FAE167B1CF3F9634901B8183D43EFC2C0E023744AD40AA76333048
                  B8E16731E81F5BEAD81DC051C20F3F8BA3C0C268D548457A8163D80D3F8B63C0
                  A24835494EF70143D80F3F8B217FA6D481878011E20D3F8B61E0C108F5C9241E
                  A598E16731023C625EA594F424304671C3CF620C58615CAB9CE169EA63F8139F
                  042B4D2B96D3D652FCC0CBC51ABBB205EA7BF859AC35ABBE89B500AF52FC70F3
                  C62B3E6709A015D840F143AD3436F8DCA506ADC06BD80DE967F26D09E9495080
                  73808FB11BCE5740978FAF0DCF791F680FDC9BE44D07B6603794CF819913CE9B
                  E9DF6675DE16B4769EDB2CE04BEC86F12930A3C4B933FC9F599DFB85AF4D26D1
                  096CC36E081F021D939CDF017C6478FE3674F7A0AC0B717BF956CD7F1B989623
                  8F76DCD76DAB3C76FA5A6582BC3BFBD5C6EB405B05F9B4F98FB1CAE707E0E20A
                  F249DAA5C06EEC9ABD8EEA7E29D302BC6498D76E5F7B539B4B753BFB79E3056A
                  FB8D5C8B7F0CABFCFA69E2BB07F3707BF756CD5D1530D735867936E5DD83503B
                  FB31869F596598EFDFC0350639D7A5EB81FDD834720C586E98FBE3D8ED21FC83
                  EB4DD26EC266677F1C18059645A861993FCBA286415C8F92B410BB9DFD616069
                  BC5258EACFB4A8E50809DE3D5884DDCEFE496071BC524EBBC79F6D515352770F
                  EEC56E67FF38D017AF94B3DC099C2891578818C2F5AEA13D009CC2A641878105
                  F14A29EB76DCA76D8B1A4F01F747AB24B087B1DBD93F04F444AB646A3DB89C2C
                  6A1DC1F5B2A1ACC0EEC7A5034077BC5272EB0606B0A9790C78225E29B55989DD
                  F0F702F3E39552B1F9B81CAD9E044FC52BA53AABB1297E1CF813B82A5E2955BB
                  1AF80BBB3EAC8E574A652C77F67F05E644ABA4767380DFB0EB475DDD3D68C1ED
                  C15B15FB0B7079B46AC2B90297BB555F5EA60EEE1EB402EBB12BF2276076B46A
                  C29B8DABC1AA3FEB2970ED7C1AB0718A046B891DC0F9D1AAB17301F02D767DDA
                  48BE55B7A0DA814D35263E59643BFBA9E8C2D564D5AF4D44BC7B702EB0D9B098
                  CFF8FFCE7E2AACEF1E6CC6CDC6D42CDC7EBB55119F507A673F150D7DF7A013D8
                  6A98FC074CBEB39F8A0EDCFD04AB3E6EC5E0EE81F5CEFE5B54B6B6DDE8DA70F7
                  14ACFAF91D01EF1E74E1BE23B74AF65D9AF3F2643BF01E767DFD8640DF48BF63
                  9864A5173652D306BC815D7FDF0C9164C8175D9E187A150DC7F2D54F06422468
                  F19BACE7D0F0276A019E277C9F7F0C915C2F61173B9E099154A29E255C9F4708
                  B8577837B52F408E62BBB39F8AE5D4BE767E12B82B74627D54BF00390A3C163A
                  A184D572F7E004868BB2BDB84DDC4A121A0696582594B025547EF7E0386E46A6
                  6E23FF166C513BFBA9584CFE2FBD4770B389A207B7963DD5B3B1C89DFD54F431
                  F567DDC314B0257D0BE557A1EB65673F150B28FF17EE106E168528B50AFD2F70
                  6B510925ACD4DD8301EA6045FE3ADCBF730FE05E70B1F08412D68DEBF1006E6F
                  42FF9FA188888888888888888888888888888888888888888888888888888888
                  88884813F80F8FB7FF0C584F46460000000049454E44AE426082}
                PictureDown.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB000000017352474200AECE1CE90000000467414D410000B18F0BFC61050000
                  00097048597300000EC300000EC301C76FA8640000001A74455874536F667477
                  617265005061696E742E4E45542076332E352E313147F342370000056B494441
                  54785EED9C69A8B46318C78F7D8DD7966449241252225B88226B1445512FF181
                  50F8E0A3E5934221148A6C590A258A224276918844B264CFBEEFBF7F6FA7A6E9
                  3A73669EE7BAE7D9FEBFFAD5DB9C33CF735FFF6BDE993933D7FD2C18638C31C6
                  18638C31C618638C31C618638C31C618638C31C618638C31C618638C31C61863
                  8C316610EC8E4FE037F802EE85A60CCA56192BEB27710F6C142D488BF96FC41F
                  F04034B91C80DFE368D6CABEB1FF70FBA39A3DBAA0457FC483D1E4A02C956994
                  B57AA05ECC15FD0F5F6A418BFE8A47A2A98732549651C68BAA17737BD63D087F
                  C26821E3FE8EC7A2A986B2538651B6E3AA27EA4D518EC0E51E8DE3FE8527A399
                  0D65A6ECA24C9752BD518F8AA0A7A2DF303AF172FE8367A1998E33519945592E
                  A77A94FED27B344EFB54B4942AE86C34935146559BBFA87A750CA67038FE8DD1
                  89AA78399A98CB30CAAC8AEA59CACBC11B189DA08E57E16A6856A12CAEC428AB
                  3ABE89B519FFA027CB1BD10F825519DC80514675FD166B733B4607CFF0365C03
                  878A6ABF15A36C32BC0B6BB3025FC4E80419DE8B6BE1D050CDF7609449862FA1
                  7A97C266F80A4627CAF04E1CD233816ABD03A32C327C15D5B35436C267303A61
                  860FE2DAD87754E303186590A17AA45E1561437C0AA31367F838AE8F7D45B53D
                  8651ED19AA37EA5151D6C547305A4086FA9E7B03EC1BAA49731351CD19AA27EA
                  CD5CD01B98FB305A4886CF63DA1B9816A05A5453546B86EAC5DCDF48AF897763
                  B4A00C5FC64DB1EB6C827A471ED598A17AA05E34C2EA7813460BCB509F646D89
                  5D456B570D516D192A7BF5A051F449D6F5182D30C3F7703BEC1ADBA2D61ED594
                  A13E3D6CD527A95760B4D00C3FC0EDB12B68ADEF63544B86CABA955C82D18233
                  FC1477C1B6B3337E82510D192AE3567301FE8BD1E2EBFA19EE8A6D456BD31AA3
                  B5D755995E889DE05C2CF5206874147A025AD3D718ADB9AECAF23CEC142B3173
                  9064D4B6ED3DD05A961A91AFAB3254969DE444FC13A3C2EAAA29D843B06926CD
                  ECD755D99D849DE678FC03A302EBAA01C8A3B029A699D9AFAA325376BD407385
                  BF6054685D3500791CCE9B5966F667555929B35E71284EBBA16456353F7F0ACE
                  0B9D6BD699FD69FD1995552FD917BFC3A8F0BACE6BEF81CE51776C7B29958D32
                  EA357BE29718055057FDB9740E964233FBA5FEBCFD0A95CD20D80D3FC728880C
                  2FC66C74CCE85C197E81BACEC2A0D8093FC228900C2FC52C4A365F19288B41B2
                  037E885130195E8D75BE31D37D758CE8D819AA76653068B6C677300A28C3EBB0
                  CA8340F7B916A36366A89A55BB812DF0758C82CA509B2F66193B2FBD61E36DDC
                  0ACD089A63D73C7B145886F7E33473731AAFD23E85E818191699D9EF0B9A677F
                  16A3E0327C0827ED3DD0CFB43F21BA6F86AAADD8CC7E5F686AEF816ED3CFA2FB
                  64F834169FD9EF0BEBE1A3180599E1F8DE03FD5BB745BF9BA16A514D6606F47A
                  ADD7ED28D00C75C145CDEB979ED97F18D74153018D3CDF8C51B019EADDF85B63
                  B7657A0B363EB6DD754A3F084AA935BBF949E843995257D128A1AF7E5288927B
                  0FB26CEDCC7E5FD0973C51F06DD0CD9F139A8F2FF5BD7C15B5968BD0CC11CDC9
                  B7E141A0359C8FA6014EC7527B0FA651E73E034D839C8AA5063427A9E69F86A6
                  059C80A5F61E44EA5C3AA7691125F71E8CAA7314BB24BBA987E6E935571F352E
                  431DFB30342D663F2CB1F740C7D4B14D07D81B75A1E4A89155D4B1F641D32134
                  67AF79FBA8A1B338C899FDBE5077EFC1C738D899FDBE5075EF81EEB3239A1EB0
                  0DBE8B51A323F5BBBA8FE9119AC3D70450D4F0513DB3DF6336C7497B0F5E43FD
                  8EE9319ACB7F0EC79BAFDB3646330034A27D0DEA9A7E527B003DB66D8C31C618
                  638C31C618638C31C618638C31C618638C31C618638C31C618638C31C618638C
                  31C69816B2B0F03FF381FF0CF14A6ED70000000049454E44AE426082}
                Position = 50.000000000000000000
                Text = '%'
                Version = '1.0.1.0'
                ArcWidth = 10.000000000000000000
                PenColor = clRed
              end
              object scGPLabel14: TscGPLabel
                Left = 207
                Top = 117
                Width = 45
                Height = 42
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 5424610
                Font.Height = -24
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 1
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = False
                Alignment = taCenter
                Caption = '0%'
              end
              object scGPLabel19: TscGPLabel
                Left = 2
                Top = 145
                Width = 258
                Height = 54
                Anchors = [akLeft, akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clRed
                Font.Height = -12
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = 16053492
                FillColorAlpha = 20
                FillColor2 = 16053492
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = False
                GlowEffect.StyleColors = True
                AutoSize = False
                Caption = 'Total: 0'#13#10'Fait: 0'#13#10'Reste: 0'
              end
            end
            object AdvMetroPanel2: TAdvMetroPanel
              Left = 267
              Top = 0
              Width = 265
              Height = 205
              Align = alClient
              Appearance.Color = clBlue
              Caption = '  SUIVI IBS'
              TabOrder = 1
              TabStop = False
              Version = '1.0.0.1'
              DesignSize = (
                265
                205)
              object Shape4: TShape
                Left = 0
                Top = 0
                Width = 265
                Height = 4
                Align = alTop
                Brush.Color = 16744448
                Pen.Style = psClear
                ExplicitWidth = 250
              end
              object scGPLabel30: TscGPLabel
                Left = 140
                Top = 45
                Width = 45
                Height = 42
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 16744448
                Font.Height = -24
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = True
                Alignment = taCenter
                Caption = '0%'
              end
              object pbGaugeIBS: TAdvGaugeCircle
                Left = 75
                Top = 30
                Width = 116
                Height = 110
                Anchors = [akLeft, akTop, akRight]
                Background.Color = clWhite
                Background.ColorTo = clWhite
                Background.ColorMirror = clNone
                Background.ColorMirrorTo = clNone
                Background.GradientType = gtVertical
                Background.GradientMirrorType = gtSolid
                Background.BorderColor = clNone
                Background.Rounding = 0
                Background.ShadowOffset = 0
                Background.Glow = gmNone
                CircleBackgroundColor = 14869218
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBlue
                Font.Height = -19
                Font.Name = 'Trebuchet Sans MS'
                Font.Style = [fsBold]
                Increment = 1.000000000000000000
                Maximum = 100.000000000000000000
                PictureUp.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB00000006624B474400FF00FF00FFA0BDA7930000052F49444154789CEDDD6B
                  88D45518C7F1EFEEBA5B5ED8B61B125D10430AA90896A2CB9261E0B2955150A0
                  5050912F8C0CB217BED47A255490518106451729830A42A1A028542ACB282251
                  A258BA60A68B9B77D7BDF5E29CBF6C3AB3FB9F99F39CFFCC99DF079E37EBEE9C
                  E732EECDE78C2022222222222222222222222222222222222222222222222222
                  222222222222529FA603EB80BD3E5EF46F9326701EB01D183F23B6039D05E625
                  115C047CCFD9C3CF62A77F1F49D025C02ECA0F3F8B5DFE7D252197017B987AF8
                  59ECF11F2309B812E827FFF0B3E807E61690AF04340FF883CA879FC5EFFE31A4
                  015D0BECA3FAE167B1CF3F9634901B8183D43EFC2C0E023744AD40AA76333048
                  B8E16731E81F5BEAD81DC051C20F3F8BA3C0C268D548457A8163D80D3F8B63C0
                  A24835494EF70143D80F3F8B217FA6D481878011E20D3F8B61E0C108F5C9241E
                  A598E16731023C625EA594F424304671C3CF620C58615CAB9CE169EA63F8139F
                  042B4D2B96D3D652FCC0CBC51ABBB205EA7BF859AC35ABBE89B500AF52FC70F3
                  C62B3E6709A015D840F143AD3436F8DCA506ADC06BD80DE967F26D09E9495080
                  73808FB11BCE5740978FAF0DCF791F680FDC9BE44D07B6603794CF819913CE9B
                  E9DF6675DE16B4769EDB2CE04BEC86F12930A3C4B933FC9F599DFB85AF4D26D1
                  096CC36E081F021D939CDF017C6478FE3674F7A0AC0B717BF956CD7F1B989623
                  8F76DCD76DAB3C76FA5A6582BC3BFBD5C6EB405B05F9B4F98FB1CAE707E0E20A
                  F249DAA5C06EEC9ABD8EEA7E29D302BC6498D76E5F7B539B4B753BFB79E3056A
                  FB8D5C8B7F0CABFCFA69E2BB07F3707BF756CD5D1530D735867936E5DD83503B
                  FB31869F596598EFDFC0350639D7A5EB81FDD834720C586E98FBE3D8ED21FC83
                  EB4DD26EC266677F1C18059645A861993FCBA286415C8F92B410BB9DFD616069
                  BC5258EACFB4A8E50809DE3D5884DDCEFE496071BC524EBBC79F6D515352770F
                  EEC56E67FF38D017AF94B3DC099C2891578818C2F5AEA13D009CC2A641878105
                  F14A29EB76DCA76D8B1A4F01F747AB24B087B1DBD93F04F444AB646A3DB89C2C
                  6A1DC1F5B2A1ACC0EEC7A5034077BC5272EB0606B0A9790C78225E29B55989DD
                  F0F702F3E39552B1F9B81CAD9E044FC52BA53AABB1297E1CF813B82A5E2955BB
                  1AF80BBB3EAC8E574A652C77F67F05E644ABA4767380DFB0EB475DDD3D68C1ED
                  C15B15FB0B7079B46AC2B90297BB555F5EA60EEE1EB402EBB12BF2276076B46A
                  C29B8DABC1AA3FEB2970ED7C1AB0718A046B891DC0F9D1AAB17301F02D767DDA
                  48BE55B7A0DA814D35263E59643BFBA9E8C2D564D5AF4D44BC7B702EB0D9B098
                  CFF8FFCE7E2AACEF1E6CC6CDC6D42CDC7EBB55119F507A673F150D7DF7A013D8
                  6A98FC074CBEB39F8A0EDCFD04AB3E6EC5E0EE81F5CEFE5B54B6B6DDE8DA70F7
                  14ACFAF91D01EF1E74E1BE23B74AF65D9AF3F2643BF01E767DFD8640DF48BF63
                  9864A5173652D306BC815D7FDF0C9164C8175D9E187A150DC7F2D54F06422468
                  F19BACE7D0F0276A019E277C9F7F0C915C2F61173B9E099154A29E255C9F4708
                  B8577837B52F408E62BBB39F8AE5D4BE767E12B82B74627D54BF00390A3C163A
                  A184D572F7E004868BB2BDB84DDC4A121A0696582594B025547EF7E0386E46A6
                  6E23FF166C513BFBA9584CFE2FBD4770B389A207B7963DD5B3B1C89DFD54F431
                  F567DDC314B0257D0BE557A1EB65673F150B28FF17EE106E168528B50AFD2F70
                  6B510925ACD4DD8301EA6045FE3ADCBF730FE05E70B1F08412D68DEBF1006E6F
                  42FF9FA188888888888888888888888888888888888888888888888888888888
                  88884813F80F8FB7FF0C584F46460000000049454E44AE426082}
                PictureDown.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB000000017352474200AECE1CE90000000467414D410000B18F0BFC61050000
                  00097048597300000EC300000EC301C76FA8640000001A74455874536F667477
                  617265005061696E742E4E45542076332E352E313147F342370000056B494441
                  54785EED9C69A8B46318C78F7D8DD7966449241252225B88226B1445512FF181
                  50F8E0A3E5934221148A6C590A258A224276918844B264CFBEEFBF7F6FA7A6E9
                  3A73669EE7BAE7D9FEBFFAD5DB9C33CF735FFF6BDE993933D7FD2C18638C31C6
                  18638C31C618638C31C618638C31C618638C31C618638C31C618638C31C61863
                  8C316610EC8E4FE037F802EE85A60CCA56192BEB27710F6C142D488BF96FC41F
                  F04034B91C80DFE368D6CABEB1FF70FBA39A3DBAA0457FC483D1E4A02C956994
                  B57AA05ECC15FD0F5F6A418BFE8A47A2A98732549651C68BAA17737BD63D087F
                  C26821E3FE8EC7A2A986B2538651B6E3AA27EA4D518EC0E51E8DE3FE8527A399
                  0D65A6ECA24C9752BD518F8AA0A7A2DF303AF172FE8367A1998E33519945592E
                  A77A94FED27B344EFB54B4942AE86C34935146559BBFA87A750CA67038FE8DD1
                  89AA78399A98CB30CAAC8AEA59CACBC11B189DA08E57E16A6856A12CAEC428AB
                  3ABE89B519FFA027CB1BD10F825519DC80514675FD166B733B4607CFF0365C03
                  878A6ABF15A36C32BC0B6BB3025FC4E80419DE8B6BE1D050CDF7609449862FA1
                  7A97C266F80A4627CAF04E1CD233816ABD03A32C327C15D5B35436C267303A61
                  860FE2DAD87754E303186590A17AA45E1561437C0AA31367F838AE8F7D45B53D
                  8651ED19AA37EA5151D6C547305A4086FA9E7B03EC1BAA49731351CD19AA27EA
                  CD5CD01B98FB305A4886CF63DA1B9816A05A5453546B86EAC5DCDF48AF897763
                  B4A00C5FC64DB1EB6C827A471ED598A17AA05E34C2EA7813460BCB509F646D89
                  5D456B570D516D192A7BF5A051F449D6F5182D30C3F7703BEC1ADBA2D61ED594
                  A13E3D6CD527A95760B4D00C3FC0EDB12B68ADEF63544B86CABA955C82D18233
                  FC1477C1B6B3337E82510D192AE3567301FE8BD1E2EBFA19EE8A6D456BD31AA3
                  B5D755995E889DE05C2CF5206874147A025AD3D718ADB9AECAF23CEC142B3173
                  9064D4B6ED3DD05A961A91AFAB3254969DE444FC13A3C2EAAA29D843B06926CD
                  ECD755D99D849DE678FC03A302EBAA01C8A3B029A699D9AFAA325376BD407385
                  BF6054685D3500791CCE9B5966F667555929B35E71284EBBA16456353F7F0ACE
                  0B9D6BD699FD69FD1995552FD917BFC3A8F0BACE6BEF81CE51776C7B29958D32
                  EA357BE29718055057FDB9740E964233FBA5FEBCFD0A95CD20D80D3FC728880C
                  2FC66C74CCE85C197E81BACEC2A0D8093FC228900C2FC52C4A365F19288B41B2
                  037E885130195E8D75BE31D37D758CE8D819AA76653068B6C677300A28C3EBB0
                  CA8340F7B916A36366A89A55BB812DF0758C82CA509B2F66193B2FBD61E36DDC
                  0ACD089A63D73C7B145886F7E33473731AAFD23E85E818191699D9EF0B9A677F
                  16A3E0327C0827ED3DD0CFB43F21BA6F86AAADD8CC7E5F686AEF816ED3CFA2FB
                  64F834169FD9EF0BEBE1A3180599E1F8DE03FD5BB745BF9BA16A514D6606F47A
                  ADD7ED28D00C75C145CDEB979ED97F18D74153018D3CDF8C51B019EADDF85B63
                  B7657A0B363EB6DD754A3F084AA935BBF949E843995257D128A1AF7E5288927B
                  0FB26CEDCC7E5FD0973C51F06DD0CD9F139A8F2FF5BD7C15B5968BD0CC11CDC9
                  B7E141A0359C8FA6014EC7527B0FA651E73E034D839C8AA5063427A9E69F86A6
                  059C80A5F61E44EA5C3AA7691125F71E8CAA7314BB24BBA987E6E935571F352E
                  431DFB30342D663F2CB1F740C7D4B14D07D81B75A1E4A89155D4B1F641D32134
                  67AF79FBA8A1B338C899FDBE5077EFC1C738D899FDBE5075EF81EEB3239A1EB0
                  0DBE8B51A323F5BBBA8FE9119AC3D70450D4F0513DB3DF6336C7497B0F5E43FD
                  8EE9319ACB7F0EC79BAFDB3646330034A27D0DEA9A7E527B003DB66D8C31C618
                  638C31C618638C31C618638C31C618638C31C618638C31C618638C31C618638C
                  31C69816B2B0F03FF381FF0CF14A6ED70000000049454E44AE426082}
                Position = 50.000000000000000000
                Text = '%'
                Version = '1.0.1.0'
                ArcWidth = 10.000000000000000000
              end
              object scGPLabel31: TscGPLabel
                Left = 2
                Top = 145
                Width = 258
                Height = 54
                Anchors = [akLeft, akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clBlue
                Font.Height = -12
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = 16053492
                FillColorAlpha = 20
                FillColor2 = 16053492
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = False
                GlowEffect.StyleColors = True
                AutoSize = False
                Caption = 'Total: 0'#13#10'Fait: 0'#13#10'Reste: 0'
              end
            end
            object AdvMetroPanel3: TAdvMetroPanel
              Left = 532
              Top = 0
              Width = 262
              Height = 205
              Align = alClient
              Appearance.Color = 33023
              Caption = '  SUIVI IRG'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -12
              Font.Name = 'Segoe UI'
              Font.Style = [fsBold]
              TabOrder = 2
              TabStop = False
              Version = '1.0.0.1'
              DesignSize = (
                262
                205)
              object Shape5: TShape
                Left = 0
                Top = 0
                Width = 262
                Height = 4
                Align = alTop
                Brush.Color = 42495
                Pen.Style = psClear
                ExplicitWidth = 250
              end
              object scGPLabel32: TscGPLabel
                Left = 140
                Top = 45
                Width = 45
                Height = 42
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 42495
                Font.Height = -24
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = True
                Alignment = taCenter
                Caption = '0%'
              end
              object pbGaugeIRG: TAdvGaugeCircle
                Left = 75
                Top = 30
                Width = 116
                Height = 110
                Anchors = [akLeft, akTop, akRight]
                Background.Color = clWhite
                Background.ColorTo = clWhite
                Background.ColorMirror = clNone
                Background.ColorMirrorTo = clNone
                Background.GradientType = gtVertical
                Background.GradientMirrorType = gtSolid
                Background.BorderColor = clNone
                Background.Rounding = 0
                Background.ShadowOffset = 0
                Background.Glow = gmNone
                CircleBackgroundColor = 14869218
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 33023
                Font.Height = -19
                Font.Name = 'Trebuchet Sans MS'
                Font.Style = [fsBold]
                Increment = 1.000000000000000000
                Maximum = 100.000000000000000000
                PictureUp.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB00000006624B474400FF00FF00FFA0BDA7930000052F49444154789CEDDD6B
                  88D45518C7F1EFEEBA5B5ED8B61B125D10430AA90896A2CB9261E0B2955150A0
                  5050912F8C0CB217BED47A255490518106451729830A42A1A028542ACB282251
                  A258BA60A68B9B77D7BDF5E29CBF6C3AB3FB9F99F39CFFCC99DF079E37EBEE9C
                  E732EECDE78C2022222222222222222222222222222222222222222222222222
                  222222222222529FA603EB80BD3E5EF46F9326701EB01D183F23B6039D05E625
                  115C047CCFD9C3CF62A77F1F49D025C02ECA0F3F8B5DFE7D252197017B987AF8
                  59ECF11F2309B812E827FFF0B3E807E61690AF04340FF883CA879FC5EFFE31A4
                  015D0BECA3FAE167B1CF3F9634901B8183D43EFC2C0E023744AD40AA76333048
                  B8E16731E81F5BEAD81DC051C20F3F8BA3C0C268D548457A8163D80D3F8B63C0
                  A24835494EF70143D80F3F8B217FA6D481878011E20D3F8B61E0C108F5C9241E
                  A598E16731023C625EA594F424304671C3CF620C58615CAB9CE169EA63F8139F
                  042B4D2B96D3D652FCC0CBC51ABBB205EA7BF859AC35ABBE89B500AF52FC70F3
                  C62B3E6709A015D840F143AD3436F8DCA506ADC06BD80DE967F26D09E9495080
                  73808FB11BCE5740978FAF0DCF791F680FDC9BE44D07B6603794CF819913CE9B
                  E9DF6675DE16B4769EDB2CE04BEC86F12930A3C4B933FC9F599DFB85AF4D26D1
                  096CC36E081F021D939CDF017C6478FE3674F7A0AC0B717BF956CD7F1B989623
                  8F76DCD76DAB3C76FA5A6582BC3BFBD5C6EB405B05F9B4F98FB1CAE707E0E20A
                  F249DAA5C06EEC9ABD8EEA7E29D302BC6498D76E5F7B539B4B753BFB79E3056A
                  FB8D5C8B7F0CABFCFA69E2BB07F3707BF756CD5D1530D735867936E5DD83503B
                  FB31869F596598EFDFC0350639D7A5EB81FDD834720C586E98FBE3D8ED21FC83
                  EB4DD26EC266677F1C18059645A861993FCBA286415C8F92B410BB9DFD616069
                  BC5258EACFB4A8E50809DE3D5884DDCEFE496071BC524EBBC79F6D515352770F
                  EEC56E67FF38D017AF94B3DC099C2891578818C2F5AEA13D009CC2A641878105
                  F14A29EB76DCA76D8B1A4F01F747AB24B087B1DBD93F04F444AB646A3DB89C2C
                  6A1DC1F5B2A1ACC0EEC7A5034077BC5272EB0606B0A9790C78225E29B55989DD
                  F0F702F3E39552B1F9B81CAD9E044FC52BA53AABB1297E1CF813B82A5E2955BB
                  1AF80BBB3EAC8E574A652C77F67F05E644ABA4767380DFB0EB475DDD3D68C1ED
                  C15B15FB0B7079B46AC2B90297BB555F5EA60EEE1EB402EBB12BF2276076B46A
                  C29B8DABC1AA3FEB2970ED7C1AB0718A046B891DC0F9D1AAB17301F02D767DDA
                  48BE55B7A0DA814D35263E59643BFBA9E8C2D564D5AF4D44BC7B702EB0D9B098
                  CFF8FFCE7E2AACEF1E6CC6CDC6D42CDC7EBB55119F507A673F150D7DF7A013D8
                  6A98FC074CBEB39F8A0EDCFD04AB3E6EC5E0EE81F5CEFE5B54B6B6DDE8DA70F7
                  14ACFAF91D01EF1E74E1BE23B74AF65D9AF3F2643BF01E767DFD8640DF48BF63
                  9864A5173652D306BC815D7FDF0C9164C8175D9E187A150DC7F2D54F06422468
                  F19BACE7D0F0276A019E277C9F7F0C915C2F61173B9E099154A29E255C9F4708
                  B8577837B52F408E62BBB39F8AE5D4BE767E12B82B74627D54BF00390A3C163A
                  A184D572F7E004868BB2BDB84DDC4A121A0696582594B025547EF7E0386E46A6
                  6E23FF166C513BFBA9584CFE2FBD4770B389A207B7963DD5B3B1C89DFD54F431
                  F567DDC314B0257D0BE557A1EB65673F150B28FF17EE106E168528B50AFD2F70
                  6B510925ACD4DD8301EA6045FE3ADCBF730FE05E70B1F08412D68DEBF1006E6F
                  42FF9FA188888888888888888888888888888888888888888888888888888888
                  88884813F80F8FB7FF0C584F46460000000049454E44AE426082}
                PictureDown.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB000000017352474200AECE1CE90000000467414D410000B18F0BFC61050000
                  00097048597300000EC300000EC301C76FA8640000001A74455874536F667477
                  617265005061696E742E4E45542076332E352E313147F342370000056B494441
                  54785EED9C69A8B46318C78F7D8DD7966449241252225B88226B1445512FF181
                  50F8E0A3E5934221148A6C590A258A224276918844B264CFBEEFBF7F6FA7A6E9
                  3A73669EE7BAE7D9FEBFFAD5DB9C33CF735FFF6BDE993933D7FD2C18638C31C6
                  18638C31C618638C31C618638C31C618638C31C618638C31C618638C31C61863
                  8C316610EC8E4FE037F802EE85A60CCA56192BEB27710F6C142D488BF96FC41F
                  F04034B91C80DFE368D6CABEB1FF70FBA39A3DBAA0457FC483D1E4A02C956994
                  B57AA05ECC15FD0F5F6A418BFE8A47A2A98732549651C68BAA17737BD63D087F
                  C26821E3FE8EC7A2A986B2538651B6E3AA27EA4D518EC0E51E8DE3FE8527A399
                  0D65A6ECA24C9752BD518F8AA0A7A2DF303AF172FE8367A1998E33519945592E
                  A77A94FED27B344EFB54B4942AE86C34935146559BBFA87A750CA67038FE8DD1
                  89AA78399A98CB30CAAC8AEA59CACBC11B189DA08E57E16A6856A12CAEC428AB
                  3ABE89B519FFA027CB1BD10F825519DC80514675FD166B733B4607CFF0365C03
                  878A6ABF15A36C32BC0B6BB3025FC4E80419DE8B6BE1D050CDF7609449862FA1
                  7A97C266F80A4627CAF04E1CD233816ABD03A32C327C15D5B35436C267303A61
                  860FE2DAD87754E303186590A17AA45E1561437C0AA31367F838AE8F7D45B53D
                  8651ED19AA37EA5151D6C547305A4086FA9E7B03EC1BAA49731351CD19AA27EA
                  CD5CD01B98FB305A4886CF63DA1B9816A05A5453546B86EAC5DCDF48AF897763
                  B4A00C5FC64DB1EB6C827A471ED598A17AA05E34C2EA7813460BCB509F646D89
                  5D456B570D516D192A7BF5A051F449D6F5182D30C3F7703BEC1ADBA2D61ED594
                  A13E3D6CD527A95760B4D00C3FC0EDB12B68ADEF63544B86CABA955C82D18233
                  FC1477C1B6B3337E82510D192AE3567301FE8BD1E2EBFA19EE8A6D456BD31AA3
                  B5D755995E889DE05C2CF5206874147A025AD3D718ADB9AECAF23CEC142B3173
                  9064D4B6ED3DD05A961A91AFAB3254969DE444FC13A3C2EAAA29D843B06926CD
                  ECD755D99D849DE678FC03A302EBAA01C8A3B029A699D9AFAA325376BD407385
                  BF6054685D3500791CCE9B5966F667555929B35E71284EBBA16456353F7F0ACE
                  0B9D6BD699FD69FD1995552FD917BFC3A8F0BACE6BEF81CE51776C7B29958D32
                  EA357BE29718055057FDB9740E964233FBA5FEBCFD0A95CD20D80D3FC728880C
                  2FC66C74CCE85C197E81BACEC2A0D8093FC228900C2FC52C4A365F19288B41B2
                  037E885130195E8D75BE31D37D758CE8D819AA76653068B6C677300A28C3EBB0
                  CA8340F7B916A36366A89A55BB812DF0758C82CA509B2F66193B2FBD61E36DDC
                  0ACD089A63D73C7B145886F7E33473731AAFD23E85E818191699D9EF0B9A677F
                  16A3E0327C0827ED3DD0CFB43F21BA6F86AAADD8CC7E5F686AEF816ED3CFA2FB
                  64F834169FD9EF0BEBE1A3180599E1F8DE03FD5BB745BF9BA16A514D6606F47A
                  ADD7ED28D00C75C145CDEB979ED97F18D74153018D3CDF8C51B019EADDF85B63
                  B7657A0B363EB6DD754A3F084AA935BBF949E843995257D128A1AF7E5288927B
                  0FB26CEDCC7E5FD0973C51F06DD0CD9F139A8F2FF5BD7C15B5968BD0CC11CDC9
                  B7E141A0359C8FA6014EC7527B0FA651E73E034D839C8AA5063427A9E69F86A6
                  059C80A5F61E44EA5C3AA7691125F71E8CAA7314BB24BBA987E6E935571F352E
                  431DFB30342D663F2CB1F740C7D4B14D07D81B75A1E4A89155D4B1F641D32134
                  67AF79FBA8A1B338C899FDBE5077EFC1C738D899FDBE5075EF81EEB3239A1EB0
                  0DBE8B51A323F5BBBA8FE9119AC3D70450D4F0513DB3DF6336C7497B0F5E43FD
                  8EE9319ACB7F0EC79BAFDB3646330034A27D0DEA9A7E527B003DB66D8C31C618
                  638C31C618638C31C618638C31C618638C31C618638C31C618638C31C618638C
                  31C69816B2B0F03FF381FF0CF14A6ED70000000049454E44AE426082}
                Position = 50.000000000000000000
                Text = '%'
                Version = '1.0.1.0'
                ArcWidth = 10.000000000000000000
                PenColor = 33023
              end
              object scGPLabel33: TscGPLabel
                Left = 2
                Top = 145
                Width = 258
                Height = 54
                Anchors = [akLeft, akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = 33023
                Font.Height = -12
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = 16053492
                FillColorAlpha = 20
                FillColor2 = 16053492
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = False
                GlowEffect.StyleColors = True
                AutoSize = False
                Caption = 'Total: 0'#13#10'Fait: 0'#13#10'Reste: 0'
              end
            end
            object AdvMetroPanel4: TAdvMetroPanel
              Left = 794
              Top = 0
              Width = 261
              Height = 205
              Align = alClient
              Appearance.Color = clMaroon
              Caption = '  SUIVI TAPP'
              Font.Charset = DEFAULT_CHARSET
              Font.Color = clWindowText
              Font.Height = -13
              Font.Name = 'Segoe UI'
              Font.Style = [fsBold]
              TabOrder = 3
              TabStop = False
              Version = '1.0.0.1'
              DesignSize = (
                261
                205)
              object Shape6: TShape
                Left = 0
                Top = 0
                Width = 261
                Height = 4
                Align = alTop
                Brush.Color = 3289845
                Pen.Style = psClear
                ExplicitWidth = 345
              end
              object scGPLabel34: TscGPLabel
                Left = 140
                Top = 45
                Width = 45
                Height = 42
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clMaroon
                Font.Height = -24
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 0
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = clBtnText
                FillColorAlpha = 20
                FillColor2 = clNone
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = False
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = True
                GlowEffect.StyleColors = True
                AutoSize = True
                Alignment = taCenter
                Caption = '0%'
              end
              object pbGaugeTAPP: TAdvGaugeCircle
                Left = 75
                Top = 27
                Width = 116
                Height = 110
                Anchors = [akLeft, akTop, akRight]
                Background.Color = clWhite
                Background.ColorTo = clWhite
                Background.ColorMirror = clNone
                Background.ColorMirrorTo = clNone
                Background.GradientType = gtVertical
                Background.GradientMirrorType = gtSolid
                Background.BorderColor = clNone
                Background.Rounding = 0
                Background.ShadowOffset = 0
                Background.Glow = gmNone
                CircleBackgroundColor = 14869218
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clMaroon
                Font.Height = -19
                Font.Name = 'Trebuchet Sans MS'
                Font.Style = [fsBold]
                Increment = 1.000000000000000000
                Maximum = 100.000000000000000000
                PictureUp.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB00000006624B474400FF00FF00FFA0BDA7930000052F49444154789CEDDD6B
                  88D45518C7F1EFEEBA5B5ED8B61B125D10430AA90896A2CB9261E0B2955150A0
                  5050912F8C0CB217BED47A255490518106451729830A42A1A028542ACB282251
                  A258BA60A68B9B77D7BDF5E29CBF6C3AB3FB9F99F39CFFCC99DF079E37EBEE9C
                  E732EECDE78C2022222222222222222222222222222222222222222222222222
                  222222222222529FA603EB80BD3E5EF46F9326701EB01D183F23B6039D05E625
                  115C047CCFD9C3CF62A77F1F49D025C02ECA0F3F8B5DFE7D252197017B987AF8
                  59ECF11F2309B812E827FFF0B3E807E61690AF04340FF883CA879FC5EFFE31A4
                  015D0BECA3FAE167B1CF3F9634901B8183D43EFC2C0E023744AD40AA76333048
                  B8E16731E81F5BEAD81DC051C20F3F8BA3C0C268D548457A8163D80D3F8B63C0
                  A24835494EF70143D80F3F8B217FA6D481878011E20D3F8B61E0C108F5C9241E
                  A598E16731023C625EA594F424304671C3CF620C58615CAB9CE169EA63F8139F
                  042B4D2B96D3D652FCC0CBC51ABBB205EA7BF859AC35ABBE89B500AF52FC70F3
                  C62B3E6709A015D840F143AD3436F8DCA506ADC06BD80DE967F26D09E9495080
                  73808FB11BCE5740978FAF0DCF791F680FDC9BE44D07B6603794CF819913CE9B
                  E9DF6675DE16B4769EDB2CE04BEC86F12930A3C4B933FC9F599DFB85AF4D26D1
                  096CC36E081F021D939CDF017C6478FE3674F7A0AC0B717BF956CD7F1B989623
                  8F76DCD76DAB3C76FA5A6582BC3BFBD5C6EB405B05F9B4F98FB1CAE707E0E20A
                  F249DAA5C06EEC9ABD8EEA7E29D302BC6498D76E5F7B539B4B753BFB79E3056A
                  FB8D5C8B7F0CABFCFA69E2BB07F3707BF756CD5D1530D735867936E5DD83503B
                  FB31869F596598EFDFC0350639D7A5EB81FDD834720C586E98FBE3D8ED21FC83
                  EB4DD26EC266677F1C18059645A861993FCBA286415C8F92B410BB9DFD616069
                  BC5258EACFB4A8E50809DE3D5884DDCEFE496071BC524EBBC79F6D515352770F
                  EEC56E67FF38D017AF94B3DC099C2891578818C2F5AEA13D009CC2A641878105
                  F14A29EB76DCA76D8B1A4F01F747AB24B087B1DBD93F04F444AB646A3DB89C2C
                  6A1DC1F5B2A1ACC0EEC7A5034077BC5272EB0606B0A9790C78225E29B55989DD
                  F0F702F3E39552B1F9B81CAD9E044FC52BA53AABB1297E1CF813B82A5E2955BB
                  1AF80BBB3EAC8E574A652C77F67F05E644ABA4767380DFB0EB475DDD3D68C1ED
                  C15B15FB0B7079B46AC2B90297BB555F5EA60EEE1EB402EBB12BF2276076B46A
                  C29B8DABC1AA3FEB2970ED7C1AB0718A046B891DC0F9D1AAB17301F02D767DDA
                  48BE55B7A0DA814D35263E59643BFBA9E8C2D564D5AF4D44BC7B702EB0D9B098
                  CFF8FFCE7E2AACEF1E6CC6CDC6D42CDC7EBB55119F507A673F150D7DF7A013D8
                  6A98FC074CBEB39F8A0EDCFD04AB3E6EC5E0EE81F5CEFE5B54B6B6DDE8DA70F7
                  14ACFAF91D01EF1E74E1BE23B74AF65D9AF3F2643BF01E767DFD8640DF48BF63
                  9864A5173652D306BC815D7FDF0C9164C8175D9E187A150DC7F2D54F06422468
                  F19BACE7D0F0276A019E277C9F7F0C915C2F61173B9E099154A29E255C9F4708
                  B8577837B52F408E62BBB39F8AE5D4BE767E12B82B74627D54BF00390A3C163A
                  A184D572F7E004868BB2BDB84DDC4A121A0696582594B025547EF7E0386E46A6
                  6E23FF166C513BFBA9584CFE2FBD4770B389A207B7963DD5B3B1C89DFD54F431
                  F567DDC314B0257D0BE557A1EB65673F150B28FF17EE106E168528B50AFD2F70
                  6B510925ACD4DD8301EA6045FE3ADCBF730FE05E70B1F08412D68DEBF1006E6F
                  42FF9FA188888888888888888888888888888888888888888888888888888888
                  88884813F80F8FB7FF0C584F46460000000049454E44AE426082}
                PictureDown.Data = {
                  89504E470D0A1A0A0000000D4948445200000080000000800806000000C33E61
                  CB000000017352474200AECE1CE90000000467414D410000B18F0BFC61050000
                  00097048597300000EC300000EC301C76FA8640000001A74455874536F667477
                  617265005061696E742E4E45542076332E352E313147F342370000056B494441
                  54785EED9C69A8B46318C78F7D8DD7966449241252225B88226B1445512FF181
                  50F8E0A3E5934221148A6C590A258A224276918844B264CFBEEFBF7F6FA7A6E9
                  3A73669EE7BAE7D9FEBFFAD5DB9C33CF735FFF6BDE993933D7FD2C18638C31C6
                  18638C31C618638C31C618638C31C618638C31C618638C31C618638C31C61863
                  8C316610EC8E4FE037F802EE85A60CCA56192BEB27710F6C142D488BF96FC41F
                  F04034B91C80DFE368D6CABEB1FF70FBA39A3DBAA0457FC483D1E4A02C956994
                  B57AA05ECC15FD0F5F6A418BFE8A47A2A98732549651C68BAA17737BD63D087F
                  C26821E3FE8EC7A2A986B2538651B6E3AA27EA4D518EC0E51E8DE3FE8527A399
                  0D65A6ECA24C9752BD518F8AA0A7A2DF303AF172FE8367A1998E33519945592E
                  A77A94FED27B344EFB54B4942AE86C34935146559BBFA87A750CA67038FE8DD1
                  89AA78399A98CB30CAAC8AEA59CACBC11B189DA08E57E16A6856A12CAEC428AB
                  3ABE89B519FFA027CB1BD10F825519DC80514675FD166B733B4607CFF0365C03
                  878A6ABF15A36C32BC0B6BB3025FC4E80419DE8B6BE1D050CDF7609449862FA1
                  7A97C266F80A4627CAF04E1CD233816ABD03A32C327C15D5B35436C267303A61
                  860FE2DAD87754E303186590A17AA45E1561437C0AA31367F838AE8F7D45B53D
                  8651ED19AA37EA5151D6C547305A4086FA9E7B03EC1BAA49731351CD19AA27EA
                  CD5CD01B98FB305A4886CF63DA1B9816A05A5453546B86EAC5DCDF48AF897763
                  B4A00C5FC64DB1EB6C827A471ED598A17AA05E34C2EA7813460BCB509F646D89
                  5D456B570D516D192A7BF5A051F449D6F5182D30C3F7703BEC1ADBA2D61ED594
                  A13E3D6CD527A95760B4D00C3FC0EDB12B68ADEF63544B86CABA955C82D18233
                  FC1477C1B6B3337E82510D192AE3567301FE8BD1E2EBFA19EE8A6D456BD31AA3
                  B5D755995E889DE05C2CF5206874147A025AD3D718ADB9AECAF23CEC142B3173
                  9064D4B6ED3DD05A961A91AFAB3254969DE444FC13A3C2EAAA29D843B06926CD
                  ECD755D99D849DE678FC03A302EBAA01C8A3B029A699D9AFAA325376BD407385
                  BF6054685D3500791CCE9B5966F667555929B35E71284EBBA16456353F7F0ACE
                  0B9D6BD699FD69FD1995552FD917BFC3A8F0BACE6BEF81CE51776C7B29958D32
                  EA357BE29718055057FDB9740E964233FBA5FEBCFD0A95CD20D80D3FC728880C
                  2FC66C74CCE85C197E81BACEC2A0D8093FC228900C2FC52C4A365F19288B41B2
                  037E885130195E8D75BE31D37D758CE8D819AA76653068B6C677300A28C3EBB0
                  CA8340F7B916A36366A89A55BB812DF0758C82CA509B2F66193B2FBD61E36DDC
                  0ACD089A63D73C7B145886F7E33473731AAFD23E85E818191699D9EF0B9A677F
                  16A3E0327C0827ED3DD0CFB43F21BA6F86AAADD8CC7E5F686AEF816ED3CFA2FB
                  64F834169FD9EF0BEBE1A3180599E1F8DE03FD5BB745BF9BA16A514D6606F47A
                  ADD7ED28D00C75C145CDEB979ED97F18D74153018D3CDF8C51B019EADDF85B63
                  B7657A0B363EB6DD754A3F084AA935BBF949E843995257D128A1AF7E5288927B
                  0FB26CEDCC7E5FD0973C51F06DD0CD9F139A8F2FF5BD7C15B5968BD0CC11CDC9
                  B7E141A0359C8FA6014EC7527B0FA651E73E034D839C8AA5063427A9E69F86A6
                  059C80A5F61E44EA5C3AA7691125F71E8CAA7314BB24BBA987E6E935571F352E
                  431DFB30342D663F2CB1F740C7D4B14D07D81B75A1E4A89155D4B1F641D32134
                  67AF79FBA8A1B338C899FDBE5077EFC1C738D899FDBE5075EF81EEB3239A1EB0
                  0DBE8B51A323F5BBBA8FE9119AC3D70450D4F0513DB3DF6336C7497B0F5E43FD
                  8EE9319ACB7F0EC79BAFDB3646330034A27D0DEA9A7E527B003DB66D8C31C618
                  638C31C618638C31C618638C31C618638C31C618638C31C618638C31C618638C
                  31C69816B2B0F03FF381FF0CF14A6ED70000000049454E44AE426082}
                Position = 50.000000000000000000
                Text = '%'
                Version = '1.0.1.0'
                ArcWidth = 10.000000000000000000
                PenColor = clMaroon
              end
              object scGPLabel35: TscGPLabel
                Left = 2
                Top = 145
                Width = 257
                Height = 54
                Anchors = [akLeft, akTop, akRight]
                Font.Charset = DEFAULT_CHARSET
                Font.Color = clMaroon
                Font.Height = -12
                Font.Name = 'Segoe UI'
                Font.Style = [fsBold]
                ParentFont = False
                FluentUIOpaque = False
                TabOrder = 2
                DragForm = False
                DragTopForm = True
                DrawTextMode = scdtmGDI
                ContentMarginLeft = 5
                ContentMarginRight = 5
                ContentMarginTop = 5
                ContentMarginBottom = 5
                DisabledFontColor = clNone
                FrameWidth = 1
                FillColor = 16053492
                FillColorAlpha = 20
                FillColor2 = 16053492
                FillColor2Alpha = 255
                FillGradientAngle = 0
                FrameColor = clBtnText
                FrameColorAlpha = 40
                FrameRadius = 5
                GlowEffect.Enabled = True
                GlowEffect.Color = clBtnShadow
                GlowEffect.AlphaValue = 255
                GlowEffect.GlowSize = 7
                GlowEffect.Offset = 0
                GlowEffect.Intensive = False
                GlowEffect.StyleColors = True
                AutoSize = False
                Caption = 'Total: 0'#13#10'Fait: 0'#13#10'Reste: 0'
              end
            end
          end
          object Panel9: TPanel
            Left = 20
            Top = 225
            Width = 1055
            Height = 24
            Align = alTop
            Caption = 'Panel9'
            TabOrder = 3
          end
        end
      end
    end
  end
  object Panel2: TPanel
    Left = 0
    Top = 0
    Width = 1097
    Height = 35
    Align = alTop
    TabOrder = 2
    ExplicitWidth = 1095
    object scGPLabel5: TscGPLabel
      Left = 1
      Top = 1
      Width = 1095
      Height = 33
      Align = alClient
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBtnText
      Font.Height = -20
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      FluentUIOpaque = True
      TabOrder = 0
      DragForm = False
      DragTopForm = True
      DrawTextMode = scdtmGDI
      ContentMarginLeft = 5
      ContentMarginRight = 5
      ContentMarginTop = 5
      ContentMarginBottom = 5
      DisabledFontColor = clNone
      FrameWidth = 0
      FillColor = clSkyBlue
      FillColorAlpha = 10
      FillColor2 = clNone
      FillColor2Alpha = 180
      FillGradientAngle = 0
      FrameColor = clBtnText
      FrameColorAlpha = 40
      FrameRadius = 5
      GlowEffect.Enabled = True
      GlowEffect.Color = clBtnShadow
      GlowEffect.AlphaValue = 255
      GlowEffect.GlowSize = 7
      GlowEffect.Offset = 0
      GlowEffect.Intensive = True
      GlowEffect.StyleColors = True
      AutoSize = False
      Alignment = taCenter
      Caption = 'G50 2026'
      ExplicitWidth = 1093
    end
  end
  object ProgressBar1: TProgressBar
    Left = 0
    Top = 682
    Width = 1097
    Height = 17
    Align = alBottom
    TabOrder = 3
    Visible = False
    ExplicitTop = 678
    ExplicitWidth = 1095
  end
  object TimerDash: TTimer
    OnTimer = TimerDashTimer
    Left = 240
    Top = 65528
  end
  object MainMenu1: TMainMenu
    Left = 344
    Top = 80
    object mnuFichier: TMenuItem
      Caption = '&Fichier'
      object D1: TMenuItem
        Caption = 'Dossiers'
        object O1: TMenuItem
          Caption = 'Ouvrir'
          OnClick = O1Click
        end
        object N3: TMenuItem
          Caption = 'Nouveau'
          OnClick = N3Click
        end
        object P1: TMenuItem
          Caption = 'Parcourir'
          OnClick = P1Click
        end
      end
      object mnuNouveau: TMenuItem
        Caption = '&Nouveau Dossier...'
        ShortCut = 16462
        Visible = False
        OnClick = mnuNouveauClick
      end
      object mnuOuvrir: TMenuItem
        Caption = '&Ouvrir Dossier...'
        ShortCut = 16463
        Visible = False
        OnClick = mnuOuvrirClick
      end
      object mnuMissingG50: TMenuItem
        Caption = 'D'#233'clarations  manquantes'
        object N1: TMenuItem
          Caption = 'G50'
          OnClick = N1Click
        end
        object G501: TMenuItem
          Caption = 'TAPP'
          OnClick = G501Click
        end
        object N2: TMenuItem
          Caption = 'Solde IBS'
          OnClick = N2Click
        end
        object S1: TMenuItem
          Caption = 'Solde IRG'
          OnClick = S1Click
        end
      end
      object T3: TMenuItem
        Caption = 'Founisseurs TVA'
        OnClick = T3Click
      end
      object mnuSep1: TMenuItem
        Caption = '-'
      end
      object ableaudeBord1: TMenuItem
        Caption = 'Tableau de Bord'
        Visible = False
      end
      object T2: TMenuItem
        Caption = 'Tableau de Bord'
        OnClick = T2Click
      end
      object SauvgareretRestaurer1: TMenuItem
        Caption = 'Sauvgarer et  &Restaurer'
        OnClick = SauvgareretRestaurer1Click
      end
      object mnuSociete: TMenuItem
        Caption = 'Sauvgarer et  &Restaurer'
        Enabled = False
        Visible = False
        OnClick = mnuSocieteClick
      end
      object mnuBatchGen: TMenuItem
        Caption = '&G'#233'n'#233'ration Massive (Batch)...'
        OnClick = mnuBatchGenClick
      end
      object T1: TMenuItem
        Caption = 'Themes'
        OnClick = T1Click
      end
      object mnuSep2: TMenuItem
        Caption = '-'
      end
      object mnuQuitter: TMenuItem
        Caption = '&Quitter'
        ShortCut = 16465
        OnClick = mnuQuitterClick
      end
    end
  end
  object DExercices: TUniDataSource
    DataSet = TExercices
    Left = 32
    Top = 393
  end
  object TExercices: TUniTable
    TableName = 'Exercices'
    Connection = DM.UniConnection
    Left = 96
    Top = 393
  end
  object TG50: TUniTable
    TableName = 'G50'
    Connection = DM.UniConnection
    MasterSource = DExercices
    MasterFields = 'Ann'#233'e'
    DetailFields = 'Ann'#233'e'
    Left = 96
    Top = 456
    object TG50IDNewG50: TWideStringField
      FieldName = 'IDNewG50'
      Size = 50
    end
    object TG50IDclients: TIntegerField
      FieldName = 'IDclients'
    end
    object TG50rs: TWideStringField
      FieldName = 'rs'
      Size = 200
    end
    object TG50Mois: TFloatField
      FieldName = 'Mois'
    end
    object TG50Annee: TWideStringField
      FieldName = 'Ann'#233'e'
      Size = 255
    end
    object TG50MoisAnnee: TWideStringField
      FieldName = 'MoisAnn'#233'e'
      Size = 255
    end
    object TG50st1: TFloatField
      FieldName = 'st1'
    end
    object TG50st2: TFloatField
      FieldName = 'st2'
    end
    object TG50st31: TFloatField
      FieldName = 'st31'
    end
    object TG50st4: TFloatField
      FieldName = 'st4'
    end
    object TG50st5: TFloatField
      FieldName = 'st5'
    end
    object TG50st32: TFloatField
      FieldName = 'st32'
    end
    object TG50totalgeneral: TFloatField
      FieldName = 'totalgeneral'
    end
    object TG50IDDEC: TWideStringField
      FieldName = 'IDDEC'
      Size = 50
    end
    object TG50idg50: TIntegerField
      FieldName = 'idg50'
    end
    object TG50ma: TWideStringField
      FieldName = 'ma'
      Size = 50
    end
    object TG50leMois: TWideStringField
      FieldName = 'leMois'
      Size = 50
    end
    object TG50ExcedentAnterieur: TFloatField
      FieldName = 'Exc'#233'dentAnterieur'
    end
    object TG50lieuced: TWideStringField
      FieldName = 'lieuced'
      Size = 50
    end
    object TG50DAtedEC: TDateTimeField
      FieldName = 'DAtedEC'
    end
    object TG50RSannee: TWideStringField
      FieldName = 'RSann'#233'e'
      Size = 50
    end
    object TG50RSanneeanterieur: TIntegerField
      FieldName = 'RSann'#233'eanterieur'
    end
    object TG50st33: TFloatField
      FieldName = 'st33'
    end
    object TG50tvastsG: TFloatField
      FieldName = 'tvastsG'
    end
    object TG50tvastsI: TFloatField
      FieldName = 'tvastsI'
    end
    object TG50st6: TFloatField
      FieldName = 'st6'
    end
    object TG50tvastse: TFloatField
      FieldName = 'tvastse'
    end
    object TG50tvastsd: TFloatField
      FieldName = 'tvastsd'
    end
    object TG50moisg50: TWideStringField
      FieldName = 'moisg50'
      Size = 50
    end
    object TG50moisg50anteriur: TWideStringField
      FieldName = 'moisg50anteriur'
      Size = 50
    end
    object TG50anneeclient: TWideStringField
      FieldName = 'anneeclient'
      Size = 50
    end
    object TG50Precompte_anterieur: TFloatField
      FieldName = 'Pr'#233'compte_ant'#233'rieur'
    end
    object TG50TTVAachatMatieres: TFloatField
      FieldName = 'TTVAachatMatieres'
    end
    object TG50TVAbiensamortissables: TFloatField
      FieldName = 'TVAbiensamortissables'
    end
    object TG50deductioncomplementaire: TFloatField
      FieldName = 'd'#233'ductioncompl'#233'mentaire'
    end
    object TG50TVAfacturesannulees: TFloatField
      FieldName = 'TVAfacturesannul'#233'es'
    end
    object TG50Autres_deductions: TFloatField
      FieldName = 'Autres_d'#233'ductions'
    end
    object TG50Totaldroits_dus: TFloatField
      FieldName = 'Totaldroits_dus'
    end
    object TG50deduction_excedentaire: TFloatField
      FieldName = 'd'#233'duction_exc'#233'dentaire'
    end
    object TG50Reversement_de_la_deduction: TFloatField
      FieldName = 'Reversement_de_la_d'#233'duction'
    end
    object TG50TOTALaRAPPELER: TFloatField
      FieldName = 'TOTALaRAPPELER'
    end
    object TG50Total_des_deductions: TFloatField
      FieldName = 'Total_des_d'#233'ductions'
    end
    object TG50TVA_a_payer: TFloatField
      FieldName = 'TVA_'#224'_payer'
    end
    object TG50Precompte_a_reporter: TFloatField
      FieldName = 'Pr'#233'compte_'#224'_reporter'
    end
    object TG50E3B96: TFloatField
      FieldName = 'E3B96'
    end
    object TG50moisg50anteriuriDclient: TWideStringField
      FieldName = 'moisg50anteriuriDclient'
      Size = 50
    end
    object TG50moisg50iDclient: TWideStringField
      FieldName = 'moisg50iDclient'
      Size = 50
    end
    object TG50PRA: TFloatField
      FieldName = 'PRA'
    end
    object TG50NatureRC: TWideStringField
      FieldName = 'NatureRC'
      Size = 50
    end
    object TG50VPDF: TBlobField
      FieldName = 'VPDF'
    end
  end
  object DG50: TUniDataSource
    DataSet = TG50
    Left = 24
    Top = 456
  end
  object QUnionG50: TUniQuery
    Connection = DM.UniConnection
    SQL.Strings = (
      
        'SELECT Tap.IDg50, Tap.CODE, Tap.impots, Tap.Caimposable,Tap.TAUX' +
        'TAP,Tap.Droits,Tap.Nt'
      'FROM Tap'
      'union'
      
        'SELECT IRGSalaires.Idg50,IRGSalaires.CODE,IRGSalaires.IMPOTS,IRG' +
        'Salaires.REVENUSIMPOSABLES,IRGSalaires.TAUX,IRGSalaires.Droits,I' +
        'RGSalaires.Nt'
      'FROM IRGSalaires'
      'union'
      
        'SELECT Timbre.Idg50,Timbre.CODE,Timbre.IMPOTS,Timbre.CAIMPOSABLE' +
        ',Timbre.TAUX,Timbre.Droits,Timbre.Nt'
      'from Timbre'
      'union'
      
        'SELECT TVA.IDG50,TVA.CODE, TVA.Op'#233'rations,TVA.CAI,TVA.TAUX,TVA.D' +
        'roits,TVA.Nt'
      'FROM TVA'
      'union'
      
        'SELECT AutresTaxes.IDG50,AutresTaxes.CODE, AutresTaxes.IMPOTS,Au' +
        'tresTaxes.Revenusimposables,AutresTaxes.TAUX,AutresTaxes.Droits,' +
        'AutresTaxes.Nt'
      'FROM AutresTaxes;'
      '')
    MasterSource = Form20.DG50
    MasterFields = 'idg50'
    DetailFields = 'IDg50'
    DMLRefresh = True
    Options.FullRefresh = True
    Options.PrepareUpdateSQL = True
    Options.AutoPrepare = True
    Options.LocalMasterDetail = True
    Options.MasterFieldsNullable = True
    FieldOptions.PositionMode = poFirst
    FieldOptions.UpdatePersistent = True
    Filtered = True
    IndexFieldNames = #39'CODE'#39
    Left = 312
    Top = 368
    object QUnionG50IDg50: TIntegerField
      FieldName = 'IDg50'
    end
    object QUnionG50CODE: TWideStringField
      FieldName = 'CODE'
      Size = 255
    end
    object QUnionG50Caimposable: TFloatField
      FieldName = 'Caimposable'
      DisplayFormat = '###,##0'
    end
    object QUnionG50TAUXTAP: TWideStringField
      FieldName = 'TAUXTAP'
      Size = 255
    end
    object QUnionG50Droits: TFloatField
      FieldName = 'Droits'
      DisplayFormat = '###,##0'
    end
    object QUnionG50Nt: TWideStringField
      FieldName = 'Nt'
      Size = 255
    end
    object QUnionG50Nat: TStringField
      FieldKind = fkLookup
      FieldName = 'Nat'
      LookupDataSet = Form20.Tnature
      LookupKeyFields = 'CodeNature'
      LookupResultField = 'Nature'
      KeyFields = 'Nt'
      Lookup = True
    end
    object QUnionG50impots: TWideMemoField
      FieldName = 'impots'
      BlobType = ftWideMemo
    end
  end
  object DunionG50: TUniDataSource
    DataSet = QUnionG50
    Left = 376
    Top = 356
  end
  object UniQuery1: TUniQuery
    Connection = DM.UniConnection
    SQL.Strings = (
      
        'SELECT IDG50, CODE, IMPOTS, Revenusimposables, TAUX, Droits, Nt ' +
        'FROM AutresTaxes;')
    Left = 802
    Top = 412
  end
  object frxXLSXExport1: TfrxXLSXExport
    UseFileCache = True
    ShowProgress = True
    OverwritePrompt = True
    DataOnly = False
    ChunkSize = 0
    OpenAfterExport = False
    PictureType = gpPNG
    Left = 603
    Top = 375
  end
  object frxPDFExport1: TfrxPDFExport
    UseFileCache = True
    ShowProgress = True
    OverwritePrompt = False
    DataOnly = False
    EmbedFontsIfProtected = False
    InteractiveFormsFontSubset = 'A-Z,a-z,0-9,#43-#47 '
    OpenAfterExport = False
    PrintOptimized = False
    Outline = False
    Background = False
    HTMLTags = True
    Quality = 95
    Transparency = False
    Author = 'FastReport'
    Subject = 'FastReport PDF export'
    ProtectionFlags = [ePrint, eModify, eCopy, eAnnot]
    HideToolbar = False
    HideMenubar = False
    HideWindowUI = False
    FitWindow = False
    CenterWindow = False
    PrintScaling = False
    PdfA = False
    PDFStandard = psNone
    PDFVersion = pv17
    Left = 387
    Top = 350
  end
end
