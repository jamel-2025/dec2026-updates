﻿unit Unit5;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, System.DateUtils, System.UITypes, Vcl.Graphics, Vcl.Controls, Vcl.Forms,
  Vcl.Dialogs, Data.DB, MemDS, DBAccess, Uni, Vcl.StdCtrls, Vcl.ExtCtrls,
  Vcl.ComCtrls,
  DBGridEh, GridsEh, ToolCtrlsEh,
  DBGridEhToolCtrls, DynVarsEh, EhLibVCL, DBAxisGridsEh, Vcl.Samples.Spin,
  DBGridEhGrouping, scExtControls, scToolPager, scControls, AdvGlowButton,
  Vcl.Buttons, Vcl.Mask, scGPExtControls, scGPDBControls, scGPControls,unit14;

type
  TForm5 = class(TForm)
    Tnaftal           : TUniTable;
    Dnaftal           : TUniDataSource;
    Tpp               : TUniTable;
    Dpp               : TUniDataSource;
    TnaftalIDF        : TIntegerField;
    TnaftalRefF       : TWideStringField;
    TnaftalDateFact   : TDateTimeField;
    TnaftalAnnee      : TWideStringField;
    TnaftalFournisseur: TWideStringField;
    TnaftalQGasoil    : TFloatField;
    TnaftalQEssence   : TFloatField;
    TnaftalQSirgaz    : TFloatField;
    TnaftalTGasoil    : TFloatField;
    TnaftalTEssence   : TFloatField;
    TnaftalTSiirgaz   : TFloatField;
    TnaftalTvente     : TFloatField;
    TnaftalTachat     : TFloatField;
    TnaftalBenefice   : TFloatField;
    TnaftalMois       : TIntegerField;
    TnaftalPUGasoil   : TFloatField;
    TnaftalPUEssence  : TFloatField;
    TnaftalPUSirgaz   : TFloatField;
    TppID             : TIntegerField;
    Tppu              : TWideStringField;
    PanelTop          : TPanel;
    PanelTitle        : TPanel;
    LblTitle          : TLabel;
    PanelFilter       : TPanel;
    LblMois           : TLabel;
    LblAnnee          : TLabel;
    CmbMois           : TComboBox;
    EdtAnnee          : TSpinEdit;
    BtnFilter         : TButton;
    BtnOpen           : TButton;
    BtnClose          : TButton;
    BtnExport         : TButton;
    BtnExit           : TButton;
    StatusBar1        : TStatusBar;
    TppPU: TFloatField;
    scToolPager1: TscToolPager;
    scToolPagerPage1: TscToolPagerPage;
    scToolPagerPage2: TscToolPagerPage;
    DBGridEh1: TDBGridEh;
    scPanel1: TscPanel;
    scGPLabel13: TscGPLabel;
    TDroit: TscGPDBEdit;
    scPanel3: TscPanel;
    SpeedButton3: TSpeedButton;
    AdvGlowButton2: TAdvGlowButton;
    Panel1: TPanel;
    BtnCancel: TButton;
    BtnDelete: TButton;
    BtnPost: TButton;
    BtnAdd: TButton;
    scToolPagerPage3: TscToolPagerPage;
    Tlurifiants           : TUniTable;
    TlurifiantsIDF        : TIntegerField;
    TlurifiantsRefF       : TWideStringField;
    TlurifiantsDateFact   : TDateTimeField;
    TlurifiantsMois       : TIntegerField;
    TlurifiantsAnnee      : TWideStringField;
    TlurifiantsFournisseur: TWideStringField;
    TlurifiantsAchatHT    : TFloatField;
    TlurifiantsTVAachat   : TFloatField;
    TlurifiantsAchatTTC   : TFloatField;
    TlurifiantsVenteHT    : TFloatField;
    TlurifiantsTVAVente   : TFloatField;
    TlurifiantsVenteTTC   : TFloatField;
    TlurifiantsBenefice   : TFloatField;
    TlurifiantsTachat     : TFloatField;
    TlurifiantsMarge      : TFloatField;
    Dlurifiants           : TUniDataSource;
    DBGridEh2             : TDBGridEh;
    DBGridEh3: TDBGridEh;
    DBGridEh4: TDBGridEh;
    Panel3: TPanel;
    BtnExportL: TButton;
    BtnCancelL: TButton;
    BtnPostL: TButton;
    BtnDeleteL: TButton;
    BtnAddL: TButton;
    UniDataSource1: TUniDataSource;
    Tprestation: TUniTable;
    Dprestation: TUniDataSource;
    DBGridEh5: TDBGridEh;
    TprestationIDP: TIntegerField;
    TprestationMois: TIntegerField;
    TprestationAnnee: TWideStringField;
    TprestationCafetiriaCA: TFloatField;
    TprestationCafetiriaTVA: TFloatField;
    TprestationRestaurantCA: TFloatField;
    TprestationRestaurantTVA: TFloatField;
    TprestationLavageCA: TFloatField;
    TprestationLavageTVA: TFloatField;
    TprestationTransportCA: TFloatField;
    TprestationTransportTVA: TFloatField;
    TprestationPrestationCA: TFloatField;
    TprestationPrestationTVA: TFloatField;

    procedure TlurifiantsAfterOpen(DataSet: TDataSet);
    procedure TlurifiantsBeforePost(DataSet: TDataSet);
    procedure TlurifiantsAfterPost(DataSet: TDataSet);
    procedure TlurifiantsAfterCancel(DataSet: TDataSet);
    procedure TlurifiantsAfterScroll(DataSet: TDataSet);
    procedure TlurifiantsNewRecord(DataSet: TDataSet);
    procedure DlurifiantsDataChange(Sender: TObject; Field: TField);
    procedure DBGridEh2DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumnEh; State: TGridDrawState);
    procedure DBGridEh2KeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure BtnAddLClick(Sender: TObject);
    procedure BtnDeleteLClick(Sender: TObject);
    procedure BtnPostLClick(Sender: TObject);
    procedure BtnCancelLClick(Sender: TObject);
    procedure BtnExportLClick(Sender: TObject);

    procedure FormCreate(Sender: TObject);
    procedure BtnFilterClick(Sender: TObject);
    procedure BtnOpenClick(Sender: TObject);
    procedure BtnCloseClick(Sender: TObject);
    procedure BtnAddClick(Sender: TObject);
    procedure BtnDeleteClick(Sender: TObject);
    procedure BtnPostClick(Sender: TObject);
    procedure BtnCancelClick(Sender: TObject);
    procedure BtnExportClick(Sender: TObject);
    procedure BtnExitClick(Sender: TObject);
    procedure TnaftalCalcFields(DataSet: TDataSet);
    procedure TnaftalAfterScroll(DataSet: TDataSet);
    procedure TnaftalAfterOpen(DataSet: TDataSet);
    procedure TnaftalNewRecord(DataSet: TDataSet);
    procedure TnaftalBeforePost(DataSet: TDataSet);
    procedure TnaftalAfterPost(DataSet: TDataSet);
    procedure TnaftalAfterCancel(DataSet: TDataSet);
    { New events for real-time calc, cell highlight, and navigation }
    procedure DnaftalDataChange(Sender: TObject; Field: TField);
    procedure DBGridEh1DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumnEh; State: TGridDrawState);
    procedure DBGridEh1KeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);

  private
    FPUGasoil  : Double;
    FPUEssence : Double;
    FPUSirgaz  : Double;
    FUpdating  : Boolean;
    FLUpdating : Boolean;
    procedure LoadPricesFromPPu;
    procedure ApplyFilter;
    procedure RecalcCurrentRow;
    procedure UpdateTitle;
    procedure UpdateStatusBar;
    procedure UpdateButtons;
    procedure ApplyFilterL;
    procedure RecalcLurifiants;
    procedure UpdateButtonsL;
    procedure UpdateStatusBarL;
    function MoisNom(M: Integer): string;
  end;

var
  Form5: TForm5;

implementation

{$R *.dfm}

uses uDataModule;

const
  CMoisNoms: array[1..12] of string = (
    'JANVIER','FEVRIER','MARS','AVRIL','MAI','JUIN',
    'JUILLET','AOUT','SEPTEMBRE','OCTOBRE','NOVEMBRE','DECEMBRE');

  { Color for the active editing cell }
  clEditCell = $00CCFFCC;  // Light green

{ ====================================================================== }
{                           FormCreate                                    }
{ ====================================================================== }
procedure TForm5.FormCreate(Sender: TObject);
var
  i: Integer;
begin
  FUpdating  := False;
  FPUGasoil  := 0;
  FPUEssence := 0;
  FPUSirgaz  := 0;

  { Month list }
  CmbMois.Items.Clear;
  for i := 1 to 12 do
    CmbMois.Items.Add(CMoisNoms[i]);
  CmbMois.ItemIndex := MonthOf(Now) - 1;
  EdtAnnee.Value    := YearOf(Now);

  { Enable Enter-as-Tab in DBGridEh for smooth cell navigation }
  DBGridEh1.OptionsEh := DBGridEh1.OptionsEh + [dghEnterAsTab];

  { Load unit prices from PPu table }
  if not Tpp.Active then
    Tpp.Open;
  LoadPricesFromPPu;

  { Open Naftal table with filter }
  if not Tnaftal.Active then
    Tnaftal.Open;
  ApplyFilter;
  UpdateButtons;

  { Init LUBRIFIANTS }
  FLUpdating := False;
  DBGridEh2.OptionsEh := DBGridEh2.OptionsEh + [dghEnterAsTab];
  if not Tlurifiants.Active then
    Tlurifiants.Open;
  ApplyFilterL;
  UpdateButtonsL;
end;

{ ====================================================================== }
{                    Load unit prices from PPu table                       }
{ ====================================================================== }
procedure TForm5.LoadPricesFromPPu;
begin
  FPUGasoil  := 0;
  FPUEssence := 0;
  FPUSirgaz  := 0;
  if not Tpp.Active then Exit;
  Tpp.First;
  while not Tpp.EOF do
  begin
    if SameText(Tpp.FieldByName('PP').AsString, 'GAS OIL') then
      FPUGasoil := StrToFloatDef(Tpp.FieldByName('PU').AsString, 0)
    else if SameText(Tpp.FieldByName('PP').AsString, 'ESSENCE S.PL') then
      FPUEssence := StrToFloatDef(Tpp.FieldByName('PU').AsString, 0)
    else if SameText(Tpp.FieldByName('PP').AsString, 'SIRGHAZ') then
      FPUSirgaz := StrToFloatDef(Tpp.FieldByName('PU').AsString, 0);
    Tpp.Next;
  end;
end;

{ ====================================================================== }
{                         Apply month/year filter                          }
{ ====================================================================== }
procedure TForm5.ApplyFilter;
var
  Mois, Annee: Integer;
begin
  Mois  := CmbMois.ItemIndex + 1;
  Annee := EdtAnnee.Value;
  Tnaftal.Filtered := False;
  Tnaftal.Filter   := Format('Mois = %d AND Annee = ''%d''', [Mois, Annee]);
  Tnaftal.Filtered := True;
  UpdateTitle;
  UpdateStatusBar;
  UpdateButtons;
end;

{ ====================================================================== }
{                          Update UI helpers                               }
{ ====================================================================== }
procedure TForm5.UpdateTitle;
begin
  LblTitle.Caption := Format(
    'DETAIL CHIFFRES D''AFFAIRES  MOIS DE :  %s  %d',
    [MoisNom(CmbMois.ItemIndex + 1), EdtAnnee.Value]);
end;

procedure TForm5.UpdateStatusBar;
begin
  if not Tnaftal.Active then
  begin
    StatusBar1.Panels[0].Text := 'RecordCount: 0';
    StatusBar1.Panels[1].Text := 'RecordNo: 0';
    StatusBar1.Panels[2].Text := '';
    Exit;
  end;
  StatusBar1.Panels[0].Text := Format('RecordCount: %d', [Tnaftal.RecordCount]);
  if not Tnaftal.IsEmpty then
    StatusBar1.Panels[1].Text := Format('RecordNo: %d', [Tnaftal.RecNo])
  else
    StatusBar1.Panels[1].Text := 'RecordNo: 0';
  if Tnaftal.State in [dsInsert] then
    StatusBar1.Panels[2].Text := '[ Nouveau enregistrement... ]'
  else if Tnaftal.State in [dsEdit] then
    StatusBar1.Panels[2].Text := '[ Modification en cours... ]'
  else
    StatusBar1.Panels[2].Text := '';
end;

procedure TForm5.UpdateButtons;
var
  IsActive  : Boolean;
  IsEditing : Boolean;
begin
  IsActive  := Tnaftal.Active;
  IsEditing := IsActive and (Tnaftal.State in [dsInsert, dsEdit]);
  BtnAdd.Enabled    := IsActive and not IsEditing;
  BtnDelete.Enabled := IsActive and not IsEditing and not Tnaftal.IsEmpty;
  BtnPost.Enabled   := IsEditing;
  BtnCancel.Enabled := IsEditing;
  BtnFilter.Enabled := not IsEditing;
  BtnOpen.Enabled   := not IsActive;
  BtnClose.Enabled  := IsActive and not IsEditing;
end;

{ ====================================================================== }
{  RecalcCurrentRow - automatic calculations                               }
{  TOT.VTE GAS OIL  = QTE GAS OIL  * PU GAS OIL                          }
{  TOT.VTE ESSENCE  = QTE ESSENCE  * PU ESSENCE                           }
{  TOT.VTE SIRGHAZ  = QTE SIRGHAZ  * PU SIRGHAZ                           }
{  TOTAL VENTES     = TOT.VTE GAS OIL + TOT.VTE ESSENCE + TOT.VTE SIRGHAZ }
{  BENEFICE         = TOTAL VENTES - TOTAL ACHATS                          }
{ ====================================================================== }
procedure TForm5.RecalcCurrentRow;
var
  QG, QE, QS : Double;
  TG, TE, TS : Double;
  TV, TA     : Double;
begin
  if FUpdating then Exit;
  if not (Tnaftal.State in [dsInsert, dsEdit]) then Exit;

  FUpdating := True;
  try
    QG := TnaftalQGasoil.AsFloat;
    QE := TnaftalQEssence.AsFloat;
    QS := TnaftalQSirgaz.AsFloat;

    TG := QG * FPUGasoil;       // TOT.VTE GAS OIL
    TE := QE * FPUEssence;      // TOT.VTE ESSENCE
    TS := QS * FPUSirgaz;       // TOT.VTE SIRGHAZ
    TV := TG + TE + TS;         // TOTAL VENTES
    TA := TnaftalTachat.AsFloat;

    TnaftalTGasoil.AsFloat  := TG;
    TnaftalTEssence.AsFloat := TE;
    TnaftalTSiirgaz.AsFloat := TS;
    TnaftalTvente.AsFloat   := TV;
    TnaftalBenefice.AsFloat := TV - TA;  // BENEFICE
  finally
    FUpdating := False;
  end;
end;

{ ====================================================================== }
{  DataSource OnDataChange - real-time recalc when user edits a cell       }
{ ====================================================================== }
procedure TForm5.DnaftalDataChange(Sender: TObject; Field: TField);
begin
  if FUpdating then Exit;
  if Field = nil then Exit;
  if not (Tnaftal.State in [dsInsert, dsEdit]) then Exit;

  { Recalculate only when a quantity or Tachat changes }
  if (Field = TnaftalQGasoil) or (Field = TnaftalQEssence) or
     (Field = TnaftalQSirgaz) or (Field = TnaftalTachat) then
    RecalcCurrentRow;
end;

{ ====================================================================== }
{  Calculated fields (PU values from PPu table)                            }
{ ====================================================================== }
procedure TForm5.TnaftalCalcFields(DataSet: TDataSet);
begin
  TnaftalPUGasoil.AsFloat  := FPUGasoil;
  TnaftalPUEssence.AsFloat := FPUEssence;
  TnaftalPUSirgaz.AsFloat  := FPUSirgaz;
end;

{ ====================================================================== }
{  New record defaults                                                     }
{ ====================================================================== }
procedure TForm5.TnaftalNewRecord(DataSet: TDataSet);
begin
  TnaftalFournisseur.AsString := 'NAFTAL';
  TnaftalDateFact.AsDateTime  := Date;
  TnaftalAnnee.AsString       := IntToStr(EdtAnnee.Value);
  TnaftalMois.AsInteger       := CmbMois.ItemIndex + 1;
  TnaftalQGasoil.AsFloat      := 0;
  TnaftalQEssence.AsFloat     := 0;
  TnaftalQSirgaz.AsFloat      := 0;
  TnaftalTGasoil.AsFloat      := 0;
  TnaftalTEssence.AsFloat     := 0;
  TnaftalTSiirgaz.AsFloat     := 0;
  TnaftalTvente.AsFloat       := 0;
  TnaftalTachat.AsFloat       := 0;
  TnaftalBenefice.AsFloat     := 0;
end;

{ ====================================================================== }
{  Before/After events                                                     }
{ ====================================================================== }
procedure TForm5.TnaftalBeforePost(DataSet: TDataSet);
begin
  if TnaftalDateFact.IsNull then
    TnaftalDateFact.AsDateTime := Date;
  TnaftalAnnee.AsString  := IntToStr(EdtAnnee.Value);
  TnaftalMois.AsInteger  := CmbMois.ItemIndex + 1;
  RecalcCurrentRow;
end;

procedure TForm5.TnaftalAfterPost(DataSet: TDataSet);
begin
  UpdateButtons;
  UpdateStatusBar;
end;

procedure TForm5.TnaftalAfterCancel(DataSet: TDataSet);
begin
  UpdateButtons;
  UpdateStatusBar;
end;

procedure TForm5.TnaftalAfterScroll(DataSet: TDataSet);
begin
  UpdateStatusBar;
  UpdateButtons;
end;

procedure TForm5.TnaftalAfterOpen(DataSet: TDataSet);
begin
  UpdateStatusBar;
  UpdateButtons;
end;

{ ====================================================================== }
{  DBGridEh1 - Highlight the active cell and draw distinct grid lines      }
{ ====================================================================== }
procedure TForm5.DBGridEh1DrawColumnCell(Sender: TObject; const Rect: TRect;
  DataCol: Integer; Column: TColumnEh; State: TGridDrawState);
begin
  { Change background of active cell when focused }
  if gdFocused in State then
  begin
    DBGridEh1.Canvas.Brush.Color := clEditCell;
    DBGridEh1.Canvas.Font.Color  := clBlack;
  end;

  DBGridEh1.DefaultDrawColumnCell(Rect, DataCol, Column, State);

  { Draw distinct vertical and horizontal lines }
  DBGridEh1.Canvas.Pen.Color := clNavy; { لون ظاهر للخطوط (أزرق داكن) }
  DBGridEh1.Canvas.MoveTo(Rect.Left, Rect.Bottom - 1);
  DBGridEh1.Canvas.LineTo(Rect.Right, Rect.Bottom - 1);
  DBGridEh1.Canvas.MoveTo(Rect.Right - 1, Rect.Top);
  DBGridEh1.Canvas.LineTo(Rect.Right - 1, Rect.Bottom);
end;

{ ====================================================================== }
{  DBGridEh1 - Enter key acts as Tab for smooth cell-to-cell navigation    }
{ ====================================================================== }
procedure TForm5.DBGridEh1KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if (Key = VK_RETURN) and (Shift = []) then
    Key := VK_TAB;
end;

{ ====================================================================== }
{                        Button handlers                                   }
{ ====================================================================== }
procedure TForm5.BtnFilterClick(Sender: TObject);
begin
  if Tnaftal.State in [dsInsert, dsEdit] then
    Tnaftal.Cancel;
  ApplyFilter;
end;

procedure TForm5.BtnOpenClick(Sender: TObject);
begin
  if not Tnaftal.Active then
  begin
    Tnaftal.Open;
    ApplyFilter;
  end;
end;

procedure TForm5.BtnCloseClick(Sender: TObject);
begin
  if Tnaftal.Active then
    Tnaftal.Close;
  UpdateStatusBar;
  UpdateButtons;
end;

procedure TForm5.BtnAddClick(Sender: TObject);
  begin
  if not Tnaftal.Active then Exit;
  Tnaftal.Append;
  DBGridEh3.SetFocus;
  UpdateButtons;
  UpdateStatusBar;
end;

procedure TForm5.BtnDeleteClick(Sender: TObject);
begin
  if not Tnaftal.Active then Exit;
  if Tnaftal.IsEmpty then Exit;
  if MessageDlg('Confirmer la suppression de cet enregistrement ?',
    mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    Tnaftal.Delete;
    UpdateStatusBar;
    UpdateButtons;
  end;
end;

procedure TForm5.BtnPostClick(Sender: TObject);
begin
  if Tnaftal.State in [dsInsert, dsEdit] then
  begin
    Tnaftal.Post;
    UpdateStatusBar;
    UpdateButtons;
  end;
end;

procedure TForm5.BtnCancelClick(Sender: TObject);
begin
  if Tnaftal.State in [dsInsert, dsEdit] then
  begin
    Tnaftal.Cancel;
    UpdateStatusBar;
    UpdateButtons;
  end;
end;

procedure TForm5.BtnExportClick(Sender: TObject);
var
  SaveDlg : TSaveDialog;
  F       : TextFile;
  FileName: string;
  i       : Integer;
  ColHeaders: array of string;
  ColFields : array of string;
  ColCount  : Integer;
  CellVal   : string;
begin
  { Build column header / field name arrays from visible grid columns }
  ColCount := DBGridEh1.Columns.Count;
  SetLength(ColHeaders, ColCount);
  SetLength(ColFields,  ColCount);
  for i := 0 to ColCount - 1 do
  begin
    ColHeaders[i] := DBGridEh1.Columns[i].Title.Caption;
    if ColHeaders[i] = '' then
      ColHeaders[i] := DBGridEh1.Columns[i].FieldName;
    ColFields[i] := DBGridEh1.Columns[i].FieldName;
  end;

  SaveDlg := TSaveDialog.Create(nil);
  try
    SaveDlg.Title      := 'Exporter vers Excel';
    SaveDlg.Filter     := 'Fichier Excel (*.xls)|*.xls|Tous fichiers (*.*)|*.*';
    SaveDlg.DefaultExt := 'xls';
    SaveDlg.FileName   := Format('CA_%s_%d',
      [MoisNom(CmbMois.ItemIndex + 1), EdtAnnee.Value]);

    if not SaveDlg.Execute then Exit;
    FileName := SaveDlg.FileName;
  finally
    SaveDlg.Free;
  end;

  AssignFile(F, FileName);
  try
    Rewrite(F);

    { HTML header — Excel opens this natively }
    WriteLn(F, '<html>');
    WriteLn(F, '<head><meta charset="UTF-8"></head>');
    WriteLn(F, '<body>');
    WriteLn(F, '<table border="1" cellspacing="0" cellpadding="3">');

    { Title row }
    WriteLn(F, Format('<tr><td colspan="%d" align="center" ' +
      'style="font-weight:bold;font-size:14px;background:#336699;color:white;">%s</td></tr>',
      [ColCount, LblTitle.Caption]));

    { Header row }
    Write(F, '<tr>');
    for i := 0 to ColCount - 1 do
      Write(F, Format('<th style="background:#4472C4;color:white;font-weight:bold;">%s</th>',
        [ColHeaders[i]]));
    WriteLn(F, '</tr>');

    { Data rows }
    Tnaftal.DisableControls;
    Tnaftal.First;
    try
      while not Tnaftal.EOF do
      begin
        Write(F, '<tr>');
        for i := 0 to ColCount - 1 do
        begin
          CellVal := Tnaftal.FieldByName(ColFields[i]).DisplayText;
          Write(F, Format('<td align="right">%s</td>', [CellVal]));
        end;
        WriteLn(F, '</tr>');
        Tnaftal.Next;
      end;
    finally
      Tnaftal.EnableControls;
    end;

    WriteLn(F, '</table>');
    WriteLn(F, '</body></html>');
    CloseFile(F);

    ShowMessage('Export réussi !' + #13#10 + FileName);
  except
    on E: Exception do
    begin
      CloseFile(F);
      ShowMessage('Erreur export : ' + E.Message);
    end;
  end;
end;

procedure TForm5.BtnExitClick(Sender: TObject);
begin
  if Tnaftal.State in [dsInsert, dsEdit] then
  begin
    if MessageDlg('Des modifications sont en cours. Quitter sans enregistrer ?',
      mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      Tnaftal.Cancel
    else
      Exit;
  end;
  Close;
end;

function TForm5.MoisNom(M: Integer): string;
begin
  if (M >= 1) and (M <= 12) then
    Result := CMoisNoms[M]
  else
    Result := '';
end;

{ ====================================================================== }
{              LUBRIFIANTS — Apply month/year filter                       }
{ ====================================================================== }
procedure TForm5.ApplyFilterL;
var
  Mois, Annee: Integer;
begin
  Mois  := CmbMois.ItemIndex + 1;
  Annee := EdtAnnee.Value;
  Tlurifiants.Filtered := False;
  Tlurifiants.Filter   := Format('Mois = %d AND Annee = ''%d''', [Mois, Annee]);
  Tlurifiants.Filtered := True;
  UpdateStatusBarL;
  UpdateButtonsL;
end;

{ ====================================================================== }
{  LUBRIFIANTS — Automatic calculations                                    }
{  AchatTTC  = AchatHT + TVAachat                                         }
{  TVAVente  = VenteHT * 0.19                                             }
{  VenteTTC  = VenteHT * 1.19                                             }
{  Benefice  = VenteHT - AchatHT                                          }
{  Marge     = VenteHT / AchatHT                                          }
{  Tachat    = AchatTTC                                                    }
{ ====================================================================== }
procedure TForm5.RecalcLurifiants;
var
  AchatTTC, TVAAchat, AchatHT, VenteHT: Double;
begin
  if FLUpdating then
    Exit;
  if not (Tlurifiants.State in [dsInsert, dsEdit]) then
    Exit;

  FLUpdating := True;
  try
    AchatTTC := TlurifiantsAchatTTC.AsFloat;
    TVAAchat := TlurifiantsTVAachat.AsFloat;

    AchatHT := AchatTTC - TVAAchat;
    if AchatHT < 0 then
      AchatHT := 0;

    VenteHT := AchatHT * 1.15;

    TlurifiantsAchatHT.AsFloat  := AchatHT;
    TlurifiantsVenteHT.AsFloat  := VenteHT;
    TlurifiantsTVAVente.AsFloat := VenteHT * 0.19;
    TlurifiantsVenteTTC.AsFloat := VenteHT + TlurifiantsTVAVente.AsFloat;
    TlurifiantsBenefice.AsFloat := VenteHT - AchatHT;
    TlurifiantsTachat.AsFloat   := AchatTTC;

    if AchatHT > 0 then
      TlurifiantsMarge.AsFloat := VenteHT / AchatHT
    else
      TlurifiantsMarge.AsFloat := 0;
  finally
    FLUpdating := False;
  end;
end;

{ ====================================================================== }
{  LUBRIFIANTS — Update status bar                                         }
{ ====================================================================== }
procedure TForm5.UpdateStatusBarL;
begin
  if not Tlurifiants.Active then
  begin
    StatusBar1.Panels[0].Text := 'RecordCount: 0';
    StatusBar1.Panels[1].Text := 'RecordNo: 0';
    StatusBar1.Panels[2].Text := '';
    Exit;
  end;
  StatusBar1.Panels[0].Text := Format('RecordCount: %d', [Tlurifiants.RecordCount]);
  if not Tlurifiants.IsEmpty then
    StatusBar1.Panels[1].Text := Format('RecordNo: %d', [Tlurifiants.RecNo])
  else
    StatusBar1.Panels[1].Text := 'RecordNo: 0';
  if Tlurifiants.State in [dsInsert] then
    StatusBar1.Panels[2].Text := '[ Nouveau enregistrement... ]'
  else if Tlurifiants.State in [dsEdit] then
    StatusBar1.Panels[2].Text := '[ Modification en cours... ]'
  else
    StatusBar1.Panels[2].Text := '';
end;

{ ====================================================================== }
{  LUBRIFIANTS — Update buttons state                                      }
{ ====================================================================== }
procedure TForm5.UpdateButtonsL;
var
  IsActive  : Boolean;
  IsEditing : Boolean;
begin
  IsActive  := Tlurifiants.Active;
  IsEditing := IsActive and (Tlurifiants.State in [dsInsert, dsEdit]);
  BtnAddL.Enabled    := IsActive and not IsEditing;
  BtnDeleteL.Enabled := IsActive and not IsEditing and not Tlurifiants.IsEmpty;
  BtnPostL.Enabled   := IsEditing;
  BtnCancelL.Enabled := IsEditing;
end;

{ ====================================================================== }
{  LUBRIFIANTS — DataSource OnDataChange (real-time recalc)                }
{ ====================================================================== }
procedure TForm5.DlurifiantsDataChange(Sender: TObject; Field: TField);
begin
  if FLUpdating then
    Exit;
  if Field = nil then
    Exit;
  if not (Tlurifiants.State in [dsInsert, dsEdit]) then
    Exit;

  if (Field = TlurifiantsAchatTTC) or
     (Field = TlurifiantsTVAachat) then
    RecalcLurifiants;
end;

{ ====================================================================== }
{  LUBRIFIANTS — New record defaults                                        }
{ ====================================================================== }
procedure TForm5.TlurifiantsNewRecord(DataSet: TDataSet);
begin
  TlurifiantsFournisseur.AsString := 'NAFTAL';
  TlurifiantsDateFact.AsDateTime  := Date;
  TlurifiantsAnnee.AsString       := IntToStr(EdtAnnee.Value);
  TlurifiantsMois.AsInteger       := CmbMois.ItemIndex + 1;
  TlurifiantsRefF.Clear;

  TlurifiantsAchatHT.AsFloat    := 0;
  TlurifiantsTVAachat.AsFloat   := 0;
  TlurifiantsAchatTTC.AsFloat   := 0;
  TlurifiantsVenteHT.AsFloat    := 0;
  TlurifiantsTVAVente.AsFloat   := 0;
  TlurifiantsVenteTTC.AsFloat   := 0;
  TlurifiantsBenefice.AsFloat   := 0;
  TlurifiantsTachat.AsFloat     := 0;
  TlurifiantsMarge.AsFloat      := 0;
end;

{ ====================================================================== }
{  LUBRIFIANTS — Before/After events                                        }
{ ====================================================================== }
procedure TForm5.TlurifiantsBeforePost(DataSet: TDataSet);
begin
  if TlurifiantsDateFact.IsNull then
    TlurifiantsDateFact.AsDateTime := Date;

  TlurifiantsAnnee.AsString := IntToStr(EdtAnnee.Value);
  TlurifiantsMois.AsInteger := CmbMois.ItemIndex + 1;

  RecalcLurifiants;
end;

procedure TForm5.TlurifiantsAfterPost(DataSet: TDataSet);
begin
  UpdateButtonsL;
  UpdateStatusBarL;
end;

procedure TForm5.TlurifiantsAfterCancel(DataSet: TDataSet);
begin
  UpdateButtonsL;
  UpdateStatusBarL;
end;

procedure TForm5.TlurifiantsAfterScroll(DataSet: TDataSet);
begin
  UpdateStatusBarL;
  UpdateButtonsL;
end;

procedure TForm5.TlurifiantsAfterOpen(DataSet: TDataSet);
begin
  UpdateStatusBarL;
  UpdateButtonsL;
end;

{ ====================================================================== }
{  DBGridEh2 - Highlight active cell + distinct grid lines                 }
{ ====================================================================== }
procedure TForm5.DBGridEh2DrawColumnCell(Sender: TObject; const Rect: TRect;
  DataCol: Integer; Column: TColumnEh; State: TGridDrawState);
begin
  if gdFocused in State then
  begin
    DBGridEh2.Canvas.Brush.Color := clEditCell;
    DBGridEh2.Canvas.Font.Color  := clBlack;
  end;
  DBGridEh2.DefaultDrawColumnCell(Rect, DataCol, Column, State);
  DBGridEh2.Canvas.Pen.Color := clNavy;
  DBGridEh2.Canvas.MoveTo(Rect.Left,    Rect.Bottom - 1);
  DBGridEh2.Canvas.LineTo(Rect.Right,   Rect.Bottom - 1);
  DBGridEh2.Canvas.MoveTo(Rect.Right - 1, Rect.Top);
  DBGridEh2.Canvas.LineTo(Rect.Right - 1, Rect.Bottom);
end;

{ ====================================================================== }
{  DBGridEh2 - Enter key as Tab                                            }
{ ====================================================================== }
procedure TForm5.DBGridEh2KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if (Key = VK_RETURN) and (Shift = []) then
    Key := VK_TAB;
end;

{ ====================================================================== }
{  LUBRIFIANTS — Button handlers                                            }
{ ====================================================================== }
procedure TForm5.BtnAddLClick(Sender: TObject);
begin
  if not Tlurifiants.Active then
    Tlurifiants.Open;

  if Tlurifiants.State in [dsInsert, dsEdit] then
    Exit;

  Tlurifiants.DisableControls;
  try
    Tlurifiants.Append;

    TlurifiantsRefF.Clear;
    TlurifiantsDateFact.AsDateTime  := Date;
    TlurifiantsMois.AsInteger       := CmbMois.ItemIndex + 1;
    TlurifiantsAnnee.AsString       := IntToStr(EdtAnnee.Value);
    TlurifiantsFournisseur.AsString := 'NAFTAL';
    TlurifiantsAchatHT.AsFloat      := 0;
    TlurifiantsTVAachat.AsFloat     := 0;
    TlurifiantsAchatTTC.AsFloat     := 0;
    TlurifiantsVenteHT.AsFloat      := 0;
    TlurifiantsTVAVente.AsFloat     := 0;
    TlurifiantsVenteTTC.AsFloat     := 0;
    TlurifiantsBenefice.AsFloat     := 0;
    TlurifiantsTachat.AsFloat       := 0;
    TlurifiantsMarge.AsFloat        := 0;

    RecalcLurifiants;
  finally
    Tlurifiants.EnableControls;
  end;

  DBGridEh4.SetFocus;
  DBGridEh4.SelectedIndex := 2;
  DBGridEh4.EditorMode := True;

  UpdateButtonsL;
  UpdateStatusBarL;
end;


procedure TForm5.BtnDeleteLClick(Sender: TObject);
begin
  if not Tlurifiants.Active then Exit;
  if Tlurifiants.IsEmpty then Exit;
  if MessageDlg('Confirmer la suppression de cet enregistrement ?',
    mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    Tlurifiants.Delete;
    UpdateStatusBarL;
    UpdateButtonsL;
  end;
end;

procedure TForm5.BtnPostLClick(Sender: TObject);
begin
  if Tlurifiants.State in [dsInsert, dsEdit] then
  begin
    Tlurifiants.Post;
    UpdateStatusBarL;
    UpdateButtonsL;
  end;
end;

procedure TForm5.BtnCancelLClick(Sender: TObject);
begin
  if Tlurifiants.State in [dsInsert, dsEdit] then
  begin
    Tlurifiants.Cancel;
    UpdateStatusBarL;
    UpdateButtonsL;
  end;
end;

{ ====================================================================== }
{  LUBRIFIANTS — Export Excel (HTML method)                                }
{ ====================================================================== }
procedure TForm5.BtnExportLClick(Sender: TObject);
var
  SaveDlg   : TSaveDialog;
  F         : TextFile;
  FileName  : string;
  i         : Integer;
  ColHeaders: array of string;
  ColFields : array of string;
  ColCount  : Integer;
  CellVal   : string;
begin
  ColCount := DBGridEh2.Columns.Count;
  SetLength(ColHeaders, ColCount);
  SetLength(ColFields,  ColCount);
  for i := 0 to ColCount - 1 do
  begin
    ColHeaders[i] := DBGridEh2.Columns[i].Title.Caption;
    if ColHeaders[i] = '' then
      ColHeaders[i] := DBGridEh2.Columns[i].FieldName;
    ColFields[i] := DBGridEh2.Columns[i].FieldName;
  end;

  SaveDlg := TSaveDialog.Create(nil);
  try
    SaveDlg.Title      := 'Exporter vers Excel';
    SaveDlg.Filter     := 'Fichier Excel (*.xls)|*.xls|Tous fichiers (*.*)|*.*';
    SaveDlg.DefaultExt := 'xls';
    SaveDlg.FileName   := Format('LUBRIFIANTS_%s_%d',
      [MoisNom(CmbMois.ItemIndex + 1), EdtAnnee.Value]);
    if not SaveDlg.Execute then Exit;
    FileName := SaveDlg.FileName;
  finally
    SaveDlg.Free;
  end;

  AssignFile(F, FileName);
  try
    Rewrite(F);
    WriteLn(F, '<html>');
    WriteLn(F, '<head><meta charset="UTF-8"></head>');
    WriteLn(F, '<body>');
    WriteLn(F, '<table border="1" cellspacing="0" cellpadding="3">');

    { Title row }
    WriteLn(F, Format('<tr><td colspan="%d" align="center" ' +
      'style="font-weight:bold;font-size:14px;background:#336699;color:white;">%s</td></tr>',
      [ColCount, Format('LUBRIFIANTS  MOIS DE :  %s  %d',
        [MoisNom(CmbMois.ItemIndex + 1), EdtAnnee.Value])]));

    { Header row }
    Write(F, '<tr>');
    for i := 0 to ColCount - 1 do
      Write(F, Format('<th style="background:#4472C4;color:white;font-weight:bold;">%s</th>',
        [ColHeaders[i]]));
    WriteLn(F, '</tr>');

    { Data rows }
    Tlurifiants.DisableControls;
    Tlurifiants.First;
    try
      while not Tlurifiants.EOF do
      begin
        Write(F, '<tr>');
        for i := 0 to ColCount - 1 do
        begin
          CellVal := Tlurifiants.FieldByName(ColFields[i]).DisplayText;
          Write(F, Format('<td align="right">%s</td>', [CellVal]));
        end;
        WriteLn(F, '</tr>');
        Tlurifiants.Next;
      end;
    finally
      Tlurifiants.EnableControls;
    end;

    WriteLn(F, '</table>');
    WriteLn(F, '</body></html>');
    CloseFile(F);
    ShowMessage('Export r'#233'ussi !' + #13#10 + FileName);
  except
    on E: Exception do
    begin
      CloseFile(F);
      ShowMessage('Erreur export : ' + E.Message);
    end;
  end;
end;

end.
