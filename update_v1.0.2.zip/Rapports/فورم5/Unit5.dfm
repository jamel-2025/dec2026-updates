object Form5: TForm5
  Left = 5
  Top = 0
  Caption = 'Detail Chiffres d'#39'Affaires'
  ClientHeight = 620
  ClientWidth = 1372
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poDesigned
  WindowState = wsMaximized
  OnCreate = FormCreate
  TextHeight = 15
  object PanelTop: TPanel
    Left = 0
    Top = 0
    Width = 1372
    Height = 88
    Align = alTop
    BevelOuter = bvNone
    Color = clWhite
    TabOrder = 0
    ExplicitWidth = 1370
    object PanelTitle: TPanel
      Left = 0
      Top = 0
      Width = 1372
      Height = 34
      Align = alTop
      BevelOuter = bvNone
      Color = 3407872
      TabOrder = 0
      ExplicitWidth = 1370
      object LblTitle: TLabel
        Left = 0
        Top = 0
        Width = 1372
        Height = 34
        Align = alClient
        Alignment = taCenter
        Caption = 'DETAIL CHIFFRES D'#39'AFFAIRES  MOIS DE :  JANVIER  2025'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWhite
        Font.Height = -15
        Font.Name = 'Segoe UI'
        Font.Style = [fsBold]
        ParentFont = False
        Layout = tlCenter
        ExplicitWidth = 401
        ExplicitHeight = 20
      end
    end
    object PanelFilter: TPanel
      Left = 0
      Top = 34
      Width = 1372
      Height = 54
      Align = alClient
      BevelOuter = bvNone
      Color = 15921906
      TabOrder = 1
      ExplicitWidth = 1370
      object LblMois: TLabel
        Left = 16
        Top = 19
        Width = 32
        Height = 15
        Caption = 'Mois :'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Segoe UI'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object LblAnnee: TLabel
        Left = 186
        Top = 19
        Width = 42
        Height = 15
        Caption = 'Annee :'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Segoe UI'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object CmbMois: TComboBox
        Left = 56
        Top = 15
        Width = 118
        Height = 23
        Style = csDropDownList
        TabOrder = 0
      end
      object EdtAnnee: TSpinEdit
        Left = 234
        Top = 15
        Width = 72
        Height = 24
        MaxValue = 2099
        MinValue = 2000
        TabOrder = 1
        Value = 2025
      end
      object BtnFilter: TButton
        Left = 320
        Top = 13
        Width = 100
        Height = 28
        Caption = 'Filtrer'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Segoe UI'
        Font.Style = [fsBold]
        ParentFont = False
        TabOrder = 2
        OnClick = BtnFilterClick
      end
      object BtnOpen: TButton
        Left = 434
        Top = 13
        Width = 80
        Height = 28
        Caption = 'Open'
        TabOrder = 3
        OnClick = BtnOpenClick
      end
      object BtnClose: TButton
        Left = 524
        Top = 13
        Width = 80
        Height = 28
        Caption = 'Close'
        TabOrder = 4
        OnClick = BtnCloseClick
      end
      object BtnExport: TButton
        Left = 1014
        Top = 13
        Width = 100
        Height = 28
        Caption = 'Export Excel'
        TabOrder = 5
        OnClick = BtnExportClick
      end
      object BtnExit: TButton
        Left = 1124
        Top = 13
        Width = 80
        Height = 28
        Caption = 'Exit'
        TabOrder = 6
        OnClick = BtnExitClick
      end
    end
  end
  object StatusBar1: TStatusBar
    Left = 0
    Top = 598
    Width = 1372
    Height = 22
    Panels = <
      item
        Text = 'RecordCount: 0'
        Width = 160
      end
      item
        Text = 'RecordNo: 0'
        Width = 160
      end
      item
        Width = 300
      end>
    ExplicitTop = 594
    ExplicitWidth = 1370
  end
  object scToolPager1: TscToolPager
    Left = 0
    Top = 88
    Width = 1372
    Height = 440
    Align = alClient
    FluentUIOpaque = False
    TabOrder = 2
    EnableDragReorderTabs = False
    TransparentBackground = False
    BorderStyle = sctpbsFrame
    ShowFocusRect = True
    TabsLeftOffset = 15
    TabsRightOffset = 15
    TabIndex = 2
    TabGlowEffect.Enabled = False
    TabGlowEffect.Color = clHighlight
    TabGlowEffect.AlphaValue = 255
    TabGlowEffect.GlowSize = 7
    TabGlowEffect.Offset = 0
    TabGlowEffect.Intensive = True
    TabGlowEffect.StyleColors = True
    TabGlowEffect.HotColor = clNone
    TabGlowEffect.PressedColor = clNone
    TabGlowEffect.FocusedColor = clNone
    TabGlowEffect.PressedGlowSize = 7
    TabGlowEffect.PressedAlphaValue = 255
    TabGlowEffect.States = [scsHot, scsPressed, scsFocused]
    WallpaperIndex = -1
    CustomBackgroundImageIndex = -1
    TabSpacing = 10
    TabMargin = 10
    MouseWheelSupport = True
    ScrollButtonWidth = 15
    CustomOverContentImageIndex = -1
    TabHeight = 30
    Tabs = <
      item
        Page = scToolPagerPage1
        Visible = True
        Enabled = True
        ImageIndex = -1
        Caption = 'Secteur p'#233'trolier'
      end
      item
        Page = scToolPagerPage2
        Visible = True
        Enabled = True
        ImageIndex = -1
        Caption = 'LUBRIFIANTS'
      end
      item
        Page = scToolPagerPage3
        Visible = True
        Enabled = True
        ImageIndex = -1
        Caption = 'Autres prestations de services'
      end>
    ActivePage = scToolPagerPage3
    StorePaintBuffer = False
    ExplicitWidth = 1370
    ExplicitHeight = 436
    object scToolPagerPage1: TscToolPagerPage
      Left = 2
      Top = 32
      Width = 1368
      Height = 406
      FluentUIOpaque = False
      TabOrder = 0
      Visible = False
      Color = clBtnFace
      StyleKind = scspsTabSheet
      ScrollButtonWidth = 15
      CustomImageIndex = -1
      WallpaperIndex = -1
      HotScroll = False
      AutoSize = False
      MouseWheelSupport = False
      ScrollType = scstHorizontal
      ScrollOffset = 0
      ScrollTimerInterval = 50
      StorePaintBuffer = False
      HorzScrollDirection = scspssdLeftToRight
      VertScrollDirection = scspssdTopToBottom
      TouchScroll = False
      CanScroll = True
      object DBGridEh1: TDBGridEh
        Left = 0
        Top = 382
        Width = 1368
        Height = 24
        Align = alBottom
        DefaultDrawing = False
        DynProps = <>
        EditActions = [geaCopyEh, geaSelectAllEh]
        FixedColor = clSilver
        FooterParams.Color = clWindow
        FooterParams.FillStyle = cfstThemedEh
        FooterParams.HorzLineColor = clInfoBk
        FooterParams.RowHeight = 20
        FooterParams.VertLineColor = clAppWorkSpace
        GridLineParams.ColorScheme = glcsThemedEh
        IndicatorOptions = [gioShowRowIndicatorEh, gioShowRecNoEh]
        OddRowColor = clScrollBar
        Options = [dgEditing, dgAlwaysShowEditor, dgTitles, dgIndicator, dgColLines, dgRowLines, dgTabs, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit]
        OptionsEh = [dghFixed3D, dghFooter3D, dghHighlightFocus, dghClearSelection, dghFitRowHeightToText, dghEnterAsTab, dghRowHighlight, dghDialogFind, dghShowRecNo, dghExtendVertLines]
        ParentColor = True
        RowDetailPanel.Color = clBtnFace
        RowHeight = 4
        RowLines = 1
        SelectionDrawParams.SelectionStyle = gsdsGridThemedEh
        SelectionDrawParams.DrawFocusFrame = True
        SelectionDrawParams.DrawFocusFrameStored = True
        SumList.Active = True
        TabOrder = 0
        TitleParams.Color = clBackground
        TitleParams.FillStyle = cfstThemedEh
        TitleParams.HorzLines = True
        TitleParams.MultiTitle = True
        TitleParams.RowLines = 2
        TitleParams.VertLines = True
        Visible = False
        OnDrawColumnCell = DBGridEh1DrawColumnCell
        OnKeyDown = DBGridEh1KeyDown
        Columns = <
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Fournisseur'
            Footer.Alignment = taCenter
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.Value = 'Total'
            Footers = <>
            Width = 85
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'DateFact'
            Footers = <>
            Title.Caption = 'Date'
            Width = 86
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'RefF'
            Footers = <>
            Title.Caption = 'REF'
            Width = 76
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'QGasoil'
            Footer.DisplayFormat = '#,##0'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Qt'#233's Achats|Qt'#233' Gas Oil'
            Width = 76
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'QEssence'
            Footer.DisplayFormat = '#,##0'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Qt'#233's Achats|Qt'#233' Essence'
            Width = 86
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'QSirgaz'
            Footer.DisplayFormat = '#,##0'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Qt'#233's Achats|Qt'#233' Sirghaz'
            Width = 76
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PUGasoil'
            Footers = <>
            ReadOnly = True
            Title.Caption = 'PU Achats|Gas Oil'
            Width = 110
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PUEssence'
            Footers = <>
            ReadOnly = True
            Title.Caption = 'PU Achats|Essence'
            Width = 80
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PUSirgaz'
            Footers = <>
            ReadOnly = True
            Title.Caption = 'PU Achats|Sirghaz'
            Width = 72
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TGasoil'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Tot Vente| Gas Oil'
            Width = 90
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TEssence'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Tot Vente|  Essence'
            Width = 96
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TSiirgaz'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Tot Vente| Sirghaz'
            Width = 80
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Tvente'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Total Ventes'
            Width = 100
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Tachat'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Total Achat'
            Width = 100
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Benefice'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'B'#233'n'#233'fice'
            Width = 100
          end>
        object RowDetailData: TRowDetailPanelControlEh
        end
      end
      object Panel1: TPanel
        Left = 0
        Top = 0
        Width = 1368
        Height = 49
        Align = alTop
        TabOrder = 1
        ExplicitWidth = 1336
        object BtnCancel: TButton
          Left = 314
          Top = 5
          Width = 80
          Height = 28
          Caption = 'Annuler'
          TabOrder = 0
          OnClick = BtnCancelClick
        end
        object BtnDelete: TButton
          Left = 114
          Top = 5
          Width = 90
          Height = 28
          Caption = 'Supprimer'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clRed
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 1
          OnClick = BtnDeleteClick
        end
        object BtnPost: TButton
          Left = 214
          Top = 5
          Width = 90
          Height = 28
          Caption = 'Enregistrer'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clNavy
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 2
          OnClick = BtnPostClick
        end
        object BtnAdd: TButton
          Left = 14
          Top = 5
          Width = 90
          Height = 28
          Caption = 'Ajouter'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clGreen
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 3
          OnClick = BtnAddClick
        end
      end
      object DBGridEh3: TDBGridEh
        Left = 0
        Top = 49
        Width = 1368
        Height = 333
        Align = alClient
        DataSource = Dnaftal
        DynProps = <>
        FooterRowCount = 1
        FooterParams.FillStyle = cfstThemedEh
        FooterParams.Font.Charset = DEFAULT_CHARSET
        FooterParams.Font.Color = clWindowText
        FooterParams.Font.Height = -12
        FooterParams.Font.Name = 'Segoe UI'
        FooterParams.Font.Style = [fsBold]
        FooterParams.ParentFont = False
        FooterParams.RowHeight = 15
        FooterParams.RowLines = 1
        GridLineParams.GridBoundaries = True
        IndicatorOptions = [gioShowRowIndicatorEh, gioShowRecNoEh]
        OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghEnterAsTab, dghRowHighlight, dghDialogFind, dghShowRecNo, dghColumnResize, dghColumnMove, dghExtendVertLines]
        SumList.Active = True
        TabOrder = 2
        TitleParams.FillStyle = cfstThemedEh
        TitleParams.MultiTitle = True
        Columns = <
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'IDF'
            Footers = <>
            Visible = False
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Fournisseur'
            Footers = <>
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'DateFact'
            Footers = <>
            Title.Caption = 'Date'
            Width = 86
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'RefF'
            Footers = <>
            Title.Caption = 'R'#233'f'
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Annee'
            Footers = <>
            Visible = False
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'QGasoil'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clRed
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Qt'#233's Achats|Qt'#233' Gas Oil'
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'QEssence'
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Qt'#233's Achats|Qt'#233' Essence'
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'QSirgaz'
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Qt'#233's Achats|Qt'#233' Sirghaz'
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PUGasoil'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = []
            Footers = <>
            ReadOnly = True
            Title.Caption = 'PU Achats|Gasoil'
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PUEssence'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = []
            Footers = <>
            ReadOnly = True
            Title.Caption = 'PU Achats|Essence'
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PUSirgaz'
            Footers = <>
            ReadOnly = True
            Title.Caption = 'PU Achats|Sirgaz'
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TGasoil'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Tot Vente|Gas Oil'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TEssence'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Tot Vente|Essence'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TSiirgaz'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Tot Vente|Sirghaz'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Tvente'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Total Ventes'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Tachat'
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Total Achat'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Benefice'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'B'#233'n'#233'fice'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Mois'
            Footers = <>
            Visible = False
          end>
        object RowDetailData: TRowDetailPanelControlEh
        end
      end
    end
    object scToolPagerPage2: TscToolPagerPage
      Left = 2
      Top = 32
      Width = 1368
      Height = 406
      FluentUIOpaque = False
      TabOrder = 1
      Visible = False
      Color = clBtnFace
      StyleKind = scspsTabSheet
      ScrollButtonWidth = 15
      CustomImageIndex = -1
      WallpaperIndex = -1
      HotScroll = False
      AutoSize = False
      MouseWheelSupport = False
      ScrollType = scstHorizontal
      ScrollOffset = 0
      ScrollTimerInterval = 50
      StorePaintBuffer = False
      HorzScrollDirection = scspssdLeftToRight
      VertScrollDirection = scspssdTopToBottom
      TouchScroll = False
      CanScroll = True
      object DBGridEh2: TDBGridEh
        Left = 0
        Top = 396
        Width = 1368
        Height = 10
        Align = alBottom
        DefaultDrawing = False
        DynProps = <>
        EditActions = [geaCopyEh, geaSelectAllEh]
        FixedColor = clSilver
        FooterRowCount = 1
        FooterParams.Color = clActiveBorder
        FooterParams.FillStyle = cfstThemedEh
        FooterParams.HorzLineColor = clGradientActiveCaption
        FooterParams.RowHeight = 15
        FooterParams.RowLines = 1
        FooterParams.VertLineColor = clWhite
        GridLineParams.ColorScheme = glcsThemedEh
        IndicatorOptions = [gioShowRowIndicatorEh, gioShowRecNoEh]
        OddRowColor = clScrollBar
        Options = [dgEditing, dgAlwaysShowEditor, dgTitles, dgIndicator, dgColLines, dgRowLines, dgTabs, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit]
        OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghFitRowHeightToText, dghDialogFind, dghShowRecNo, dghColumnResize, dghExtendVertLines]
        RowDetailPanel.Color = clBtnFace
        RowHeight = 4
        RowLines = 1
        SelectionDrawParams.SelectionStyle = gsdsGridThemedEh
        SelectionDrawParams.DrawFocusFrame = True
        SelectionDrawParams.DrawFocusFrameStored = True
        SumList.Active = True
        TabOrder = 0
        TitleParams.Color = clBackground
        TitleParams.FillStyle = cfstThemedEh
        TitleParams.HorzLines = True
        TitleParams.MultiTitle = True
        TitleParams.RowLines = 2
        TitleParams.VertLines = True
        Visible = False
        OnDrawColumnCell = DBGridEh2DrawColumnCell
        OnKeyDown = DBGridEh2KeyDown
        Columns = <
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Fournisseur'
            Footer.Alignment = taCenter
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.Value = 'Total'
            Footers = <>
            Width = 85
          end
          item
            CellButtons = <>
            DisplayFormat = 'dd/mm/yyyy'
            DynProps = <>
            EditButtons = <>
            EditMask = 'dd/mm/yyyy'
            FieldName = 'DateFact'
            Footers = <>
            Title.Caption = 'Date'
            Width = 90
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'RefF'
            Footers = <>
            Title.Caption = 'R'#233'f'#233'rence'
            Width = 90
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'AchatHT'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'ACHATS|HT'
            Width = 110
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TVAachat'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'ACHATS|TVA 19%'
            Width = 100
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'AchatTTC'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'ACHATS|TTC'
            Width = 110
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'VenteHT'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'VENTES|HT'
            Width = 110
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TVAVente'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'VENTES|TVA 19%'
            Width = 100
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'VenteTTC'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'VENTES|TTC'
            Width = 110
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Benefice'
            Footer.DisplayFormat = '#,##0.00'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'B'#233'n'#233'fice'
            Width = 110
          end
          item
            Alignment = taRightJustify
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Marge'
            Footer.DisplayFormat = '#,##0.00'
            Footers = <>
            ReadOnly = True
            Width = 70
          end>
        object RowDetailData: TRowDetailPanelControlEh
        end
      end
      object DBGridEh4: TDBGridEh
        Left = 0
        Top = 57
        Width = 1368
        Height = 339
        Align = alClient
        DataSource = Dlurifiants
        DynProps = <>
        FooterRowCount = 1
        FooterParams.FillStyle = cfstThemedEh
        FooterParams.Font.Charset = DEFAULT_CHARSET
        FooterParams.Font.Color = clWindowText
        FooterParams.Font.Height = -12
        FooterParams.Font.Name = 'Segoe UI'
        FooterParams.Font.Style = [fsBold]
        FooterParams.ParentFont = False
        FooterParams.RowHeight = 15
        FooterParams.RowLines = 1
        GridLineParams.GridBoundaries = True
        IndicatorOptions = [gioShowRowIndicatorEh, gioShowRecNoEh]
        OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghEnterAsTab, dghRowHighlight, dghDialogFind, dghShowRecNo, dghColumnResize, dghColumnMove, dghExtendVertLines]
        SumList.Active = True
        TabOrder = 1
        TitleParams.FillStyle = cfstThemedEh
        TitleParams.MultiTitle = True
        Columns = <
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'IDF'
            Footers = <>
            Visible = False
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Fournisseur'
            Footers = <>
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'DateFact'
            Footers = <>
            Title.Caption = 'Date'
            Width = 86
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'RefF'
            Footers = <>
            Title.Caption = 'R'#233'f'
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Annee'
            Footers = <>
            Visible = False
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'AchatHT'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clRed
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'ACHATS|HT'
            Width = 117
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TVAachat'
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'ACHATS|TVA 19%'
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'AchatTTC'
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'ACHATS|TTC'
            Width = 128
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'VenteHT'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = []
            Footers = <>
            ReadOnly = True
            Title.Caption = 'VENTES|HT'
            Width = 110
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TVAVente'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = []
            Footers = <>
            ReadOnly = True
            Title.Caption = 'VENTES|TVA 19%'
            Width = 99
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'VenteTTC'
            Footers = <>
            ReadOnly = True
            Title.Caption = 'VENTES|TTC'
            Width = 111
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Benefice'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'B'#233'n'#233'fice'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Marge'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Mois'
            Footers = <>
            Visible = False
          end>
        object RowDetailData: TRowDetailPanelControlEh
        end
      end
      object Panel3: TPanel
        Left = 0
        Top = 0
        Width = 1368
        Height = 57
        Align = alTop
        TabOrder = 2
        ExplicitLeft = 3
        ExplicitTop = 72
        ExplicitWidth = 902
        object BtnExportL: TButton
          Left = 429
          Top = 13
          Width = 100
          Height = 28
          Caption = 'Export Excel'
          TabOrder = 0
          OnClick = BtnExportLClick
        end
        object BtnCancelL: TButton
          Left = 322
          Top = 13
          Width = 80
          Height = 28
          Caption = 'Annuler'
          TabOrder = 1
          OnClick = BtnCancelLClick
        end
        object BtnPostL: TButton
          Left = 222
          Top = 13
          Width = 90
          Height = 28
          Caption = 'Enregistrer'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clNavy
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 2
          OnClick = BtnPostLClick
        end
        object BtnDeleteL: TButton
          Left = 122
          Top = 13
          Width = 90
          Height = 28
          Caption = 'Supprimer'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clRed
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 3
          OnClick = BtnDeleteLClick
        end
        object BtnAddL: TButton
          Left = 22
          Top = 13
          Width = 90
          Height = 28
          Caption = 'Ajouter'
          Font.Charset = DEFAULT_CHARSET
          Font.Color = clGreen
          Font.Height = -12
          Font.Name = 'Segoe UI'
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 4
          OnClick = BtnAddLClick
        end
      end
    end
    object scToolPagerPage3: TscToolPagerPage
      Left = 2
      Top = 32
      Width = 1368
      Height = 406
      FluentUIOpaque = False
      TabOrder = 2
      Color = clBtnFace
      StyleKind = scspsTabSheet
      ScrollButtonWidth = 15
      CustomImageIndex = -1
      WallpaperIndex = -1
      HotScroll = False
      AutoSize = False
      MouseWheelSupport = False
      ScrollType = scstHorizontal
      ScrollOffset = 0
      ScrollTimerInterval = 50
      StorePaintBuffer = False
      HorzScrollDirection = scspssdLeftToRight
      VertScrollDirection = scspssdTopToBottom
      TouchScroll = False
      CanScroll = True
      object DBGridEh5: TDBGridEh
        Left = 0
        Top = 0
        Width = 1368
        Height = 406
        Align = alClient
        DataSource = Dprestation
        DynProps = <>
        FooterRowCount = 1
        FooterParams.FillStyle = cfstThemedEh
        FooterParams.Font.Charset = DEFAULT_CHARSET
        FooterParams.Font.Color = clWindowText
        FooterParams.Font.Height = -12
        FooterParams.Font.Name = 'Segoe UI'
        FooterParams.Font.Style = [fsBold]
        FooterParams.ParentFont = False
        FooterParams.RowHeight = 15
        FooterParams.RowLines = 1
        GridLineParams.GridBoundaries = True
        IndicatorOptions = [gioShowRowIndicatorEh, gioShowRecNoEh]
        OptionsEh = [dghFixed3D, dghHighlightFocus, dghClearSelection, dghEnterAsTab, dghRowHighlight, dghDialogFind, dghShowRecNo, dghColumnResize, dghColumnMove, dghExtendVertLines]
        SumList.Active = True
        TabOrder = 0
        TitleParams.FillStyle = cfstThemedEh
        TitleParams.MultiTitle = True
        Columns = <
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'IDP'
            Footers = <>
            Visible = False
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Mois'
            Footers = <>
            Title.Caption = 'mois'
            Visible = False
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Annee'
            Footers = <>
            Visible = False
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'RestaurantCA'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clRed
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = [fsBold]
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Chifftre d'#39'affaires|CAFETERIA'
            Width = 117
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'LavageCA'
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Chifftre d'#39'affaires|RESTAURANT'
            Width = 76
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TransportCA'
            Footer.ValueType = fvtSum
            Footers = <>
            Title.Caption = 'Chifftre d'#39'affaires|LAVAGE'
            Width = 128
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TransportCA'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = []
            Footers = <>
            ReadOnly = True
            Title.Caption = 'Chifftre d'#39'affaires|TRANSPORT'
            Width = 110
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'CafetiriaTVA'
            Footer.Font.Charset = DEFAULT_CHARSET
            Footer.Font.Color = clWindowText
            Footer.Font.Height = -12
            Footer.Font.Name = 'Segoe UI'
            Footer.Font.Style = []
            Footers = <>
            ReadOnly = True
            Title.Caption = 'TVA|CAFETERIA'
            Width = 99
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'RestaurantTVA'
            Footers = <>
            ReadOnly = True
            Title.Caption = 'TVA|RESTAURANT'
            Width = 111
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'LavageTVA'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'TVA|LAVAGE'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'TransportTVA'
            Footer.ValueType = fvtSum
            Footers = <>
            ReadOnly = True
            Title.Caption = 'TVA|TRANSPORT'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'Mois'
            Footers = <>
            Visible = False
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PrestationCA'
            Footers = <>
            Title.Caption = 'Prestation CA'
            Width = 100
          end
          item
            CellButtons = <>
            DynProps = <>
            EditButtons = <>
            FieldName = 'PrestationTVA'
            Footers = <>
            Title.Caption = 'Prestation TVA'
            Width = 100
          end>
        object RowDetailData: TRowDetailPanelControlEh
        end
      end
    end
  end
  object scPanel1: TscPanel
    Left = 0
    Top = 528
    Width = 1372
    Height = 35
    Align = alBottom
    Enabled = False
    FluentUIOpaque = False
    TabOrder = 3
    CustomImageIndex = -1
    DragForm = False
    DragTopForm = True
    StyleKind = scpsPanel
    ShowCaption = False
    BorderStyle = scpbsBottomBevel
    WallpaperIndex = -1
    LightBorderColor = clBtnHighlight
    ShadowBorderColor = clBtnShadow
    CaptionGlowEffect.Enabled = False
    CaptionGlowEffect.Color = clBtnShadow
    CaptionGlowEffect.AlphaValue = 255
    CaptionGlowEffect.GlowSize = 7
    CaptionGlowEffect.Offset = 0
    CaptionGlowEffect.Intensive = True
    CaptionGlowEffect.StyleColors = True
    Color = clBtnFace
    Caption = 'scPanel1'
    StorePaintBuffer = False
    WordWrap = False
    ExplicitTop = 524
    ExplicitWidth = 1370
    object scGPLabel13: TscGPLabel
      Left = 146
      Top = 6
      Width = 135
      Height = 23
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBtnText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      FluentUIOpaque = False
      TabOrder = 0
      DragForm = False
      DragTopForm = True
      DrawTextMode = scdtmGDI
      ContentMarginLeft = 5
      ContentMarginRight = 5
      ContentMarginTop = 2
      ContentMarginBottom = 2
      DisabledFontColor = clNone
      FrameWidth = 1
      FillColor = clBtnText
      FillColorAlpha = 20
      FillColor2 = clNone
      FillColor2Alpha = 255
      FillGradientAngle = 0
      FrameColor = clBtnText
      FrameColorAlpha = 40
      FrameRadius = 2
      GlowEffect.Enabled = False
      GlowEffect.Color = clBtnShadow
      GlowEffect.AlphaValue = 255
      GlowEffect.GlowSize = 7
      GlowEffect.Offset = 0
      GlowEffect.Intensive = True
      GlowEffect.StyleColors = True
      AutoSize = False
      VertAlignment = scvtaCenter
      Caption = 'Total des Droits :'
    end
    object TDroit: TscGPDBEdit
      Left = 287
      Top = 6
      Width = 113
      Height = 23
      FluentUIOpaque = False
      Options.NormalColor = clWindow
      Options.HotColor = clWindow
      Options.FocusedColor = 12779261
      Options.DisabledColor = clWindow
      Options.NormalColorAlpha = 200
      Options.HotColorAlpha = 255
      Options.FocusedColorAlpha = 255
      Options.DisabledColorAlpha = 150
      Options.FrameNormalColor = clBtnText
      Options.FrameHotColor = clHighlight
      Options.FrameFocusedColor = clHighlight
      Options.FrameDisabledColor = clBtnText
      Options.FrameWidth = 1
      Options.FrameNormalColorAlpha = 100
      Options.FrameHotColorAlpha = 255
      Options.FrameFocusedColorAlpha = 255
      Options.FrameDisabledColorAlpha = 50
      Options.FontNormalColor = clWindowText
      Options.FontHotColor = clWindowText
      Options.FontFocusedColor = clWindowText
      Options.FontDisabledColor = clGrayText
      Options.FocusedLineColor = 12779261
      Options.FocusedLineWidth = 0
      Options.ShapeFillGradientAngle = 90
      Options.ShapeCornerRadius = 10
      Options.ShapeStyle = scgpessLineRect
      Options.ScaleFrameWidth = False
      Options.StyleColors = True
      ContentMarginLeft = 5
      ContentMarginRight = 5
      ContentMarginTop = 2
      ContentMarginBottom = 2
      HideMaskWithEmptyText = False
      HidePromptTextIfFocused = False
      PromptTextColor = clNone
      Transparent = False
      LeftButton.Kind = scgpebCustom
      LeftButton.Enabled = True
      LeftButton.Visible = False
      LeftButton.ImageIndex = -1
      LeftButton.ImageHotIndex = -1
      LeftButton.ImagePressedIndex = -1
      LeftButton.RepeatClick = False
      LeftButton.RepeatClickInterval = 200
      LeftButton.ShowHint = False
      LeftButton.GlyphColor = clWindowText
      LeftButton.GlyphColorAlpha = 180
      LeftButton.GlyphColorHotAlpha = 240
      LeftButton.GlyphColorPressedAlpha = 150
      LeftButton.GlyphThickness = 2
      LeftButton.GlyphSize = 0
      LeftButton.Width = 0
      RightButton.Kind = scgpebCustom
      RightButton.Enabled = True
      RightButton.Visible = False
      RightButton.ImageIndex = -1
      RightButton.ImageHotIndex = -1
      RightButton.ImagePressedIndex = -1
      RightButton.RepeatClick = False
      RightButton.RepeatClickInterval = 200
      RightButton.ShowHint = False
      RightButton.GlyphColor = clWindowText
      RightButton.GlyphColorAlpha = 180
      RightButton.GlyphColorHotAlpha = 240
      RightButton.GlyphColorPressedAlpha = 150
      RightButton.GlyphThickness = 2
      RightButton.GlyphSize = 0
      RightButton.Width = 0
      CustomDraw = False
      Text = ''
      Alignment = taRightJustify
      Color = clBtnFace
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Arial'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 1
      DataField = 'Totaldroits'
      DataSource = Form20.DTTAPP
    end
  end
  object scPanel3: TscPanel
    Left = 0
    Top = 563
    Width = 1372
    Height = 35
    Align = alBottom
    FluentUIOpaque = False
    TabOrder = 4
    CustomImageIndex = -1
    DragForm = False
    DragTopForm = True
    StyleKind = scpsPanel
    ShowCaption = False
    BorderStyle = scpbsBottomBevel
    WallpaperIndex = -1
    LightBorderColor = clBtnHighlight
    ShadowBorderColor = clBtnShadow
    CaptionGlowEffect.Enabled = False
    CaptionGlowEffect.Color = clBtnShadow
    CaptionGlowEffect.AlphaValue = 255
    CaptionGlowEffect.GlowSize = 7
    CaptionGlowEffect.Offset = 0
    CaptionGlowEffect.Intensive = True
    CaptionGlowEffect.StyleColors = True
    Color = clBtnFace
    Caption = 'scPanel1'
    StorePaintBuffer = False
    WordWrap = False
    ExplicitTop = 559
    ExplicitWidth = 1370
    DesignSize = (
      1372
      35)
    object SpeedButton3: TSpeedButton
      Left = 1242
      Top = 4
      Width = 95
      Height = 25
      Anchors = [akTop]
      Caption = '   Annuler'
      ImageIndex = 43
      Images = DM.Smal
      HotImageIndex = 9
      Flat = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Arial'
      Font.Style = [fsBold]
      ParentFont = False
      Spacing = 0
      StyleName = 'puerto rico'
    end
    object AdvGlowButton2: TAdvGlowButton
      Left = 1120
      Top = 6
      Width = 84
      Height = 24
      Margins.Left = 1
      Margins.Right = 1
      Anchors = [akTop, akRight]
      Caption = 'Valider'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ImageIndex = 12
      Images = DM.Smal
      MarginHorz = 0
      NotesFont.Charset = DEFAULT_CHARSET
      NotesFont.Color = clWindowText
      NotesFont.Height = -11
      NotesFont.Name = 'Tahoma'
      NotesFont.Style = []
      ParentFont = False
      Rounded = True
      Spacing = 0
      Transparent = True
      TabOrder = 0
      Appearance.BorderColor = 11382963
      Appearance.BorderColorHot = 11565130
      Appearance.BorderColorCheckedHot = 11565130
      Appearance.BorderColorDown = 11565130
      Appearance.BorderColorChecked = 13744549
      Appearance.BorderColorDisabled = 13948116
      Appearance.Color = clWhite
      Appearance.ColorTo = clWhite
      Appearance.ColorChecked = 13744549
      Appearance.ColorCheckedTo = 13744549
      Appearance.ColorDisabled = clWhite
      Appearance.ColorDisabledTo = clNone
      Appearance.ColorDown = 11565130
      Appearance.ColorDownTo = 11565130
      Appearance.ColorHot = 16444643
      Appearance.ColorHotTo = 16444643
      Appearance.ColorMirror = clWhite
      Appearance.ColorMirrorTo = clWhite
      Appearance.ColorMirrorHot = 16444643
      Appearance.ColorMirrorHotTo = 16444643
      Appearance.ColorMirrorDown = 11565130
      Appearance.ColorMirrorDownTo = 11565130
      Appearance.ColorMirrorChecked = 13744549
      Appearance.ColorMirrorCheckedTo = 13744549
      Appearance.ColorMirrorDisabled = clWhite
      Appearance.ColorMirrorDisabledTo = clNone
      Appearance.GradientHot = ggVertical
      Appearance.GradientMirrorHot = ggVertical
      Appearance.GradientDown = ggVertical
      Appearance.GradientMirrorDown = ggVertical
      Appearance.GradientChecked = ggVertical
      Appearance.TextColorChecked = 3750459
      Appearance.TextColorDown = 2303013
      Appearance.TextColorHot = 2303013
      Appearance.TextColorDisabled = 13948116
      ExplicitLeft = 1118
    end
  end
  object Tnaftal: TUniTable
    TableName = 'Naftal'
    Connection = DM.UniConnection
    MasterSource = Form14.UniDataSource1
    MasterFields = 'Annee'
    DetailFields = 'Annee'
    Active = True
    AfterOpen = TnaftalAfterOpen
    BeforePost = TnaftalBeforePost
    AfterPost = TnaftalAfterPost
    AfterCancel = TnaftalAfterCancel
    AfterScroll = TnaftalAfterScroll
    OnCalcFields = TnaftalCalcFields
    OnNewRecord = TnaftalNewRecord
    Left = 40
    Top = 356
    ParamData = <
      item
        DataType = ftWideString
        Name = 'Annee'
        ParamType = ptInput
        Value = nil
      end>
    object TnaftalIDF: TIntegerField
      AutoGenerateValue = arAutoInc
      FieldName = 'IDF'
      ReadOnly = True
    end
    object TnaftalRefF: TWideStringField
      FieldName = 'RefF'
      Size = 255
    end
    object TnaftalDateFact: TDateTimeField
      FieldName = 'DateFact'
      DisplayFormat = 'dd/mm/yyyy'
      EditMask = '!99/99/0000;;_'
    end
    object TnaftalAnnee: TWideStringField
      FieldName = 'Annee'
      Size = 255
    end
    object TnaftalFournisseur: TWideStringField
      FieldName = 'Fournisseur'
      Size = 255
    end
    object TnaftalQGasoil: TFloatField
      FieldName = 'QGasoil'
      DisplayFormat = '#,##0.##'
      EditFormat = '0.##'
    end
    object TnaftalQEssence: TFloatField
      FieldName = 'QEssence'
      DisplayFormat = '#,##0.##'
      EditFormat = '0.##'
    end
    object TnaftalQSirgaz: TFloatField
      FieldName = 'QSirgaz'
      DisplayFormat = '#,##0.##'
      EditFormat = '0.##'
    end
    object TnaftalTGasoil: TFloatField
      FieldName = 'TGasoil'
      DisplayFormat = '#,##0.00'
    end
    object TnaftalTEssence: TFloatField
      FieldName = 'TEssence'
      DisplayFormat = '#,##0.00'
    end
    object TnaftalTSiirgaz: TFloatField
      FieldName = 'TSiirgaz'
      DisplayFormat = '#,##0.00'
    end
    object TnaftalTvente: TFloatField
      FieldName = 'Tvente'
      DisplayFormat = '#,##0.00'
    end
    object TnaftalTachat: TFloatField
      FieldName = 'Tachat'
      DisplayFormat = '#,##0.00'
    end
    object TnaftalBenefice: TFloatField
      FieldName = 'Benefice'
      DisplayFormat = '#,##0.00'
    end
    object TnaftalMois: TIntegerField
      FieldName = 'Mois'
    end
    object TnaftalPUGasoil: TFloatField
      FieldKind = fkCalculated
      FieldName = 'PUGasoil'
      DisplayFormat = '#,##0.00'
      Calculated = True
    end
    object TnaftalPUEssence: TFloatField
      FieldKind = fkCalculated
      FieldName = 'PUEssence'
      DisplayFormat = '#,##0.00'
      Calculated = True
    end
    object TnaftalPUSirgaz: TFloatField
      FieldKind = fkCalculated
      FieldName = 'PUSirgaz'
      DisplayFormat = '#,##0.00'
      Calculated = True
    end
  end
  object Dnaftal: TUniDataSource
    DataSet = Tnaftal
    OnDataChange = DnaftalDataChange
    Left = 65400
    Top = 464
  end
  object Tpp: TUniTable
    TableName = 'PPu'
    Connection = DM.UniCRef
    Active = True
    Left = 232
    Top = 356
    object TppID: TIntegerField
      AutoGenerateValue = arAutoInc
      FieldName = 'ID'
      ReadOnly = True
    end
    object Tppu: TWideStringField
      FieldName = 'PP'
      Size = 255
    end
    object TppPU: TFloatField
      FieldName = 'PU'
    end
  end
  object Dpp: TUniDataSource
    DataSet = Tpp
    Left = 232
    Top = 424
  end
  object Tlurifiants: TUniTable
    TableName = 'Naftal2'
    Connection = DM.UniConnection
    MasterSource = Form14.UniDataSource1
    MasterFields = 'Annee'
    DetailFields = 'Annee'
    Active = True
    AfterOpen = TlurifiantsAfterOpen
    BeforePost = TlurifiantsBeforePost
    AfterPost = TlurifiantsAfterPost
    AfterCancel = TlurifiantsAfterCancel
    AfterScroll = TlurifiantsAfterScroll
    OnNewRecord = TlurifiantsNewRecord
    Left = 90
    Top = 352
    ParamData = <
      item
        DataType = ftWideString
        Name = 'Annee'
        ParamType = ptInput
        Value = nil
      end>
    object TlurifiantsIDF: TIntegerField
      AutoGenerateValue = arAutoInc
      FieldName = 'IDF'
      ReadOnly = True
    end
    object TlurifiantsRefF: TWideStringField
      FieldName = 'RefF'
      Size = 255
    end
    object TlurifiantsDateFact: TDateTimeField
      FieldName = 'DateFact'
      EditMask = '!99/99/0000;;_'
    end
    object TlurifiantsMois: TIntegerField
      FieldName = 'Mois'
    end
    object TlurifiantsAnnee: TWideStringField
      FieldName = 'Annee'
      Size = 255
    end
    object TlurifiantsFournisseur: TWideStringField
      FieldName = 'Fournisseur'
      Size = 255
    end
    object TlurifiantsAchatHT: TFloatField
      FieldName = 'AchatHT'
      DisplayFormat = '#,##0.00'
      EditFormat = '0.##'
    end
    object TlurifiantsTVAachat: TFloatField
      FieldName = 'TVAachat'
      DisplayFormat = '#,##0.00'
      EditFormat = '0.##'
    end
    object TlurifiantsAchatTTC: TFloatField
      FieldName = 'AchatTTC'
      DisplayFormat = '#,##0.00'
    end
    object TlurifiantsVenteHT: TFloatField
      FieldName = 'VenteHT'
      DisplayFormat = '#,##0.00'
      EditFormat = '0.##'
    end
    object TlurifiantsTVAVente: TFloatField
      FieldName = 'TVAVente'
      DisplayFormat = '#,##0.00'
    end
    object TlurifiantsVenteTTC: TFloatField
      FieldName = 'VenteTTC'
      DisplayFormat = '#,##0.00'
    end
    object TlurifiantsBenefice: TFloatField
      FieldName = 'Benefice'
      DisplayFormat = '#,##0.00'
    end
    object TlurifiantsTachat: TFloatField
      FieldName = 'Tachat'
      DisplayFormat = '#,##0.00'
    end
    object TlurifiantsMarge: TFloatField
      FieldName = 'Marge'
      DisplayFormat = '#,##0.####'
    end
  end
  object Dlurifiants: TUniDataSource
    DataSet = Tlurifiants
    OnDataChange = DlurifiantsDataChange
    Left = 90
    Top = 408
  end
  object UniDataSource1: TUniDataSource
    Left = 138
    Top = 296
  end
  object Tprestation: TUniTable
    TableName = 'Naftal3'
    Connection = DM.UniConnection
    MasterSource = Form14.UniDataSource1
    MasterFields = 'Annee'
    DetailFields = 'Annee'
    Left = 178
    Top = 352
    ParamData = <
      item
        DataType = ftWideString
        Name = 'Annee'
        ParamType = ptInput
        Value = nil
      end>
    object TprestationIDP: TIntegerField
      FieldName = 'IDP'
      ReadOnly = True
    end
    object TprestationMois: TIntegerField
      FieldName = 'Mois'
    end
    object TprestationAnnee: TWideStringField
      FieldName = 'Annee'
      Size = 255
    end
    object TprestationCafetiriaCA: TFloatField
      FieldName = 'CafetiriaCA'
    end
    object TprestationCafetiriaTVA: TFloatField
      FieldName = 'CafetiriaTVA'
    end
    object TprestationRestaurantCA: TFloatField
      FieldName = 'RestaurantCA'
    end
    object TprestationRestaurantTVA: TFloatField
      FieldName = 'RestaurantTVA'
    end
    object TprestationLavageCA: TFloatField
      FieldName = 'LavageCA'
    end
    object TprestationLavageTVA: TFloatField
      FieldName = 'LavageTVA'
    end
    object TprestationTransportCA: TFloatField
      FieldName = 'TransportCA'
    end
    object TprestationTransportTVA: TFloatField
      FieldName = 'TransportTVA'
    end
    object TprestationPrestationCA: TFloatField
      FieldName = 'PrestationCA'
    end
    object TprestationPrestationTVA: TFloatField
      FieldName = 'PrestationTVA'
    end
  end
  object Dprestation: TUniDataSource
    DataSet = Tprestation
    Left = 162
    Top = 408
  end
end
