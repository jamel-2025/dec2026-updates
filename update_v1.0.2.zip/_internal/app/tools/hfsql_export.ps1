# Export des tables WinDev (HFSQL Classic .FIC) vers des fichiers JSON — Étape 1 de la génération massive
# (Delphi uBatchGen.btnDirectImportClick). Exécuté par le PowerShell 32 bits car le pilote ODBC HFSQL
# utilisé par l'application d'origine (wd240hfo.dll) est 32 bits.
# Les chaînes HFSQL sont en Windows-1252 : elles sont lues en octets puis décodées (DecodeFieldToStr).
param(
  [Parameter(Mandatory = $true)][string]$RepFic,
  [Parameter(Mandatory = $true)][string]$OutDir,
  [Parameter(Mandatory = $true)][string]$Tables,
  [string]$Driver = ''
)
$ErrorActionPreference = 'Stop'
if (-not $RepFic.EndsWith('\')) { $RepFic += '\' }

# FindHfsqlDriver : explicit -Driver, bundled copy, WinDev application folder (and its parent: the .fic often sit
# in a data sub-folder), installed PC SOFT ODBC drivers (any version), then the HFSQL driver registered in ODBC.
$scriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Definition }
$parent = Split-Path -Parent $RepFic.TrimEnd('\')
$dirs = @()
if ($scriptDir) { $dirs += Join-Path $scriptDir 'ODBC_HFSQL' }
$dirs += $RepFic
$dirs += Join-Path $RepFic 'ODBC_HFSQL'
if ($parent) { $dirs += @($parent, (Join-Path $parent 'ODBC_HFSQL')) }
foreach ($pf in @(${env:ProgramFiles(x86)}, $env:ProgramFiles, ${env:CommonProgramFiles(x86)}, $env:CommonProgramFiles)) {
  if ($pf) {
    $pcSoftDir = Join-Path $pf 'PC SOFT'
    if (Test-Path $pcSoftDir) {
      $dirs += @(Get-ChildItem -Path $pcSoftDir -ErrorAction SilentlyContinue |
          Where-Object { $_.PSIsContainer } |
          ForEach-Object { @($_.FullName, (Join-Path $_.FullName 'ODBC\Win32x86')) })
    }
    $commonSoftDir = Join-Path $pf 'Common Files\PC SOFT'
    if (Test-Path $commonSoftDir) {
      $dirs += @(Get-ChildItem -Path $commonSoftDir -ErrorAction SilentlyContinue |
          Where-Object { $_.PSIsContainer } |
          ForEach-Object { Join-Path $_.FullName 'ODBC\Win32x86' })
    }
  }
}
$candidates = @()
if ($Driver -and (Test-Path $Driver)) { $candidates += $Driver }
foreach ($d in $dirs) {
  if ($d -and (Test-Path $d)) {
    $candidates += @(Get-ChildItem -Path $d -Filter 'wd*hfo.dll' -ErrorAction SilentlyContinue |
        Where-Object { -not $_.PSIsContainer } |
        Sort-Object { $_.Name -ne 'wd240hfo.dll' } | ForEach-Object { $_.FullName })
  }
}
if (-not $candidates) {
  # pilote HFSQL déjà installé sur le poste (ODBC 32 bits)
  Get-ChildItem 'HKLM:\SOFTWARE\ODBC\ODBCINST.INI' -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match 'HFSQL|Hyper ?File' } |
    ForEach-Object { $dv = (Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue).Driver; if ($dv -and (Test-Path $dv)) { $candidates += $dv } }
}
if (-not $candidates) { Write-Output "ERREUR|Pilote ODBC HFSQL (wd240hfo.dll) introuvable : copiez wd240hfo.dll (dossier de l'application WinDev) dans $RepFic"; exit 2 }
$dll = $candidates[0]

# EnsureOdbcDSN (source de données utilisateur, comme l'application Delphi)
$dsn = 'DEC2026_HFSQL'
$key = "HKCU:\Software\ODBC\ODBC.INI\$dsn"
New-Item -Path $key -Force | Out-Null
Set-ItemProperty -Path $key -Name Driver -Value $dll
Set-ItemProperty -Path $key -Name RepFic -Value $RepFic
Set-ItemProperty -Path $key -Name IntegrityCheck -Value '0'
Set-ItemProperty -Path $key -Name PWDXX -Value ''
New-Item -Path 'HKCU:\Software\ODBC\ODBC.INI\ODBC Data Sources' -Force | Out-Null
Set-ItemProperty -Path 'HKCU:\Software\ODBC\ODBC.INI\ODBC Data Sources' -Name $dsn -Value 'HFSQL'
Write-Output "PILOTE|$dll"

$enc = [Text.Encoding]::GetEncoding(1252)
$utf8 = New-Object Text.UTF8Encoding($false)
$c = New-Object System.Data.Odbc.OdbcConnection("DSN=$dsn")
$c.Open()
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function J([object]$v) {
  if ($null -eq $v) { return 'null' }
  if ($v -is [byte[]]) { return 'null' }   # binary (photo…): skipped like Delphi's TBlobField
  if ($v -is [bool]) { if ($v) { return '1' } else { return '0' } }
  if ($v -is [datetime]) { if ($v.Year -lt 1901) { return 'null' }; return '"' + $v.ToString('yyyy-MM-ddTHH:mm:ss') + '"' }
  if ($v -is [int] -or $v -is [long] -or $v -is [int16] -or $v -is [byte] -or $v -is [uint32]) { return [string]$v }
  if ($v -is [double] -or $v -is [single] -or $v -is [decimal]) { return ([double]$v).ToString('R', [Globalization.CultureInfo]::InvariantCulture) }
  $s = [string]$v
  $s = $s.Replace('\', '\\').Replace('"', '\"').Replace("`r", '\r').Replace("`n", '\n').Replace("`t", '\t')
  $s = [regex]::Replace($s, '[\x00-\x1f]', '')
  return '"' + $s + '"'
}

foreach ($t in $Tables.Split(',')) {
  $t = $t.Trim(); if (-not $t) { continue }
  if (-not ((Test-Path (Join-Path $RepFic "$t.fic")) -or (Test-Path (Join-Path $RepFic "$t.FIC")))) { Write-Output "ABSENT|$t"; continue }
  try {
    $cmd = $c.CreateCommand(); $cmd.CommandText = "SELECT * FROM $t"
    $r = $cmd.ExecuteReader()
    $cols = @(); $isStr = @()
    for ($i = 0; $i -lt $r.FieldCount; $i++) { $cols += (J $r.GetName($i)); $isStr += ($r.GetFieldType($i) -eq [string]) }
    $w = New-Object IO.StreamWriter((Join-Path $OutDir "$t.jsonl"), $false, $utf8)
    $w.WriteLine('[' + ($cols -join ',') + ']')
    $n = 0; $buf = New-Object byte[] 65536
    while ($r.Read()) {
      $vals = New-Object string[] $r.FieldCount
      for ($i = 0; $i -lt $r.FieldCount; $i++) {
        if ($isStr[$i]) {
          # raw bytes first (a prior IsDBNull/GetValue would cache the mis-decoded string)
          try {
            $len = $r.GetBytes($i, 0, $buf, 0, $buf.Length)
            $vals[$i] = J ($enc.GetString($buf, 0, [int]$len).TrimEnd([char]0).TrimEnd())
          } catch { $vals[$i] = 'null' }
          continue
        }
        if ($r.IsDBNull($i)) { $vals[$i] = 'null' } else { $vals[$i] = J ($r.GetValue($i)) }
      }
      $w.WriteLine('[' + ($vals -join ',') + ']'); $n++
    }
    $w.Close(); $r.Close()
    Write-Output "OK|$t|$n"
  } catch { Write-Output ("ERREUR|$t|" + $_.Exception.Message) }
}
$c.Close()
