"""Lotissement — Delphi uMain (cartes Lotissements / Lots), uForm3_Lotis (étude), uForm4_Lotis (lot),
uForm7_Lotis / uForm17_Lotis (versements), uForm11 (situation globale), uForm12 (versements),
uForm13 (créances), uForm8 (situation annuelle / TCR), uImportLotis (import Excel), Unit36.frxReport2.
Tables: Lotissement, Lots (Idetude → Lotissement.ID), VersClients (IDclient → Lots.ID).

Étude (BSClick / BcalcClick), per m² of « superficie utile » S3:
  total viabilisation = sous-traitance + BET + électricité + gaz + autres;
  superficie à vendre = parties communes + utile; superficie totale = réservée + communes + utile;
  valeur après viabilisation = terrain + viabilisation; coût de revient /m² = valeur / S3;
  différence = prix de cession /m² − coût /m²  (= base TVA, TVA sur la marge);
  droits TVA = base × taux TVA; base TAP = prix − TVA (TAP supprimée : taux 0, masquée);
  base IRG/IBS = base TAP − coût; droits = barème IRG (P PH, SNC) ou taux IBS (26 % par défaut);
  colonnes « lotissement » = valeurs /m² × S3.
Lot (RzButton1/Button5): prix de cession /m² = prix spécial du lot sinon prix de l’étude;
  base TVA = prix du lot − coût de revient du lot; total droits = droits TVA;
  chiffre d’affaires (BaseTapLot) = prix du lot − TVA; reste = prix du lot − versements.
Logical choices: unified lot formula (Delphi's « prix général » path used the study's
difference, identical in value); deletions cascade to lots / payments; lot numbers unique per study.
"""
from __future__ import annotations

import base64
import csv
import io

from fastapi import HTTPException

from ..core.db import connect
from . import dates, dossiers
from .g50 import Conflict, G50Error, _next_id, _num

MODES = ["Espèce", "Chèque Bancaire", "Versement Bancaire"]
IRG_FORMS = {"P PH", "SNC"}


def irg(base: float) -> float:
    """uCustom_Lotis.IRG — barème appliqué par le lotissement."""
    if base <= 240000:
        return 10000
    if base <= 480000:
        return (base - 240000) * 0.23
    if base <= 960000:
        return (base - 480000) * 0.27 + 55200
    if base <= 1920000:
        return (base - 960000) * 0.30 + 184800
    if base <= 3840000:
        return (base - 1920000) * 0.33 + 472800
    return (base - 3840000) * 0.35 + 1106400


def _fj(code: str) -> str:
    fj = str(dossiers.societe(code).get("fj") or "").strip().upper()
    return {"PERSONNE PHYSIQUE": "P PH"}.get(fj, fj)


def _r(v: float) -> float:
    return round(v + 0.0, 2)


# ------------------------------------------------------------------ études (Lotissement)
def _calc_study(d: dict) -> dict:
    n = lambda k: _num(d.get(k))
    s3 = n("SupUtile")
    if s3 <= 0:
        raise G50Error("Veuillez saisir une « Superficie utile » supérieure à 0 avant le calcul.")
    vb = {k: n(k) for k in ("soustraitance", "ServicesBET", "TrvxElec", "TrvxGaz", "Autres")}
    out = dict(d)
    s7 = sum(vb.values())
    s8 = n("PrixchatTerrain") + s7
    s9 = s8 / s3
    s10 = n("PCessionUniTTC")
    ttva = n("TTVA") if d.get("TTVA") not in (None, "") else 19
    bareme = str(d.get("fJ") or "").upper() in IRG_FORMS
    taux_bic = 0.0 if bareme else (n("TauxBic") if d.get("TauxBic") not in (None, "", "Bareme") else 26)
    s11 = s10 - s9
    s15 = s11 * ttva / 100
    s14 = s10 - s15
    s17 = s14 - s9
    s18 = round(irg(s17)) if bareme else round(s17 * taux_bic / 100)
    s26 = s17 * s3
    s27 = round(irg(s26)) if bareme else round(s26 * taux_bic / 100)
    label = "IRG" if bareme else "IBS"
    out.update({
        "CoutsTravaux": _r(s7), "SupTotaleVendre": n("SupPconununes") + s3, "SupTotale": n("SupeReservee") + n("SupPconununes") + s3,
        "Tvaleurapresviabilisation": _r(s8), "CoutrevnentUni": _r(s9), "PCessionUniTTC": _r(s10), "TTVA": ttva, "TTAP": 0,
        "DifferenceTTC": _r(s11), "DifferenceHT": _r(s11), "BaseimposableTVA": _r(s11), "DroitTVA": _r(s15),
        "BaseimposableTAP": _r(s14), "DroitTAP": 0, "BaseBIC": _r(s17), "DroitsBIC": s18, "TotalDroitsM": _r(s15 + s18),
        "DifferenceTTCL": _r(s11 * s3), "DifferenceHTL": _r(s11 * s3), "BaseTVAL": _r(s11 * s3), "DroitTVAL": _r(s15 * s3),
        "BaseTAPL": _r(s14 * s3), "DroitTAPL": 0, "BaseBICL": _r(s26), "DroitsBICL": s27, "TotalDroitL": _r(s15 * s3 + s27),
        "TauxBic": "Bareme" if bareme else str(int(taux_bic) if taux_bic == int(taux_bic) else taux_bic),
        "TBIC": f"Taux {label}", "CBaseBIC": f"Base {label}", "CDroitsBIC": f"Droits {label}",
        "CBaseBICL": f"Base {label}", "CDroitsBICL": f"Droits {label}",
        "PrixchatTerrainM2": _r(n("PrixchatTerrain") / s3), "CoutsTravauxM": _r(s7 / s3),
        **{f"{k}M2": _r(v / s3) for k, v in vb.items()},
    })
    return out


STUDY_INPUTS = ("Lotisseur", "Adresse", "SupeReservee", "SupPconununes", "SupUtile", "PrixchatTerrain", "soustraitance",
                "ServicesBET", "TrvxElec", "TrvxGaz", "Autres", "PCessionUniTTC", "TTVA", "TauxBic", "fJ")


def studies(code: str, q: str = "") -> list[dict]:
    sql, args = "SELECT * FROM Lotissement", []
    if q:
        sql += ' WHERE "Lotisseur" LIKE ? OR "Adresse" LIKE ?'
        args = [f"%{q}%", f"%{q}%"]
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(sql + ' ORDER BY "ID"', args)]
        for r in rows:
            r["_id"] = r["ID"]
            r["nb_lots"], r["vendus"], r["ventes"], r["reste"] = c.execute(
                'SELECT COUNT(*), SUM(CASE WHEN "DateActe" IS NOT NULL AND "DateActe" <> \'\' THEN 1 ELSE 0 END), '
                'COALESCE(SUM("PcessionLot"), 0), COALESCE(SUM("ResteU"), 0) FROM Lots WHERE "Idetude" = ?', (r["ID"],)).fetchone()
    return rows


def defaults(code: str) -> dict:
    """uForm3_Lotis.FormShow — lotisseur = raison sociale, forme juridique of the dossier."""
    s = dossiers.societe(code)
    fj = _fj(code)
    return {"Lotisseur": s.get("rs") or "", "fJ": fj, "TTVA": 19, "TauxBic": "Bareme" if fj in IRG_FORMS else "26"}


def study(code: str, lid: int) -> dict:
    with connect(code) as c:
        r = c.execute('SELECT * FROM Lotissement WHERE "ID" = ?', (lid,)).fetchone()
    if r is None:
        raise HTTPException(404, "Lotissement introuvable")
    return {**dict(r), "_id": lid}


def save_study(code: str, data: dict, lid: int | None = None) -> dict:
    if not str(data.get("Adresse") or "").strip():
        raise G50Error("Le champ « Adresse de lotissement » est obligatoire.")
    base = defaults(code)
    values = {k: data.get(k, base.get(k)) for k in STUDY_INPUTS}
    values["fJ"] = values.get("fJ") or base["fJ"]
    values = _calc_study(values)
    old_price = _num(study(code, lid).get("PCessionUniTTC")) if lid is not None else None
    with connect(code) as c:
        cols = {r[1] for r in c.execute("PRAGMA table_info(Lotissement)")}
        values = {k: v for k, v in values.items() if k in cols}
        if lid is None:
            values["ID"] = lid = _next_id(c, "Lotissement", "ID")
            c.execute(f'INSERT INTO Lotissement ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        else:
            if not c.execute(f'UPDATE Lotissement SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} WHERE "ID" = ?',
                             (*values.values(), lid)).rowcount:
                raise HTTPException(404, "Lotissement introuvable")
            # the study's prices feed the lots: recompute them
            st = dict(c.execute('SELECT * FROM Lotissement WHERE "ID" = ?', (lid,)).fetchone())
            for lot in [dict(x) for x in c.execute('SELECT * FROM Lots WHERE "Idetude" = ?', (lid,))]:
                if _num(lot.get("PCessionU")) == old_price:      # sold at the general price: follow the study
                    lot["PCessionU"] = None
                _write_lot(c, st, lot, lot["ID"])
    return study(code, lid)


def delete_study(code: str, lid: int) -> None:
    with connect(code) as c:
        c.execute('DELETE FROM VersClients WHERE "IDclient" IN (SELECT "ID" FROM Lots WHERE "Idetude" = ?)', (lid,))
        c.execute('DELETE FROM Lots WHERE "Idetude" = ?', (lid,))
        if not c.execute('DELETE FROM Lotissement WHERE "ID" = ?', (lid,)).rowcount:
            raise HTTPException(404, "Lotissement introuvable")


# ------------------------------------------------------------------ lots
def _calc_lot(st: dict, d: dict, verse: float) -> dict:
    sup = _num(d.get("SupLot"))
    pvu = _num(d.get("PCessionU")) or _num(st.get("PCessionUniTTC"))
    cu = _num(st.get("CoutrevnentUni"))
    ttva = _num(d.get("TTVA")) if d.get("TTVA") not in (None, "") else _num(st.get("TTVA"))
    pv, cout = pvu * sup, cu * sup
    base = pv - cout
    tva = base * ttva / 100
    return {"PCessionU": _r(pvu), "PcessionLot": _r(pv), "CoutrevnentU": _r(cu), "CoutrevnentLot": _r(cout),
            "DifferenceTTC": _r(base), "DifferenceHT": _r(base - tva), "BaseTvaLot": _r(base), "DroitsTvaLot": _r(tva),
            "TTVA": ttva, "TTAP": 0, "BaseTapLot": _r(pv - tva), "DroitsTapLot": 0, "TotalDroits": _r(tva),
            "TVersemU": _r(verse), "ResteU": _r(pv - verse)}


def _write_lot(c, st: dict, d: dict, lot_id: int | None) -> int:
    verse = _num(c.execute('SELECT SUM("Mtvers") FROM VersClients WHERE "IDclient" = ?', (lot_id,)).fetchone()[0]) if lot_id else 0.0
    acte = dates.parse(dates.to_storage(d.get("DateActe"))) if d.get("DateActe") else None
    g50 = str(d.get("G50") or "").strip()
    if g50 and not (len(g50) == 7 and g50[2] == "/" and g50[:2].isdigit() and g50[3:].isdigit() and 1 <= int(g50[:2]) <= 12):
        raise G50Error("G50 : saisir le mois de la déclaration au format mm/aaaa")
    values = {"Nlot": int(_num(d.get("Nlot"))), "Nfacade": int(_num(d.get("Nfacade"))), "SupLot": _num(d.get("SupLot")),
              "Acquereur": str(d.get("Acquereur") or "").strip(), "Idetude": st["ID"],
              "DateActe": dates.to_storage(acte) if acte else None, "G50": g50 or None,
              "G50mois": g50[:2] if g50 else None, "G50annee": g50[3:] if g50 else None,
              "CAmois": f"{acte.month:02d}" if acte else None, "CAannee": str(acte.year) if acte else None,
              **_calc_lot(st, {**d, "PCessionU": d.get("PCessionU")}, verse)}
    if lot_id is None:
        values["ID"] = lot_id = _next_id(c, "Lots", "ID")
        c.execute(f'INSERT INTO Lots ({", ".join(chr(34) + k + chr(34) for k in values)}) VALUES ({", ".join("?" for _ in values)})',
                  tuple(values.values()))
    elif not c.execute(f'UPDATE Lots SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} WHERE "ID" = ?',
                       (*values.values(), lot_id)).rowcount:
        raise HTTPException(404, "Lot introuvable")
    return lot_id


def lots(code: str, lid: int, q: str = "") -> dict:
    st = study(code, lid)
    sql, args = 'SELECT * FROM Lots WHERE "Idetude" = ?', [lid]
    if q:
        sql += ' AND (CAST("Nlot" AS TEXT) LIKE ? OR "Acquereur" LIKE ?)'
        args += [f"%{q}%", f"%{q}%"]
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(sql + ' ORDER BY "Nlot"', args)]
    for r in rows:
        r["_id"] = r["ID"]
        r["date_display"] = dates.to_display(r.get("DateActe"))
    keys = ("SupLot", "PcessionLot", "CoutrevnentLot", "BaseTvaLot", "DroitsTvaLot", "BaseTapLot", "TotalDroits", "TVersemU", "ResteU")
    return {"study": st, "items": rows, "totals": {k: sum(_num(r.get(k)) for r in rows) for k in keys}, "modes": MODES}


def save_lot(code: str, lid: int, data: dict, lot_id: int | None = None) -> dict:
    if not _num(data.get("Nlot")):
        raise G50Error("Veuillez saisir le numéro du lot")
    if _num(data.get("SupLot")) <= 0:
        raise G50Error("Veuillez saisir la superficie du lot")
    st = study(code, lid)
    if not _num(st.get("CoutrevnentUni")):
        raise G50Error("Calculez d’abord le coût de revient de l’étude du lotissement")
    with connect(code) as c:
        dup = c.execute('SELECT "ID" FROM Lots WHERE "Idetude" = ? AND "Nlot" = ?', (lid, int(_num(data["Nlot"])))).fetchone()
        if dup and dup[0] != lot_id:
            raise Conflict(f"Le lot N° {int(_num(data['Nlot']))} existe déjà dans ce lotissement")
        lot_id = _write_lot(c, st, data, lot_id)
    return lot_detail(code, lot_id)


def lot_detail(code: str, lot_id: int) -> dict:
    with connect(code) as c:
        r = c.execute('SELECT * FROM Lots WHERE "ID" = ?', (lot_id,)).fetchone()
        if r is None:
            raise HTTPException(404, "Lot introuvable")
        vers = [dict(v) for v in c.execute('SELECT * FROM VersClients WHERE "IDclient" = ? ORDER BY "DateVer", "IDvers"', (lot_id,))]
    for v in vers:
        v["_id"] = v["IDvers"]
        v["date_display"] = dates.to_display(v.get("DateVer"))
    return {**dict(r), "_id": lot_id, "date_display": dates.to_display(r["DateActe"]), "versements": vers}


def delete_lot(code: str, lot_id: int) -> None:
    with connect(code) as c:
        c.execute('DELETE FROM VersClients WHERE "IDclient" = ?', (lot_id,))
        if not c.execute('DELETE FROM Lots WHERE "ID" = ?', (lot_id,)).rowcount:
            raise HTTPException(404, "Lot introuvable")


# ------------------------------------------------------------------ versements (VersClients)
def _sync_lot(c, lot_id: int) -> None:
    """uForm17_Lotis.BcalcClick — total des versements et reste à payer du lot."""
    verse = _num(c.execute('SELECT SUM("Mtvers") FROM VersClients WHERE "IDclient" = ?', (lot_id,)).fetchone()[0])
    c.execute('UPDATE Lots SET "TVersemU" = ?, "ResteU" = COALESCE("PcessionLot", 0) - ? WHERE "ID" = ?', (verse, verse, lot_id))


def save_versement(code: str, lot_id: int, data: dict, vid: int | None = None) -> dict:
    if not _num(data.get("Mtvers")):
        raise G50Error("Veuillez saisir le montant versé")
    if not data.get("DateVer"):
        raise G50Error("Veuillez saisir la date du versement")
    if data.get("ModeVers") not in MODES:
        raise G50Error("Veuillez sélectionner le mode de versement")
    d = dates.parse(dates.to_storage(data["DateVer"]))
    with connect(code) as c:
        if c.execute('SELECT 1 FROM Lots WHERE "ID" = ?', (lot_id,)).fetchone() is None:
            raise HTTPException(404, "Lot introuvable")
        values = {"IDclient": lot_id, "Mtvers": int(round(_num(data["Mtvers"]))), "DateVer": dates.to_storage(d),
                  "ModeVers": data["ModeVers"], "Nmois": d.month, "Annee": d.year}
        if vid is None:
            values["IDvers"] = _next_id(c, "VersClients", "IDvers")
            values["NumVer"] = c.execute('SELECT COUNT(*) FROM VersClients WHERE "IDclient" = ?', (lot_id,)).fetchone()[0] + 1
            c.execute(f'INSERT INTO VersClients ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE VersClients SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} '
                           'WHERE "IDvers" = ? AND "IDclient" = ?', (*values.values(), vid, lot_id)).rowcount:
            raise HTTPException(404, "Versement introuvable")
        _sync_lot(c, lot_id)
    return lot_detail(code, lot_id)


def delete_versement(code: str, lot_id: int, vid: int) -> dict:
    with connect(code) as c:
        if not c.execute('DELETE FROM VersClients WHERE "IDvers" = ? AND "IDclient" = ?', (vid, lot_id)).rowcount:
            raise HTTPException(404, "Versement introuvable")
        _sync_lot(c, lot_id)
    return lot_detail(code, lot_id)


# ------------------------------------------------------------------ situations (Qversements, Qcreance, QTcr)
def versements(code: str, lid: int) -> list[dict]:
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(
            'SELECT l."Nlot", l."Acquereur", v."Mtvers", v."DateVer", v."ModeVers", v."IDvers" AS _id FROM VersClients v '
            'JOIN Lots l ON v."IDclient" = l."ID" WHERE l."Idetude" = ? ORDER BY v."DateVer", v."IDvers"', (lid,))]
    for r in rows:
        r["date_display"] = dates.to_display(r.get("DateVer"))
    return rows


def creances(code: str, lid: int) -> list[dict]:
    with connect(code) as c:
        return [dict(r) | {"_id": r["Nlot"]} for r in c.execute(
            'SELECT "Nlot", "SupLot", "Acquereur", "PcessionLot", "TVersemU", "ResteU" FROM Lots '
            'WHERE "Idetude" = ? AND "ResteU" > 0 ORDER BY "Nlot"', (lid,))]


def tcr(code: str, lid: int) -> list[dict]:
    """QTcr — compte de résultat par année de l’acte; droits IRG/IBS on the result (Dirg, Tdroits)."""
    st = study(code, lid)
    bareme = str(st.get("TauxBic") or "") == "Bareme"
    taux = 0 if bareme else _num(st.get("TauxBic"))
    m2 = {k: _num(st.get(k)) for k in ("PrixchatTerrainM2", "soustraitanceM2", "ServicesBETM2", "TrvxElecM2", "TrvxGazM2", "AutresM2")}
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(
            'SELECT "CAannee", SUM("SupLot") AS Tsuperficie, COUNT("Nlot") AS NbreLots, SUM("PcessionLot") AS PCessionTTC, '
            'SUM("CoutrevnentLot") AS CoutRevnent, SUM("BaseTapLot") AS CA, SUM("DroitsTapLot") AS TDroitsTAP, '
            'SUM("BaseTvaLot") AS BaseTva, SUM("DroitsTvaLot") AS TDroitsTVA FROM Lots '
            'WHERE "Idetude" = ? AND "CAannee" > \'0\' GROUP BY "CAannee" ORDER BY "CAannee"', (lid,))]
    for r in rows:
        sup = _num(r["Tsuperficie"])
        r.update({"Annee": r["CAannee"], "ValeurTerrain": sup * m2["PrixchatTerrainM2"], "Soustraitance": sup * m2["soustraitanceM2"],
                  "ServiceBET": sup * m2["ServicesBETM2"], "TrElect": sup * m2["TrvxElecM2"], "TrGaz": sup * m2["TrvxGazM2"],
                  "AutresTrv": sup * m2["AutresM2"]})
        r["Tcharges"] = sum(r[k] for k in ("ValeurTerrain", "ServiceBET", "TrElect", "TrGaz", "AutresTrv", "Soustraitance"))
        r["resultat"] = _num(r["CA"]) - r["Tcharges"]
        r["Dirg"] = round(irg(r["resultat"])) if bareme else round(max(r["resultat"], 0) * taux / 100)
        r["Tdroits"] = round(_num(r["TDroitsTVA"]) + r["Dirg"])
        r["IRG"] = r["Dirg"]
        r["_id"] = r["CAannee"]
        r["impot"] = "IRG" if bareme else "IBS"
    return rows


# ------------------------------------------------------------------ import Excel (uImportLotis)
def read_import(filename: str, content_b64: str) -> list[dict]:
    """Columns: N° lot, N° façades, acquéreur, superficie (first row = headers)."""
    raw = base64.b64decode(content_b64)
    if filename.lower().endswith((".xlsx", ".xlsm")):
        from openpyxl import load_workbook
        ws = load_workbook(io.BytesIO(raw), read_only=True, data_only=True).active
        table = [list(r) for r in ws.iter_rows(values_only=True)]
    elif filename.lower().endswith((".csv", ".txt")):
        text = raw.decode("utf-8-sig", errors="replace")
        table = list(csv.reader(io.StringIO(text), delimiter=";" if text.count(";") > text.count(",") else ","))
    else:
        raise G50Error("Format non pris en charge : utilisez un fichier Excel (.xlsx) ou CSV")
    out = []
    for row in table[1:]:
        row = (list(row) + [None] * 4)[:4]
        if all(v in (None, "") for v in row):
            continue
        out.append({"Nlot": int(_num(row[0])), "Nfacade": int(_num(row[1])), "Acquereur": str(row[2] or "").strip(),
                    "SupLot": _num(str(row[3]).replace(",", ".") if isinstance(row[3], str) else row[3])})
    if not out:
        raise G50Error("Le fichier ne contient aucune ligne à importer")
    return out


def import_lots(code: str, lid: int, rows: list[dict]) -> dict:
    st = study(code, lid)
    if not _num(st.get("CoutrevnentUni")):
        raise G50Error("Calculez d’abord le coût de revient de l’étude du lotissement")
    added, skipped = 0, []
    with connect(code) as c:
        existing = {r[0] for r in c.execute('SELECT "Nlot" FROM Lots WHERE "Idetude" = ?', (lid,))}
        for r in rows:
            if not r.get("Nlot") or _num(r.get("SupLot")) <= 0 or r["Nlot"] in existing:
                skipped.append(r.get("Nlot"))
                continue
            _write_lot(c, st, r, None)
            existing.add(r["Nlot"])
            added += 1
    return {"added": added, "skipped": skipped}
