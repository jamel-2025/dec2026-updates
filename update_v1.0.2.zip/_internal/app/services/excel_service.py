"""Service d'inspection et d'importation de fichiers Excel (tableurs) pour le Dossier Numérique et les Ventes.
Permet la prévisualisation immédiate et l'importation de masse avec contrôle d'intégrité et anti-doublon.
"""
from __future__ import annotations

import csv
import io
from pathlib import Path
from typing import Any

import openpyxl

from ..core.db import connect
from . import dates, ref, tiers, ventes
from .g50 import G50Error, _num


def inspect_excel_file(file_bytes: bytes, filename: str) -> dict[str, Any]:
    """Inspecte un fichier Excel ou CSV et retourne ses feuilles, en-têtes et lignes échantillons."""
    ext = Path(filename).suffix.lower()
    sheets_info = []
    is_xlsx_zip = file_bytes[:4] == b"PK\x03\x04"

    if ext in (".xlsx", ".xlsm") or is_xlsx_zip:
        try:
            wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True, read_only=True)
            for sname in wb.sheetnames:
                ws = wb[sname]
                all_rows = []
                for r_idx, row in enumerate(ws.iter_rows(values_only=True)):
                    if r_idx > 100:  # Limiter l'échantillon à 100 lignes
                        break
                    row_vals = [str(v).strip() if v is not None else "" for v in row]
                    if any(row_vals):
                        all_rows.append(row_vals)

                headers = all_rows[0] if all_rows else []
                preview_rows = all_rows[1:16] if len(all_rows) > 1 else []

                sheets_info.append({
                    "sheet_name": sname,
                    "headers": headers,
                    "preview_rows": preview_rows,
                    "total_sample_rows": len(all_rows),
                })
            ext = ".xlsx"
        except Exception:
            pass

    if not sheets_info and (ext == ".csv" or not is_xlsx_zip):
        try:
            text = file_bytes.decode("utf-8")
        except UnicodeDecodeError:
            text = file_bytes.decode("latin-1")

        dialect = csv.Sniffer().sniff(text[:2048]) if len(text) > 20 else csv.excel
        reader = csv.reader(io.StringIO(text), dialect)
        all_rows = []
        for r_idx, row in enumerate(reader):
            if r_idx > 100:
                break
            if any(row):
                all_rows.append([c.strip() for c in row])

        headers = all_rows[0] if all_rows else []
        preview_rows = all_rows[1:16] if len(all_rows) > 1 else []

        sheets_info.append({
            "sheet_name": "CSV Data",
            "headers": headers,
            "preview_rows": preview_rows,
            "total_sample_rows": len(all_rows),
        })

    return {
        "filename": filename,
        "format": ext,
        "sheets": sheets_info,
    }


def import_excel_to_ventes(code: str, file_bytes: bytes, filename: str, mapping: dict[str, Any]) -> dict[str, Any]:
    """Importe les lignes d'un fichier Excel dans les Factures de Vente avec respect des règles de gestion."""
    sheet_name = mapping.get("sheet_name")
    col_date = int(mapping.get("col_date", 0))
    col_num = int(mapping.get("col_num", 1))
    col_client = int(mapping.get("col_client", 2))
    col_ht = int(mapping.get("col_ht", 3))
    col_tva = int(mapping.get("col_tva", -1))  # -1 = utiliser taux par défaut
    taux_defaut = int(mapping.get("taux_defaut", 19))
    has_header = bool(mapping.get("has_header", True))

    ext = Path(filename).suffix.lower()
    is_xlsx_zip = file_bytes[:4] == b"PK\x03\x04"
    raw_rows = []

    if ext in (".xlsx", ".xlsm") or is_xlsx_zip:
        try:
            wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
            ws = wb[sheet_name] if sheet_name and sheet_name in wb.sheetnames else wb.active
            for row in ws.iter_rows(values_only=True):
                vals = [v if v is not None else "" for v in row]
                if any(str(v).strip() for v in vals):
                    raw_rows.append(vals)
        except Exception:
            pass
    if not raw_rows and (ext == ".csv" or not is_xlsx_zip):
        try:
            text = file_bytes.decode("utf-8")
        except UnicodeDecodeError:
            text = file_bytes.decode("latin-1")
        dialect = csv.Sniffer().sniff(text[:2048]) if len(text) > 20 else csv.excel
        reader = csv.reader(io.StringIO(text), dialect)
        for row in reader:
            if any(c.strip() for c in row):
                raw_rows.append(row)

    if has_header and raw_rows:
        raw_rows = raw_rows[1:]

    succes = 0
    doublons = 0
    erreurs = []

    # Cache clients existants pour association rapide
    with connect(code) as c:
        existing_clients = {
            str(r[1]).strip().lower(): r[0]
            for r in c.execute("SELECT IDclientvente, rs FROM ClientrVentes").fetchall()
        }

    for row_idx, r in enumerate(raw_rows, start=2 if has_header else 1):
        try:
            val_date = str(r[col_date]).strip() if col_date < len(r) else ""
            val_num = str(r[col_num]).strip() if col_num < len(r) else ""
            val_client = str(r[col_client]).strip() if col_client < len(r) else ""
            val_ht = _num(r[col_ht]) if col_ht < len(r) else 0.0

            if col_tva >= 0 and col_tva < len(r) and str(r[col_tva]).strip():
                val_taux = int(_num(r[col_tva]))
            else:
                val_taux = taux_defaut

            if not val_num or not val_client or val_ht <= 0:
                continue

            # Traitement de la date
            # Peut être datetime openpyxl ou string jj/mm/aaaa ou aaaa-mm-jj
            if hasattr(r[col_date], "strftime"):
                date_display = r[col_date].strftime("%d/%m/%Y")
            else:
                s_d = str(val_date).replace(".", "/").replace("-", "/")
                parts = s_d.split("/")
                if len(parts) == 3 and len(parts[0]) == 4:  # AAAA/MM/JJ
                    date_display = f"{parts[2].zfill(2)}/{parts[1].zfill(2)}/{parts[0]}"
                elif len(parts) == 3:
                    date_display = f"{parts[0].zfill(2)}/{parts[1].zfill(2)}/{parts[2]}"
                else:
                    date_display = dates.to_display(dates.now_iso())

            # Résoudre ID client ou créer automatiquement
            client_key = val_client.lower()
            id_client = existing_clients.get(client_key)
            if not id_client:
                # Créer le client dans ClientrVentes
                new_c = tiers.create_item(code, "clients", {"rs": val_client})
                id_client = new_c["_id"]
                existing_clients[client_key] = id_client

            body = {
                "nfacture": val_num,
                "datrfature": date_display,
                "ClientsVente": val_client,
                "IDClentventes": id_client,
                "ht": val_ht,
                "TauxTva": val_taux,
            }

            try:
                ventes.save(code, body)
                succes += 1
            except Exception as ex:
                msg = str(ex)
                if "déjà saisie" in msg.lower() or "conflict" in msg.lower():
                    doublons += 1
                else:
                    erreurs.append(f"Ligne {row_idx} ({val_num}) : {msg}")

        except Exception as e:
            erreurs.append(f"Ligne {row_idx} : {str(e)}")

    return {
        "succes": succes,
        "doublons": doublons,
        "erreurs": erreurs[:20],
        "total_traite": len(raw_rows),
    }
