"""Sauvegarde et restauration — Delphi Unit1 (Form1).

Delphi: « Sauvegarder » zips the whole Dossiers folder to SauvDDMMYYYY.zip and keeps a history
(name, path, date, size); « Restaurer » extracts a chosen archive over the Dossiers folder after
confirmation, then restarts the application.
Web version (local-first): archives live in data/backups (the history is that folder);
each dossier database is copied with the SQLite backup API so the copy is consistent while the
server runs. Logical safeguards: archive entries are validated (<code>/G50.sqlite only, no path
traversal), a safety backup is taken before every restore, stale WAL/SHM files are removed.
"""
from __future__ import annotations

import base64
import io
import re
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from ..core import config
from .g50 import G50Error

ENTRY = re.compile(r"^([A-Za-z0-9_-]{1,40})/" + re.escape(config.DB_FILENAME) + r"$")
NAME = re.compile(r"^[A-Za-z0-9_.-]{1,100}\.zip$")


def size_label(n: int) -> str:
    """FormatTailleFichier."""
    for unit, k in (("Go", 1 << 30), ("Mo", 1 << 20), ("Ko", 1 << 10)):
        if n >= k:
            return f"{n / k:.2f}".rstrip("0").rstrip(".").replace(".", ",") + f" {unit}"
    return f"{n} Octets"


import os
import subprocess

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _ps() -> str:
    root = Path(os.environ.get("SystemRoot") or r"C:\Windows")
    p = root / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return str(p) if p.is_file() else "powershell"


def _run_ps_script(script: str, env: dict | None = None) -> str:
    import base64
    b64 = base64.b64encode(script.encode("utf-16le")).decode("ascii")
    r = subprocess.run(
        [_ps(), "-NoProfile", "-STA", "-EncodedCommand", b64],
        capture_output=True,
        timeout=600,
        env=env if env is not None else dict(os.environ),
        creationflags=NO_WINDOW
    )
    lines = r.stdout.decode("utf-8", "replace").strip().splitlines()
    return lines[-1].strip() if lines else ""


def pick_folder(initial: str = "") -> str:
    """Boîte de dialogue native Windows pour choisir un dossier de sauvegarde (toujours au premier plan)."""
    ps = (
        "[Console]::OutputEncoding = [Text.Encoding]::UTF8\n"
        "Add-Type -AssemblyName System.Windows.Forms\n"
        "$f = New-Object System.Windows.Forms.Form\n"
        "$f.TopMost = $true\n"
        "$f.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen\n"
        "$f.Size = New-Object System.Drawing.Size(1, 1)\n"
        "$f.Opacity = 0.01\n"
        "$f.Show()\n"
        "$f.Activate()\n"
        "$f.BringToFront()\n"
        "$d = New-Object System.Windows.Forms.FolderBrowserDialog\n"
        "$d.Description = 'Choisissez le dossier où enregistrer ou rechercher la sauvegarde'\n"
        "$d.ShowNewFolderButton = $true\n"
        "if ($env:DEC_INITIAL -and (Test-Path $env:DEC_INITIAL)) { $d.SelectedPath = $env:DEC_INITIAL }\n"
        "$res = $d.ShowDialog($f)\n"
        "$f.Close()\n"
        "$f.Dispose()\n"
        "if ($res -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }\n"
    )
    env = dict(os.environ, DEC_INITIAL=initial or "")
    return _run_ps_script(ps, env)


def pick_file(initial: str = "") -> str:
    """Boîte de dialogue native Windows pour choisir un fichier de sauvegarde à restaurer (toujours au premier plan)."""
    ps = (
        "[Console]::OutputEncoding = [Text.Encoding]::UTF8\n"
        "Add-Type -AssemblyName System.Windows.Forms\n"
        "$f = New-Object System.Windows.Forms.Form\n"
        "$f.TopMost = $true\n"
        "$f.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen\n"
        "$f.Size = New-Object System.Drawing.Size(1, 1)\n"
        "$f.Opacity = 0.01\n"
        "$f.Show()\n"
        "$f.Activate()\n"
        "$f.BringToFront()\n"
        "$d = New-Object System.Windows.Forms.OpenFileDialog\n"
        "$d.Title = 'Sélectionnez le fichier de sauvegarde à restaurer (ZIP)'\n"
        "$d.Filter = 'Fichiers ZIP (*.zip)|*.zip|Tous les fichiers (*.*)|*.*'\n"
        "if ($env:DEC_INITIAL -and (Test-Path $env:DEC_INITIAL)) { $d.InitialDirectory = $env:DEC_INITIAL }\n"
        "$res = $d.ShowDialog($f)\n"
        "$f.Close()\n"
        "$f.Dispose()\n"
        "if ($res -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.FileName }\n"
    )
    env = dict(os.environ, DEC_INITIAL=initial or "")
    return _run_ps_script(ps, env)


def open_folder(folder_path: str = "") -> str:
    target = Path(folder_path) if folder_path and Path(folder_path).is_dir() else config.BACKUP_DIR
    target.mkdir(parents=True, exist_ok=True)
    subprocess.Popen(["explorer.exe", str(target.resolve())])
    return str(target.resolve())


def inspect_file(file_path: str) -> dict:
    p = Path(file_path.strip())
    if not p.is_file():
        raise G50Error(f"Fichier introuvable : {file_path}")
    try:
        with zipfile.ZipFile(p) as z:
            codes = sorted({m.group(1) for n in z.namelist() if (m := ENTRY.match(n.replace("\\", "/")))}, key=lambda c: (len(c), c))
            st = p.stat()
            return {
                "name": p.name,
                "path": str(p.resolve()),
                "folder": str(p.parent.resolve()),
                "date": datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M:%S"),
                "size": st.st_size,
                "size_label": size_label(st.st_size),
                "dossiers": codes,
                "valid": bool(codes),
            }
    except zipfile.BadZipFile as e:
        raise G50Error("Le fichier sélectionné n’est pas une archive ZIP valide") from e


def history_with_folder(custom_dir: str = "") -> dict:
    """Scanne STRICTEMENT le dossier actif sélectionné sans fusionner d'anciens dossiers."""
    if custom_dir and Path(custom_dir).is_dir():
        target = Path(custom_dir).resolve()
    else:
        target = config.BACKUP_DIR.resolve()
        target.mkdir(parents=True, exist_ok=True)

    seen = set()
    out = []
    if target.is_dir():
        for p in sorted(target.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True):
            if not p.is_file():
                continue
            resolved = str(p.resolve())
            if resolved in seen:
                continue
            seen.add(resolved)
            try:
                st = p.stat()
                with zipfile.ZipFile(p) as z:
                    codes = sorted({m.group(1) for n in z.namelist() if (m := ENTRY.match(n.replace("\\", "/")))}, key=lambda c: (len(c), c))
            except Exception:
                codes = []
            out.append({
                "name": p.name,
                "path": str(p.resolve()),
                "folder": str(p.parent.resolve()),
                "date": datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M:%S"),
                "size": st.st_size,
                "size_label": size_label(st.st_size),
                "dossiers": codes,
                "_id": str(p.resolve())
            })
    return {"items": out, "active_folder": str(target), "total": len(out)}


def history(custom_dir: str = "") -> list[dict]:
    return history_with_folder(custom_dir)["items"]


def _path(name: str) -> Path:
    # Si c'est un chemin complet existant
    candidate = Path(name)
    if candidate.is_file() and candidate.suffix.lower() == ".zip":
        return candidate
    if not NAME.match(name or ""):
        raise G50Error("Nom de sauvegarde invalide")
    p = config.BACKUP_DIR / name
    if not p.is_file():
        raise G50Error("Le fichier sélectionné est introuvable. Il a peut-être été supprimé ou déplacé !")
    return p


def backup(prefix: str = "Sauv", target_dir: str = "") -> dict:
    """BtnSauvegarderClick."""
    dbs = sorted(d / config.DB_FILENAME for d in config.SOCIETES_DIR.iterdir() if (d / config.DB_FILENAME).is_file()) \
        if config.SOCIETES_DIR.is_dir() else []
    if not dbs:
        raise G50Error("Attention : le dossier à sauvegarder est complètement vide !")
    config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    now = datetime.now()
    name = f"{prefix}{now:%d%m%Y}.zip"
    if (config.BACKUP_DIR / name).exists():              # several backups the same day
        name = f"{prefix}{now:%d%m%Y_%H%M%S}.zip"
    target = config.BACKUP_DIR / name
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        for db in dbs:
            copy = Path(tmp) / f"{db.parent.name}.sqlite"
            src = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            dst = sqlite3.connect(copy)
            try:
                src.backup(dst)
            finally:
                dst.close()
                src.close()
            z.write(copy, f"{db.parent.name}/{config.DB_FILENAME}")

    target_folder_path = None
    if target_dir and target_dir.strip():
        td = Path(target_dir.strip())
        try:
            td.mkdir(parents=True, exist_ok=True)
            out_target = td / name
            out_target.write_bytes(target.read_bytes())
            target_folder_path = str(out_target.resolve())
        except Exception:
            pass

    items = history(custom_dir=target_dir)
    res = next((h for h in items if h["name"] == name), None)
    if not res:
        res = {"name": name, "path": str(target.resolve()), "folder": str(target.parent.resolve()), "date": datetime.now().strftime("%d/%m/%Y %H:%M:%S"), "size": target.stat().st_size, "size_label": size_label(target.stat().st_size), "dossiers": [db.parent.name for db in dbs], "_id": str(target.resolve())}
    if target_folder_path:
        res["target_path"] = target_folder_path
        res["folder"] = str(Path(target_folder_path).parent)
    return res


def _restore_zip(z: zipfile.ZipFile) -> list[str]:
    names = [n for n in z.namelist() if not n.endswith("/")]
    entries = {n: m.group(1) for n in names if (m := ENTRY.match(n.replace("\\", "/")))}
    if not entries:
        raise G50Error("Cette archive ne contient aucun dossier G50 (attendu : <dossier>/G50.sqlite)")
    # validate every database before touching the data
    with tempfile.TemporaryDirectory() as tmp:
        staged = {}
        for n, code in entries.items():
            p = Path(tmp) / f"{code}.sqlite"
            p.write_bytes(z.read(n))
            c = None
            try:
                c = sqlite3.connect(p)
                check = c.execute("PRAGMA integrity_check").fetchone()
                ok = bool(check and check[0] == "ok" and c.execute("SELECT 1 FROM sqlite_master WHERE name = 'clients'").fetchone())
            except sqlite3.Error:
                ok = False
            finally:
                if c is not None:
                    try:
                        c.close()
                    except Exception:
                        pass
            if not ok:
                raise G50Error(f"Le dossier {code} de l’archive est endommagé : restauration annulée")
            staged[code] = p
        if any((config.SOCIETES_DIR / code / config.DB_FILENAME).exists() for code in staged):
            backup("AvantRestauration")
        for code, p in staged.items():
            d = config.SOCIETES_DIR / code
            d.mkdir(parents=True, exist_ok=True)
            for suffix in ("-wal", "-shm", "-journal"):
                (d / (config.DB_FILENAME + suffix)).unlink(missing_ok=True)
            (d / config.DB_FILENAME).write_bytes(p.read_bytes())
    return sorted(staged)


def restore(name: str) -> dict:
    with zipfile.ZipFile(_path(name)) as z:
        return {"restored": _restore_zip(z), "source": name}


def restore_upload(filename: str, content_b64: str) -> dict:
    try:
        with zipfile.ZipFile(io.BytesIO(base64.b64decode(content_b64))) as z:
            return {"restored": _restore_zip(z), "source": filename}
    except zipfile.BadZipFile as e:
        raise G50Error("Le fichier n’est pas une archive ZIP valide") from e


def file_path(name: str) -> Path:
    return _path(name)
