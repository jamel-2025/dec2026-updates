"""Third-party directories — Delphi Unit30/Unit31 (Fournisseurs TVA, table fournisseurTva) and
Unit41/Unit42 (Table des Clients, table ClientrVentes). Same fiche: raison sociale (required),
activité, adresse, NIF, article d'imposition, RC, NIN.

Logical addition: a supplier/client still referenced by invoices cannot be deleted (Delphi
deleted it and left the invoices pointing to nothing).
"""
from __future__ import annotations

from dataclasses import dataclass

from fastapi import HTTPException

from ..core.db import connect
from .g50 import Conflict, G50Error, _next_id

FIELDS = ("rs", "activité", "adresse", "NIF", "ai", "rcom", "NIN")


@dataclass(frozen=True)
class Kind:
    table: str
    pk: str
    usage_sql: str        # counts the invoices referencing the record
    label: str


KINDS = {
    "fournisseurs": Kind("fournisseurTva", "IDfournisseurTva",
                         'SELECT COUNT(*) FROM DetailEtatTVA WHERE "IDfournisseurTva" = ?', "fournisseur"),
    "clients": Kind("ClientrVentes", "IDclientvente",
                    'SELECT COUNT(*) FROM FacturesVentes WHERE "IDClentventes" = ?', "client"),
}


def _kind(name: str) -> Kind:
    k = KINDS.get(name)
    if k is None:
        raise HTTPException(404, "Répertoire inconnu")
    return k


def list_(code: str, kind_name: str, q: str = "", limit: int = 500) -> dict:
    k = _kind(kind_name)
    like = f"%{q.strip()}%"
    with connect(code) as c:
        total = c.execute(f'SELECT COUNT(*) FROM "{k.table}"').fetchone()[0]
        rows = [dict(r) for r in c.execute(
            f'SELECT * FROM "{k.table}" WHERE rs LIKE ? OR NIF LIKE ? OR rcom LIKE ? OR adresse LIKE ? '
            f'ORDER BY rs COLLATE NOCASE LIMIT ?', (like, like, like, like, limit))]
        for r in rows:
            r["_id"] = r[k.pk]
            r["usage"] = c.execute(k.usage_sql, (r[k.pk],)).fetchone()[0]
    return {"total": total, "items": rows}


def save(code: str, kind_name: str, data: dict, item_id: int | None = None) -> dict:
    k = _kind(kind_name)
    values = {f: str(data.get(f) or "").strip() for f in FIELDS}
    if not values["rs"]:
        raise G50Error("Veuillez saisir la raison sociale")
    with connect(code) as c:
        dup = c.execute(f'SELECT "{k.pk}" FROM "{k.table}" WHERE UPPER(TRIM(rs)) = UPPER(?)', (values["rs"],)).fetchone()
        if dup and dup[0] != item_id:
            raise Conflict(f"Ce {k.label} existe déjà")
        if item_id is None:
            item_id = _next_id(c, k.table, k.pk)
            values[k.pk] = item_id
            c.execute(f'INSERT INTO "{k.table}" ({", ".join(chr(34) + f + chr(34) for f in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE "{k.table}" SET {", ".join(chr(34) + f + chr(34) + " = ?" for f in values)} '
                           f'WHERE "{k.pk}" = ?', (*values.values(), item_id)).rowcount:
            raise HTTPException(404, f"{k.label.capitalize()} introuvable")
        if kind_name == "fournisseurs":   # keep the name shown on the deducted invoices in sync
            c.execute('UPDATE DetailEtatTVA SET fournisseur = ? WHERE "IDfournisseurTva" = ?', (values["rs"], item_id))
        row = dict(c.execute(f'SELECT * FROM "{k.table}" WHERE "{k.pk}" = ?', (item_id,)).fetchone())
    row["_id"] = item_id
    return row


def delete(code: str, kind_name: str, item_id: int) -> None:
    k = _kind(kind_name)
    with connect(code) as c:
        used = c.execute(k.usage_sql, (item_id,)).fetchone()[0]
        if used:
            raise Conflict(f"Ce {k.label} figure sur {used} facture{'s' if used > 1 else ''} : suppression impossible")
        if not c.execute(f'DELETE FROM "{k.table}" WHERE "{k.pk}" = ?', (item_id,)).rowcount:
            raise HTTPException(404, f"{k.label.capitalize()} introuvable")
