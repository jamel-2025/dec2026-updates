"""Module de gestion des honoraires du cabinet comptable.

Gestion des conventions d'honoraires par société et exercice,
génération automatique des échéanciers (mensuel, trimestriel, semestriel, personnalisé),
suivi des règlements (espèces, chèque, virement), calcul des créances et retards,
génération de reçus de paiement et tableau de bord global de recouvrement multi-sociétés.
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime
from typing import Any

from fastapi import HTTPException

from ..core import config
from ..core.db import connect
from . import dossiers


# ------------------------------------------------------------------ Profil du Cabinet (G50ref.sqlite)

def _ref_conn() -> sqlite3.Connection:
    config.REF_DB.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.REF_DB)
    c.row_factory = sqlite3.Row
    return c


def init_cabinet_table() -> None:
    """Crée la table CabinetProfile dans G50ref.sqlite si inexistante."""
    with _ref_conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS CabinetProfile (
                id INTEGER PRIMARY KEY DEFAULT 1,
                nom_cabinet TEXT NOT NULL DEFAULT 'Cabinet d''Expertise Comptable & Commissariat aux Comptes',
                expert_comptable TEXT NOT NULL DEFAULT 'L''Expert-Comptable',
                titre TEXT DEFAULT 'Comptable Agréé / Commissaire aux Comptes',
                agrement TEXT DEFAULT '',
                nif TEXT DEFAULT '',
                nis TEXT DEFAULT '',
                adresse TEXT DEFAULT '',
                ville TEXT DEFAULT '',
                telephone TEXT DEFAULT '',
                email TEXT DEFAULT '',
                banque TEXT DEFAULT '',
                rib TEXT DEFAULT '',
                updated_at TEXT
            )
        """)
        exists = c.execute("SELECT 1 FROM CabinetProfile WHERE id = 1").fetchone()
        if not exists:
            c.execute("""
                INSERT INTO CabinetProfile (id, nom_cabinet, expert_comptable, titre)
                VALUES (1, 'Cabinet d''Expertise Comptable & Commissariat aux Comptes', 'L''Expert-Comptable', 'Comptable Agréé')
            """)
            c.commit()


def get_cabinet_profile() -> dict[str, Any]:
    init_cabinet_table()
    with _ref_conn() as c:
        row = c.execute("SELECT * FROM CabinetProfile WHERE id = 1").fetchone()
        return dict(row) if row else {}


def update_cabinet_profile(data: dict[str, Any]) -> dict[str, Any]:
    init_cabinet_table()
    allowed = {
        "nom_cabinet", "expert_comptable", "titre", "agrement", "nif", "nis",
        "adresse", "ville", "telephone", "email", "banque", "rib"
    }
    updates = {k: str(v or "").strip() for k, v in data.items() if k in allowed}
    updates["updated_at"] = datetime.now().isoformat()
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    with _ref_conn() as c:
        c.execute(f"UPDATE CabinetProfile SET {set_clause} WHERE id = 1", list(updates.values()))
        c.commit()
    return get_cabinet_profile()


# ------------------------------------------------------------------ Tables par dossier (G50.sqlite)

def ensure_dossier_tables(conn: sqlite3.Connection) -> None:
    """Crée les tables HonorairesContrat et HonorairesEcheances dans la base de la société."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS HonorairesContrat (
            exercice TEXT PRIMARY KEY,
            montant_annuel REAL NOT NULL DEFAULT 0,
            periodicite TEXT NOT NULL DEFAULT 'mensuel',
            jour_echeance INTEGER DEFAULT 5,
            notes TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS HonorairesEcheances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exercice TEXT NOT NULL,
            numero INTEGER NOT NULL,
            libelle TEXT NOT NULL,
            date_echeance TEXT NOT NULL,
            montant_du REAL NOT NULL DEFAULT 0,
            montant_regle REAL NOT NULL DEFAULT 0,
            date_reglement TEXT,
            mode_reglement TEXT,
            ref_piece TEXT,
            statut TEXT NOT NULL DEFAULT 'en_attente',
            observations TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_hon_ech_ex ON HonorairesEcheances (exercice)")


def _compute_status(montant_du: float, montant_regle: float, date_ech_str: str) -> str:
    """Calcule dynamiquement le statut de l'échéance."""
    du = round(float(montant_du or 0), 2)
    regle = round(float(montant_regle or 0), 2)
    if regle >= du and du > 0:
        return "paye"
    if regle > 0:
        return "partiel"
    try:
        ech_date = datetime.strptime(date_ech_str, "%Y-%m-%d").date()
        if ech_date < date.today():
            return "en_retard"
    except Exception:
        pass
    return "en_attente"


# ------------------------------------------------------------------ Gestion du contrat & échéances

MOIS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]
MOIS_AR = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def get_contrat(code: str, exercice: str) -> dict[str, Any]:
    with connect(code) as c:
        ensure_dossier_tables(c)
        r = c.execute("SELECT * FROM HonorairesContrat WHERE exercice = ?", (exercice,)).fetchone()
        if not r:
            return {
                "exercice": exercice,
                "montant_annuel": 0.0,
                "periodicite": "mensuel",
                "jour_echeance": 5,
                "notes": "",
                "configure": False,
            }
        d = dict(r)
        d["configure"] = True
        return d


def save_contrat(code: str, exercice: str, data: dict[str, Any]) -> dict[str, Any]:
    montant_annuel = max(0.0, float(data.get("montant_annuel") or 0.0))
    periodicite = str(data.get("periodicite") or "mensuel").lower()
    if periodicite not in ("mensuel", "trimestriel", "semestriel", "annuel", "libre"):
        periodicite = "mensuel"
    jour_echeance = max(1, min(28, int(data.get("jour_echeance") or 5)))
    notes = str(data.get("notes") or "").strip()
    now_iso = datetime.now().isoformat()

    with connect(code) as c:
        ensure_dossier_tables(c)
        c.execute("""
            INSERT INTO HonorairesContrat (exercice, montant_annuel, periodicite, jour_echeance, notes, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(exercice) DO UPDATE SET
                montant_annuel = excluded.montant_annuel,
                periodicite = excluded.periodicite,
                jour_echeance = excluded.jour_echeance,
                notes = excluded.notes,
                updated_at = excluded.updated_at
        """, (exercice, montant_annuel, periodicite, jour_echeance, notes, now_iso, now_iso))
        c.commit()

    return get_contrat(code, exercice)


def generate_echeancier(code: str, exercice: str, montant_annuel: float, periodicite: str, jour_echeance: int = 5, replace: bool = False) -> list[dict[str, Any]]:
    """Génère automatiquement la liste des tranches/échéances pour l'année."""
    montant_annuel = round(float(montant_annuel), 2)
    jour = max(1, min(28, int(jour_echeance)))
    now_iso = datetime.now().isoformat()

    with connect(code) as c:
        ensure_dossier_tables(c)
        existing = c.execute("SELECT * FROM HonorairesEcheances WHERE exercice = ? ORDER BY numero", (exercice,)).fetchall()
        if existing and not replace:
            return [dict(x) for x in existing]

        # Conserver les règlements antérieurs par numéro si existants
        reglements_anterieurs: dict[int, dict[str, Any]] = {}
        if existing and replace:
            for row in existing:
                rd = dict(row)
                if rd.get("montant_regle", 0) > 0:
                    reglements_anterieurs[rd["numero"]] = {
                        "montant_regle": rd["montant_regle"],
                        "date_reglement": rd.get("date_reglement"),
                        "mode_reglement": rd.get("mode_reglement"),
                        "ref_piece": rd.get("ref_piece"),
                        "observations": rd.get("observations"),
                    }
            c.execute("DELETE FROM HonorairesEcheances WHERE exercice = ?", (exercice,))

        tranches: list[tuple[int, str, str, float]] = []

        if periodicite == "mensuel":
            part = round(montant_annuel / 12, 2)
            for m in range(1, 13):
                # La dernière tranche absorbe la différence de centimes éventuelle
                val = (montant_annuel - part * 11) if m == 12 else part
                dt_str = f"{exercice}-{m:02d}-{jour:02d}"
                libelle = f"Honoraires {MOIS_FR[m-1]} {exercice} / أتعاب شهر {MOIS_AR[m-1]}"
                tranches.append((m, libelle, dt_str, val))

        elif periodicite == "trimestriel":
            part = round(montant_annuel / 4, 2)
            trimestres = [
                (1, "1er Trimestre (T1)", f"{exercice}-03-31", "الفصل الأول T1"),
                (2, "2ème Trimestre (T2)", f"{exercice}-06-30", "الفصل الثاني T2"),
                (3, "3ème Trimestre (T3)", f"{exercice}-09-30", "الفصل الثالث T3"),
                (4, "4ème Trimestre (T4)", f"{exercice}-12-31", "الفصل الرابع T4"),
            ]
            for num, lib_fr, dt_str, lib_ar in trimestres:
                val = (montant_annuel - part * 3) if num == 4 else part
                tranches.append((num, f"Honoraires {lib_fr} / أتعاب {lib_ar}", dt_str, val))

        elif periodicite == "semestriel":
            part = round(montant_annuel / 2, 2)
            semestres = [
                (1, "1er Semestre (S1)", f"{exercice}-06-30", "السداسي الأول S1"),
                (2, "2ème Semestre (S2)", f"{exercice}-12-31", "السداسي الثاني S2"),
            ]
            for num, lib_fr, dt_str, lib_ar in semestres:
                val = (montant_annuel - part) if num == 2 else part
                tranches.append((num, f"Honoraires {lib_fr} / أتعاب {lib_ar}", dt_str, val))

        elif periodicite == "annuel":
            tranches.append((1, f"Honoraires Annuels {exercice} / الأتعاب السنوية الإجمالية", f"{exercice}-12-31", montant_annuel))

        for num, lib, dt_str, mnt in tranches:
            reg = reglements_anterieurs.get(num, {})
            m_regle = float(reg.get("montant_regle") or 0.0)
            d_regle = reg.get("date_reglement")
            mode = reg.get("mode_reglement")
            ref_p = reg.get("ref_piece") or ""
            obs = reg.get("observations") or ""
            stat = _compute_status(mnt, m_regle, dt_str)

            c.execute("""
                INSERT INTO HonorairesEcheances (
                    exercice, numero, libelle, date_echeance, montant_du, montant_regle,
                    date_reglement, mode_reglement, ref_piece, statut, observations, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (exercice, num, lib, dt_str, mnt, m_regle, d_regle, mode, ref_p, stat, obs, now_iso, now_iso))

        c.commit()

    return list_echeances(code, exercice)


def list_echeances(code: str, exercice: str) -> list[dict[str, Any]]:
    with connect(code) as c:
        ensure_dossier_tables(c)
        rows = c.execute("SELECT * FROM HonorairesEcheances WHERE exercice = ? ORDER BY numero, date_echeance", (exercice,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            # Rafraîchir dynamiquement le statut si la date d'échéance est dépassée
            stat = _compute_status(d["montant_du"], d["montant_regle"], d["date_echeance"])
            d["statut"] = stat
            d["reste_a_payer"] = max(0.0, round(d["montant_du"] - d["montant_regle"], 2))
            out.append(d)
        return out


def add_custom_echeance(code: str, exercice: str, data: dict[str, Any]) -> dict[str, Any]:
    libelle = str(data.get("libelle") or "").strip()
    if not libelle:
        raise HTTPException(400, "Le libellé de l'échéance est obligatoire")
    date_ech = str(data.get("date_echeance") or f"{exercice}-12-31").strip()
    montant_du = max(0.0, float(data.get("montant_du") or 0.0))
    now_iso = datetime.now().isoformat()

    with connect(code) as c:
        ensure_dossier_tables(c)
        max_num = c.execute("SELECT COALESCE(MAX(numero), 0) FROM HonorairesEcheances WHERE exercice = ?", (exercice,)).fetchone()[0]
        numero = max_num + 1
        statut = _compute_status(montant_du, 0.0, date_ech)
        cur = c.execute("""
            INSERT INTO HonorairesEcheances (
                exercice, numero, libelle, date_echeance, montant_du, montant_regle,
                statut, observations, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, 0.0, ?, ?, ?, ?)
        """, (exercice, numero, libelle, date_ech, montant_du, statut, str(data.get("observations") or "").strip(), now_iso, now_iso))
        c.commit()
        item_id = cur.lastrowid
        r = c.execute("SELECT * FROM HonorairesEcheances WHERE id = ?", (item_id,)).fetchone()
        return dict(r)


def update_echeance(code: str, echeance_id: int, data: dict[str, Any]) -> dict[str, Any]:
    with connect(code) as c:
        ensure_dossier_tables(c)
        curr = c.execute("SELECT * FROM HonorairesEcheances WHERE id = ?", (echeance_id,)).fetchone()
        if not curr:
            raise HTTPException(404, "Échéance introuvable")
        cd = dict(curr)

        libelle = str(data.get("libelle") or cd["libelle"]).strip()
        date_ech = str(data.get("date_echeance") or cd["date_echeance"]).strip()
        montant_du = max(0.0, float(data.get("montant_du") if data.get("montant_du") is not None else cd["montant_du"]))
        montant_regle = max(0.0, float(data.get("montant_regle") if data.get("montant_regle") is not None else cd["montant_regle"]))
        date_reglement = data.get("date_reglement") if data.get("date_reglement") is not None else cd["date_reglement"]
        mode_reglement = data.get("mode_reglement") if data.get("mode_reglement") is not None else cd["mode_reglement"]
        ref_piece = str(data.get("ref_piece") if data.get("ref_piece") is not None else (cd["ref_piece"] or "")).strip()
        observations = str(data.get("observations") if data.get("observations") is not None else (cd["observations"] or "")).strip()

        statut = _compute_status(montant_du, montant_regle, date_ech)
        now_iso = datetime.now().isoformat()

        c.execute("""
            UPDATE HonorairesEcheances SET
                libelle = ?, date_echeance = ?, montant_du = ?, montant_regle = ?,
                date_reglement = ?, mode_reglement = ?, ref_piece = ?,
                statut = ?, observations = ?, updated_at = ?
            WHERE id = ?
        """, (libelle, date_ech, montant_du, montant_regle, date_reglement, mode_reglement, ref_piece, statut, observations, now_iso, echeance_id))
        c.commit()

        r = c.execute("SELECT * FROM HonorairesEcheances WHERE id = ?", (echeance_id,)).fetchone()
        out = dict(r)
        out["reste_a_payer"] = max(0.0, round(out["montant_du"] - out["montant_regle"], 2))
        return out


def delete_echeance(code: str, echeance_id: int) -> dict[str, Any]:
    with connect(code) as c:
        ensure_dossier_tables(c)
        c.execute("DELETE FROM HonorairesEcheances WHERE id = ?", (echeance_id,))
        c.commit()
    return {"status": "ok", "deleted_id": echeance_id}


def enregistrer_reglement(code: str, echeance_id: int, data: dict[str, Any]) -> dict[str, Any]:
    """Enregistre un paiement complet ou partiel sur une échéance."""
    montant_paye = max(0.0, float(data.get("montant_paye") or 0.0))
    date_reglement = str(data.get("date_reglement") or date.today().isoformat()).strip()
    mode_reglement = str(data.get("mode_reglement") or "especes").lower()
    ref_piece = str(data.get("ref_piece") or "").strip()
    observations = str(data.get("observations") or "").strip()

    with connect(code) as c:
        ensure_dossier_tables(c)
        curr = c.execute("SELECT * FROM HonorairesEcheances WHERE id = ?", (echeance_id,)).fetchone()
        if not curr:
            raise HTTPException(404, "Échéance introuvable")
        cd = dict(curr)

        # Si le paiement est cumulatif ou remplace le règlement précédent
        is_cumul = bool(data.get("cumuler", False))
        nouveau_regle = (cd["montant_regle"] + montant_paye) if is_cumul else montant_paye
        statut = _compute_status(cd["montant_du"], nouveau_regle, cd["date_echeance"])
        now_iso = datetime.now().isoformat()

        c.execute("""
            UPDATE HonorairesEcheances SET
                montant_regle = ?, date_reglement = ?, mode_reglement = ?,
                ref_piece = ?, statut = ?, observations = ?, updated_at = ?
            WHERE id = ?
        """, (nouveau_regle, date_reglement, mode_reglement, ref_piece, statut, observations, now_iso, echeance_id))
        c.commit()

        r = c.execute("SELECT * FROM HonorairesEcheances WHERE id = ?", (echeance_id,)).fetchone()
        out = dict(r)
        out["reste_a_payer"] = max(0.0, round(out["montant_du"] - out["montant_regle"], 2))
        return out


# ------------------------------------------------------------------ Conversion des montants en lettres (Tafqeet)

def nombre_en_lettres_ar(montant: float) -> str:
    """Convertit un montant en Dinars Algériens en toutes lettres en arabe."""
    unites = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"]
    dix = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"]
    dizaines = ["", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"]
    centaines = ["", "مائة", "مئتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"]

    val = int(round(montant))
    if val == 0:
        return "صفر دينار جزائري"

    def _convert_3(n: int) -> str:
        parts = []
        c = n // 100
        d = (n % 100) // 10
        u = n % 10
        if c > 0:
            parts.append(centaines[c])
        if d == 1:
            parts.append(dix[u])
        elif d > 1:
            if u > 0:
                parts.append(f"{unites[u]} و{dizaines[d]}")
            else:
                parts.append(dizaines[d])
        elif u > 0:
            parts.append(unites[u])
        return " و".join(parts)

    millions = val // 1_000_000
    mille = (val % 1_000_000) // 1_000
    reste = val % 1_000

    chunks = []
    if millions == 1:
        chunks.append("مليون")
    elif millions == 2:
        chunks.append("مليونان")
    elif 3 <= millions <= 10:
        chunks.append(f"{_convert_3(millions)} ملايين")
    elif millions > 10:
        chunks.append(f"{_convert_3(millions)} مليون")

    if mille == 1:
        chunks.append("ألف")
    elif mille == 2:
        chunks.append("ألفان")
    elif 3 <= mille <= 10:
        chunks.append(f"{_convert_3(mille)} آلاف")
    elif mille > 10:
        chunks.append(f"{_convert_3(mille)} ألف")

    if reste > 0:
        chunks.append(_convert_3(reste))

    res = " و".join(chunks)
    return f"{res} دينار جزائري"


def nombre_en_lettres_fr(montant: float) -> str:
    """Convertit un montant en Dinars Algériens en toutes lettres en français."""
    units = ["", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf"]
    teens = ["dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf"]
    tens = ["", "dix", "vingt", "trente", "quarante", "cinquante", "soixante", "soixante-dix", "quatre-vingts", "quatre-vingt-dix"]

    val = int(round(montant))
    if val == 0:
        return "zéro dinar algérien"

    def _conv(n: int) -> str:
        if n == 0:
            return ""
        if n < 10:
            return units[n]
        if n < 20:
            return teens[n - 10]
        if n < 70:
            u = n % 10
            t = tens[n // 10]
            if u == 1:
                return f"{t} et un"
            return f"{t}-{units[u]}" if u else t
        if n < 80:
            u = n - 60
            return f"soixante et onze" if u == 11 else f"soixante-{teens[u - 10]}" if u >= 10 else f"soixante-{units[u]}"
        if n < 100:
            u = n - 80
            return f"quatre-vingt-{teens[u - 10]}" if u >= 10 else f"quatre-vingt-{units[u]}" if u else "quatre-vingts"
        c = n // 100
        r = n % 100
        prefix = "cent" if c == 1 else f"{units[c]} cents" if r == 0 else f"{units[c]} cent"
        return f"{prefix} {_conv(r)}".strip() if r else prefix

    parts = []
    millions = val // 1_000_000
    thousands = (val % 1_000_000) // 1_000
    rem = val % 1_000

    if millions:
        parts.append(f"{_conv(millions)} million" if millions == 1 else f"{_conv(millions)} millions")
    if thousands:
        parts.append("mille" if thousands == 1 else f"{_conv(thousands)} mille")
    if rem:
        parts.append(_conv(rem))

    txt = " ".join(parts)
    return f"{txt[0].upper()}{txt[1:]} dinars algériens"


# ------------------------------------------------------------------ Données du reçu de paiement

def get_recu_paiement(code: str, echeance_id: int) -> dict[str, Any]:
    """Génère les données complètes pour l'impression du reçu officiel de paiement."""
    cabinet = get_cabinet_profile()
    client = dossiers.societe(code)

    with connect(code) as c:
        ensure_dossier_tables(c)
        ech = c.execute("SELECT * FROM HonorairesEcheances WHERE id = ?", (echeance_id,)).fetchone()
        if not ech:
            raise HTTPException(404, "Échéance introuvable")
        ech_d = dict(ech)

    montant = ech_d["montant_regle"]
    return {
        "recu_num": f"REC-{ech_d['exercice']}-{code}-{ech_d['numero']:02d}",
        "date_recu": ech_d.get("date_reglement") or date.today().isoformat(),
        "cabinet": cabinet,
        "client": {
            "code": code,
            "rs": client.get("rs") or f"Société {code}",
            "fj": client.get("fj") or "",
            "gerant": client.get("gerant") or "",
            "nif": client.get("NIF") or client.get("NIF2") or "",
            "nis": client.get("NIS") or "",
            "rc": client.get("RC") or "",
            "ai": client.get("AI") or "",
            "adresse": client.get("adresse") or "",
            "activite": client.get("activité") or client.get("act") or "",
            "telephone": client.get("tel") or "",
        },
        "echeance": {
            "numero": ech_d["numero"],
            "libelle": ech_d["libelle"],
            "exercice": ech_d["exercice"],
            "date_echeance": ech_d["date_echeance"],
            "montant_du": ech_d["montant_du"],
            "montant_regle": ech_d["montant_regle"],
            "reste_a_payer": max(0.0, round(ech_d["montant_du"] - ech_d["montant_regle"], 2)),
            "mode_reglement": ech_d["mode_reglement"],
            "ref_piece": ech_d["ref_piece"],
            "observations": ech_d["observations"],
        },
        "montant_en_lettres_ar": nombre_en_lettres_ar(montant),
        "montant_en_lettres_fr": nombre_en_lettres_fr(montant),
    }


# ------------------------------------------------------------------ Tableau de bord global multi-sociétés

def get_synthese_globale(exercice: str) -> dict[str, Any]:
    """Synthèse financière consolidée des honoraires du cabinet pour toutes les sociétés."""
    dossier_list = dossiers.list_dossiers()
    societes_stats: list[dict[str, Any]] = []

    total_budgete = 0.0
    total_du = 0.0
    total_encaisse = 0.0
    total_creances = 0.0

    modes_encaissement: dict[str, float] = {"especes": 0.0, "cheque": 0.0, "virement": 0.0, "autre": 0.0}
    mois_encaissement: dict[int, float] = {m: 0.0 for m in range(1, 13)}

    nb_a_jour = 0
    nb_retard = 0
    nb_partiel = 0
    nb_non_conf = 0

    for d in dossier_list:
        code = d["code"]
        contrat = get_contrat(code, exercice)
        echeances = list_echeances(code, exercice)

        soc_du = sum(e["montant_du"] for e in echeances)
        soc_regle = sum(e["montant_regle"] for e in echeances)
        soc_reste = max(0.0, round(soc_du - soc_regle, 2))
        soc_budget = contrat.get("montant_annuel", 0.0)

        # Si pas d'échéances mais contrat renseigné
        if not soc_du and soc_budget > 0:
            soc_du = soc_budget
            soc_reste = soc_budget

        total_budgete += soc_budget
        total_du += soc_du
        total_encaisse += soc_regle
        total_creances += soc_reste

        # Statut global du dossier
        has_retard = any(e["statut"] == "en_retard" for e in echeances)
        is_paid = (soc_du > 0 and soc_regle >= soc_du)
        is_partiel = (soc_regle > 0 and soc_regle < soc_du)

        if not contrat.get("configure") and not echeances:
            statut_dossier = "non_configure"
            nb_non_conf += 1
        elif has_retard:
            statut_dossier = "retard"
            nb_retard += 1
        elif is_paid:
            statut_dossier = "a_jour"
            nb_a_jour += 1
        elif is_partiel:
            statut_dossier = "partiel"
            nb_partiel += 1
        else:
            statut_dossier = "en_cours"

        # Prochaine échéance à payer
        prochaine = None
        for e in echeances:
            if e["statut"] in ("en_attente", "partiel", "en_retard"):
                prochaine = {
                    "numero": e["numero"],
                    "libelle": e["libelle"],
                    "date": e["date_echeance"],
                    "montant": e["montant_du"] - e["montant_regle"],
                    "statut": e["statut"],
                }
                break

        # Ventilation des modes et mois pour cette société
        for e in echeances:
            m_regle = e.get("montant_regle", 0.0)
            if m_regle > 0:
                mode = (e.get("mode_reglement") or "autre").lower()
                modes_encaissement[mode] = modes_encaissement.get(mode, 0.0) + m_regle
                d_regle = e.get("date_reglement")
                if d_regle:
                    try:
                        m_idx = datetime.strptime(d_regle[:10], "%Y-%m-%d").month
                        mois_encaissement[m_idx] = mois_encaissement.get(m_idx, 0.0) + m_regle
                    except Exception:
                        pass

        taux_soc = round((soc_regle / soc_du * 100), 1) if soc_du > 0 else 0.0

        societes_stats.append({
            "code": code,
            "rs": d.get("rs") or f"Société {code}",
            "nif": d.get("nif") or "",
            "fj": d.get("fj") or "",
            "activite": d.get("activite") or "",
            "contrat_configure": contrat.get("configure", False),
            "montant_annuel": soc_budget,
            "periodicite": contrat.get("periodicite", "mensuel"),
            "total_du": round(soc_du, 2),
            "total_regle": round(soc_regle, 2),
            "reste_a_payer": round(soc_reste, 2),
            "taux_recouvrement": taux_soc,
            "nb_echeances": len(echeances),
            "prochaine_echeance": prochaine,
            "statut": statut_dossier,
        })

    taux_global = round((total_encaisse / total_du * 100), 1) if total_du > 0 else 0.0

    return {
        "exercice": exercice,
        "kpi": {
            "total_budgete": round(total_budgete, 2),
            "total_du": round(total_du, 2),
            "total_encaisse": round(total_encaisse, 2),
            "total_creances": round(total_creances, 2),
            "taux_recouvrement": taux_global,
            "total_societes": len(dossier_list),
            "nb_a_jour": nb_a_jour,
            "nb_retard": nb_retard,
            "nb_partiel": nb_partiel,
            "nb_non_configurees": nb_non_conf,
        },
        "modes_encaissement": {k: round(v, 2) for k, v in modes_encaissement.items()},
        "mois_encaissement": {k: round(v, 2) for k, v in mois_encaissement.items()},
        "societes": societes_stats,
    }
