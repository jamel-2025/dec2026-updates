"""Dossier Notes & Central Alerts Hub — Multi-Sociétés Task & Alert System.

Persisted in data/audit.sqlite.
Supports both per-dossier note management and a centralized firm-wide alerts cockpit
for all companies (S1..Sn) with deadlines, statuses, priorities and direct navigation.
"""
from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime, date
from typing import Any

from ..core import config

_TABLE = """
CREATE TABLE IF NOT EXISTS dossier_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dossier TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT 'note',
    reminder_date TEXT,
    pinned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notes_dossier ON dossier_notes (dossier);
"""


def _conn() -> sqlite3.Connection:
    config.AUDIT_DB.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(config.AUDIT_DB), timeout=10.0, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init():
    with _conn() as c:
        c.executescript(_TABLE)
        # Migrate schema dynamically if existing table misses newly added columns
        cols = {row["name"] for row in c.execute("PRAGMA table_info(dossier_notes)").fetchall()}
        if "status" not in cols:
            c.execute("ALTER TABLE dossier_notes ADD COLUMN status TEXT NOT NULL DEFAULT 'pending'")
        if "priority" not in cols:
            c.execute("ALTER TABLE dossier_notes ADD COLUMN priority TEXT NOT NULL DEFAULT 'normal'")
        if "resolution_note" not in cols:
            c.execute("ALTER TABLE dossier_notes ADD COLUMN resolution_note TEXT NOT NULL DEFAULT ''")
        if "resolved_at" not in cols:
            c.execute("ALTER TABLE dossier_notes ADD COLUMN resolved_at TEXT")
        c.execute("CREATE INDEX IF NOT EXISTS idx_notes_status ON dossier_notes (status)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_notes_reminder ON dossier_notes (reminder_date)")
        c.commit()


try:
    init()
except Exception:
    pass


def _get_dossier_names_map() -> dict[str, dict]:
    """Map dossier codes (e.g. 'S1', 'S2') to their metadata (Raison Sociale, Forme Juridique, NIF)."""
    mapping = {}
    try:
        from . import dossiers
        for d in dossiers.list_dossiers():
            code = d.get("code") or d.get("dossier")
            if code:
                mapping[code] = {
                    "rs": d.get("rs") or code,
                    "fj": d.get("fj") or "",
                    "nif": d.get("nif") or "",
                }
    except Exception:
        pass
    return mapping


def _enrich_note(dict_row: dict, names_map: dict[str, dict]) -> dict:
    item = dict(dict_row)
    d_code = item.get("dossier", "")
    info = names_map.get(d_code, {})
    item["rs"] = info.get("rs") or d_code
    item["fj"] = info.get("fj") or ""
    item["nif"] = info.get("nif") or ""

    # Deadline calculations
    rem_str = item.get("reminder_date")
    item["is_overdue"] = False
    item["is_due_today"] = False
    item["days_left"] = None

    if rem_str and item.get("status") != "done":
        try:
            rem_d = datetime.strptime(rem_str[:10], "%Y-%m-%d").date()
            today = date.today()
            delta = (rem_d - today).days
            item["days_left"] = delta
            if delta < 0:
                item["is_overdue"] = True
            elif delta == 0:
                item["is_due_today"] = True
        except Exception:
            pass

    return item


def list_notes(dossier: str) -> list[dict]:
    """Lists notes for a specific dossier."""
    names_map = _get_dossier_names_map()
    with _conn() as c:
        rows = c.execute(
            """SELECT * FROM dossier_notes WHERE dossier = ?
               ORDER BY pinned DESC,
                        CASE status WHEN 'pending' THEN 1 WHEN 'in_progress' THEN 2 ELSE 3 END,
                        CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END,
                        updated_at DESC""",
            (dossier,),
        ).fetchall()
    return [_enrich_note(dict(r), names_map) for r in rows]


def list_all_notes(
    status: str | None = None,
    priority: str | None = None,
    dossier: str | None = None,
    category: str | None = None,
    search: str | None = None,
) -> list[dict]:
    """Lists notes across ALL dossiers for the centralized Alerts Cockpit."""
    names_map = _get_dossier_names_map()
    query = "SELECT * FROM dossier_notes WHERE 1=1"
    params: list[Any] = []

    if status and status != "all":
        if status == "pending_all":
            query += " AND status IN ('pending', 'in_progress')"
        else:
            query += " AND status = ?"
            params.append(status)

    if priority and priority != "all":
        query += " AND priority = ?"
        params.append(priority)

    if dossier and dossier != "all":
        query += " AND dossier = ?"
        params.append(dossier)

    if category and category != "all":
        query += " AND category = ?"
        params.append(category)

    if search and search.strip():
        term = f"%{search.strip()}%"
        query += " AND (title LIKE ? OR content LIKE ? OR dossier LIKE ?)"
        params.extend([term, term, term])

    query += """ ORDER BY pinned DESC,
                CASE status WHEN 'pending' THEN 1 WHEN 'in_progress' THEN 2 ELSE 3 END,
                CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'normal' THEN 3 ELSE 4 END,
                CASE WHEN reminder_date IS NOT NULL AND reminder_date != '' THEN reminder_date ELSE '9999-12-31' END ASC,
                updated_at DESC"""

    with _conn() as c:
        rows = c.execute(query, params).fetchall()

    return [_enrich_note(dict(r), names_map) for r in rows]


def get_notes_summary() -> dict:
    """Calculates firm-wide notification and alert metrics for the Dashboard."""
    today_str = date.today().strftime("%Y-%m-%d")
    with _conn() as c:
        total = c.execute("SELECT COUNT(*) FROM dossier_notes").fetchone()[0]
        pending = c.execute("SELECT COUNT(*) FROM dossier_notes WHERE status IN ('pending', 'in_progress')").fetchone()[0]
        urgent = c.execute("SELECT COUNT(*) FROM dossier_notes WHERE status IN ('pending', 'in_progress') AND priority = 'urgent'").fetchone()[0]
        done = c.execute("SELECT COUNT(*) FROM dossier_notes WHERE status = 'done'").fetchone()[0]

        overdue = c.execute(
            """SELECT COUNT(*) FROM dossier_notes
               WHERE status != 'done' AND reminder_date IS NOT NULL AND reminder_date != ''
               AND date(reminder_date) < date(?)""",
            (today_str,),
        ).fetchone()[0]

        due_today = c.execute(
            """SELECT COUNT(*) FROM dossier_notes
               WHERE status != 'done' AND reminder_date IS NOT NULL AND reminder_date != ''
               AND date(reminder_date) = date(?)""",
            (today_str,),
        ).fetchone()[0]

        # Group by category
        cat_rows = c.execute("SELECT category, COUNT(*) as c FROM dossier_notes WHERE status != 'done' GROUP BY category").fetchall()
        by_category = {r["category"]: r["c"] for r in cat_rows}

        # Group by dossier
        dos_rows = c.execute("SELECT dossier, COUNT(*) as c FROM dossier_notes WHERE status != 'done' GROUP BY dossier").fetchall()
        by_dossier = {r["dossier"]: r["c"] for r in dos_rows}

    return {
        "total": total,
        "pending": pending,
        "urgent": urgent,
        "overdue": overdue,
        "due_today": due_today,
        "done": done,
        "by_category": by_category,
        "by_dossier": by_dossier,
    }


def add_note(dossier: str, data: dict) -> dict:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    names_map = _get_dossier_names_map()
    with _conn() as c:
        cur = c.execute(
            """INSERT INTO dossier_notes (
                    dossier, title, content, category, reminder_date, pinned,
                    status, priority, resolution_note, resolved_at, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                dossier,
                data.get("title", "").strip(),
                data.get("content", "").strip(),
                data.get("category", "note"),
                data.get("reminder_date") or None,
                1 if data.get("pinned") else 0,
                data.get("status", "pending"),
                data.get("priority", "normal"),
                data.get("resolution_note", "").strip(),
                None,
                now,
                now,
            ),
        )
        row = c.execute("SELECT * FROM dossier_notes WHERE id = ?", (cur.lastrowid,)).fetchone()
    return _enrich_note(dict(row), names_map)


def update_note(note_id: int, data: dict) -> dict:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    names_map = _get_dossier_names_map()
    with _conn() as c:
        c.execute(
            """UPDATE dossier_notes SET
                    title=?, content=?, category=?, reminder_date=?, pinned=?,
                    status=?, priority=?, resolution_note=?, updated_at=?
               WHERE id=?""",
            (
                data.get("title", "").strip(),
                data.get("content", "").strip(),
                data.get("category", "note"),
                data.get("reminder_date") or None,
                1 if data.get("pinned") else 0,
                data.get("status", "pending"),
                data.get("priority", "normal"),
                data.get("resolution_note", "").strip(),
                now,
                note_id,
            ),
        )
        row = c.execute("SELECT * FROM dossier_notes WHERE id = ?", (note_id,)).fetchone()
    if not row:
        raise ValueError("Note introuvable")
    return _enrich_note(dict(row), names_map)


def resolve_note(note_id: int, resolution_note: str = "") -> dict:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    names_map = _get_dossier_names_map()
    with _conn() as c:
        c.execute(
            """UPDATE dossier_notes
               SET status = 'done', resolved_at = ?, resolution_note = ?, updated_at = ?
               WHERE id = ?""",
            (now, resolution_note.strip(), now, note_id),
        )
        row = c.execute("SELECT * FROM dossier_notes WHERE id = ?", (note_id,)).fetchone()
    if not row:
        raise ValueError("Note introuvable")
    return _enrich_note(dict(row), names_map)


def reopen_note(note_id: int) -> dict:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    names_map = _get_dossier_names_map()
    with _conn() as c:
        c.execute(
            """UPDATE dossier_notes
               SET status = 'pending', resolved_at = NULL, updated_at = ?
               WHERE id = ?""",
            (now, note_id),
        )
        row = c.execute("SELECT * FROM dossier_notes WHERE id = ?", (note_id,)).fetchone()
    if not row:
        raise ValueError("Note introuvable")
    return _enrich_note(dict(row), names_map)


def delete_note(note_id: int) -> bool:
    with _conn() as c:
        c.execute("DELETE FROM dossier_notes WHERE id = ?", (note_id,))
    return True


def toggle_pin(note_id: int) -> dict:
    names_map = _get_dossier_names_map()
    with _conn() as c:
        row = c.execute("SELECT * FROM dossier_notes WHERE id = ?", (note_id,)).fetchone()
        if not row:
            raise ValueError("Note introuvable")
        new_pin = 0 if row["pinned"] else 1
        c.execute("UPDATE dossier_notes SET pinned=?, updated_at=? WHERE id=?",
                  (new_pin, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), note_id))
        row = c.execute("SELECT * FROM dossier_notes WHERE id = ?", (note_id,)).fetchone()
    return _enrich_note(dict(row), names_map)


def get_reminders() -> list[dict]:
    """Get all notes with upcoming reminders (next 30 days)."""
    names_map = _get_dossier_names_map()
    with _conn() as c:
        rows = c.execute(
            """SELECT * FROM dossier_notes 
               WHERE reminder_date IS NOT NULL AND reminder_date != '' AND status != 'done'
               AND date(reminder_date) >= date('now', '-7 days') AND date(reminder_date) <= date('now', '+30 days')
               ORDER BY reminder_date ASC""",
        ).fetchall()
    return [_enrich_note(dict(r), names_map) for r in rows]


def get_all_notes_count() -> dict:
    """Get note counts per dossier for dashboard display."""
    with _conn() as c:
        rows = c.execute(
            "SELECT dossier, COUNT(*) as count FROM dossier_notes WHERE status != 'done' GROUP BY dossier"
        ).fetchall()
    return {r["dossier"]: r["count"] for r in rows}
