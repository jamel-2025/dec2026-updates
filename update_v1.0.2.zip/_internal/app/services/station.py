"""Station-service — Delphi uMain page 6, Unit14 (mois), Unit5 (détail), Unit39 (prix de référence),
reports Unit5.RsatationM (état mensuel) and Unit21.Rstation (état annuel).

Tables: Station (one record per month), Naftal (carburants), Naftal2 (lubrifiants),
Naftal3 (prestations, one per month), PPu (prix de référence GAS OIL / ESSENCE S.PL / SIRGHAZ).

Rules (Unit5):
  * carburants: montant = quantité × prix de référence; vente = Σ montants; bénéfice = vente − achat;
    secteur pétrolier sans TVA;
  * lubrifiants: achat HT = achat TTC − TVA achat; vente HT = achat HT × 1,15; TVA vente 19 %;
  * prestations: cafétéria, restaurant, lavage, transport, TVA 19 % chacune;
  * totaux du mois = Σ des trois tables (CalculerTotauxCA).
Correction: Delphi added the cafeteria *turnover* instead of its TVA in PrestationTVA.
"""
from __future__ import annotations

import sqlite3

from fastapi import HTTPException

from ..core.db import connect
from . import dates, ref
from .g50 import Conflict, G50Error, _next_id, _num

PRODUCTS = [("GAS OIL", "Gasoil"), ("ESSENCE S.PL", "Essence"), ("SIRGHAZ", "Sirgaz")]
LUB_MARKUP = 1.15
TVA_RATE = 19


def _r(v: float) -> float:
    return round(v + 0.0, 2)


# ------------------------------------------------------------------ prices (PPu)
def prices(c: sqlite3.Connection) -> dict[str, float]:
    rows = {str(r["PP"]).strip().upper(): _num(r["PU"]) for r in c.execute("SELECT PP, PU FROM PPu")}
    return {key: rows.get(pp, 0.0) for pp, key in PRODUCTS}


def set_prices(code: str, data: dict) -> dict:
    with connect(code) as c:
        for pp, key in PRODUCTS:
            if key in data:
                if c.execute("UPDATE PPu SET PU = ? WHERE UPPER(TRIM(PP)) = ?", (_num(data[key]), pp)).rowcount == 0:
                    c.execute("INSERT INTO PPu (ID, PP, PU) VALUES (?, ?, ?)", (_next_id(c, "PPu", "ID"), pp, _num(data[key])))
        return prices(c)


# ------------------------------------------------------------------ months
def _station(c: sqlite3.Connection, sid: int) -> dict:
    r = c.execute('SELECT * FROM Station WHERE "IDStation" = ?', (sid,)).fetchone()
    if r is None:
        raise HTTPException(404, "Déclaration station introuvable")
    return dict(r)


def year(code: str, annee: str) -> dict:
    with connect(code) as c:
        rows = [dict(r) for r in c.execute('SELECT * FROM Station WHERE "Annee" = ? ORDER BY "Mois"', (str(annee),))]
        p = prices(c)
    keys = ("SecteurpetrolierCA", "ReventeCA", "ReventeTVA", "PrestationCA", "PrestationTVA", "TotalCA", "TotalTVA")
    return {"items": rows, "prices": p, "totals": {k: sum(_num(r.get(k)) for r in rows) for k in keys},
            "mois": [{"mois": int(m["MOIS"]), "label": m["LeMois"]} for m in ref.table("Mois")]}


def create(code: str, annee: str, mois: int) -> dict:
    """Unit14.Button1Click — one declaration per month."""
    mois = int(mois)
    label = ref.mois_label(mois)
    with connect(code) as c:
        if c.execute('SELECT 1 FROM Station WHERE "Mois" = ? AND "Annee" = ?', (mois, str(annee))).fetchone():
            raise Conflict(f"La déclaration station pour {label} {annee} existe déjà.")
        sid = _next_id(c, "Station", "IDStation")
        c.execute('INSERT INTO Station ("IDStation", "Mois", "Annee", "ma", "leMois", "SecteurpetrolierCA", "SecteurpetrolierTVA", '
                  '"ReventeCA", "ReventeTVA", "PrestationCA", "PrestationTVA", "TotalCA", "TotalTVA") '
                  'VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0, 0, 0)', (sid, mois, str(annee), f"{mois}{annee}", label))
    return detail(code, sid)


def delete(code: str, sid: int) -> None:
    with connect(code) as c:
        _station(c, sid)
        for t in ("Naftal", "Naftal2", "Naftal3"):
            c.execute(f'DELETE FROM {t} WHERE "IDStation" = ?', (sid,))
        c.execute('DELETE FROM Station WHERE "IDStation" = ?', (sid,))


def _recalc(c: sqlite3.Connection, sid: int) -> None:
    """CalculerTotauxCA."""
    one = lambda sql: _num(c.execute(sql, (sid,)).fetchone()[0])
    sect = one('SELECT SUM(Tvente) FROM Naftal WHERE "IDStation" = ?')
    rev_ca, rev_tva = one('SELECT SUM(VenteHT) FROM Naftal2 WHERE "IDStation" = ?'), one('SELECT SUM(TVAVente) FROM Naftal2 WHERE "IDStation" = ?')
    pre_ca, pre_tva = one('SELECT SUM(PrestationCA) FROM Naftal3 WHERE "IDStation" = ?'), one('SELECT SUM(PrestationTVA) FROM Naftal3 WHERE "IDStation" = ?')
    c.execute('UPDATE Station SET "SecteurpetrolierCA" = ?, "SecteurpetrolierTVA" = 0, "ReventeCA" = ?, "ReventeTVA" = ?, '
              '"PrestationCA" = ?, "PrestationTVA" = ?, "TotalCA" = ?, "TotalTVA" = ? WHERE "IDStation" = ?',
              (_r(sect), _r(rev_ca), _r(rev_tva), _r(pre_ca), _r(pre_tva), _r(sect + rev_ca + pre_ca), _r(rev_tva + pre_tva), sid))


def detail(code: str, sid: int) -> dict:
    with connect(code) as c:
        s = _station(c, sid)
        lines = {}
        for kind, (table, pk) in {"carburants": ("Naftal", "IDF"), "lubrifiants": ("Naftal2", "IDF"), "prestations": ("Naftal3", "IDP")}.items():
            rows = [dict(r) for r in c.execute(f'SELECT * FROM {table} WHERE "IDStation" = ? ORDER BY "{pk}"', (sid,))]
            for r in rows:
                r["_id"] = r[pk]
                if "DateFact" in r:
                    r["date_display"] = dates.to_display(r.get("DateFact"))
                if table == "Naftal":     # unit price applied (PU* columns absent from older dossiers)
                    for k, t in (("Gasoil", "TGasoil"), ("Essence", "TEssence"), ("Sirgaz", "TSiirgaz")):
                        if r.get(f"PU{k}") is None:
                            q = _num(r.get(f"Q{k}"))
                            r[f"PU{k}"] = round(_num(r.get(t)) / q, 2) if q else 0
            lines[kind] = rows
        p = prices(c)
    return {**s, "lines": lines, "prices": p}


# ------------------------------------------------------------------ lines
def _carburant(d: dict, p: dict[str, float]) -> dict:
    q = {k: _num(d.get(f"Q{k}")) for k in ("Gasoil", "Essence", "Sirgaz")}
    t = {k: q[k] * p[k] for k in q}
    vente, achat = sum(t.values()), _num(d.get("Tachat"))
    return {"Fournisseur": str(d.get("Fournisseur") or "NAFTAL"), "RefF": str(d.get("RefF") or ""),
            "DateFact": dates.to_storage(d.get("DateFact")) if d.get("DateFact") else None,
            "QGasoil": q["Gasoil"], "QEssence": q["Essence"], "QSirgaz": q["Sirgaz"],
            "PUGasoil": p["Gasoil"], "PUEssence": p["Essence"], "PUSirgaz": p["Sirgaz"],
            "TGasoil": _r(t["Gasoil"]), "TEssence": _r(t["Essence"]), "TSiirgaz": _r(t["Sirgaz"]),
            "Tvente": _r(vente), "Tachat": _r(achat), "Benefice": _r(vente - achat)}


def _lubrifiant(d: dict, p: dict) -> dict:
    ttc, tva_a = _num(d.get("AchatTTC")), _num(d.get("TVAachat"))
    ht = max(ttc - tva_a, 0.0)
    vente = ht * LUB_MARKUP
    tva_v = vente * TVA_RATE / 100
    return {"Fournisseur": str(d.get("Fournisseur") or "NAFTAL"), "RefF": str(d.get("RefF") or ""),
            "DateFact": dates.to_storage(d.get("DateFact")) if d.get("DateFact") else None,
            "AchatTTC": _r(ttc), "TVAachat": _r(tva_a), "AchatHT": _r(ht), "VenteHT": _r(vente), "TVAVente": _r(tva_v),
            "VenteTTC": _r(vente + tva_v), "Benefice": _r(vente - ht), "Tachat": _r(ttc), "Marge": round(vente / ht, 4) if ht else 0}


def _prestation(d: dict, p: dict) -> dict:
    out, ca_tot, tva_tot = {}, 0.0, 0.0
    for k in ("Cafetiria", "Restaurant", "Lavage", "Transport"):
        ca = _num(d.get(f"{k}CA"))
        out[f"{k}CA"], out[f"{k}TVA"] = _r(ca), _r(ca * TVA_RATE / 100)
        ca_tot += ca
        tva_tot += ca * TVA_RATE / 100
    out.update({"PrestationCA": _r(ca_tot), "PrestationTVA": _r(tva_tot)})
    return out


KINDS = {"carburants": ("Naftal", "IDF", _carburant), "lubrifiants": ("Naftal2", "IDF", _lubrifiant),
         "prestations": ("Naftal3", "IDP", _prestation)}


def save_line(code: str, sid: int, kind: str, data: dict, line_id: int | None = None) -> dict:
    if kind not in KINDS:
        raise HTTPException(404, "Type de ligne inconnu")
    table, pk, compute = KINDS[kind]
    with connect(code) as c:
        s = _station(c, sid)
        if kind == "prestations" and line_id is None and c.execute('SELECT 1 FROM Naftal3 WHERE "IDStation" = ?', (sid,)).fetchone():
            raise Conflict("Un seul enregistrement de prestations par mois : modifiez l’existant")
        values = compute(data, prices(c))
        if kind != "prestations" and not any(values.get(k) for k in ("QGasoil", "QEssence", "QSirgaz", "AchatTTC")):
            raise G50Error("Veuillez saisir les quantités ou le montant d’achat")
        values.update({"Mois": int(_num(s["Mois"])), "Annee": str(s["Annee"]), "IDStation": sid})
        if kind == "prestations":
            values.update({"TotalCA": values["PrestationCA"], "TotalTVA": values["PrestationTVA"]})
        # older dossiers lack the PU* columns of the Delphi field list: keep only existing columns
        cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
        values = {k: v for k, v in values.items() if k in cols}
        if line_id is None:
            values[pk] = _next_id(c, table, pk)
            c.execute(f'INSERT INTO {table} ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE {table} SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} '
                           f'WHERE "{pk}" = ? AND "IDStation" = ?', (*values.values(), line_id, sid)).rowcount:
            raise HTTPException(404, "Ligne introuvable")
        _recalc(c, sid)
    return detail(code, sid)


def delete_line(code: str, sid: int, kind: str, line_id: int) -> dict:
    table, pk, _ = KINDS[kind]
    with connect(code) as c:
        if not c.execute(f'DELETE FROM {table} WHERE "{pk}" = ? AND "IDStation" = ?', (line_id, sid)).rowcount:
            raise HTTPException(404, "Ligne introuvable")
        _recalc(c, sid)
    return detail(code, sid)
