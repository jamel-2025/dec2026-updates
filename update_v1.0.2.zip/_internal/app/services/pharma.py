"""Déclaration CA Pharmacie — Delphi: uMain page scAdvancedPagerPage5 + Form12 (Unit12),
dataset Form20.TPharma = table DecCAPharm, detail of Exercices (Année -> Exercice).

Behaviour reproduced:
  * Modifier  (SpeedButton37): TPharma.Edit + Form12.ShowModal. On an empty detail
    dataset Edit inserts, so the record of the exercice is created on first Valider.
  * Valider   (Form12.AdvGlowButton2): TPharma.Post.  Total (Button1Click) = F1+..+F5.
  * Supp      (SpeedButton36): confirmation, TPharma.Delete.
  * Imp Decl  (SpeedButton35): RPharma.fr3 with DBPharma + DBSociete, or the message
    'Aucune Déclaration CA Pharma à imprimer' when empty.
"""
from __future__ import annotations

from ..core import registry
from ..core.db import connect
from . import dates

TABLE = "DecCAPharm"
AMOUNTS = ("CA1", "CA2", "CA3", "CA4", "CA5")


def _row(r) -> dict | None:
    if r is None:
        return None
    d = dict(r)
    d["DAtedEC_display"] = dates.to_display(d.get("DAtedEC"))
    return d


def get(code: str, exercice: str) -> dict | None:
    with connect(code) as c:
        r = c.execute(f'SELECT * FROM "{TABLE}" WHERE "Exercice" = ? ORDER BY "IDcaPhar" LIMIT 1',
                      (str(exercice),)).fetchone()
    return _row(r)


def save(code: str, exercice: str, data: dict) -> dict:
    t = registry.get(TABLE)
    values = {k: registry.coerce(t.field(k), data.get(k)) for k in AMOUNTS}
    values = {k: (v if v is not None else 0) for k, v in values.items()}
    values["Totalca"] = float(sum(values[k] for k in AMOUNTS))
    values["DAtedEC"] = dates.to_storage(data.get("DAtedEC"))
    with connect(code) as c:
        r = c.execute(f'SELECT "IDcaPhar" FROM "{TABLE}" WHERE "Exercice" = ? ORDER BY "IDcaPhar" LIMIT 1',
                      (str(exercice),)).fetchone()
        if r is not None:
            sets = ", ".join(f'"{k}" = ?' for k in values)
            c.execute(f'UPDATE "{TABLE}" SET {sets} WHERE "IDcaPhar" = ?', (*values.values(), r[0]))
        else:
            new_id = c.execute(f'SELECT COALESCE(MAX("IDcaPhar"), 0) + 1 FROM "{TABLE}"').fetchone()[0]
            cols = ["IDcaPhar", "Exercice", *values]
            col_list = ", ".join(f'"{k}"' for k in cols)
            c.execute(f'INSERT INTO "{TABLE}" ({col_list}) VALUES ({", ".join("?" for _ in cols)})',
                      (new_id, str(exercice), *values.values()))
    return get(code, exercice)


def delete(code: str, exercice: str) -> bool:
    with connect(code) as c:
        cur = c.execute(f'DELETE FROM "{TABLE}" WHERE "IDcaPhar" = (SELECT "IDcaPhar" FROM "{TABLE}" '
                        f'WHERE "Exercice" = ? ORDER BY "IDcaPhar" LIMIT 1)', (str(exercice),))
        return cur.rowcount > 0
