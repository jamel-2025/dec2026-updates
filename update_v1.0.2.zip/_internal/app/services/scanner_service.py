"""
Module de gestion du Scanner Matériel (WIA - Windows Image Acquisition).
Permet l'acquisition directe depuis les imprimantes multifonctions et scanners (USB / Wi-Fi).
"""
import os
import sys
import json
import base64
import logging
import subprocess
from pathlib import Path
from typing import Dict, Any, List

logger = logging.getLogger("scanner_service")

SCRIPTS_DIR = Path(__file__).resolve().parent

def get_ps1_path() -> Path:
    candidates = [
        SCRIPTS_DIR / "scanner_wia.ps1",
    ]
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            candidates.append(Path(meipass) / "app" / "services" / "scanner_wia.ps1")
            candidates.append(Path(meipass) / "backend" / "app" / "services" / "scanner_wia.ps1")
            candidates.append(Path(meipass) / "scanner_wia.ps1")
        exe_dir = Path(sys.executable).resolve().parent
        candidates.append(exe_dir / "backend" / "app" / "services" / "scanner_wia.ps1")
        candidates.append(exe_dir / "scanner_wia.ps1")

    project_root = os.environ.get("DEC_PROJECT_ROOT")
    if project_root:
        candidates.append(Path(project_root) / "backend" / "app" / "services" / "scanner_wia.ps1")
        candidates.append(Path(project_root) / "scanner_wia.ps1")

    for p in candidates:
        if p.is_file():
            return p
    return SCRIPTS_DIR / "scanner_wia.ps1"

PS1_PATH = get_ps1_path()


def list_connected_scanners() -> List[Dict[str, Any]]:
    """Détecte et liste les scanners et imprimantes multifonctions connectés via WIA."""
    ps1 = get_ps1_path()
    if not ps1.is_file():
        logger.error("Script scanner_wia.ps1 introuvable à : %s", ps1)
        return []

    try:
        cmd = [
            "powershell.exe",
            "-NoProfile",
            "-NonInteractive",
            "-InputFormat", "None",
            "-ExecutionPolicy", "Bypass",
            "-File", str(PS1_PATH),
            "-Action", "list",
        ]
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            stdin=subprocess.DEVNULL,
            timeout=20,
            encoding="utf-8",
            errors="replace"
        )
        for line in res.stdout.splitlines():
            line = line.strip()
            if line.startswith("RESULT:"):
                raw_json = line[len("RESULT:"):].strip()
                data = json.loads(raw_json)
                return data if isinstance(data, list) else [data]
            if line.startswith("ERROR:"):
                logger.warning("Erreur WIA list : %s", line)
    except Exception as e:
        logger.error("Exception lors de la détection des scanners : %s", e)

    return []


def scan_document_from_hardware(
    device_id: str = "",
    color_mode: str = "color",
    dpi: int = 200,
) -> Dict[str, Any]:
    """
    Déclenche la boîte de dialogue ou l'acquisition directe WIA sous Windows.
    Retourne le statut et l'image capturée encodée en base64 pour affichage et sauvegarde immédiate.
    """
    ps1 = get_ps1_path()
    if not ps1.is_file():
        return {
            "status": "error",
            "message": "Composant WIA scanner introuvable sur le système.",
        }

    temp_out = os.path.join(os.environ.get("TEMP", "C:\\Temp"), f"scan_{os.getpid()}_{int(os.times().system * 1000)}.jpg")

    cmd = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", str(ps1),
        "-Action", "scan",
        "-DeviceId", str(device_id or ""),
        "-ColorMode", color_mode,
        "-DPI", str(dpi),
        "-OutFile", temp_out,
    ]

    try:
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            stdin=subprocess.DEVNULL,
            timeout=180,
            encoding="utf-8",
            errors="replace"
        )
        
        result_obj = None
        for line in res.stdout.splitlines():
            line = line.strip()
            if line.startswith("RESULT:"):
                result_obj = json.loads(line[len("RESULT:"):])
                break

        if not result_obj:
            err_msg = res.stderr.strip() or res.stdout.strip() or "Aucune réponse du sous-système de numérisation."
            return {"status": "error", "message": err_msg}

        if result_obj.get("status") == "ok":
            file_path = result_obj.get("file_path", temp_out)
            if os.path.isfile(file_path):
                with open(file_path, "rb") as f:
                    file_bytes = f.read()

                b64_str = base64.b64encode(file_bytes).decode("ascii")
                data_uri = f"data:image/jpeg;base64,{b64_str}"

                # Nettoyage fichier temporaire
                try:
                    os.remove(file_path)
                except Exception:
                    pass

                return {
                    "status": "ok",
                    "image_base64": data_uri,
                    "mime_type": "image/jpeg",
                    "taille_octets": len(file_bytes),
                    "message": "Numérisation effectuée avec succès.",
                }
            else:
                return {"status": "error", "message": "Le fichier numérisé est introuvable."}

        return result_obj

    except subprocess.TimeoutExpired:
        return {"status": "error", "message": "Délai de numérisation dépassé (l'appareil ne répond pas)."}
    except Exception as e:
        logger.error("Exception scan_document_from_hardware : %s", e)
        return {"status": "error", "message": str(e)}
