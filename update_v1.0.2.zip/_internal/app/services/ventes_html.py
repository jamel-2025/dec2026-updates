"""État des ventes (mensuel / annuel) — Mise en page HTML haute fidélité (modèle officiel A4 Paysage)
et export Excel enrichi avec les coordonnées fiscales du client (NIF, RC, AI, Adresse) conformes
au modèle officiel Série G. N° 3 & N° 3 bis.

Fusion de la colonne Mois et Année en une seule colonne « Période » (ex: Janvier 2024, Octobre 2024)
pour maximiser l'espace utile et offrir une lisibilité optimale.
"""
from __future__ import annotations

import base64
from datetime import datetime
from html import escape
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..core import config
from ..core.db import connect
from . import dates, dossiers, ventes
from .g50 import G50Error, _num

FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def _font_face() -> str:
    faces = []
    for f, rng in (
        ("cairo-arabic-wght-normal.woff2", "U+0600-06FF,U+0750-077F,U+0870-08FF,U+FB50-FDFF,U+FE70-FEFF"),
        ("cairo-latin-wght-normal.woff2", "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+2000-206F,U+20AC"),
    ):
        p = FONTS / f
        if p.is_file():
            b64 = base64.b64encode(p.read_bytes()).decode()
            faces.append(
                f"@font-face{{font-family:'Cairo';font-weight:200 1000;src:url(data:font/woff2;base64,{b64}) format('woff2');unicode-range:{rng};}}"
            )
    return "".join(faces)


def money(v: float | int | None) -> str:
    val = round(float(v or 0), 2)
    s = f"{val:,.2f}".replace(",", " ").replace(".", ",")
    return s


CSS = """
@page {
    size: A4 landscape;
    margin: 8mm 10mm;
}
* {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
}
body {
    margin: 0;
    font-family: 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif;
    color: #0f172a;
    font-size: 11px;
    line-height: 1.4;
    background: #fff;
}
.report-page {
    width: 100%;
    max-width: 1120px;
    margin: 0 auto;
    padding: 4px;
}
.top-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    border-bottom: 2px solid #006233;
    padding-bottom: 8px;
    margin-bottom: 10px;
    gap: 12px;
}
.soc-info {
    flex: 1.2;
    font-size: 10.5px;
    line-height: 1.45;
}
.soc-name {
    font-size: 15px;
    font-weight: 800;
    color: #006233;
    text-transform: uppercase;
    margin-bottom: 2px;
}
.soc-grid {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 2px 10px;
    margin-top: 4px;
}
.soc-lbl {
    font-weight: 700;
    color: #475569;
}
.soc-val {
    font-weight: 600;
    color: #1e293b;
    font-family: monospace;
}
.title-box {
    flex: 1.6;
    text-align: center;
    border: 1.5px solid #006233;
    background: #f0fdf4;
    border-radius: 6px;
    padding: 8px 12px;
}
.main-title {
    font-size: 16px;
    font-weight: 900;
    color: #006233;
    margin: 0 0 3px 0;
    letter-spacing: 0.02em;
}
.sub-title {
    font-size: 10px;
    color: #166534;
    font-weight: 600;
    margin: 0;
}
.doc-meta {
    flex: 0.8;
    text-align: right;
    font-size: 10.5px;
    line-height: 1.5;
}
.doc-meta b {
    color: #0f172a;
    font-family: monospace;
}
.table-container {
    width: 100%;
    margin-top: 6px;
    border: 1px solid #cbd5e1;
    border-radius: 4px;
    overflow: hidden;
}
table.ventes-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10px;
}
table.ventes-table th {
    background: #f1f5f9;
    color: #1e293b;
    font-weight: 800;
    padding: 6px 4px;
    border: 1px solid #cbd5e1;
    text-align: center;
    vertical-align: middle;
}
table.ventes-table th.ar {
    font-size: 9.5px;
    color: #475569;
    font-weight: 600;
    display: block;
}
table.ventes-table td {
    padding: 5px 4px;
    border: 1px solid #e2e8f0;
    vertical-align: middle;
    color: #1e293b;
}
table.ventes-table tr:nth-child(even) td {
    background: #f8fafc;
}
.col-num {
    text-align: center;
    font-family: monospace;
    font-weight: 700;
    width: 80px;
}
.col-date {
    text-align: center;
    width: 75px;
    white-space: nowrap;
}
.col-client {
    font-weight: 700;
    color: #0f172a;
}
.col-id {
    font-family: monospace;
    font-size: 9.5px;
    text-align: center;
    color: #334155;
    white-space: nowrap;
}
.col-adr {
    font-size: 9px;
    color: #64748b;
    max-width: 140px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.col-periode {
    text-align: center;
    font-weight: 700;
    color: #047857;
    background: #ecfdf5;
    width: 90px;
    white-space: nowrap;
}
.col-money {
    text-align: right;
    font-family: monospace;
    font-weight: 600;
    white-space: nowrap;
    padding-right: 6px;
}
.col-taux {
    text-align: center;
    width: 50px;
}
table.ventes-table tr.total-row td {
    background: #e2e8f0 !important;
    font-weight: 900;
    font-size: 11px;
    color: #0f172a;
    border-top: 2px solid #64748b;
    border-bottom: 2px solid #64748b;
}
.kpi-bar {
    display: flex;
    gap: 16px;
    margin-top: 8px;
    padding: 8px 12px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 4px;
    font-size: 11px;
}
.kpi-item {
    display: flex;
    align-items: center;
    gap: 6px;
}
.kpi-lbl {
    color: #475569;
    font-weight: 600;
}
.kpi-val {
    font-weight: 800;
    color: #006233;
    font-family: monospace;
    font-size: 12px;
}
.footer-signatures {
    display: flex;
    justify-content: space-between;
    margin-top: 14px;
    gap: 30px;
    page-break-inside: avoid;
}
.sig-box {
    flex: 1;
    border: 1px solid #94a3b8;
    border-radius: 4px;
    height: 85px;
    padding: 6px 10px;
    text-align: center;
    font-size: 10.5px;
}
.sig-title {
    font-weight: 800;
    color: #334155;
    border-bottom: 1px dashed #cbd5e1;
    padding-bottom: 4px;
    margin-bottom: 4px;
}
"""


def render(code: str, params: dict) -> tuple[str, str]:
    """Génère la vue HTML haute fidélité pour l'impression de l'état des ventes (mensuel ou annuel)."""
    annee = str(params.get("exercice") or params.get("annee") or "").strip()
    mois = str(params.get("mois") or "").strip()
    res = ventes.list_(code, annee, mois)
    rows = res["items"]
    if not rows:
        raise G50Error("Aucune facture de vente enregistrée pour la période sélectionnée")

    soc = dossiers.societe(code)
    tot_ht = res["totals"]["ht"]
    tot_tva = res["totals"]["tva"]
    tot_ttc = res["totals"]["ttc"]
    nb_factures = len(rows)
    distinct_clients = len({str(r.get("ClientsVente") or "").strip().lower() for r in rows if r.get("ClientsVente")})

    if mois:
        title_fr = f"ETAT DES VENTES — MOIS DE : {mois.upper()} {annee}"
        title_ar = f"كشف المبيعات — شهر {mois} {annee}"
    else:
        title_fr = f"ETAT DES VENTES ANNUELLES — EXERCICE : {annee}"
        title_ar = f"كشف المبيعات السنوي — سنة {annee}"

    rows_html = []
    for r in rows:
        nfac = escape(str(r.get("nfacture") or ""))
        dt = escape(str(r.get("date_display") or ""))
        client = escape(str(r.get("ClientsVente") or ""))
        nif = escape(str(r.get("NIF") or "—"))
        rc = escape(str(r.get("rcom") or "—"))
        ai = escape(str(r.get("ai") or "—"))
        adr = escape(str(r.get("adresse") or "—"))
        
        # Période fusionnée : ex "Octobre 2024"
        periode = escape(str(r.get("Periode") or (f"{r.get('leMois') or ''} {r.get('Année') or ''}".strip()) or "—"))
        
        ht_val = _num(r.get("ht"))
        taux_val = r.get("TauxTva") if r.get("TauxTva") is not None else 19
        tva_val = _num(r.get("tvadroits"))
        ttc_val = _num(r.get("TTC")) or (ht_val + tva_val)

        rows_html.append(f"""
        <tr>
            <td class="col-num">{nfac}</td>
            <td class="col-date">{dt}</td>
            <td class="col-client">{client}</td>
            <td class="col-id">{nif}</td>
            <td class="col-id">{rc}</td>
            <td class="col-id">{ai}</td>
            <td class="col-adr" title="{adr}">{adr}</td>
            <td class="col-periode">{periode}</td>
            <td class="col-money">{money(ht_val)}</td>
            <td class="col-taux">{taux_val}%</td>
            <td class="col-money" style="color:#047857;">{money(tva_val)}</td>
            <td class="col-money" style="font-weight:700;">{money(ttc_val)}</td>
        </tr>
        """)

    body = f"""<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>{escape(title_fr)}</title>
    <style>
        {_font_face()}
        {CSS}
    </style>
</head>
<body>
<div class="report-page">
    <div class="top-header">
        <div class="soc-info">
            <div class="soc-name">{escape(str(soc.get("rs") or soc.get("RaisonSociale") or "ENTREPRISE"))}</div>
            <div>{escape(str(soc.get("activite") or soc.get("Activité") or ""))}</div>
            <div>{escape(str(soc.get("adresse") or soc.get("Adresse") or ""))}</div>
            <div class="soc-grid">
                <span class="soc-lbl">NIF :</span><span class="soc-val">{escape(str(soc.get("NIF") or ""))}</span>
                <span class="soc-lbl">RC :</span><span class="soc-val">{escape(str(soc.get("rc") or soc.get("rcom") or ""))}</span>
                <span class="soc-lbl">Article :</span><span class="soc-val">{escape(str(soc.get("ai") or ""))}</span>
            </div>
        </div>

        <div class="title-box">
            <div style="font-size:10px; font-weight:700; color:#475569; margin-bottom:2px;">
                RÉPUBLIQUE ALGÉRIENNE DÉMOCRATIQUE ET POPULAIRE<br>
                DIRECTION GÉNÉRALE DES IMPÔTS
            </div>
            <h1 class="main-title">{escape(title_fr)}</h1>
            <p class="sub-title">{escape(title_ar)} · Relevé officiel des ventes (Conforme Série G - N° 3 / 3 bis)</p>
        </div>

        <div class="doc-meta">
            <div>Exercice : <b>{escape(annee)}</b></div>
            <div>Période : <b>{escape(mois or "Année entière")}</b></div>
            <div>Date d'édition : <b>{datetime.now().strftime('%d/%m/%Y')}</b></div>
            <div style="margin-top:4px; font-size:9.5px; color:#64748b;">Système Dec G50 2026</div>
        </div>
    </div>

    <div class="table-container">
        <table class="ventes-table">
            <thead>
                <tr>
                    <th rowspan="2" style="width:75px;">N° Facture<span class="ar">رقم الفاتورة</span></th>
                    <th rowspan="2" style="width:70px;">Date<span class="ar">التاريخ</span></th>
                    <th rowspan="2" style="min-width:140px;">Client / Raison Sociale<span class="ar">العميل / إسم الشركة</span></th>
                    <th colspan="3" style="background:#e2e8f0;">Coordonnées Fiscales du Client (G3 / G3 bis)<span class="ar">بيانات الزبون الجبائية</span></th>
                    <th rowspan="2" style="max-width:130px;">Adresse du Client<span class="ar">عنوان العميل</span></th>
                    <th rowspan="2" style="width:85px; background:#dcfce7; color:#166534;">Période<span class="ar">الفترة (شهر/سنة)</span></th>
                    <th rowspan="2" style="width:95px;">Montant HT (DA)<span class="ar">المبلغ خ.ر</span></th>
                    <th rowspan="2" style="width:45px;">Taux<span class="ar">النسبة</span></th>
                    <th rowspan="2" style="width:90px;">Montant TVA (DA)<span class="ar">الرسم (ق.م)</span></th>
                    <th rowspan="2" style="width:95px;">Total TTC (DA)<span class="ar">المبلغ الإجمالي</span></th>
                </tr>
                <tr>
                    <th style="width:90px;">N° NIF<span class="ar">الرقم الجبائي</span></th>
                    <th style="width:75px;">N° RC<span class="ar">السجل التجاري</span></th>
                    <th style="width:65px;">N° Article<span class="ar">المادة</span></th>
                </tr>
            </thead>
            <tbody>
                {"".join(rows_html)}
                <tr class="total-row">
                    <td colspan="8" style="text-align:right; padding-right:12px; font-size:11px; letter-spacing:0.04em;">
                        TOTAL GÉNÉRAL ({nb_factures} facture{'s' if nb_factures > 1 else ''}) :
                    </td>
                    <td class="col-money" style="font-size:11px;">{money(tot_ht)}</td>
                    <td style="text-align:center;">—</td>
                    <td class="col-money" style="font-size:11px; color:#047857;">{money(tot_tva)}</td>
                    <td class="col-money" style="font-size:11.5px; color:#0f172a;">{money(tot_ttc)}</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="kpi-bar">
        <div class="kpi-item">
            <span class="kpi-lbl">Total Factures :</span>
            <span class="kpi-val">{nb_factures}</span>
        </div>
        <div class="kpi-item">
            <span class="kpi-lbl">Clients Distincts :</span>
            <span class="kpi-val">{distinct_clients}</span>
        </div>
        <div class="kpi-item" style="margin-left:auto;">
            <span class="kpi-lbl">Chiffre d'Affaires HT :</span>
            <span class="kpi-val">{money(tot_ht)} DA</span>
        </div>
        <div class="kpi-item">
            <span class="kpi-lbl">TVA Facturée :</span>
            <span class="kpi-val" style="color:#047857;">{money(tot_tva)} DA</span>
        </div>
        <div class="kpi-item">
            <span class="kpi-lbl">Total TTC :</span>
            <span class="kpi-val" style="color:#0f172a;">{money(tot_ttc)} DA</span>
        </div>
    </div>

    <div class="footer-signatures">
        <div class="sig-box">
            <div class="sig-title">Le Comptable / Le Déclarant</div>
            <div style="font-size:9.5px; color:#64748b; margin-top:28px;">Visa et observations</div>
        </div>
        <div class="sig-box">
            <div class="sig-title">Cachet et Signature de l'Entreprise</div>
            <div style="font-size:9.5px; color:#64748b; margin-top:28px;">Date et mention « Certifié exact et sincère »</div>
        </div>
    </div>
</div>
</body>
</html>
"""
    return body, title_fr


def export_excel(code: str, params: dict, out_path: Path) -> None:
    """Exporte l'état des ventes sous forme de classeur Excel professionnel et formaté."""
    annee = str(params.get("exercice") or params.get("annee") or "").strip()
    mois = str(params.get("mois") or "").strip()
    res = ventes.list_(code, annee, mois)
    rows = res["items"]
    soc = dossiers.societe(code)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"Ventes_{mois or annee}"
    ws.views.sheetView[0].showGridLines = True

    # Styles
    f_title = Font(name="Calibri", size=14, bold=True, color="006233")
    f_sub = Font(name="Calibri", size=10, italic=True, color="475569")
    f_header = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    f_total = Font(name="Calibri", size=11, bold=True, color="000000")
    f_data = Font(name="Calibri", size=10)
    f_num = Font(name="Consolas", size=10)

    fill_head = PatternFill(start_color="006233", end_color="006233", fill_type="solid")
    fill_subhead = PatternFill(start_color="166534", end_color="166534", fill_type="solid")
    fill_total = PatternFill(start_color="E2E8F0", end_color="E2E8F0", fill_type="solid")
    fill_periode = PatternFill(start_color="DCFCE7", end_color="DCFCE7", fill_type="solid")

    thin_border = Border(
        left=Side(style="thin", color="CBD5E1"),
        right=Side(style="thin", color="CBD5E1"),
        top=Side(style="thin", color="CBD5E1"),
        bottom=Side(style="thin", color="CBD5E1")
    )
    total_border = Border(
        top=Side(style="medium", color="000000"),
        bottom=Side(style="double", color="000000")
    )

    # 1. En-tête société & Titre
    soc_name = str(soc.get("rs") or soc.get("RaisonSociale") or "ENTREPRISE").upper()
    ws["A1"] = soc_name
    ws["A1"].font = Font(name="Calibri", size=12, bold=True, color="006233")
    ws["A2"] = f"NIF : {soc.get('NIF') or '—'}  |  RC : {soc.get('rc') or soc.get('rcom') or '—'}  |  Article : {soc.get('ai') or '—'}"
    ws["A2"].font = f_sub

    title_text = f"ETAT DES VENTES — MOIS DE : {mois.upper()} {annee}" if mois else f"ETAT DES VENTES ANNUELLES — ANNEE : {annee}"
    ws["A4"] = title_text
    ws["A4"].font = f_title
    ws["A5"] = "Relevé détaillé des factures de vente avec coordonnées fiscales des clients (Conforme Série G. N° 3 & N° 3 bis)"
    ws["A5"].font = f_sub

    # 2. En-têtes du tableau
    headers = [
        "N° Facture", "Date Facture", "Client / Raison Sociale",
        "N° NIF", "N° RC", "N° Article (AI)", "Adresse du Client",
        "Période", "Montant HT (DA)", "Taux TVA", "Montant TVA (DA)", "Total TTC (DA)"
    ]

    header_row = 7
    for col_idx, h in enumerate(headers, start=1):
        cell = ws.cell(row=header_row, column=col_idx, value=h)
        cell.font = f_header
        cell.fill = fill_head
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
    ws.row_dimensions[header_row].height = 28

    # 3. Lignes de données
    current_row = 8
    for r in rows:
        nfac = str(r.get("nfacture") or "")
        dt = str(r.get("date_display") or "")
        client = str(r.get("ClientsVente") or "")
        nif = str(r.get("NIF") or "")
        rc = str(r.get("rcom") or "")
        ai = str(r.get("ai") or "")
        adr = str(r.get("adresse") or "")
        periode = str(r.get("Periode") or (f"{r.get('leMois') or ''} {r.get('Année') or ''}".strip()) or "")

        ht_val = _num(r.get("ht"))
        taux_val = _num(r.get("TauxTva") if r.get("TauxTva") is not None else 19)
        tva_val = _num(r.get("tvadroits"))
        ttc_val = _num(r.get("TTC")) or (ht_val + tva_val)

        row_values = [
            nfac, dt, client, nif, rc, ai, adr,
            periode, ht_val, f"{int(taux_val)}%", tva_val, ttc_val
        ]

        for col_idx, val in enumerate(row_values, start=1):
            cell = ws.cell(row=current_row, column=col_idx, value=val)
            cell.border = thin_border
            cell.font = f_data

            if col_idx in (1, 2, 4, 5, 6):
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.font = f_num
            elif col_idx == 8:
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.font = Font(name="Calibri", size=10, bold=True, color="006233")
                cell.fill = fill_periode
            elif col_idx in (9, 11, 12):
                cell.alignment = Alignment(horizontal="right", vertical="center")
                cell.font = f_num
                cell.number_format = '#,##0.00'
            elif col_idx == 10:
                cell.alignment = Alignment(horizontal="center", vertical="center")

        current_row += 1

    # 4. Ligne Total Général
    ws.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=8)
    total_lbl = ws.cell(row=current_row, column=1, value=f"TOTAL GÉNÉRAL ({len(rows)} factures) :")
    total_lbl.font = f_total
    total_lbl.fill = fill_total
    total_lbl.alignment = Alignment(horizontal="right", vertical="center")

    for col in range(1, 9):
        ws.cell(row=current_row, column=col).border = total_border
        ws.cell(row=current_row, column=col).fill = fill_total

    # Formules Somme Excel
    last_data_row = current_row - 1
    # HT
    c_ht = ws.cell(row=current_row, column=9, value=f"=SUM(I8:I{last_data_row})")
    c_ht.font = f_total
    c_ht.fill = fill_total
    c_ht.number_format = '#,##0.00'
    c_ht.border = total_border

    # Taux (vide)
    c_tx = ws.cell(row=current_row, column=10, value="—")
    c_tx.alignment = Alignment(horizontal="center", vertical="center")
    c_tx.font = f_total
    c_tx.fill = fill_total
    c_tx.border = total_border

    # TVA
    c_tva = ws.cell(row=current_row, column=11, value=f"=SUM(K8:K{last_data_row})")
    c_tva.font = f_total
    c_tva.fill = fill_total
    c_tva.number_format = '#,##0.00'
    c_tva.border = total_border

    # TTC
    c_ttc = ws.cell(row=current_row, column=12, value=f"=SUM(L8:L{last_data_row})")
    c_ttc.font = f_total
    c_ttc.fill = fill_total
    c_ttc.number_format = '#,##0.00'
    c_ttc.border = total_border

    ws.row_dimensions[current_row].height = 24

    # 5. Ajustement des largeurs de colonnes
    col_widths = {
        "A": 14, "B": 13, "C": 28, "D": 18, "E": 15, "F": 14,
        "G": 24, "H": 16, "I": 18, "J": 10, "K": 18, "L": 19
    }
    for col_letter, width in col_widths.items():
        ws.column_dimensions[col_letter].width = width

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(out_path))
