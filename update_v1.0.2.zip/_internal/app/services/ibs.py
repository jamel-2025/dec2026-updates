"""IBS — acomptes provisionnels and solde de liquidation.

Delphi: uMain page 2, Unit7 (acomptes, table IBSAcomptes), Unit45 (solde, table IBSsolde),
report RIbs (dataset RecapIBS = the solde of the exercice).

Rules (Unit45):
  * IBS per bracket = base × rate (capital 5 %, production 19 %, BTP/tourisme 23 %,
    commerce & services 26 %), with a minimum of 10 000 DA when the base is entered.
  * Deductions = excédent antérieur (previous exercice's excédent à reporter)
    + acomptes 1/2/3 (from IBSAcomptes) + acomptes non-résidents + crédit d'impôt.
  * Total IBS > deductions → solde de liquidation; otherwise excédent de versement.
"""
from __future__ import annotations

import sqlite3

from fastapi import HTTPException

from ..core.db import connect
from .g50 import Conflict, G50Error, _client, _next_id, _num, _r2

ACOMPTES = [("E1B80", "1er acompte"), ("E1B81", "2éme acompte"), ("E1B82", "3éme acompte")]
ACOMPTE_ALIASES = {"E1B80": ("1er acompte",), "E1B81": ("2éme acompte", "2eme acompte"), "E1B82": ("3éme acompte", "3eme acompte")}
MINIMUM = 10000.0
BRACKETS = [  # (base field, rate field, duties field, rate, label)
    ("Montantcapital", "TAux5", "droits5", 5, "Montant du capital social appelé"),
    ("ActivitésproductionBase", "ActivitésproductionTaux", "ActivitésproductionDroits", 19, "Activités de production de biens"),
    ("ActivitébâtimentBase", "ActivitébâtimentTaux", "ActivitébâtimentDroits", 23, "Activités de bâtiment, de travaux publics et d’hydraulique, et tourisme"),
    ("ActivitéscommerceBase", "ActivitéscommerceTaux", "ActivitéscommerceDroits", 26, "Activités de commerce et de services"),
]


def _code_of(row: dict) -> str | None:
    """Which acompte a row is (Unit45.Button1Click matches on impots or code)."""
    imp, code = str(row.get("impots") or "").strip().lower(), str(row.get("code") or "").strip().upper()
    for c, names in ACOMPTE_ALIASES.items():
        if code == c or imp in names or code.lower() in names:
            return c
    return None


# ------------------------------------------------------------------ acomptes
def acomptes(c: sqlite3.Connection, exercice: str) -> list[dict]:
    rows = [dict(r) for r in c.execute('SELECT * FROM IBSAcomptes WHERE CAST("Exercice" AS TEXT) = ? ORDER BY code, "ID"', (str(exercice),))]
    for r in rows:
        r["_id"] = r["ID"]
        r["_code"] = _code_of(r)
    return rows


def save_acompte(code: str, exercice: str, data: dict, acompte_id: int | None = None) -> dict:
    """Unit7: one acompte of each rank per exercice."""
    acode = str(data.get("code") or "").strip().upper()
    label = dict(ACOMPTES).get(acode)
    if not label:
        raise G50Error("Sélectionnez l’acompte (1er, 2ème ou 3ème)")
    base, taux = _num(data.get("Revenusimposables")), _num(data.get("taux"))
    droits = _num(data.get("droits")) if data.get("droits") not in (None, "") else base * taux / 100
    with connect(code) as c:
        for r in acomptes(c, exercice):
            if r["_code"] == acode and r["ID"] != acompte_id:
                raise Conflict(f"Le {label} existe déjà pour l’exercice {exercice}")
        cl = _client(c)
        idc = str(cl.get("IDclients") or "")
        values = {"code": acode, "impots": label, "Revenusimposables": _r2(base), "taux": taux, "droits": _r2(droits),
                  "Exercice": str(exercice), "IDclients": idc, "ClientExercice": f"{idc} {exercice}",
                  "codeacompte": f"{idc} {acode} {exercice}", "refacompte": label.split()[0]}
        if acompte_id is None:
            values["ID"] = _next_id(c, "IBSAcomptes", "ID")
            values["Idg50"] = 0
            c.execute(f'INSERT INTO IBSAcomptes ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        else:
            if not c.execute('SELECT 1 FROM IBSAcomptes WHERE "ID" = ?', (acompte_id,)).fetchone():
                raise HTTPException(404, "Acompte introuvable")
            c.execute(f'UPDATE IBSAcomptes SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} WHERE "ID" = ?',
                      (*values.values(), acompte_id))
        _sync_solde_acomptes(c, exercice)
    return state(code, exercice)


def delete_acompte(code: str, exercice: str, acompte_id: int) -> dict:
    with connect(code) as c:
        if not c.execute('DELETE FROM IBSAcomptes WHERE "ID" = ?', (acompte_id,)).rowcount:
            raise HTTPException(404, "Acompte introuvable")
        _sync_solde_acomptes(c, exercice)
    return state(code, exercice)


# ------------------------------------------------------------------ solde
def _solde_row(c: sqlite3.Connection, exercice: str) -> dict | None:
    r = c.execute('SELECT * FROM IBSsolde WHERE CAST("Exercice" AS TEXT) = ? ORDER BY "ID" LIMIT 1', (str(exercice),)).fetchone()
    return dict(r) if r else None


def _previous_excedent(c: sqlite3.Connection, exercice: str) -> float:
    prev = _solde_row(c, str(int(exercice) - 1))
    return _num(prev.get("Excédentversement")) if prev else 0.0


def _compute(v: dict) -> dict:
    """Unit45: brackets with the 10 000 DA minimum, deductions, solde / excédent."""
    out = dict(v)
    total = 0.0
    for base_f, rate_f, duty_f, rate, _ in BRACKETS:
        out[rate_f] = rate
        if v.get(base_f) in (None, "") or _num(v.get(base_f)) == 0:
            # no base: the duty may be entered directly (e.g. minimum d'imposition only)
            duty = _num(v.get(duty_f))
            out[duty_f] = round(duty) if duty else None
            total += duty
            continue
        duty = max(_num(v[base_f]) * rate / 100, MINIMUM)
        out[duty_f] = round(duty)
        total += duty
    ded = sum(_num(v.get(k)) for k in ("Excédentantérieur", "Acompte1", "Acompte2", "Acompte3", "Acomptesnonrésidentes", "Creditimpôt"))
    out["Montantglobaldéduire"] = round(ded)
    out["TOTALDROITSDUS"] = round(total)
    if total > ded:
        out["Soldedeliquidation"], out["Excédentversement"] = round(total - ded), None
    else:
        out["Soldedeliquidation"], out["Excédentversement"] = None, round(ded - total)
    return out


INPUTS = ("Résultattaxable", "Montantcapital", "ActivitésproductionBase", "ActivitébâtimentBase", "ActivitéscommerceBase",
          "droits5", "ActivitésproductionDroits", "ActivitébâtimentDroits", "ActivitéscommerceDroits",
          "Excédentantérieur", "Acompte1", "Acompte2", "Acompte3", "Acomptesnonrésidentes", "Creditimpôt", "MinimumImposition")


def _defaults(c: sqlite3.Connection, exercice: str) -> dict:
    """Unit45.Button1Click « Maj données antérieures »."""
    acs = {r["_code"]: _num(r["droits"]) for r in acomptes(c, exercice)}
    return {"Excédentantérieur": _previous_excedent(c, exercice), "Acompte1": acs.get("E1B80", 0.0),
            "Acompte2": acs.get("E1B81", 0.0), "Acompte3": acs.get("E1B82", 0.0)}


def _sync_solde_acomptes(c: sqlite3.Connection, exercice: str) -> None:
    """Keep the acomptes of an existing solde aligned with the acomptes table."""
    row = _solde_row(c, exercice)
    if row is None:
        return
    row.update({k: v for k, v in _defaults(c, exercice).items() if k != "Excédentantérieur"})
    _write(c, exercice, row, row["ID"])


def _write(c: sqlite3.Connection, exercice: str, values: dict, solde_id: int | None) -> None:
    v = _compute(values)
    cl = _client(c)
    idc = str(cl.get("IDclients") or "")
    v.update({"Exercice": int(exercice), "IDclients": idc, "ClientExercice": f"{idc} {exercice}",
              "ClientExerciceprecedent": f"{idc} {int(exercice) - 1}",
              "Codeacompte1": f"{idc} E1B80 {exercice}", "Codeacompte2": f"{idc} E1B81 {exercice}", "Codeacompte3": f"{idc} E1B82 {exercice}"})
    for k in INPUTS:
        if k in v and v[k] not in (None, ""):
            v[k] = round(_num(v[k]))
    cols = {r[1] for r in c.execute('PRAGMA table_info(IBSsolde)')}
    v = {k: val for k, val in v.items() if k in cols and k != "ID"}
    if solde_id is None:
        v["ID"] = _next_id(c, "IBSsolde", "ID")
        c.execute(f'INSERT INTO IBSsolde ({", ".join(chr(34) + k + chr(34) for k in v)}) VALUES ({", ".join("?" for _ in v)})', tuple(v.values()))
    else:
        c.execute(f'UPDATE IBSsolde SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in v)} WHERE "ID" = ?', (*v.values(), solde_id))


def save_solde(code: str, exercice: str, data: dict) -> dict:
    with connect(code) as c:
        row = _solde_row(c, exercice)
        values = dict(row or _defaults(c, exercice))
        for k in INPUTS:
            if k in data:
                values[k] = data[k]
        _write(c, exercice, values, row["ID"] if row else None)
    return state(code, exercice)


def refresh_solde(code: str, exercice: str) -> dict:
    """« Mettre à jour les données antérieures »: excédent N-1 and acomptes of the exercice."""
    with connect(code) as c:
        row = _solde_row(c, exercice)
        values = dict(row or {})
        values.update(_defaults(c, exercice))
        _write(c, exercice, values, row["ID"] if row else None)
    return state(code, exercice)


def delete_solde(code: str, exercice: str) -> dict:
    with connect(code) as c:
        if not c.execute('DELETE FROM IBSsolde WHERE CAST("Exercice" AS TEXT) = ?', (str(exercice),)).rowcount:
            raise HTTPException(404, "Aucun solde IBS à supprimer")
    return state(code, exercice)


def state(code: str, exercice: str) -> dict:
    with connect(code) as c:
        acs = acomptes(c, exercice)
        row = _solde_row(c, exercice)
        defaults = _defaults(c, exercice)
    solde = None
    if row:
        solde = {k: row.get(k) for k in row}
        solde["brackets"] = [{"base_field": b, "label": lbl, "rate": rate, "base": row.get(b), "droits": row.get(d)}
                             for b, _, d, rate, lbl in BRACKETS]
    return {"exercice": str(exercice), "acomptes": acs, "solde": solde, "defaults": defaults,
            "acompte_types": [{"code": c, "label": l} for c, l in ACOMPTES], "minimum": MINIMUM}
