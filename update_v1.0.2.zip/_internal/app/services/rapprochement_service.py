"""Service de Rapprochement Fiscal & Comptable et Détection de Risques.
Module d'audit de conformité :
1. Cadrage du Chiffre d'Affaires (CA G50 vs Ventes Comptables Comptes 70, TVA Collectée 4457).
2. Cadrage des Achats et Services (TVA Déductible Biens & Services vs Compte 44566 & Charges 38/60/61/62).
3. Cadrage des Équipements & Investissements (TVA Déductible Immobilisations vs Compte 44562 & Classe 2).
4. Cadrage de la Masse Salariale (Base Salaires IRG vs Charges Personnel Compte 63, IRG 4421).
5. Suivi du Précompte TVA et continuité mensuelle.
6. Détecteur intelligent d'anomalies fiscales et ratios de cohérence.
7. Évolution multi-annuelle et statistiques de croissance.
Note légale : La TAP a été définitivement supprimée par la LF 2024 et est totalement exclue.
"""
from __future__ import annotations

import io
import json
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..core.db import connect
from . import dates

MONTH_NAMES_FR = [
    "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
    "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
]

MONTH_NAMES_AR = [
    "جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان",
    "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
]


def _init_table(c: sqlite3.Connection) -> None:
    """Crée la table de persistance des écritures et ajustements comptables si absente."""
    c.execute("""
        CREATE TABLE IF NOT EXISTS RapprochementComptable (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            annee TEXT NOT NULL,
            mois INTEGER NOT NULL,
            ca_comptable REAL DEFAULT 0.0,
            tva_collectee_comptable REAL DEFAULT 0.0,
            achats_comptable REAL DEFAULT 0.0,
            tva_achats_comptable REAL DEFAULT 0.0,
            immo_comptable REAL DEFAULT 0.0,
            tva_immo_comptable REAL DEFAULT 0.0,
            salaires_comptable REAL DEFAULT 0.0,
            irg_comptable REAL DEFAULT 0.0,
            notes TEXT DEFAULT '',
            updated_at TEXT,
            UNIQUE(annee, mois)
        )
    """)
    c.commit()


def get_available_years(code: str) -> List[str]:
    """Retourne la liste ordonnée des années d'exercice disponibles dans le dossier."""
    years_set = set()
    with connect(code) as c:
        _init_table(c)
        try:
            for r in c.execute("SELECT DISTINCT Année FROM G50 WHERE Année IS NOT NULL AND TRIM(Année) != ''"):
                val = str(r[0]).strip()
                if val.isdigit() and len(val) == 4:
                    years_set.add(val)
        except Exception:
            pass

        try:
            for r in c.execute("SELECT DISTINCT annee FROM RapprochementComptable WHERE annee IS NOT NULL"):
                val = str(r[0]).strip()
                if val.isdigit() and len(val) == 4:
                    years_set.add(val)
        except Exception:
            pass

    curr_year = str(datetime.now().year)
    years_set.add(curr_year)
    # Trier par ordre décroissant
    return sorted(list(years_set), reverse=True)


def get_annual_rapprochement(code: str, annee: str) -> Dict[str, Any]:
    """Extrait le rapprochement fiscal/comptable complet pour les 12 mois de l'année."""
    annee_str = str(annee).strip()
    with connect(code) as c:
        _init_table(c)

        # 1. Infos Société
        soc_info = {}
        try:
            row_cli = c.execute("SELECT rs, activité, adresse, NIF, article, commune, RS_AR, Activite_AR FROM clients LIMIT 1").fetchone()
            if row_cli:
                soc_info = {
                    "rs": row_cli[0] or "Société",
                    "activite": row_cli[1] or "",
                    "adresse": row_cli[2] or "",
                    "nif": row_cli[3] or "",
                    "article": row_cli[4] or "",
                    "commune": row_cli[5] or "",
                    "rs_ar": row_cli[6] or row_cli[0] or "الشركة",
                    "activite_ar": row_cli[7] or row_cli[1] or "",
                }
        except Exception:
            pass

        # 2. Données G50
        g50_by_month: Dict[int, Dict[str, Any]] = {}
        try:
            cur = c.execute("""
                SELECT idg50, Mois, Année, leMois,
                       COALESCE(tvastsG, 0) as ca_g,
                       COALESCE(tvastsI, 0) as ca_i,
                       COALESCE(tvastse, 0) as ca_e,
                       COALESCE(tvastsd, 0) as tva_droits,
                       COALESCE(Totaldroits_dus, 0) as tva_collectee,
                       COALESCE(TTVAachatMatieres, 0) as tva_achats,
                       COALESCE(TVAbiensamortissables, 0) as tva_immo,
                       COALESCE(Précompte_antérieur, 0) as precompte_ant,
                       COALESCE(Précompte_à_reporter, 0) as precompte_rep,
                       COALESCE(TVA_à_payer, 0) as tva_payer,
                       COALESCE(st31, 0) + COALESCE(st32, 0) + COALESCE(st33, 0) as irg_g50
                FROM G50
                WHERE Année = ?
                ORDER BY CAST(Mois AS INTEGER)
            """, (annee_str,))
            for r in cur.fetchall():
                try:
                    m_idx = int(float(r[1]))
                    g50_by_month[m_idx] = {
                        "idg50": r[0],
                        "mois": m_idx,
                        "ca_g": float(r[4] or 0),
                        "ca_i": float(r[5] or 0),
                        "ca_e": float(r[6] or 0),
                        "tva_droits": float(r[7] or 0),
                        "tva_collectee": float(r[8] or 0),
                        "tva_achats": float(r[9] or 0),
                        "tva_immo": float(r[10] or 0),
                        "precompte_ant": float(r[11] or 0),
                        "precompte_rep": float(r[12] or 0),
                        "tva_payer": float(r[13] or 0),
                        "irg_g50": float(r[14] or 0),
                    }
                except Exception:
                    pass
        except Exception:
            pass

        # 3. Données Comptables enregistrées
        compta_by_month: Dict[int, Dict[str, Any]] = {}
        try:
            cur = c.execute("SELECT * FROM RapprochementComptable WHERE annee = ?", (annee_str,))
            cols = [col[0] for col in cur.description]
            for r in cur.fetchall():
                d = dict(zip(cols, r))
                m_idx = int(d["mois"])
                compta_by_month[m_idx] = d
        except Exception:
            pass

        # 4. Construction des 12 mois
        months_list: List[Dict[str, Any]] = []
        tot_ca_ht_g50 = tot_ca_ht_compta = 0.0
        tot_tva_coll_g50 = tot_tva_coll_compta = 0.0
        tot_tva_achats_g50 = tot_tva_achats_compta = 0.0
        tot_tva_immo_g50 = tot_tva_immo_compta = 0.0
        tot_salaires_g50 = tot_salaires_compta = 0.0
        tot_irg_g50 = tot_irg_compta = 0.0

        for m in range(1, 13):
            g = g50_by_month.get(m, {})
            idg50 = g.get("idg50")
            cp = compta_by_month.get(m, {})

            # Ventilation TVA
            ca_19 = ca_9 = ca_exo = 0.0
            tva_19 = tva_9 = 0.0
            if idg50:
                try:
                    for tr in c.execute("SELECT TAUX, SUM(CAI), SUM(CAE), SUM(DROITS) FROM TVA WHERE Idg50 = ? GROUP BY TAUX", (idg50,)).fetchall():
                        tx = float(tr[0] or 0)
                        if abs(tx - 19) < 0.5:
                            ca_19 = float(tr[1] or 0)
                            tva_19 = float(tr[3] or 0)
                        elif abs(tx - 9) < 0.5:
                            ca_9 = float(tr[1] or 0)
                            tva_9 = float(tr[3] or 0)
                        ca_exo += float(tr[2] or 0)
                except Exception:
                    pass

            ca_total_ht = ca_19 + ca_9 + ca_exo
            if ca_total_ht == 0.0 and g.get("ca_g"):
                ca_total_ht = float(g.get("ca_g") or 0)

            tva_coll = tva_19 + tva_9
            if tva_coll == 0.0 and g.get("tva_collectee"):
                tva_coll = float(g.get("tva_collectee") or 0)

            ca_ttc = ca_total_ht + tva_coll

            # IRG Salaires
            base_sal = 0.0
            irg_sal = 0.0
            if idg50:
                try:
                    row_irg = c.execute("SELECT SUM(Revenusimposables), SUM(droits) FROM IRGSalaires WHERE Idg50 = ?", (idg50,)).fetchone()
                    if row_irg and row_irg[0] is not None:
                        base_sal = float(row_irg[0] or 0)
                        irg_sal = float(row_irg[1] or 0)
                except Exception:
                    pass
            if irg_sal == 0.0 and g.get("irg_g50"):
                irg_sal = float(g.get("irg_g50") or 0)

            # TVA Achats & Immo
            tva_achats_val = float(g.get("tva_achats") or 0)
            tva_immo_val = float(g.get("tva_immo") or 0)
            if idg50 and (tva_achats_val == 0.0 and tva_immo_val == 0.0):
                try:
                    for dr in c.execute("SELECT tvadroits, NATURE FROM DetailEtatTVA WHERE IDg50 = ?", (idg50,)).fetchall():
                        v = float(dr[0] or 0)
                        nat = str(dr[1] or "").lower()
                        if "amort" in nat or "invest" in nat or "équip" in nat:
                            tva_immo_val += v
                        else:
                            tva_achats_val += v
                except Exception:
                    pass

            # Valeurs Comptables
            ca_compta = float(cp.get("ca_comptable") or 0)
            tva_coll_compta = float(cp.get("tva_collectee_comptable") or 0)
            achats_compta = float(cp.get("achats_comptable") or 0)
            tva_achats_compta = float(cp.get("tva_achats_comptable") or 0)
            immo_compta = float(cp.get("immo_comptable") or 0)
            tva_immo_compta = float(cp.get("tva_immo_comptable") or 0)
            salaires_compta = float(cp.get("salaires_comptable") or 0)
            irg_compta = float(cp.get("irg_comptable") or 0)
            notes_val = str(cp.get("notes") or "")

            # Écarts (Fiscal - Comptable)
            ecart_ca = round(ca_total_ht - ca_compta, 2)
            ecart_tva_coll = round(tva_coll - tva_coll_compta, 2)
            ecart_tva_achats = round(tva_achats_val - tva_achats_compta, 2)
            ecart_tva_immo = round(tva_immo_val - tva_immo_compta, 2)
            ecart_salaires = round(base_sal - salaires_compta, 2)
            ecart_irg = round(irg_sal - irg_compta, 2)

            # Qualification statut
            has_compta = (ca_compta > 0 or tva_coll_compta > 0 or tva_achats_compta > 0 or salaires_compta > 0)
            if not has_compta and not idg50:
                statut = "vide"
            elif not has_compta and idg50:
                statut = "g50_seul"
            elif abs(ecart_ca) < 1.0 and abs(ecart_tva_coll) < 1.0 and abs(ecart_tva_achats) < 1.0 and abs(ecart_salaires) < 1.0:
                statut = "conforme"
            elif abs(ecart_ca) <= 1000.0 and abs(ecart_tva_coll) <= 200.0:
                statut = "acceptable"
            else:
                statut = "anomalie"

            # Ratios mensuels
            ratio_sal_ca = round((base_sal / ca_total_ht * 100.0), 2) if ca_total_ht > 0 else 0.0

            m_data = {
                "mois": m,
                "mois_nom_fr": MONTH_NAMES_FR[m - 1],
                "mois_nom_ar": MONTH_NAMES_AR[m - 1],
                "has_g50": bool(idg50),
                "idg50": idg50,
                # G50
                "ca_19": ca_19,
                "ca_9": ca_9,
                "ca_exo": ca_exo,
                "ca_total_ht": ca_total_ht,
                "tva_collectee": tva_coll,
                "ca_ttc": ca_ttc,
                "tva_achats": tva_achats_val,
                "tva_immo": tva_immo_val,
                "precompte_ant": float(g.get("precompte_ant") or 0),
                "precompte_rep": float(g.get("precompte_rep") or 0),
                "tva_payer": float(g.get("tva_payer") or 0),
                "base_salaires": base_sal,
                "irg_salaires": irg_sal,
                # Comptable
                "ca_comptable": ca_compta,
                "tva_collectee_comptable": tva_coll_compta,
                "achats_comptable": achats_compta,
                "tva_achats_comptable": tva_achats_compta,
                "immo_comptable": immo_compta,
                "tva_immo_comptable": tva_immo_compta,
                "salaires_comptable": salaires_compta,
                "irg_comptable": irg_compta,
                "notes": notes_val,
                # Écarts
                "ecart_ca": ecart_ca,
                "ecart_tva_coll": ecart_tva_coll,
                "ecart_tva_achats": ecart_tva_achats,
                "ecart_tva_immo": ecart_tva_immo,
                "ecart_salaires": ecart_salaires,
                "ecart_irg": ecart_irg,
                # Statut & Ratios
                "statut": statut,
                "ratio_sal_ca": ratio_sal_ca,
            }
            months_list.append(m_data)

            # Cumuls
            tot_ca_ht_g50 += ca_total_ht
            tot_ca_ht_compta += ca_compta
            tot_tva_coll_g50 += tva_coll
            tot_tva_coll_compta += tva_coll_compta
            tot_tva_achats_g50 += tva_achats_val
            tot_tva_achats_compta += tva_achats_compta
            tot_tva_immo_g50 += tva_immo_val
            tot_tva_immo_compta += tva_immo_compta
            tot_salaires_g50 += base_sal
            tot_salaires_compta += salaires_compta
            tot_irg_g50 += irg_sal
            tot_irg_compta += irg_compta

        # 5. Alertes & Détection intelligente d'anomalies fiscales
        alerts: List[Dict[str, str]] = []
        for m_obj in months_list:
            m_num = m_obj["mois"]
            m_label = m_obj["mois_nom_fr"]
            # 1. Salaires sans CA
            if m_obj["base_salaires"] > 0 and m_obj["ca_total_ht"] == 0.0 and m_obj["has_g50"]:
                alerts.append({
                    "type": "warning",
                    "code": "SALAIRES_SANS_CA",
                    "mois": m_num,
                    "message_fr": f"{m_label} : Salaires déclarés ({m_obj['base_salaires']:,.2f} DA) avec Chiffre d'Affaires nul.",
                    "message_ar": f"{m_obj['mois_nom_ar']} : كتلة أجور مصرح بها ({m_obj['base_salaires']:,.2f} دج) مع رقم أعمال منعدم.",
                    "gravite": "Moyenne",
                })
            # 2. Rupture de précompte
            if m_num > 1:
                prev_m = months_list[m_num - 2]
                if prev_m["has_g50"] and m_obj["has_g50"]:
                    prev_rep = prev_m["precompte_rep"]
                    curr_ant = m_obj["precompte_ant"]
                    if abs(prev_rep - curr_ant) > 1.0 and (prev_rep > 0 or curr_ant > 0):
                        alerts.append({
                            "type": "danger",
                            "code": "RUPTURE_PRECOMPTE",
                            "mois": m_num,
                            "message_fr": f"{m_label} : Rupture du précompte TVA reporté ({prev_rep:,.2f} DA) vs antérieur ({curr_ant:,.2f} DA).",
                            "message_ar": f"{m_obj['mois_nom_ar']} : انقطاع في رصيد الرسم المنقول ({prev_rep:,.2f} دج مقابل السابق {curr_ant:,.2f} دج).",
                            "gravite": "Haute",
                        })
            # 3. Écart significatif de CA
            if abs(m_obj["ecart_ca"]) > 50000.0:
                alerts.append({
                    "type": "danger",
                    "code": "ECART_CA_SIGNIFICATIF",
                    "mois": m_num,
                    "message_fr": f"{m_label} : Écart important de CA HT ({m_obj['ecart_ca']:+,.2f} DA) entre G50 et Comptabilité.",
                    "message_ar": f"{m_obj['mois_nom_ar']} : فارق كبير في رقم الأعمال ({m_obj['ecart_ca']:+,.2f} دج) بين التصريح والمحاسبة.",
                    "gravite": "Critique",
                })
            # 4. Écart TVA Déductible Achats
            if abs(m_obj["ecart_tva_achats"]) > 10000.0:
                alerts.append({
                    "type": "warning",
                    "code": "ECART_TVA_ACHATS",
                    "mois": m_num,
                    "message_fr": f"{m_label} : Écart de TVA Déductible sur Achats ({m_obj['ecart_tva_achats']:+,.2f} DA).",
                    "message_ar": f"{m_obj['mois_nom_ar']} : فارق في الرسم المسترجع على المشتريات ({m_obj['ecart_tva_achats']:+,.2f} دج).",
                    "gravite": "Moyenne",
                })

        # 6. Totaux & Ratios Annuels
        tot_ecart_ca = round(tot_ca_ht_g50 - tot_ca_ht_compta, 2)
        tot_ecart_tva_coll = round(tot_tva_coll_g50 - tot_tva_coll_compta, 2)
        tot_ecart_tva_achats = round(tot_tva_achats_g50 - tot_tva_achats_compta, 2)
        tot_ecart_tva_immo = round(tot_tva_immo_g50 - tot_tva_immo_compta, 2)
        tot_ecart_salaires = round(tot_salaires_g50 - tot_salaires_compta, 2)
        tot_ecart_irg = round(tot_irg_g50 - tot_irg_compta, 2)

        ratio_sal_ca_annual_g50 = round((tot_salaires_g50 / tot_ca_ht_g50 * 100.0), 2) if tot_ca_ht_g50 > 0 else 0.0
        ratio_sal_ca_annual_compta = round((tot_salaires_compta / tot_ca_ht_compta * 100.0), 2) if tot_ca_ht_compta > 0 else 0.0

        conforme_count = sum(1 for m in months_list if m["statut"] == "conforme")
        mois_actifs = sum(1 for m in months_list if m["has_g50"] or m["ca_comptable"] > 0)
        taux_conformite = round((conforme_count / mois_actifs * 100.0), 1) if mois_actifs > 0 else 100.0

        return {
            "dossier": code,
            "annee": annee_str,
            "societe": soc_info,
            "mois": months_list,
            "totaux": {
                "ca_ht_g50": tot_ca_ht_g50,
                "ca_ht_compta": tot_ca_ht_compta,
                "ecart_ca": tot_ecart_ca,
                "tva_coll_g50": tot_tva_coll_g50,
                "tva_coll_compta": tot_tva_coll_compta,
                "ecart_tva_coll": tot_ecart_tva_coll,
                "tva_achats_g50": tot_tva_achats_g50,
                "tva_achats_compta": tot_tva_achats_compta,
                "ecart_tva_achats": tot_ecart_tva_achats,
                "tva_immo_g50": tot_tva_immo_g50,
                "tva_immo_compta": tot_tva_immo_compta,
                "ecart_tva_immo": tot_ecart_tva_immo,
                "salaires_g50": tot_salaires_g50,
                "salaires_compta": tot_salaires_compta,
                "ecart_salaires": tot_ecart_salaires,
                "irg_g50": tot_irg_g50,
                "irg_compta": tot_irg_compta,
                "ecart_irg": tot_ecart_irg,
            },
            "kpis": {
                "taux_conformite": taux_conformite,
                "ratio_salaires_ca_g50": ratio_sal_ca_annual_g50,
                "ratio_salaires_ca_compta": ratio_sal_ca_annual_compta,
                "total_deductions_tva_g50": tot_tva_achats_g50 + tot_tva_immo_g50,
                "mois_avec_declarations": sum(1 for m in months_list if m["has_g50"]),
                "anomalies_count": len([a for a in alerts if a["type"] == "danger"]),
                "avertissements_count": len([a for a in alerts if a["type"] == "warning"]),
            },
            "alertes": alerts,
        }


def save_month_comptable(code: str, annee: str, mois: int, data: Dict[str, Any]) -> bool:
    """Enregistre ou met à jour les données comptables pour un mois donné."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with connect(code) as c:
        _init_table(c)
        c.execute("""
            INSERT INTO RapprochementComptable (
                annee, mois, ca_comptable, tva_collectee_comptable,
                achats_comptable, tva_achats_comptable, immo_comptable,
                tva_immo_comptable, salaires_comptable, irg_comptable,
                notes, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(annee, mois) DO UPDATE SET
                ca_comptable = excluded.ca_comptable,
                tva_collectee_comptable = excluded.tva_collectee_comptable,
                achats_comptable = excluded.achats_comptable,
                tva_achats_comptable = excluded.tva_achats_comptable,
                immo_comptable = excluded.immo_comptable,
                tva_immo_comptable = excluded.tva_immo_comptable,
                salaires_comptable = excluded.salaires_comptable,
                irg_comptable = excluded.irg_comptable,
                notes = excluded.notes,
                updated_at = excluded.updated_at
        """, (
            str(annee).strip(),
            int(mois),
            float(data.get("ca_comptable") or 0.0),
            float(data.get("tva_collectee_comptable") or 0.0),
            float(data.get("achats_comptable") or 0.0),
            float(data.get("tva_achats_comptable") or 0.0),
            float(data.get("immo_comptable") or 0.0),
            float(data.get("tva_immo_comptable") or 0.0),
            float(data.get("salaires_comptable") or 0.0),
            float(data.get("irg_comptable") or 0.0),
            str(data.get("notes") or "").strip(),
            now_str,
        ))
        c.commit()
    return True


def save_bulk_comptable(code: str, annee: str, months_data: List[Dict[str, Any]]) -> bool:
    """Enregistre en masse les 12 mois pour une année donnée."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    annee_str = str(annee).strip()
    with connect(code) as c:
        _init_table(c)
        for item in months_data:
            mois = int(item.get("mois", 1))
            c.execute("""
                INSERT INTO RapprochementComptable (
                    annee, mois, ca_comptable, tva_collectee_comptable,
                    achats_comptable, tva_achats_comptable, immo_comptable,
                    tva_immo_comptable, salaires_comptable, irg_comptable,
                    notes, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(annee, mois) DO UPDATE SET
                    ca_comptable = excluded.ca_comptable,
                    tva_collectee_comptable = excluded.tva_collectee_comptable,
                    achats_comptable = excluded.achats_comptable,
                    tva_achats_comptable = excluded.tva_achats_comptable,
                    immo_comptable = excluded.immo_comptable,
                    tva_immo_comptable = excluded.tva_immo_comptable,
                    salaires_comptable = excluded.salaires_comptable,
                    irg_comptable = excluded.irg_comptable,
                    notes = excluded.notes,
                    updated_at = excluded.updated_at
            """, (
                annee_str,
                mois,
                float(item.get("ca_comptable") or 0.0),
                float(item.get("tva_collectee_comptable") or 0.0),
                float(item.get("achats_comptable") or 0.0),
                float(item.get("tva_achats_comptable") or 0.0),
                float(item.get("immo_comptable") or 0.0),
                float(item.get("tva_immo_comptable") or 0.0),
                float(item.get("salaires_comptable") or 0.0),
                float(item.get("irg_comptable") or 0.0),
                str(item.get("notes") or "").strip(),
                now_str,
            ))
        c.commit()
    return True


def get_multiyear_trends(code: str) -> List[Dict[str, Any]]:
    """Retourne l'historique et les tendances multi-annuelles (Évolution CA, Salaires, Achats, Équipements)."""
    years = get_available_years(code)
    trends: List[Dict[str, Any]] = []

    for y in reversed(years):
        data = get_annual_rapprochement(code, y)
        tot = data["totaux"]
        kp = data["kpis"]
        trends.append({
            "annee": y,
            "ca_g50": tot["ca_ht_g50"],
            "ca_compta": tot["ca_ht_compta"],
            "tva_collectee": tot["tva_coll_g50"],
            "tva_achats": tot["tva_achats_g50"],
            "tva_immo": tot["tva_immo_g50"],
            "salaires_g50": tot["salaires_g50"],
            "salaires_compta": tot["salaires_compta"],
            "irg_g50": tot["irg_g50"],
            "ratio_salaires_ca": kp["ratio_salaires_ca_g50"],
            "taux_conformite": kp["taux_conformite"],
            "mois_actifs": kp["mois_avec_declarations"],
        })

    return trends


def get_multiyear_range_analysis(code: str, start_year: str, end_year: str) -> Dict[str, Any]:
    """Analyse pluriannuelle complète entre l'année A et l'année B avec taux de croissance et ratios."""
    try:
        y1 = int(start_year)
        y2 = int(end_year)
    except Exception:
        y1, y2 = 2021, 2025

    y_min, y_max = min(y1, y2), max(y1, y2)
    range_years = [str(y) for y in range(y_min, y_max + 1)]

    annual_items: List[Dict[str, Any]] = []
    tot_ca = tot_salaires = tot_tva_achats = tot_tva_immo = tot_tva_coll = 0.0

    prev_ca: Optional[float] = None
    prev_sal: Optional[float] = None

    for y in range_years:
        ann_data = get_annual_rapprochement(code, y)
        tot = ann_data["totaux"]
        kp = ann_data["kpis"]

        ca = float(tot["ca_ht_g50"] or 0)
        sal = float(tot["salaires_g50"] or 0)
        tva_c = float(tot["tva_coll_g50"] or 0)
        tva_a = float(tot["tva_achats_g50"] or 0)
        tva_i = float(tot["tva_immo_g50"] or 0)

        # Variations annuelles
        var_ca_pct = round(((ca - prev_ca) / prev_ca * 100.0), 1) if (prev_ca is not None and prev_ca > 0) else None
        var_sal_pct = round(((sal - prev_sal) / prev_sal * 100.0), 1) if (prev_sal is not None and prev_sal > 0) else None

        annual_items.append({
            "annee": y,
            "ca_g50": ca,
            "ca_compta": float(tot["ca_ht_compta"] or 0),
            "ecart_ca": float(tot["ecart_ca"] or 0),
            "tva_collectee": tva_c,
            "tva_achats": tva_a,
            "tva_immo": tva_i,
            "salaires_g50": sal,
            "salaires_compta": float(tot["salaires_compta"] or 0),
            "irg_g50": float(tot["irg_g50"] or 0),
            "ratio_salaires_ca": kp["ratio_salaires_ca_g50"],
            "taux_conformite": kp["taux_conformite"],
            "mois_avec_declarations": kp["mois_avec_declarations"],
            "var_ca_pct": var_ca_pct,
            "var_sal_pct": var_sal_pct,
        })

        tot_ca += ca
        tot_salaires += sal
        tot_tva_coll += tva_c
        tot_tva_achats += tva_a
        tot_tva_immo += tva_i

        prev_ca = ca
        prev_sal = sal

    # Croissance globale sur la période
    first_ca = annual_items[0]["ca_g50"] if annual_items else 0.0
    last_ca = annual_items[-1]["ca_g50"] if annual_items else 0.0
    croissance_globale_ca = round(((last_ca - first_ca) / first_ca * 100.0), 1) if first_ca > 0 else 0.0

    nb_years = len(annual_items) or 1
    moy_ca = round(tot_ca / nb_years, 2)
    moy_sal = round(tot_salaires / nb_years, 2)
    moy_ratio_sal_ca = round((tot_salaires / tot_ca * 100.0), 2) if tot_ca > 0 else 0.0

    return {
        "dossier": code,
        "periode": f"{y_min} - {y_max}",
        "annee_debut": str(y_min),
        "annee_fin": str(y_max),
        "annees": annual_items,
        "totaux_periode": {
            "ca_total": tot_ca,
            "salaires_total": tot_salaires,
            "tva_collectee_total": tot_tva_coll,
            "tva_achats_total": tot_tva_achats,
            "tva_immo_total": tot_tva_immo,
            "moyenne_ca": moy_ca,
            "moyenne_salaires": moy_sal,
            "croissance_globale_ca": croissance_globale_ca,
            "ratio_moyen_salaires_ca": moy_ratio_sal_ca,
        }
    }


def export_rapprochement_excel(code: str, annee: str) -> bytes:
    """Génère un classeur Excel officiel de cadrage fiscal et de rapprochement comptable."""
    data = get_annual_rapprochement(code, annee)
    soc = data["societe"]
    tot = data["totaux"]

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"Cadrage {annee}"
    ws.views.sheetView[0].showGridLines = True

    # Styles
    navy_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    header_fill = PatternFill(start_color="2563EB", end_color="2563EB", fill_type="solid")
    sub_fill = PatternFill(start_color="E0E7FF", end_color="E0E7FF", fill_type="solid")
    tot_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    thin_border = Border(
        left=Side(style='thin', color='CBD5E1'),
        right=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='CBD5E1'),
        bottom=Side(style='thin', color='CBD5E1')
    )
    title_font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    h_font = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    bold_font = Font(name="Calibri", size=10, bold=True)
    norm_font = Font(name="Calibri", size=10)

    # Titre
    ws.merge_cells("A1:K1")
    title_cell = ws["A1"]
    title_cell.value = f"CADRAGE FISCAL & RAPPROCHEMENT COMPTABLE — EXERCICE {annee}"
    title_cell.fill = navy_fill
    title_cell.font = title_font
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 35

    # En-tête Société
    ws["A2"] = f"Société : {soc.get('rs', '')} | NIF : {soc.get('nif', '')} | Article : {soc.get('article', '')}"
    ws["A2"].font = bold_font
    ws.row_dimensions[2].height = 20

    # Headers
    headers = [
        "Mois", "CA HT (G50)", "CA HT (Compta)", "Écart CA",
        "TVA Coll. (G50)", "TVA Déd. Achats", "TVA Déd. Invest.",
        "Précompte Reporté", "Masse Salariale (G50)", "Masse Salariale (Compta)", "Statut"
    ]
    for col_idx, h_text in enumerate(headers, 1):
        cell = ws.cell(row=4, column=col_idx, value=h_text)
        cell.fill = header_fill
        cell.font = h_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
    ws.row_dimensions[4].height = 28

    # Lignes des 12 mois
    row_idx = 5
    for m in data["mois"]:
        ws.cell(row=row_idx, column=1, value=m["mois_nom_fr"]).font = bold_font
        ws.cell(row=row_idx, column=2, value=m["ca_total_ht"]).number_format = "#,##0.00"
        ws.cell(row=row_idx, column=3, value=m["ca_comptable"]).number_format = "#,##0.00"

        c_ecart = ws.cell(row=row_idx, column=4, value=m["ecart_ca"])
        c_ecart.number_format = "+#,##0.00;-#,##0.00;0.00"
        if abs(m["ecart_ca"]) > 1.0:
            c_ecart.font = Font(name="Calibri", size=10, bold=True, color="DC2626")

        ws.cell(row=row_idx, column=5, value=m["tva_collectee"]).number_format = "#,##0.00"
        ws.cell(row=row_idx, column=6, value=m["tva_achats"]).number_format = "#,##0.00"
        ws.cell(row=row_idx, column=7, value=m["tva_immo"]).number_format = "#,##0.00"
        ws.cell(row=row_idx, column=8, value=m["precompte_rep"]).number_format = "#,##0.00"
        ws.cell(row=row_idx, column=9, value=m["base_salaires"]).number_format = "#,##0.00"
        ws.cell(row=row_idx, column=10, value=m["salaires_comptable"]).number_format = "#,##0.00"

        statut_fr = "Conforme" if m["statut"] == "conforme" else ("Anomalie" if m["statut"] == "anomalie" else "G50 seul")
        c_st = ws.cell(row=row_idx, column=11, value=statut_fr)
        c_st.alignment = Alignment(horizontal="center")

        for c_idx in range(1, 12):
            ws.cell(row=row_idx, column=c_idx).border = thin_border
            if c_idx > 1 and c_idx < 11:
                ws.cell(row=row_idx, column=c_idx).font = norm_font
        row_idx += 1

    # Ligne Total Annuel
    tot_row = row_idx
    ws.cell(row=tot_row, column=1, value="TOTAL ANNUEL").font = bold_font
    ws.cell(row=tot_row, column=2, value=tot["ca_ht_g50"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=3, value=tot["ca_ht_compta"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=4, value=tot["ecart_ca"]).number_format = "+#,##0.00;-#,##0.00;0.00"
    ws.cell(row=tot_row, column=5, value=tot["tva_coll_g50"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=6, value=tot["tva_achats_g50"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=7, value=tot["tva_immo_g50"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=8, value=data["mois"][-1]["precompte_rep"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=9, value=tot["salaires_g50"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=10, value=tot["salaires_compta"]).number_format = "#,##0.00"
    ws.cell(row=tot_row, column=11, value=f"{data['kpis']['taux_conformite']}% Conforme").alignment = Alignment(horizontal="center")

    for c_idx in range(1, 12):
        cell = ws.cell(row=tot_row, column=c_idx)
        cell.fill = tot_fill
        cell.font = bold_font
        cell.border = thin_border
    ws.row_dimensions[tot_row].height = 24

    # Largeurs de colonnes
    col_widths = [15, 18, 18, 16, 17, 17, 17, 18, 22, 22, 14]
    for idx, width in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
