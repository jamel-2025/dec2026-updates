"""Factures de vente — Delphi uMain.N4Click (F-vente), Unit43 (état annuel), Unit40 (facture),
Unit44 (impression, embedded report ReportSales). Table FacturesVentes.

Rules (Unit40):
  * required: n° facture, date, client, HT; TVA = HT × taux / 100, TTC = HT + TVA;
  * an invoice number can be entered only once per client (numbers compared without
    leading zeros, case-insensitive) — message « facture déjà saisie en mois de … »;
  * month / year attached to the invoice and link to the G50 of that month (IDg50).
Logical choice: the month is the month of the invoice date unless one is given.
"""
from __future__ import annotations

import sqlite3

from fastapi import HTTPException

from ..core.db import connect
from . import dates, ref
from .g50 import Conflict, G50Error, _next_id, _num


def _norm(no: str) -> str:
    s = str(no or "").strip()
    return str(int(s)) if s.isdigit() else s.upper()


def _rows(c: sqlite3.Connection, annee: str) -> list[dict]:
    query = """
        SELECT 
            f.*,
            COALESCE(c.NIF, '') AS NIF,
            COALESCE(c.rcom, '') AS rcom,
            COALESCE(c.ai, '') AS ai,
            COALESCE(c.adresse, '') AS adresse,
            COALESCE(c.activité, '') AS activite,
            COALESCE(c.rs, f.ClientsVente) AS client_rs
        FROM FacturesVentes f
        LEFT JOIN ClientrVentes c 
            ON (f.IDClentventes IS NOT NULL AND f.IDClentventes = c.IDclientvente)
            OR (f.IDClentventes IS NULL AND UPPER(TRIM(f.ClientsVente)) = UPPER(TRIM(c.rs)))
        WHERE f."Année" = ? OR (COALESCE(f."Année", '') = '' AND substr(f.datrfature, 1, 4) = ?)
        ORDER BY f.datrfature, f."IDFacturesVente"
    """
    rows = [dict(r) for r in c.execute(query, (str(annee), str(annee)))]
    for r in rows:
        r["_id"] = r["IDFacturesVente"]
        r["date_display"] = dates.to_display(r.get("datrfature"))
        m = str(r.get("leMois") or "").strip()
        a = str(r.get("Année") or "").strip()
        r["Periode"] = f"{m} {a}".strip() if (m or a) else ""
    return rows


def list_(code: str, annee: str, mois: str = "", q: str = "") -> dict:
    with connect(code) as c:
        rows = _rows(c, annee)
    months = [m["LeMois"] for m in ref.table("Mois")]
    if mois:
        rows = [r for r in rows if str(r.get("leMois") or "") == mois]
    if q:
        ql = q.lower()
        rows = [r for r in rows if ql in str(r.get("ClientsVente") or "").lower() or ql in str(r.get("nfacture") or "").lower()]
    tot = lambda k: sum(_num(r.get(k)) for r in rows)
    return {"items": rows, "months": months, "totals": {"ht": tot("ht"), "tva": tot("tvadroits"), "ttc": tot("TTC")}}


def save(code: str, data: dict, item_id: int | None = None) -> dict:
    for k, msg in (("nfacture", "Veuillez saisir le numéro de facture"), ("datrfature", "Veuillez saisir la date de facture"),
                   ("ClientsVente", "Veuillez saisir le client"), ("ht", "Veuillez saisir le montant HT")):
        if data.get(k) in (None, ""):
            raise G50Error(msg)
    date_iso = dates.to_storage(data["datrfature"])
    d = dates.parse(date_iso)
    ht = _num(data["ht"])
    taux = _num(data.get("TauxTva") if data.get("TauxTva") not in (None, "") else 19)
    tva = ht * taux / 100
    mois = str(data.get("leMois") or ref.mois_label(d.month))
    annee = str(data.get("Année") or d.year)
    client = str(data["ClientsVente"]).strip()
    with connect(code) as c:
        for r in c.execute('SELECT "IDFacturesVente", nfacture, "leMois", "Année" FROM FacturesVentes '
                           'WHERE UPPER(TRIM("ClientsVente")) = UPPER(?)', (client,)):
            if r[0] != item_id and _norm(r[1]) == _norm(data["nfacture"]):
                raise Conflict(f"Facture déjà saisie au mois de {(r[2] or '')} {(r[3] or '')}".strip())
        g = c.execute('SELECT idg50 FROM G50 WHERE "leMois" = ? AND "Année" = ?', (mois, annee)).fetchone()
        values = {"nfacture": str(data["nfacture"]).strip(), "datrfature": date_iso, "ClientsVente": client,
                  "IDClentventes": data.get("IDClentventes") or None, "ht": round(ht, 2), "TauxTva": int(taux),
                  "tvadroits": round(tva, 2), "TTC": round(ht + tva, 2), "leMois": mois, "Année": annee,
                  "IDg50": g[0] if g else None}
        if item_id is None:
            values["IDFacturesVente"] = _next_id(c, "FacturesVentes", "IDFacturesVente")
            c.execute(f'INSERT INTO FacturesVentes ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
            item_id = values["IDFacturesVente"]
        elif not c.execute(f'UPDATE FacturesVentes SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} '
                           'WHERE "IDFacturesVente" = ?', (*values.values(), item_id)).rowcount:
            raise HTTPException(404, "Facture introuvable")
    return {"id": item_id, "annee": annee, "leMois": mois}


def delete(code: str, item_id: int) -> None:
    with connect(code) as c:
        if not c.execute('DELETE FROM FacturesVentes WHERE "IDFacturesVente" = ?', (item_id,)).rowcount:
            raise HTTPException(404, "Facture introuvable")
