"""Shared reference tables (Delphi DM.UniCRef = DB\\Ref.mdb), read-only."""
from __future__ import annotations

import sqlite3
from functools import lru_cache

from fastapi import HTTPException

from ..core import config


def _conn() -> sqlite3.Connection:
    if not config.REF_DB.is_file():
        raise HTTPException(500, "Base de référence absente (lancer tools/import_ref.py)")
    c = sqlite3.connect(f"file:{config.REF_DB}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    return c


@lru_cache(maxsize=64)
def _rows(table: str, order: str) -> tuple[dict, ...]:
    c = _conn()
    try:
        return tuple(dict(r) for r in c.execute(f'SELECT * FROM "{table}" ORDER BY {order}'))
    finally:
        c.close()


def table(table: str) -> list[dict]:
    order = {
        "TVAref": '"N"', "TAPRef": '"N"', "TlsRef": '"N"', "IRGIBSRef": '"N", "CODE"',
        "AutresTaxesRef": 'rowid', "TauxTVA": '"TAUX"', "naturededction": '"IDNATUREDEDCTION"', "Mois": '"MOIS"',
    }.get(table, "rowid")
    return [dict(r) for r in _rows(table, order)]


def find(table_name: str, column: str, value) -> dict | None:
    v = str(value or "").strip()
    for r in table(table_name):
        if str(r.get(column) or "").strip() == v:
            return r
    return None


def mois_label(mois: int) -> str:
    r = find("Mois", "MOIS", float(mois))
    if r is None:
        r = next((x for x in table("Mois") if int(x["MOIS"]) == int(mois)), None)
    return (r or {}).get("LeMois") or str(mois)


def clear_cache():
    _rows.cache_clear()
