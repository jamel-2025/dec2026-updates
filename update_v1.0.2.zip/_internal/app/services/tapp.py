"""TAPP-TFP — taxe d'apprentissage (TA) et taxe de formation professionnelle (TFP), annual
declaration per semester. Delphi: uMain page 3, Unit11 (Form11), table DeclarationTAPP,
report RTAPP.fr3 (loaded from Rapports).

Rules (Unit11 + form wording):
  * Formation (annexe II): exempt below 20 employees; ratio (I) = dépenses / masse salariale,
    taux applicable = 1 % − (I), droits = masse × taux.
  * Apprentissage (annexe III): same computation with the apprenticeship expenses.
  * Total des droits = droits TF + droits TA. One declaration per semester and exercice.
Correction: Delphi subtracted the ratio as a fraction from 1 % (e.g. 0.2 % → 1 − 0.002); the
ratio is expressed in % here, as the form label « Taux applicable (1% − (I)) » states.
"""
from __future__ import annotations

import sqlite3

from fastapi import HTTPException

from ..core.db import connect
from . import dates
from .g50 import Conflict, G50Error, _client, _next_id, _num

PERIODS = ["1er Semestre", "2éme Semestre"]
TF_FIELDS = ["Fraispédagogiques", "Fraisdhébergement", "Fraisrestauration", "Fraisdassurance", "Fraisdetransport"]
TA_FIELDS = ["Fraispédagogiques2", "Primes", "Présalaires", "Coûtsdesfournitures", "Autresfrais"]
TF_EXEMPT_BELOW = 20


def _part(masse: float, depenses: float) -> tuple[float, float, float]:
    """(ratio %, taux applicable %, droits) for one annex."""
    if masse <= 0:
        return 0.0, 0.0, 0.0
    ratio = depenses / masse * 100
    taux = max(0.0, 1.0 - ratio)
    return round(ratio, 4), round(taux, 4), masse * taux / 100


def compute(data: dict) -> dict:
    nb = int(_num(data.get("NbreSalaries")))
    masse = _num(data.get("MasseSalaire"))
    out: dict = {"NbreSalaries": nb, "MasseSalaire": round(masse)}
    if nb < TF_EXEMPT_BELOW:                     # Unit11.NbreSalariesExit: TF not due, annex II cleared
        out.update({k: None for k in TF_FIELDS})
        out.update({"TotalANNEXE2": 0, "RatioTF": 0.0, "TauxTF": 0.0, "DroitsTF": 0, "BaseTF": 0})
    else:
        out.update({k: round(_num(data.get(k))) for k in TF_FIELDS})
        dep = sum(out[k] for k in TF_FIELDS)
        r, t, d = _part(masse, dep)
        out.update({"TotalANNEXE2": dep, "RatioTF": r, "TauxTF": t, "DroitsTF": round(d), "BaseTF": round(masse)})
    out.update({k: round(_num(data.get(k))) for k in TA_FIELDS})
    dep = sum(out[k] for k in TA_FIELDS)
    r, t, d = _part(masse, dep)
    out.update({"TotalANNEXE3": dep, "RatioTAPP": r, "TauxTAAP": t, "droitsTAPP": round(d), "BASETAPP": round(masse)})
    out["Totaldroits"] = out["DroitsTF"] + out["droitsTAPP"]
    return out


def _rows(c: sqlite3.Connection, exercice: str) -> list[dict]:
    rows = [dict(r) for r in c.execute('SELECT * FROM DeclarationTAPP WHERE "Exercice" = ? ORDER BY "ClientExercice", "IDDeclarationTAPP"', (str(exercice),))]
    for r in rows:
        r["_id"] = r["IDDeclarationTAPP"]
        r["date_display"] = dates.to_display(r.get("DateDecl"))
    return rows


def state(code: str, exercice: str) -> dict:
    with connect(code) as c:
        return {"exercice": str(exercice), "items": _rows(c, exercice), "periods": PERIODS,
                "tf_fields": TF_FIELDS, "ta_fields": TA_FIELDS, "tf_exempt_below": TF_EXEMPT_BELOW}


def save(code: str, exercice: str, data: dict, decl_id: int | None = None) -> dict:
    period = str(data.get("ClientExercice") or "").strip()
    if period and period not in PERIODS:
        raise G50Error("Période invalide")
    if not _num(data.get("MasseSalaire")):
        raise G50Error("Veuillez saisir la masse salariale globale")
    values = compute(data)
    values["ClientExercice"] = period
    values["DateDecl"] = dates.to_storage(data.get("DateDecl")) if data.get("DateDecl") else None
    with connect(code) as c:
        if period and any(r["ClientExercice"] == period and r["_id"] != decl_id for r in _rows(c, exercice)):
            raise Conflict(f"Le {period} existe déjà pour l’exercice {exercice}")
        cl = _client(c)
        values.update({"Exercice": str(exercice), "idclient": str(cl.get("IDclients") or ""), "rs": cl.get("rs"),
                       "Nif": cl.get("NIF"), "NIF2": cl.get("NIF2")})
        if decl_id is None:
            values["IDDeclarationTAPP"] = _next_id(c, "DeclarationTAPP", "IDDeclarationTAPP")
            c.execute(f'INSERT INTO DeclarationTAPP ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE DeclarationTAPP SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} '
                           'WHERE "IDDeclarationTAPP" = ?', (*values.values(), decl_id)).rowcount:
            raise HTTPException(404, "Déclaration introuvable")
    return state(code, exercice)


def delete(code: str, exercice: str, decl_id: int) -> dict:
    with connect(code) as c:
        if not c.execute('DELETE FROM DeclarationTAPP WHERE "IDDeclarationTAPP" = ?', (decl_id,)).rowcount:
            raise HTTPException(404, "Déclaration introuvable")
    return state(code, exercice)
