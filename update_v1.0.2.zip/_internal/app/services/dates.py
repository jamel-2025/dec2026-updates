"""Date conversions between the UI (dd/mm/yyyy, Delphi DisplayFormat) and the storage
format of the migrated databases (ISO 'YYYY-MM-DDTHH:MM:SS')."""
from __future__ import annotations

import re
from datetime import date, datetime


def to_storage(value) -> str | None:
    if value in (None, ""):
        return None
    if isinstance(value, (date, datetime)):
        return datetime(value.year, value.month, value.day).isoformat()
    s = str(value).strip()
    m = re.fullmatch(r"(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})", s)
    if m:
        d, mo, y = map(int, m.groups())
        return datetime(y, mo, d).isoformat()
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        y, mo, d = map(int, m.groups())
        return datetime(y, mo, d).isoformat()
    raise ValueError(f"Date invalide : {s!r} (attendu jj/mm/aaaa)")


def parse(value) -> date | None:
    if value in (None, ""):
        return None
    s = str(value)
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return date(*map(int, m.groups()))
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", s.strip())
    if m:
        d, mo, y = map(int, m.groups())
        return date(y, mo, d)
    return None


def to_display(value) -> str:
    d = parse(value)
    return d.strftime("%d/%m/%Y") if d else ""
