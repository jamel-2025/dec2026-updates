"""Company dossiers (uOpenSociete / DM.tclient) and the menu visibility rules of
TfrmMain.UpdateCompanyState (uMain.pas)."""
from __future__ import annotations

import sqlite3

from ..core import config
from ..core.db import connect


def _flag(row: dict, key: str) -> bool:
    return bool(row.get(key)) and str(row.get(key)) not in ("0", "False", "false")


def societe(code: str) -> dict:
    with connect(code) as c:
        row = c.execute("SELECT * FROM clients LIMIT 1").fetchone()
    return dict(row) if row else {}


def menu_visibility(s: dict) -> dict:
    """uMain: I1 (IBS) / I2 (IRG) by legal form; sector items by the company flags."""
    fj = (s.get("fj") or "").strip().lower()
    if fj in ("sarl", "eurl", "spa"):
        ibs, irg = True, False
    elif fj == "personne physique":
        ibs, irg = False, True
    else:
        ibs, irg = True, True
    return {
        "ibs": ibs,
        "irg": irg,
        "pharma": _flag(s, "Pharma"),
        "station": _flag(s, "StationServices"),
        "promotion": _flag(s, "Promotion"),
        "lotissement": _flag(s, "Lotissement"),
        "fventes": _flag(s, "Fventes"),
        "clients": True,
    }


def list_dossiers() -> list[dict]:
    out = []
    if not config.SOCIETES_DIR.is_dir():
        return out
    for d in sorted(config.SOCIETES_DIR.iterdir(), key=lambda p: (len(p.name), p.name)):
        db = d / config.DB_FILENAME
        if not db.is_file():
            continue
        info = {"code": d.name, "rs": "", "nif": "", "nif2": "", "fj": "", "activite": "", "telephone": "", "exercices": []}
        try:
            c = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            c.row_factory = sqlite3.Row
            r = c.execute("SELECT * FROM clients LIMIT 1").fetchone()
            if r:
                rd = dict(r)
                info.update(
                    rs=rd.get("rs") or "",
                    nif=rd.get("NIF") or "",
                    nif2=rd.get("NIF2") or "",
                    fj=rd.get("fj") or "",
                    activite=rd.get("activité") or rd.get("act") or "",
                    telephone=rd.get("TelelWatsapp") or rd.get("tel") or rd.get("Telephone") or "",
                )
            info["exercices"] = [x[0] for x in c.execute(
                "SELECT DISTINCT \"Année\" FROM Exercices WHERE TRIM(COALESCE(\"Année\",'')) <> '' "
                "ORDER BY CAST(\"Année\" AS INTEGER)")]
            c.close()
        except sqlite3.Error as e:
            info["error"] = str(e)
        out.append(info)
    return out


def exercices(code: str) -> list[str]:
    with connect(code) as c:
        return [r[0] for r in c.execute(
            "SELECT DISTINCT \"Année\" FROM Exercices WHERE TRIM(COALESCE(\"Année\",'')) <> '' "
            "ORDER BY CAST(\"Année\" AS INTEGER)")]
