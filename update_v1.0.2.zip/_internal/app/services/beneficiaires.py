"""Bénéficiaires effectifs — Delphi uBeneficiaireEffectif, impression Rapports/Beneficiaire_Effectif.fr3
(4 pages: AR/FR × inscrit / non inscrit au RC). Table BeneficiairesEffectifs.

Rules:
  * one declaration per year (1990–2099) — « لا يمكن إنشاء تصريح مكرر لنفس السنة »;
  * nom et prénom (arabe) obligatoires; new declaration: déclarant = gérant (Gerant_AR), bénéficiaire = déclarant;
  * « modèle par défaut » (IsDefaultTemplate): one record serves as template for the next years;
  * bénéficiaire inscrit au RC: naissance, adresse et pièces non requises (disabled in Delphi);
  * critère 1 (capital / droits de vote) with rates; critères 2 (contrôle) et 3 (représentant légal);
  * print: X marks, dates yyyy/mm/dd, rates « n %», lieu de déclaration سطيف / Sétif (as in Delphi).
"""
from __future__ import annotations

from datetime import date

from fastapi import HTTPException

from ..core.db import connect
from . import dates, dossiers
from .g50 import Conflict, G50Error, _next_id, _num

DATE_FIELDS = ("DateNaissance", "DatePiece", "DateExpPiece", "DatePasseport", "DateExpPasseport", "DateBeneficiaire")
TEXT_FIELDS = ("NomComplet_AR", "NomComplet_FR", "Nationalite_AR", "Nationalite_FR", "LieuNaissance_AR", "Adresse_AR", "NumPiece",
               "LieuPiece_AR", "NumPasseport", "LieuPasseport_AR", "AutrePieceRef_AR", "NomDeclarant_AR", "Observations")
BOOL_FIELDS = ("EstDansRC", "Critere_Capital", "Critere_Vote", "Critere_Controle", "Critere_RepresentantLegal", "AutreBeneficiaireExiste")
# template copy (btnApplyDefaultClick)
TEMPLATE_FIELDS = (*TEXT_FIELDS, *DATE_FIELDS[:-1], *BOOL_FIELDS[:-1], "TauxCapital", "TauxVote", "TypeDemande")


def _bool(v) -> int:
    return 1 if v in (True, 1, "1", "true", "True", -1) else 0


def _row(r: dict) -> dict:
    out = {**r, "_id": r["IDBeneficiaire"]}
    for k in (*DATE_FIELDS, "DateDeclaration"):
        out[f"{k}_display"] = dates.to_display(r.get(k)) if r.get(k) else ""
    return out


def company(code: str) -> dict:
    """LoadCompanyDefaults."""
    s = dossiers.societe(code)
    return {"SocRS": s.get("rs") or s.get("RS_AR") or "", "SocRC": s.get("RC") or "", "Declarant": s.get("Gerant_AR") or s.get("gerant") or ""}


def list_(code: str) -> dict:
    with connect(code) as c:
        rows = [_row(dict(r)) for r in c.execute("SELECT * FROM BeneficiairesEffectifs ORDER BY Annee DESC, IDBeneficiaire DESC")]
    return {"items": rows, "company": company(code)}


def new(code: str, annee: int) -> dict:
    """btnNewClick — year check, company defaults; fields of the default template when one exists."""
    annee = int(_num(annee))
    if not 1990 <= annee <= 2099:
        raise G50Error("يرجى إدخال سنة صحيحة بين 1990 و 2099.")
    with connect(code) as c:
        dup = c.execute("SELECT NomComplet_AR FROM BeneficiairesEffectifs WHERE Annee = ?", (annee,)).fetchone()
        if dup:
            raise Conflict(f"يوجد بالفعل تصريح مسجل لسنة {annee} باسم المستفيد: {(dup[0] or '').strip()} — "
                           "لا يمكن إنشاء تصريح مكرر لنفس السنة.")
        tpl = c.execute("SELECT * FROM BeneficiairesEffectifs WHERE IsDefaultTemplate = 1 LIMIT 1").fetchone()
    co = company(code)
    d = {"Annee": annee, "TypeDemande": 1, "EstDansRC": 1, "NomDeclarant_AR": co["Declarant"], "NomComplet_AR": co["Declarant"],
         "DateBeneficiaire": date.today().strftime("%d/%m/%Y"), "from_template": False}
    if tpl:
        t = _row(dict(tpl))
        for k in TEMPLATE_FIELDS:
            d[k] = t.get(f"{k}_display", t.get(k)) if k in DATE_FIELDS else t.get(k)
        d["from_template"] = True
    return d


def save(code: str, data: dict, bid: int | None = None) -> dict:
    if not str(data.get("NomComplet_AR") or "").strip():
        raise G50Error("يرجى إدخال الاسم واللقب للمستفيد الحقيقي.")
    annee = int(_num(data.get("Annee")))
    if not 1990 <= annee <= 2099:
        raise G50Error("يرجى إدخال سنة صحيحة بين 1990 و 2099.")
    v: dict = {"Annee": annee, "TypeDemande": 2 if int(_num(data.get("TypeDemande"))) == 2 else 1}
    for k in TEXT_FIELDS:
        v[k] = str(data.get(k) or "").strip()
    for k in BOOL_FIELDS:
        v[k] = _bool(data.get(k))
    for k in DATE_FIELDS:
        v[k] = dates.to_storage(data.get(k)) if data.get(k) else None
    v["DateBeneficiaire"] = v["DateBeneficiaire"] or dates.to_storage(date.today())
    v["TauxCapital"] = _num(str(data.get("TauxCapital") or 0).replace(",", "."))
    v["TauxVote"] = _num(str(data.get("TauxVote") or 0).replace(",", "."))
    v["DateDeclaration"] = dates.to_storage(date.today())
    with connect(code) as c:
        dup = c.execute("SELECT IDBeneficiaire FROM BeneficiairesEffectifs WHERE Annee = ?", (annee,)).fetchone()
        if dup and dup[0] != bid:
            raise Conflict(f"يوجد بالفعل تصريح مسجل لسنة {annee} — لا يمكن إنشاء تصريح مكرر لنفس السنة.")
        if bid is None:
            v["IDBeneficiaire"] = bid = _next_id(c, "BeneficiairesEffectifs", "IDBeneficiaire")
            v["IsDefaultTemplate"] = 0
            c.execute(f'INSERT INTO BeneficiairesEffectifs ({", ".join(v)}) VALUES ({", ".join("?" for _ in v)})', tuple(v.values()))
        elif not c.execute(f'UPDATE BeneficiairesEffectifs SET {", ".join(k + " = ?" for k in v)} WHERE IDBeneficiaire = ?',
                           (*v.values(), bid)).rowcount:
            raise HTTPException(404, "Déclaration introuvable")
    return get(code, bid)


def get(code: str, bid: int) -> dict:
    with connect(code) as c:
        r = c.execute("SELECT * FROM BeneficiairesEffectifs WHERE IDBeneficiaire = ?", (bid,)).fetchone()
    if r is None:
        raise HTTPException(404, "Déclaration introuvable")
    return _row(dict(r))


def delete(code: str, bid: int) -> None:
    with connect(code) as c:
        if not c.execute("DELETE FROM BeneficiairesEffectifs WHERE IDBeneficiaire = ?", (bid,)).rowcount:
            raise HTTPException(404, "Déclaration introuvable")


def set_default(code: str, bid: int) -> None:
    """btnSetDefaultClick."""
    with connect(code) as c:
        if c.execute("SELECT 1 FROM BeneficiairesEffectifs WHERE IDBeneficiaire = ?", (bid,)).fetchone() is None:
            raise HTTPException(404, "Déclaration introuvable")
        c.execute("UPDATE BeneficiairesEffectifs SET IsDefaultTemplate = 0")
        c.execute("UPDATE BeneficiairesEffectifs SET IsDefaultTemplate = 1 WHERE IDBeneficiaire = ?", (bid,))


def print_variables(code: str, bid: int) -> dict:
    """PrepareFastReport."""
    r = get(code, bid)
    co = company(code)
    ymd = lambda k: dates.parse(r.get(k)).strftime("%Y/%m/%d") if dates.parse(r.get(k)) else ""
    x = lambda b: "X" if b else ""
    taux = lambda on, v: f"{_num(v):.2f} %" if on else ""
    nom_fr = (r.get("NomComplet_FR") or "").strip() or r.get("NomComplet_AR") or ""
    return {
        "Annee": str(r["Annee"]), "SocRS_AR": co["SocRS"], "SocRS_FR": co["SocRS"], "SocRC": co["SocRC"],
        "Declarant_AR": r.get("NomDeclarant_AR") or co["Declarant"], "Declarant_FR": r.get("NomDeclarant_AR") or co["Declarant"],
        "Chk_Immat": x(r.get("TypeDemande") != 2), "Chk_Modif": x(r.get("TypeDemande") == 2),
        "Chk_EstDansRC_Oui": x(r.get("EstDansRC")), "Chk_EstDansRC_Non": x(not r.get("EstDansRC")),
        "NomComplet_AR": r.get("NomComplet_AR") or "", "NomComplet_FR": nom_fr,
        "Nationalite_AR": r.get("Nationalite_AR") or "", "Nationalite_FR": r.get("Nationalite_FR") or "",
        "DateNaissance": ymd("DateNaissance"), "LieuNaissance_AR": r.get("LieuNaissance_AR") or "", "LieuNaissance_FR": r.get("LieuNaissance_AR") or "",
        "Adresse_AR": r.get("Adresse_AR") or "", "Adresse_FR": r.get("Adresse_AR") or "",
        "NumPiece": r.get("NumPiece") or "", "DatePiece": ymd("DatePiece"), "LieuPiece_AR": r.get("LieuPiece_AR") or "",
        "LieuPiece_FR": r.get("LieuPiece_AR") or "", "DateExpPiece": ymd("DateExpPiece"),
        "NumPasseport": r.get("NumPasseport") or "", "DatePasseport": ymd("DatePasseport"), "LieuPasseport_AR": r.get("LieuPasseport_AR") or "",
        "LieuPasseport_FR": r.get("LieuPasseport_AR") or "", "DateExpPasseport": ymd("DateExpPasseport"),
        "AutrePieceRef_AR": r.get("AutrePieceRef_AR") or "", "AutrePieceRef_FR": r.get("AutrePieceRef_AR") or "",
        "Chk_Critere1": x(r.get("Critere_Capital") or r.get("Critere_Vote")),
        "Chk_Critere1_Cap": x(r.get("Critere_Capital")), "TauxCapitalTxt": taux(r.get("Critere_Capital"), r.get("TauxCapital")),
        "Chk_Critere1_Vote": x(r.get("Critere_Vote")), "TauxVoteTxt": taux(r.get("Critere_Vote"), r.get("TauxVote")),
        "Chk_Critere2": x(r.get("Critere_Controle")), "Chk_Critere3": x(r.get("Critere_RepresentantLegal")),
        "DateBeneficiaire": ymd("DateBeneficiaire"), "Chk_AutreOui": x(r.get("AutreBeneficiaireExiste")),
        "Chk_AutreNon": x(not r.get("AutreBeneficiaireExiste")), "DateDeclaration": date.today().strftime("%Y/%m/%d"),
        "LieuDeclaration_AR": "سطيف", "LieuDeclaration_FR": "Sétif",
    }
