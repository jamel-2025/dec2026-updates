"""Algerian fiscal invoice scanner & OCR service (Hybrid: Gemini Vision AI + Windows Native OCR).
Powered by Algerian Fiscal Invoice Engine (DGI / SCF / CNRC compliant).
Extracts & Validates:
  - rs: Raison sociale / Nom commercial
  - activité: Activité ou profession
  - adresse: Adresse (Rue, Commune, Wilaya)
  - NIF: Numéro d'Identification Fiscale (strictement 15 chiffres)
  - NIN: Numéro d'Identification Nationale (18 chiffres) / NIS (9-13 chiffres)
  - rcom: Registre de commerce format CNRC (ex: 16/00-1234567B18)
  - ai: Article d'imposition (strictement 11 chiffres)
"""
from __future__ import annotations

import base64
import json
import logging
import os
import re
import subprocess
import tempfile
import unicodedata
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx

from ..core import access, config

logger = logging.getLogger("invoice_ocr")

# ============================================================================
# 1. OFFICIAL ALGERIAN 58 WILAYAS REFERENCE DATABASE (Post-2019/2021 Reform)
# ============================================================================

WILAYAS_58: Dict[str, Dict[str, Any]] = {
    "01": {"fr": "Adrar", "ar": "أدرار", "aliases": ["adrar"]},
    "02": {"fr": "Chlef", "ar": "الشلف", "aliases": ["chlef", "ech-chlef", "el asnam"]},
    "03": {"fr": "Laghouat", "ar": "الأغواط", "aliases": ["laghouat", "el aghouat"]},
    "04": {"fr": "Oum El Bouaghi", "ar": "أم البواقي", "aliases": ["oum el bouaghi", "oeb"]},
    "05": {"fr": "Batna", "ar": "باتنة", "aliases": ["batna"]},
    "06": {"fr": "Béjaïa", "ar": "بجاية", "aliases": ["bejaia", "béjaïa", "bougie"]},
    "07": {"fr": "Biskra", "ar": "بسكرة", "aliases": ["biskra"]},
    "08": {"fr": "Béchar", "ar": "بشار", "aliases": ["bechar", "béchar"]},
    "09": {"fr": "Blida", "ar": "البليدة", "aliases": ["blida"]},
    "10": {"fr": "Bouira", "ar": "البويرة", "aliases": ["bouira"]},
    "11": {"fr": "Tamanrasset", "ar": "تمنراست", "aliases": ["tamanrasset", "tamanghasset"]},
    "12": {"fr": "Tébessa", "ar": "تبسة", "aliases": ["tebessa", "tébessa"]},
    "13": {"fr": "Tlemcen", "ar": "تلمسان", "aliases": ["tlemcen"]},
    "14": {"fr": "Tiaret", "ar": "تيارت", "aliases": ["tiaret"]},
    "15": {"fr": "Tizi Ouzou", "ar": "تيزي وزو", "aliases": ["tizi ouzou", "tizi-ouzou", "to"]},
    "16": {"fr": "Alger", "ar": "الجزائر", "aliases": ["alger", "algiers", "alger centre", "bab ezzouar", "hydra", "dar el beida", "cheraga", "rouiba"]},
    "17": {"fr": "Djelfa", "ar": "الجلفة", "aliases": ["djelfa"]},
    "18": {"fr": "Jijel", "ar": "جيجل", "aliases": ["jijel", "djijel"]},
    "19": {"fr": "Sétif", "ar": "سطيف", "aliases": ["setif", "sétif", "el eulma"]},
    "20": {"fr": "Saïda", "ar": "سعيدة", "aliases": ["saida", "saïda"]},
    "21": {"fr": "Skikda", "ar": "سكيكدة", "aliases": ["skikda", "philippeville"]},
    "22": {"fr": "Sidi Bel Abbès", "ar": "سيدي بلعباس", "aliases": ["sidi bel abbes", "sidi bel abbès", "sba"]},
    "23": {"fr": "Annaba", "ar": "عنابة", "aliases": ["annaba", "bône"]},
    "24": {"fr": "Guelma", "ar": "قالمة", "aliases": ["guelma"]},
    "25": {"fr": "Constantine", "ar": "قسنطينة", "aliases": ["constantine", "el khroub"]},
    "26": {"fr": "Médéa", "ar": "المدية", "aliases": ["medea", "médéa"]},
    "27": {"fr": "Mostaganem", "ar": "مستغانم", "aliases": ["mostaganem"]},
    "28": {"fr": "M'Sila", "ar": "المسيلة", "aliases": ["msila", "m'sila", "bousaada"]},
    "29": {"fr": "Mascara", "ar": "معسكر", "aliases": ["mascara"]},
    "30": {"fr": "Ouargla", "ar": "ورقلة", "aliases": ["ouargla", "hassi messaoud"]},
    "31": {"fr": "Oran", "ar": "وهران", "aliases": ["oran", "es senia", "bir el djir"]},
    "32": {"fr": "El Bayadh", "ar": "البيض", "aliases": ["el bayadh", "el-bayadh"]},
    "33": {"fr": "Illizi", "ar": "إيليزي", "aliases": ["illizi"]},
    "34": {"fr": "Bordj Bou Arréridj", "ar": "برج بوعريريج", "aliases": ["bordj bou arreridj", "bordj bou arréridj", "bba"]},
    "35": {"fr": "Boumerdès", "ar": "بومرداس", "aliases": ["boumerdes", "boumerdès", "rocher noir"]},
    "36": {"fr": "El Tarf", "ar": "الطارف", "aliases": ["el tarf", "el-tarf"]},
    "37": {"fr": "Tindouf", "ar": "تندوف", "aliases": ["tindouf"]},
    "38": {"fr": "Tissemsilt", "ar": "تيسمسيلت", "aliases": ["tissemsilt"]},
    "39": {"fr": "El Oued", "ar": "الوادي", "aliases": ["el oued", "oued souf"]},
    "40": {"fr": "Khenchela", "ar": "خنشلة", "aliases": ["khenchela"]},
    "41": {"fr": "Souk Ahras", "ar": "سوق أهراس", "aliases": ["souk ahras"]},
    "42": {"fr": "Tipaza", "ar": "تيبازة", "aliases": ["tipaza", "tipasa", "kolea"]},
    "43": {"fr": "Mila", "ar": "ميلة", "aliases": ["mila"]},
    "44": {"fr": "Aïn Defla", "ar": "عين الدفلى", "aliases": ["ain defla", "aïn defla", "khemis miliana"]},
    "45": {"fr": "Naâma", "ar": "النعامة", "aliases": ["naama", "naâma", "mecheria"]},
    "46": {"fr": "Aïn Témouchent", "ar": "عين تموشنت", "aliases": ["ain temouchent", "aïn témouchent"]},
    "47": {"fr": "Ghardaïa", "ar": "غرداية", "aliases": ["ghardaia", "ghardaïa", "mzab"]},
    "48": {"fr": "Relizane", "ar": "غليزان", "aliases": ["relizane"]},
    "49": {"fr": "Timimoun", "ar": "تيميمون", "aliases": ["timimoun"]},
    "50": {"fr": "Bordj Badji Mokhtar", "ar": "برج باجي مختار", "aliases": ["bordj badji mokhtar", "bbm"]},
    "51": {"fr": "Ouled Djellal", "ar": "أولاد جلال", "aliases": ["ouled djellal"]},
    "52": {"fr": "Béni Abbès", "ar": "بني عباس", "aliases": ["beni abbes", "béni abbès"]},
    "53": {"fr": "In Salah", "ar": "عين صالح", "aliases": ["in salah", "ain salah"]},
    "54": {"fr": "In Guezzam", "ar": "عين قزام", "aliases": ["in guezzam", "ain guezzam"]},
    "55": {"fr": "Touggourt", "ar": "تقرت", "aliases": ["touggourt"]},
    "56": {"fr": "Djanet", "ar": "جانت", "aliases": ["djanet"]},
    "57": {"fr": "El M'Ghair", "ar": "المغير", "aliases": ["el m'ghair", "el mghair", "el-m'ghair"]},
    "58": {"fr": "El Meniaa", "ar": "المنيعة", "aliases": ["el meniaa", "el golea", "el goléa"]}
}


# ============================================================================
# 2. KEY MANAGEMENT (acces.json & ENVIRONMENT)
# ============================================================================

def get_gemini_api_key() -> str:
    """Retrieve Gemini API key from acces.json, environment, or return empty string."""
    try:
        cfg = access.load()
        key = cfg.get("gemini_api_key", "").strip()
        if key:
            return key
    except Exception:
        pass
    return os.environ.get("GEMINI_API_KEY", "").strip()


def save_gemini_api_key(key: str) -> None:
    """Save Gemini API key to acces.json."""
    cfg = access.load()
    cfg["gemini_api_key"] = key.strip()
    access.save(cfg)


# ============================================================================
# 3. OCR SELF-HEALING & REGEX NORMALIZATION PIPELINE
# ============================================================================

def heal_numeric_ocr(text: Optional[str]) -> str:
    """Repairs common OCR letter-digit substitutions in purely numeric Algerian fiscal fields."""
    if not text:
        return ""

    substitutions = {
        'O': '0', 'o': '0', 'Q': '0', 'D': '0',
        'I': '1', 'l': '1', '|': '1', '!': '1', 'i': '1',
        'Z': '2', 'z': '2',
        'E': '3',
        'A': '4',
        'S': '5', 's': '5', '$': '5',
        'G': '6', 'b': '6',
        'T': '7',
        'B': '8',
        'g': '9', 'q': '9'
    }

    norm = unicodedata.normalize('NFKD', str(text).strip())
    cleaned: List[str] = []
    for char in norm:
        if char in substitutions:
            cleaned.append(substitutions[char])
        elif char.isdigit():
            cleaned.append(char)

    return "".join(cleaned)


def sanitize_nif(raw_nif: Optional[str]) -> Tuple[Optional[str], float, List[str]]:
    """Cleans and validates the Algerian NIF (strictly 15 digits)."""
    if not raw_nif:
        return None, 0.0, ["NIF absent"]

    raw_str = str(raw_nif).strip()
    healed = heal_numeric_ocr(raw_str)
    notes: List[str] = []

    if len(healed) == 15:
        raw_digits_only = re.sub(r'\D', '', raw_str)
        if raw_digits_only != healed:
            notes.append(f"NIF corrigé: '{raw_str}' -> '{healed}'")
            return healed, 0.92, notes
        return healed, 1.0, ["NIF valide (15 chiffres conformes DGI)"]

    if len(healed) > 15:
        match = re.search(r'\d{15}', healed)
        if match:
            candidate = match.group(0)
            notes.append(f"NIF 15-chiffres extrait: '{candidate}'")
            return candidate, 0.85, notes

    if 10 <= len(healed) < 15:
        notes.append(f"NIF incomplet ({len(healed)}/15 chiffres)")
        return healed, 0.40, notes

    return raw_str, 0.10, notes


def sanitize_ai(raw_ai: Optional[str]) -> Tuple[Optional[str], float, List[str]]:
    """Cleans and validates the Article d'Imposition (strictly 11 digits). Prevents collision with phone numbers or NIF."""
    if not raw_ai:
        return None, 0.0, ["Article d'Imposition (AI) absent"]

    raw_str = str(raw_ai).strip()
    healed = heal_numeric_ocr(raw_str)
    notes: List[str] = []

    # Prevent phone number collision
    if len(healed) in (9, 10) and healed.startswith(('05', '06', '07', '02', '03', '04')):
        notes.append("Valeur AI rejetée car c'est un numéro de téléphone")
        return None, 0.0, notes

    # Prevent NIF collision
    if len(healed) == 15:
        notes.append("Valeur AI rejetée car c'est un NIF de 15 chiffres")
        return None, 0.0, notes

    if len(healed) == 11:
        wilaya_prefix = healed[:2]
        if wilaya_prefix in WILAYAS_58:
            wilaya_name = WILAYAS_58[wilaya_prefix]["fr"]
            notes.append(f"AI valide 11 chiffres (Wilaya {wilaya_prefix} - {wilaya_name})")
            return healed, 1.0, notes
        else:
            return healed, 0.70, [f"AI 11 chiffres (Préfixe wilaya {wilaya_prefix})"]

    if len(healed) > 11:
        for code in WILAYAS_58.keys():
            idx = healed.find(code)
            if idx != -1 and len(healed[idx:]) >= 11:
                candidate = healed[idx:idx + 11]
                return candidate, 0.80, [f"AI 11-chiffres extrait avec préfixe {code}"]

    return raw_str, 0.20, notes


def sanitize_rcom(raw_rcom: Optional[str]) -> Tuple[Optional[str], float, List[str]]:
    """Cleans and formats Algerian Registre de Commerce (CNRC canonical formats)."""
    if not raw_rcom:
        return None, 0.0, ["RC absent"]

    raw = str(raw_rcom).strip().upper()
    clean = re.sub(r'[^A-Z0-9\/\-\.\s]', '', raw)
    clean = re.sub(r'\s+', ' ', clean).strip()
    notes: List[str] = []

    # Pattern 1: Standard CNRC: WW/CC-NNNNNNN[A|B]YY
    std_regex = r'^(\d{2})[\s\/\.\-](\d{2})[\s\/\.\-](\d{5,8})[\s\/\.\-]?([AB8])[\s\/\.\-]?(\d{2})$'
    m_std = re.match(std_regex, clean)
    if m_std:
        w, c, seq, t, y = m_std.groups()
        if t == '8':
            t = 'B'
            notes.append("Correction OCR: '8' -> 'B' (Personne Morale)")
        return f"{w}/{c}-{seq.zfill(7)}{t}{y}", 0.98, notes

    # Pattern 2: Search within text
    search_std = re.search(r'(\d{2})[\/\.\-](\d{2})[\/\.\-](\d{5,8})[\s\-]?([AB8])[\s\-]?(\d{2})', clean)
    if search_std:
        w, c, seq, t, y = search_std.groups()
        if t == '8':
            t = 'B'
        return f"{w}/{c}-{seq.zfill(7)}{t}{y}", 0.92, notes

    # Pattern 3: Simple CNRC: WW [A|B] NNNNNNN
    simple_regex = r'^(\d{2})[\s\/\.\-]?([AB8])[\s\/\.\-]?(\d{4,8})$'
    m_simple = re.match(simple_regex, clean)
    if m_simple:
        w, t, seq = m_simple.groups()
        if t == '8':
            t = 'B'
        return f"{w} {t} {seq.zfill(7)}", 0.90, notes

    return clean, 0.50, notes


def sanitize_nin_nis(raw_val: Optional[str]) -> Tuple[Optional[str], float, List[str]]:
    """Cleans NIN (18 digits) or NIS (9 or 13 digits)."""
    if not raw_val:
        return None, 0.0, ["NIN/NIS absent"]

    healed = heal_numeric_ocr(str(raw_val))
    notes: List[str] = []
    if len(healed) == 18:
        return healed, 1.0, ["NIN biométrique conforme (18 chiffres)"]
    elif len(healed) in (9, 13, 14):
        return healed, 0.95, [f"NIS conforme ({len(healed)} chiffres)"]

    notes.append(f"NIN/NIS non standard ({len(healed)} chiffres)")
    return healed, 0.40, notes


def match_wilaya(text: Optional[str]) -> Tuple[Optional[str], Optional[str], float]:
    """Matches free-form address or wilaya text against 58 official Algerian Wilayas."""
    if not text:
        return None, None, 0.0

    raw = str(text).strip()
    norm = unicodedata.normalize('NFKD', raw).encode('ASCII', 'ignore').decode('utf-8').lower()

    if raw in WILAYAS_58:
        return WILAYAS_58[raw]["fr"], raw, 1.0

    for code, data in WILAYAS_58.items():
        if data["ar"] in raw:
            return data["fr"], code, 0.98

    for code, data in WILAYAS_58.items():
        data_fr_norm = unicodedata.normalize('NFKD', data["fr"]).encode('ASCII', 'ignore').decode('utf-8').lower()
        if re.search(r'\b' + re.escape(data_fr_norm) + r'\b', norm):
            return data["fr"], code, 0.95
        for alias in data["aliases"]:
            alias_norm = unicodedata.normalize('NFKD', alias).encode('ASCII', 'ignore').decode('utf-8').lower()
            if re.search(r'\b' + re.escape(alias_norm) + r'\b', norm):
                return data["fr"], code, 0.90

    pc_match = re.search(r'\b(0[1-9]|[1-4][0-9]|5[0-8])\d{3}\b', raw)
    if pc_match:
        code = pc_match.group(1)
        if code in WILAYAS_58:
            return WILAYAS_58[code]["fr"], code, 0.85

    return None, None, 0.0


# ============================================================================
# 4. WINDOWS NATIVE WINRT OCR SCRIPT (OFFLINE FALLBACK)
# ============================================================================

PS_OCR_SCRIPT = """
param([string]$ImagePath)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = [System.WindowsRuntimeSystemExtensions].GetMethods() | ? { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' }

Function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}

[void][Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
[void][Windows.Media.Ocr.OcrEngine, Windows.Foundation.UniversalApiContract, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation.UniversalApiContract, ContentType = WindowsRuntime]

$resolved = (Resolve-Path $ImagePath).Path
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($resolved)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new("en-US"))
}
$result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

foreach ($line in $result.Lines) {
    Write-Output $line.Text
}
"""


def parse_algerian_fiscal_text(text: str, target: str = "fournisseur") -> Dict[str, Any]:
    """Offline heuristic parser applying Algerian fiscal healing rules to raw OCR text."""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    data = {
        "rs": "",
        "activité": "",
        "adresse": "",
        "NIF": "",
        "NIN": "",
        "rcom": "",
        "ai": "",
        "wilaya": "",
    }

    joined_text = " " + " \n ".join(lines) + " "

    # 1. NIF: 15 digits
    nif_match = re.search(r'(?:NIF|N\.I\.F|IDENTIFICATION FISCALE|IDENT[\s.]*FISCALE)?[:\s\t]*\b([0-9\s]{15,20})\b', joined_text, re.IGNORECASE)
    if nif_match:
        c_nif, _, _ = sanitize_nif(nif_match.group(1))
        data["NIF"] = c_nif or ""
    else:
        any_15 = re.search(r'\b([0-9]{15})\b', joined_text)
        if any_15:
            c_nif, _, _ = sanitize_nif(any_15.group(1))
            data["NIF"] = c_nif or ""

    # 2. NIN: 18 digits or NIS
    nin_match = re.search(r'(?:NIN|N\.I\.N|NIS|N\.I\.S|IDENTIFICATION NATIONALE)?[:\s\t]*\b([0-9\s]{9,22})\b', joined_text, re.IGNORECASE)
    if nin_match:
        c_nin, _, _ = sanitize_nin_nis(nin_match.group(1))
        data["NIN"] = c_nin or ""
    else:
        any_18 = re.search(r'\b([0-9]{18})\b', joined_text)
        if any_18:
            data["NIN"] = any_18.group(1)

    # 3. Article d'imposition (AI): 11 digits
    ai_match = re.search(r'(?:ARTICLE|ART|A\.I|AI|ART[\s.]*IMP)?[:\s\t]*\b([0-9\s]{11,15})\b', joined_text, re.IGNORECASE)
    if ai_match:
        c_ai, _, _ = sanitize_ai(ai_match.group(1))
        data["ai"] = c_ai or ""
    else:
        any_11 = re.search(r'\b([0-9]{11})\b', joined_text)
        if any_11 and any_11.group(1) != data["NIF"][:11]:
            c_ai, _, _ = sanitize_ai(any_11.group(1))
            data["ai"] = c_ai or ""

    # 4. Registre de Commerce (RC)
    rc_match = re.search(
        r'(?:RC|R\.C|REGISTRE(?: DE)? COMMERCE)?[:\s\t]*([0-9]{2}[\/\s\'\.-][0-9]{2}[\/\s\'\.-][0-9]{5,8}(?:[A-Za-z8][0-9]{2})?)',
        joined_text,
        re.IGNORECASE
    )
    if rc_match:
        c_rc, _, _ = sanitize_rcom(rc_match.group(1))
        data["rcom"] = c_rc or ""

    # 5. Raison Sociale
    for line in lines:
        if re.search(r'\b(SARL|EURL|SPA|SNC|ETS|ETABLISSEMENT|STE|SOCIETE|COMPAGNIE|مؤسسة|شركة|ش\.ذ\.م\.م|ش\.ذ\.أ)\b', line, re.IGNORECASE):
            data["rs"] = line.strip()
            break

    if not data["rs"] and lines:
        for line in lines:
            if not re.search(r'^(NIF|NIS|NIN|RC|ART|TEL|FAX|MOB|RIB|EMAIL|DATE|BON|FACTURE)', line, re.IGNORECASE) and len(line) > 3:
                data["rs"] = line.strip()
                break

    # 6. Activité
    for line in lines:
        m = re.search(r'(?:ACTIVITE|OBJET|BRANCHE|METIER|النشاط)[:\s\t]+(.+)', line, re.IGNORECASE)
        if m:
            data["activité"] = m.group(1).strip()
            break

    # 7. Adresse & Wilaya
    for line in lines:
        m = re.search(r'(?:ADRESSE|SIEGE|SIEGE SOCIAL|DOMICILE|العنوان)[:\s\t]+(.+)', line, re.IGNORECASE)
        if m:
            data["adresse"] = m.group(1).strip()
            break
        elif re.search(r'\b(RUE|AVENUE|BD|BOULEVARD|ROUTE|ZONE|CITE|LOT|BP)\b', line, re.IGNORECASE):
            if not data["adresse"] and line != data["rs"] and line != data["activité"]:
                data["adresse"] = line.strip()

    w_name, w_code, _ = match_wilaya(f"{data['adresse']} {joined_text}")
    if w_name:
        data["wilaya"] = w_name

    return data


def run_windows_native_ocr(image_bytes: bytes, target: str = "fournisseur") -> Tuple[Dict[str, Any], str]:
    """Execute Windows Native WinRT OCR on image bytes and parse Algerian fiscal identity."""
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_img:
        tmp_img.write(image_bytes)
        tmp_img_path = Path(tmp_img.name)

    with tempfile.NamedTemporaryFile(suffix=".ps1", delete=False, mode="w", encoding="utf-8") as tmp_ps:
        tmp_ps.write(PS_OCR_SCRIPT)
        tmp_ps_path = Path(tmp_ps.name)

    try:
        proc = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy", "Bypass",
                "-File", str(tmp_ps_path),
                "-ImagePath", str(tmp_img_path)
            ],
            capture_output=True,
            text=True,
            timeout=25,
            encoding="utf-8",
            errors="replace"
        )
        raw_text = proc.stdout.strip()
        parsed = parse_algerian_fiscal_text(raw_text, target=target)
        return parsed, raw_text
    finally:
        try:
            tmp_img_path.unlink(missing_ok=True)
            tmp_ps_path.unlink(missing_ok=True)
        except Exception:
            pass


# ============================================================================
# 5. ADVANCED GEMINI VISION MULTIMODAL AUDITOR ENGINE
# ============================================================================

GEMINI_PROMPT_TEMPLATE = """Tu es un expert-comptable algérien et auditeur fiscal senior spécialisé dans le Système Comptable Financier (SCF) et la réglementation DGI.
Analyse cette facture commerciale algérienne (Facture, Bon de livraison, Cachet humide) et extrais les informations fiscales avec une précision absolue.

RÈGLE D'OR DE DISTINCTION SPATIALE :
1. FOURNISSEUR (Émetteur / Vendeur) :
   - Se trouve dans l'en-tête (haut de page, logo, raison sociale principale, coordonnées bancaires).
   - Cachet humide situé généralement en bas sous "Cachet et Signature du Fournisseur".

2. CLIENT (Destinataire / Acheteur / Doit) :
   - Se trouve dans l'encadré dédié au client, marqué par : "Client", "DOIT", "Facturé à", "Destinataire", "الزبون", "العميل".
   - Ne JAMAIS confondre les coordonnées du fournisseur avec celles du client !

NORMES FISCALES DGI :
- NIF : Strictement 15 chiffres.
- Article d'imposition (AI) : Strictement 11 chiffres (2 chiffres code wilaya 01-58 + recette + rôle).
- Registre de commerce (RC) : Format CNRC officiel (ex: 16/00-1234567B18 ou XX B XXXXXXX).
- NIN : 18 chiffres (biométrique) ou NIS (9 ou 13 chiffres).
- Wilaya : Nom de la wilaya parmi les 58 wilayas d'Algérie.

Réponds STRICTEMENT avec un objet JSON valide ayant la structure suivante, sans aucun texte additionnel ni markdown :
{
  "client": {
    "rs": "Nom ou Raison sociale du client",
    "activite": "Activité du client",
    "adresse": "Adresse complète du client",
    "commune": "Commune du client",
    "wilaya": "Wilaya du client",
    "NIF": "15 chiffres NIF client",
    "NIN": "NIN ou NIS client",
    "rcom": "RC client format CNRC",
    "ai": "11 chiffres AI client",
    "telephone": "Téléphone",
    "email": "Email"
  },
  "fournisseur": {
    "rs": "Nom ou Raison sociale du fournisseur",
    "activite": "Activité du fournisseur",
    "adresse": "Adresse complète du fournisseur",
    "commune": "Commune du fournisseur",
    "wilaya": "Wilaya du fournisseur",
    "NIF": "15 chiffres NIF fournisseur",
    "NIN": "NIN ou NIS fournisseur",
    "rcom": "RC fournisseur format CNRC",
    "ai": "11 chiffres AI fournisseur",
    "telephone": "Téléphone",
    "email": "Email"
  },
  "date_facture": "Date de facture si lisible",
  "numero_facture": "Numéro de facture si lisible"
}
"""


async def run_gemini_vision(
    image_bytes: bytes,
    mime_type: str,
    api_key: str,
    target: str = "fournisseur"
) -> Tuple[Dict[str, Any], str]:
    """Calls Gemini Vision API with high-precision Algerian fiscal prompt and cleans output."""
    b64_data = base64.b64encode(image_bytes).decode("utf-8")

    models = ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"]
    last_err = ""

    for model in models:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": GEMINI_PROMPT_TEMPLATE},
                        {
                            "inline_data": {
                                "mime_type": mime_type,
                                "data": b64_data
                            }
                        }
                    ]
                }
            ],
            "generationConfig": {
                "response_mime_type": "application/json",
                "temperature": 0.05
            }
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.post(url, json=payload)
                if resp.status_code == 200:
                    result = resp.json()
                    candidates = result.get("candidates", [])
                    if candidates:
                        text_content = candidates[0]["content"]["parts"][0]["text"]
                        cleaned_json = re.sub(r"^```(?:json)?\s*|\s*```$", "", text_content.strip(), flags=re.MULTILINE)
                        raw_obj = json.loads(cleaned_json)

                        # Select requested entity (client or fournisseur)
                        entity = raw_obj.get(target) or raw_obj.get("fournisseur" if target == "fournisseur" else "client") or {}

                        # Apply self-healing & DGI validations
                        clean_nif, nif_conf, _ = sanitize_nif(entity.get("NIF") or entity.get("nif"))
                        clean_ai, ai_conf, _ = sanitize_ai(entity.get("ai") or entity.get("article"))
                        clean_rc, rc_conf, _ = sanitize_rcom(entity.get("rcom") or entity.get("rc"))
                        clean_nin, _, _ = sanitize_nin_nis(entity.get("NIN") or entity.get("nin"))

                        raw_addr = str(entity.get("adresse") or "").strip()
                        commune = str(entity.get("commune") or "").strip()
                        w_raw = str(entity.get("wilaya") or "").strip()

                        w_name, w_code, _ = match_wilaya(f"{w_raw} {raw_addr} {commune}")
                        final_wilaya = w_name or w_raw

                        full_addr = raw_addr
                        if commune and commune not in full_addr:
                            full_addr = f"{full_addr}, {commune}".strip(", ")
                        if final_wilaya and final_wilaya not in full_addr:
                            full_addr = f"{full_addr} ({final_wilaya})".strip()

                        normalized: Dict[str, Any] = {
                            "rs": str(entity.get("rs") or entity.get("raison_sociale") or "").strip(),
                            "activité": str(entity.get("activite") or entity.get("activité") or "").strip(),
                            "adresse": full_addr,
                            "NIF": clean_nif or "",
                            "NIN": clean_nin or "",
                            "rcom": clean_rc or "",
                            "ai": clean_ai or "",
                            "wilaya": final_wilaya,
                            "telephone": str(entity.get("telephone") or "").strip(),
                            "email": str(entity.get("email") or "").strip(),
                            "target_extracted": target,
                        }
                        return normalized, text_content
                else:
                    last_err = f"API Gemini HTTP {resp.status_code}: {resp.text}"
        except Exception as e:
            last_err = f"Erreur Gemini ({model}): {e}"

    raise RuntimeError(last_err or "Échec de l'appel à l'API Gemini Vision")


# ============================================================================
# 6. PIPELINE ORCHESTRATOR
# ============================================================================

async def scan_invoice_header(
    image_bytes: bytes,
    mime_type: str = "image/jpeg",
    custom_api_key: Optional[str] = None,
    target: str = "fournisseur"
) -> Dict[str, Any]:
    """Hybrid scanning pipeline: tries Gemini Vision AI first, falls back gracefully to Windows Native OCR."""
    api_key = (custom_api_key or "").strip() or get_gemini_api_key()

    # 1. Attempt Gemini Vision AI if API key is present
    if api_key:
        try:
            data, raw = await run_gemini_vision(image_bytes, mime_type, api_key, target=target)
            return {
                "success": True,
                "engine": "gemini",
                "engine_label": "IA Gemini Vision DGI",
                "data": data,
                "raw_text": raw,
            }
        except Exception as e:
            logger.warning(f"Gemini Vision failed ({e}), falling back to local OCR")
            try:
                local_data, local_raw = run_windows_native_ocr(image_bytes, target=target)
                return {
                    "success": True,
                    "engine": "local_fallback",
                    "engine_label": "OCR Local (Repli)",
                    "data": local_data,
                    "raw_text": local_raw,
                    "warning": f"L'IA n'a pas pu répondre ({e}). L'OCR local Windows a pris le relais."
                }
            except Exception as local_err:
                raise RuntimeError(f"Échec de l'IA ({e}) et de l'OCR local ({local_err})")

    # 2. Offline Mode: Windows Native OCR directly
    local_data, local_raw = run_windows_native_ocr(image_bytes, target=target)
    return {
        "success": True,
        "engine": "local_ocr",
        "engine_label": "OCR Local Windows (Hors-ligne)",
        "data": local_data,
        "raw_text": local_raw,
    }
