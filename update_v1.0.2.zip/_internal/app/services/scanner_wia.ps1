# ================================================================
# WIA Scanner Acquisition Helper for Windows (Win7, 8, 10, 11)
# ================================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$Action = "list", # "list" or "scan"

    [Parameter(Mandatory=$false)]
    [string]$DeviceId = "",

    [Parameter(Mandatory=$false)]
    [string]$ColorMode = "color", # "color", "grayscale", "bw"

    [Parameter(Mandatory=$false)]
    [int]$DPI = 200,

    [Parameter(Mandatory=$false)]
    [string]$OutFile = ""
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Get-Scanners {
    try {
        $dm = New-Object -ComObject WIA.DeviceManager
        $scanners = @()
        foreach ($d in $dm.DeviceInfos) {
            # Type 1 = ScannerDeviceType
            if ($d.Type -eq 1) {
                $scanners += [PSCustomObject]@{
                    id   = [string]$d.DeviceId
                    name = [string]$d.Properties.Item("Name").Value
                    type = "scanner"
                }
            }
        }
        $json = ConvertTo-Json -Compress @($scanners)
        Write-Output "RESULT:$json"
    } catch {
        $err = [PSCustomObject]@{
            status = "error"
            message = $_.Exception.Message
        }
        Write-Output "ERROR:$(ConvertTo-Json -Compress $err)"
    }
}

function Invoke-Scan {
    param(
        [string]$targetOut,
        [string]$targetDevId,
        [string]$mode,
        [int]$resDpi
    )

    if (-not $targetOut) {
        $targetOut = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "scan_" + [System.Guid]::NewGuid().ToString("N") + ".jpg")
    }

    $intent = 1 # Color
    if ($mode -eq "grayscale") { $intent = 2 }
    elseif ($mode -eq "bw") { $intent = 4 }

    $bmpGuid = "{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}"
    $tempBmp = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), "scan_raw_" + [System.Guid]::NewGuid().ToString("N") + ".bmp")

    $image = $null

    try {
        $dm = New-Object -ComObject WIA.DeviceManager
        $devInfo = $null
        foreach ($d in $dm.DeviceInfos) {
            if ($d.Type -eq 1) {
                if (-not $targetDevId -or $d.DeviceId -eq $targetDevId) {
                    $devInfo = $d
                    break
                }
            }
        }

        if (-not $devInfo) {
            $res = [PSCustomObject]@{ status = "no_scanner"; message = "Aucun scanner ou imprimante multifonction détecté." }
            Write-Output "RESULT:$(ConvertTo-Json -Compress $res)"
            return
        }

        # 1. Direct device acquisition
        $dev = $devInfo.Connect()
        $item = $dev.Items.Item(1)

        # Set scan properties (Intent, DPI)
        try { $item.Properties.Item("6146").Value = $intent } catch {}
        try { $item.Properties.Item("6147").Value = $resDpi } catch {}
        try { $item.Properties.Item("6148").Value = $resDpi } catch {}

        # Direct transfer using native BMP format
        $image = $item.Transfer($bmpGuid)
    } catch {
        # 2. Fallback to WIA.CommonDialog without manufacturer page
        try {
            $dialog = New-Object -ComObject WIA.CommonDialog
            $image = $dialog.ShowAcquireImage(1, $intent, 131072, $bmpGuid, $false, $false, $true)
        } catch {
            $msg = $_.Exception.Message
            $status = "error"
            if ($msg -match "0x80210015" -or $msg -match "WIA_ERROR_DEVICE_OFFLINE" -or $msg -match "n'est pas disponible" -or $msg -match "not available") {
                $status = "no_scanner"
                $msg = "Aucun scanner ou imprimante multifonction détecté ou appareil hors-tension."
            } elseif ($msg -match "0x80210064" -or $msg -match "0x80210065") {
                $status = "busy"
                $msg = "Le scanner est actuellement occupé par une autre opération."
            } elseif ($msg -match "0x80210067" -or $msg -match "annulé" -or $msg -match "cancel") {
                $status = "cancelled"
                $msg = "Numérisation annulée par l'utilisateur."
            }

            $res = [PSCustomObject]@{ status = $status; message = $msg }
            Write-Output "RESULT:$(ConvertTo-Json -Compress $res)"
            return
        }
    }

    if ($null -eq $image) {
        $res = [PSCustomObject]@{ status = "cancelled"; message = "Numérisation annulée." }
        Write-Output "RESULT:$(ConvertTo-Json -Compress $res)"
        return
    }

    try {
        if (Test-Path $tempBmp) { Remove-Item -Force $tempBmp }
        $image.SaveFile($tempBmp)

        # Convert BMP to high-quality JPEG using .NET System.Drawing
        Add-Type -AssemblyName System.Drawing
        $bmpImg = [System.Drawing.Image]::FromFile($tempBmp)
        
        $encoderParams = New-Object System.Drawing.Imaging.EncoderParameters(1)
        $qualityEncoder = [System.Drawing.Imaging.Encoder]::Quality
        $encoderParams.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter($qualityEncoder, [long]90)
        
        $jpegCodec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq "image/jpeg" }
        
        if (Test-Path $targetOut) { Remove-Item -Force $targetOut }
        $bmpImg.Save($targetOut, $jpegCodec, $encoderParams)
        $bmpImg.Dispose()
        if (Test-Path $tempBmp) { Remove-Item -Force $tempBmp }

        $res = [PSCustomObject]@{
            status    = "ok"
            file_path = $targetOut
            mime_type = "image/jpeg"
        }
        Write-Output "RESULT:$(ConvertTo-Json -Compress $res)"
    } catch {
        # Fallback to direct file save
        try {
            if (Test-Path $targetOut) { Remove-Item -Force $targetOut }
            $image.SaveFile($targetOut)
            $res = [PSCustomObject]@{ status = "ok"; file_path = $targetOut; mime_type = "image/jpeg" }
            Write-Output "RESULT:$(ConvertTo-Json -Compress $res)"
        } catch {
            $res = [PSCustomObject]@{ status = "error"; message = $_.Exception.Message }
            Write-Output "RESULT:$(ConvertTo-Json -Compress $res)"
        }
    }
}

if ($Action -eq "scan") {
    Invoke-Scan -targetOut $OutFile -targetDevId $DeviceId -mode $ColorMode -resDpi $DPI
} else {
    Get-Scanners
}
