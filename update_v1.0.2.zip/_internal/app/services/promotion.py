"""Promotion immobilière — suivi des encaissements (versements des clients par projet).
Delphi uMain (onglet Encaissements), Unit17 (projets), Unit18 (versement), Unit19 / Unit20.Rencaissem (état).
Tables: Encaissements, ProjEncaissement.

Rules (Unit18):
  * required: date, client, montant TTC, taux de TVA, projet, mode de règlement;
  * HT = TTC / (1 + taux / 100), TVA = TTC − HT (taux 0 : HT = TTC);
  * modes de règlement : Espèce, Chèque bancaire, Virement bancaire;
  * the grid and the report follow the open exercice, filtered by project or client.
Logical additions: month / period of the payment filled from its date; a project used by
payments can be neither deleted nor duplicated; renaming a project updates its payments.
"""
from __future__ import annotations

from fastapi import HTTPException

from ..core.db import connect
from . import dates, ref
from .g50 import Conflict, G50Error, _next_id, _num

MODES = ["Espece", "Cheque Bancaire", "Virement Bancaire"]


# ------------------------------------------------------------------ projets (Unit17)
def projets(code: str) -> list[dict]:
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(
            'SELECT p."ID" AS _id, p."Projet" AS projet, '
            '(SELECT COUNT(*) FROM Encaissements e WHERE TRIM(e."Projet") = TRIM(p."Projet")) AS usage '
            'FROM ProjEncaissement p ORDER BY p."Projet"')]
    return rows


def save_projet(code: str, name: str, pid: int | None = None) -> dict:
    name = str(name or "").strip()
    if not name:
        raise G50Error("Veuillez saisir le nom du projet")
    with connect(code) as c:
        dup = c.execute('SELECT "ID" FROM ProjEncaissement WHERE UPPER(TRIM("Projet")) = UPPER(?)', (name,)).fetchone()
        if dup and dup[0] != pid:
            raise Conflict(f"Le projet « {name} » existe déjà")
        if pid is None:
            pid = _next_id(c, "ProjEncaissement", "ID")
            c.execute('INSERT INTO ProjEncaissement ("ID", "Projet") VALUES (?, ?)', (pid, name))
        else:
            old = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
            if old is None:
                raise HTTPException(404, "Projet introuvable")
            c.execute('UPDATE ProjEncaissement SET "Projet" = ? WHERE "ID" = ?', (name, pid))
            c.execute('UPDATE Encaissements SET "Projet" = ? WHERE TRIM("Projet") = TRIM(?)', (name, old[0]))
    return {"_id": pid, "projet": name}


def delete_projet(code: str, pid: int) -> None:
    with connect(code) as c:
        r = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        if r is None:
            raise HTTPException(404, "Projet introuvable")
        n = c.execute('SELECT COUNT(*) FROM Encaissements WHERE TRIM("Projet") = TRIM(?)', (r[0],)).fetchone()[0]
        if n:
            raise Conflict(f"Le projet « {r[0]} » a {n} versement(s) : suppression impossible")
        c.execute('DELETE FROM ProjEncaissement WHERE "ID" = ?', (pid,))


# ------------------------------------------------------------------ versements (Unit18)
def rows(code: str, annee: str, projet: str = "", q: str = "") -> list[dict]:
    sql, args = 'SELECT * FROM Encaissements WHERE CAST("Annee" AS INTEGER) = ?', [int(_num(annee))]
    if projet:
        sql += ' AND "Projet" LIKE ?'
        args.append(f"%{projet}%")
    if q:
        sql += ' AND "Client" LIKE ?'
        args.append(f"%{q}%")
    with connect(code) as c:
        out = [dict(r) for r in c.execute(sql + ' ORDER BY "DateOP", "IDOP"', args)]
    for r in out:
        r["_id"] = r["IDOP"]
        r["date_display"] = dates.to_display(r.get("DateOP"))
    return out


def list_(code: str, annee: str, projet: str = "", q: str = "") -> dict:
    items = rows(code, annee, projet, q)
    tot = lambda k: sum(_num(r.get(k)) for r in items)
    return {"items": items, "totals": {"ttc": tot("MontantTTC"), "ht": tot("HT"), "tva": tot("TVA")},
            "projets": projets(code), "modes": MODES, "taux": [_num(t["TAUX"]) for t in ref.table("TauxTVA")]}


def save(code: str, annee: str, data: dict, item_id: int | None = None) -> dict:
    for k, msg in (("DateOP", "Veuillez saisir la date de l’opération."), ("Client", "Veuillez saisir le nom du client."),
                   ("MontantTTC", "Veuillez saisir le montant TTC."), ("TauxTva", "Veuillez sélectionner le taux TVA."),
                   ("Projet", "Veuillez sélectionner le projet."), ("ModeReg", "Veuillez sélectionner le mode de règlement.")):
        if data.get(k) in (None, "") or (k == "MontantTTC" and not _num(data[k])):
            raise G50Error(msg)
    if data["ModeReg"] not in MODES:
        raise G50Error("Mode de règlement inconnu")
    date_iso = dates.to_storage(data["DateOP"])
    d = dates.parse(date_iso)
    ttc, taux = _num(data["MontantTTC"]), _num(data["TauxTva"])
    ht = ttc / (1 + taux / 100) if taux > 0 else ttc
    values = {"DateOP": date_iso, "Client": str(data["Client"]).strip(), "CodeTier": str(data.get("CodeTier") or ""),
              "MontantTTC": round(ttc, 2), "TauxTva": taux, "HT": round(ht, 2), "TVA": round(ttc - ht, 2),
              "Projet": str(data["Projet"]).strip(), "ModeReg": data["ModeReg"], "obs": str(data.get("obs") or ""),
              "Annee": int(_num(annee)), "NMois": d.month, "Peride": d.month, "LaPeriode": ref.mois_label(d.month)}
    with connect(code) as c:
        if not c.execute('SELECT 1 FROM ProjEncaissement WHERE TRIM("Projet") = ?', (values["Projet"],)).fetchone():
            raise G50Error("Projet inconnu : ajoutez-le d’abord à la liste des projets")
        if item_id is None:
            values["IDOP"] = item_id = _next_id(c, "Encaissements", "IDOP")
            c.execute(f'INSERT INTO Encaissements ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE Encaissements SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} '
                           'WHERE "IDOP" = ?', (*values.values(), item_id)).rowcount:
            raise HTTPException(404, "Versement introuvable")
    return {"id": item_id}


def delete(code: str, item_id: int) -> None:
    with connect(code) as c:
        if not c.execute('DELETE FROM Encaissements WHERE "IDOP" = ?', (item_id,)).rowcount:
            raise HTTPException(404, "Versement introuvable")
