"""Suivi des obligations fiscales, sociales et légales par société et exercice.
Gestion du référentiel des obligations, auto-génération à chaque nouvel exercice,
suivi des dépôts, calcul dynamique des délais et matrice consolidée.
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime
from typing import Any

from fastapi import HTTPException

from ..core import config
from ..core.db import connect
from . import dossiers

DEFAULT_OBLIGATIONS = [
    {
        "code": "G4_IBS",
        "libelle": "G4 — Déclaration annuelle IBS + Liasse fiscale G2",
        "organisme": "DGI",
        "delai_legal": "30 Avril",
        "mois_echeance": 4,
        "jour_echeance": 30,
        "decalage_annee": 1,
        "applicable_a": "SARL, EURL, SPA, SNC",
        "ordre": 1,
        "actif": 1,
    },
    {
        "code": "G1_G11_IRG",
        "libelle": "G1 / G11 — Déclaration annuelle IRG / BIC Réel + Liasse G2",
        "organisme": "DGI",
        "delai_legal": "30 Avril",
        "mois_echeance": 4,
        "jour_echeance": 30,
        "decalage_annee": 1,
        "applicable_a": "Personnes Physiques",
        "ordre": 2,
        "actif": 1,
    },
    {
        "code": "G3_CLIENTS",
        "libelle": "G3 / G3 Bis — État 104 des clients (Ventes en gros)",
        "organisme": "DGI",
        "delai_legal": "30 Avril",
        "mois_echeance": 4,
        "jour_echeance": 30,
        "decalage_annee": 1,
        "applicable_a": "Ventes en gros, Producteurs",
        "ordre": 3,
        "actif": 1,
    },
    {
        "code": "G29_SALAIRES",
        "libelle": "G29 — État 301 bis Déclaration annuelle IRG/Salaires",
        "organisme": "DGI",
        "delai_legal": "30 Avril",
        "mois_echeance": 4,
        "jour_echeance": 30,
        "decalage_annee": 1,
        "applicable_a": "Employeurs",
        "ordre": 4,
        "actif": 1,
    },
    {
        "code": "TAPP",
        "libelle": "TAPP / TFP — Taxe d’apprentissage et formation",
        "organisme": "DGI",
        "delai_legal": "20 Juillet / 20 Janvier",
        "mois_echeance": 7,
        "jour_echeance": 20,
        "decalage_annee": 0,
        "applicable_a": "Assujettis TAPP",
        "ordre": 5,
        "actif": 1,
    },
    {
        "code": "DAS_CNAS",
        "libelle": "DAS — Déclaration annuelle des salaires et salariés",
        "organisme": "CNAS",
        "delai_legal": "31 Janvier",
        "mois_echeance": 1,
        "jour_echeance": 31,
        "decalage_annee": 1,
        "applicable_a": "Employeurs",
        "ordre": 6,
        "actif": 1,
    },
    {
        "code": "CASNOS",
        "libelle": "CASNOS — Cotisation annuelle des non-salariés",
        "organisme": "CASNOS",
        "delai_legal": "30 Juin",
        "mois_echeance": 6,
        "jour_echeance": 30,
        "decalage_annee": 0,
        "applicable_a": "Gérants, Exploitants",
        "ordre": 7,
        "actif": 1,
    },
    {
        "code": "COMPTES_SOCIAUX",
        "libelle": "Comptes Sociaux — Dépôt légal annuel au CNRC",
        "organisme": "CNRC",
        "delai_legal": "31 Juillet",
        "mois_echeance": 7,
        "jour_echeance": 31,
        "decalage_annee": 1,
        "applicable_a": "SARL, EURL, SPA, SNC",
        "ordre": 8,
        "actif": 1,
    },
    {
        "code": "CACOBATPH",
        "libelle": "CACOBATPH — Déclaration annuelle congés & intempéries",
        "organisme": "CACOBATPH",
        "delai_legal": "31 Janvier",
        "mois_echeance": 1,
        "jour_echeance": 31,
        "decalage_annee": 1,
        "applicable_a": "Secteur BTPH",
        "ordre": 9,
        "actif": 0,  # désactivé par défaut, activable selon besoin
    },
]


# ------------------------------------------------------------------ Référentiel des obligations (G50ref.sqlite)

def _ref_conn() -> sqlite3.Connection:
    config.REF_DB.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.REF_DB)
    c.row_factory = sqlite3.Row
    return c


def init_ref_table() -> None:
    """Crée et initialise la table RefObligations dans G50ref.sqlite si inexistante."""
    with _ref_conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS RefObligations (
                code TEXT PRIMARY KEY,
                libelle TEXT NOT NULL,
                organisme TEXT NOT NULL,
                delai_legal TEXT NOT NULL,
                mois_echeance INTEGER NOT NULL DEFAULT 4,
                jour_echeance INTEGER NOT NULL DEFAULT 30,
                decalage_annee INTEGER NOT NULL DEFAULT 1,
                applicable_a TEXT,
                ordre INTEGER NOT NULL DEFAULT 10,
                actif INTEGER NOT NULL DEFAULT 1
            )
        """)
        existing = {r[0] for r in c.execute("SELECT code FROM RefObligations").fetchall()}
        for o in DEFAULT_OBLIGATIONS:
            if o["code"] not in existing:
                c.execute("""
                    INSERT INTO RefObligations (code, libelle, organisme, delai_legal,
                                               mois_echeance, jour_echeance, decalage_annee,
                                               applicable_a, ordre, actif)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    o["code"], o["libelle"], o["organisme"], o["delai_legal"],
                    o["mois_echeance"], o["jour_echeance"], o["decalage_annee"],
                    o["applicable_a"], o["ordre"], o["actif"],
                ))
        c.commit()


def get_ref_obligations(active_only: bool = False) -> list[dict[str, Any]]:
    init_ref_table()
    with _ref_conn() as c:
        sql = "SELECT * FROM RefObligations"
        if active_only:
            sql += " WHERE actif = 1"
        sql += " ORDER BY ordre ASC, code ASC"
        return [dict(r) for r in c.execute(sql).fetchall()]


def update_ref_obligation(code: str, data: dict[str, Any]) -> dict[str, Any]:
    init_ref_table()
    allowed = {"libelle", "organisme", "delai_legal", "mois_echeance", "jour_echeance",
               "decalage_annee", "applicable_a", "ordre", "actif"}
    updates = {k: data[k] for k in allowed if k in data}
    if not updates:
        raise HTTPException(400, "Aucun champ valide à mettre à jour")
    with _ref_conn() as c:
        set_clause = ", ".join(f'"{k}" = ?' for k in updates)
        c.execute(f"UPDATE RefObligations SET {set_clause} WHERE code = ?", (*updates.values(), code))
        c.commit()
        r = c.execute("SELECT * FROM RefObligations WHERE code = ?", (code,)).fetchone()
        if not r:
            raise HTTPException(404, f"Obligation {code} introuvable")
        return dict(r)


def add_ref_obligation(data: dict[str, Any]) -> dict[str, Any]:
    init_ref_table()
    code = str(data.get("code") or "").strip().upper().replace(" ", "_")
    if not code:
        raise HTTPException(400, "Le code de l’obligation est obligatoire")
    libelle = str(data.get("libelle") or "").strip()
    if not libelle:
        raise HTTPException(400, "Le libellé de l’obligation est obligatoire")
    with _ref_conn() as c:
        exists = c.execute("SELECT 1 FROM RefObligations WHERE code = ?", (code,)).fetchone()
        if exists:
            raise HTTPException(409, f"Une obligation avec le code « {code} » existe déjà")
        c.execute("""
            INSERT INTO RefObligations (code, libelle, organisme, delai_legal,
                                       mois_echeance, jour_echeance, decalage_annee,
                                       applicable_a, ordre, actif)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            code,
            libelle,
            str(data.get("organisme") or "DGI").strip().upper(),
            str(data.get("delai_legal") or "30 Avril").strip(),
            int(data.get("mois_echeance", 4)),
            int(data.get("jour_echeance", 30)),
            int(data.get("decalage_annee", 1)),
            str(data.get("applicable_a") or "").strip(),
            int(data.get("ordre", 99)),
            int(data.get("actif", 1)),
        ))
        c.commit()
        r = c.execute("SELECT * FROM RefObligations WHERE code = ?", (code,)).fetchone()
        return dict(r)


# ------------------------------------------------------------------ Suivi des obligations par société

def ensure_dossier_table(conn: sqlite3.Connection) -> None:
    """Crée la table SuiviObligations dans le fichier SQLite de la société."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS SuiviObligations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exercice TEXT NOT NULL,
            code_obligation TEXT NOT NULL,
            concerne INTEGER NOT NULL DEFAULT 1,
            date_depot TEXT,
            ref_quittance TEXT,
            montant REAL DEFAULT 0,
            observations TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_suivi_obl_ex ON SuiviObligations (exercice, code_obligation)")


def _determine_default_concerne(fj: str, obl_code: str, sector: str = "") -> int:
    """Détermine si la société est concernée par défaut selon sa forme juridique."""
    fj_norm = (fj or "").strip().lower()
    is_pm = any(k in fj_norm for k in ("sarl", "eurl", "spa", "snc"))
    is_pp = "personne physique" in fj_norm or "physique" in fj_norm

    if obl_code == "G4_IBS":
        return 1 if is_pm else 0
    if obl_code == "G1_G11_IRG":
        return 1 if is_pp else 0
    if obl_code == "COMPTES_SOCIAUX":
        return 1 if is_pm else 0
    if obl_code == "CASNOS":
        return 1 if is_pp else 0
    if obl_code == "CACOBATPH":
        return 1 if "bâtiment" in sector.lower() or "travaux" in sector.lower() else 0
    # Par défaut pour G3, G29, DAS, TAPP : activé
    return 1


def auto_generate_for_exercice(code: str, exercice: str) -> None:
    """Génère automatiquement les lignes d’obligations pour l'exercice spécifié si absentes."""
    init_ref_table()
    ref_list = get_ref_obligations(active_only=True)
    if not ref_list:
        return

    annee_str = str(exercice).strip()
    with connect(code) as c:
        ensure_dossier_table(c)
        existing = {r[0] for r in c.execute("SELECT code_obligation FROM SuiviObligations WHERE exercice = ?", (annee_str,)).fetchall()}
        
        # Vérifier si l'exercice précédent existe pour hériter des préférences 'concerne'
        prev_annee = str(int(annee_str) - 1) if annee_str.isdigit() else ""
        prev_concerne = {}
        if prev_annee:
            for r in c.execute("SELECT code_obligation, concerne FROM SuiviObligations WHERE exercice = ?", (prev_annee,)).fetchall():
                prev_concerne[r[0]] = int(r[1])

        # Informations de la société pour les règles de défaut
        soc = c.execute("SELECT fj, cbilan FROM clients LIMIT 1").fetchone()
        fj = soc[0] if soc else ""
        sector = soc[1] if soc and len(soc) > 1 else ""

        now_iso = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        missing_obls = [o for o in ref_list if o["code"] not in existing]
        for o in missing_obls:
            obl_code = o["code"]
            if obl_code in prev_concerne:
                concerne = prev_concerne[obl_code]
            else:
                concerne = _determine_default_concerne(fj, obl_code, sector)

            c.execute("""
                INSERT INTO SuiviObligations (exercice, code_obligation, concerne,
                                             date_depot, ref_quittance, montant,
                                             observations, created_at, updated_at)
                VALUES (?, ?, ?, NULL, '', 0, '', ?, ?)
            """, (annee_str, obl_code, concerne, now_iso, now_iso))


def _compute_status(row: dict[str, Any], today: date | None = None) -> dict[str, Any]:
    """Calcule le statut exact, l'échéance et les jours restants/de retard."""
    today = today or date.today()
    exercice_str = str(row["exercice"]).strip()
    exercice_num = int(exercice_str) if exercice_str.isdigit() else today.year

    decalage = int(row.get("decalage_annee", 1))
    target_year = exercice_num + decalage
    mois_ech = int(row.get("mois_echeance", 4))
    jour_ech = int(row.get("jour_echeance", 30))

    try:
        echeance_date = date(target_year, mois_ech, jour_ech)
    except ValueError:
        echeance_date = date(target_year, mois_ech, 28)

    date_depot_str = (row.get("date_depot") or "").strip()
    concerne = bool(row.get("concerne", 1))

    out = dict(row)
    out["date_echeance"] = echeance_date.isoformat()
    out["date_echeance_display"] = echeance_date.strftime("%d/%m/%Y")

    if not concerne:
        out["statut"] = "non_concerne"
        out["statut_label"] = "Non concerné"
        out["statut_color"] = "muted"
        out["jours_restants"] = None
        out["jours_retard"] = None
        out["depose_a_temps"] = None
        return out

    if date_depot_str:
        out["statut"] = "depose"
        out["statut_label"] = "Déposé ✓"
        out["statut_color"] = "success"
        out["jours_restants"] = 0
        out["jours_retard"] = 0
        # Comparer date de dépôt et échéance si date_depot est analysable
        try:
            dp = date.fromisoformat(date_depot_str[:10])
            out["depose_a_temps"] = dp <= echeance_date
        except ValueError:
            out["depose_a_temps"] = True
        return out

    # Non encore déposé
    diff_days = (echeance_date - today).days
    if diff_days < 0:
        out["statut"] = "retard"
        out["statut_label"] = f"En retard (+{abs(diff_days)} j)"
        out["statut_color"] = "danger"
        out["jours_restants"] = 0
        out["jours_retard"] = abs(diff_days)
        out["depose_a_temps"] = False
    elif diff_days <= 15:
        out["statut"] = "urgent"
        out["statut_label"] = f"Échéance proche ({diff_days} j)"
        out["statut_color"] = "warning"
        out["jours_restants"] = diff_days
        out["jours_retard"] = 0
        out["depose_a_temps"] = None
    else:
        out["statut"] = "en_cours"
        out["statut_label"] = f"À faire ({diff_days} j)"
        out["statut_color"] = "info"
        out["jours_restants"] = diff_days
        out["jours_retard"] = 0
        out["depose_a_temps"] = None

    return out


def list_dossier_obligations(code: str, exercice: str) -> dict[str, Any]:
    """Récupère les obligations d'un dossier pour un exercice donné avec calcul dynamique."""
    annee_str = str(exercice).strip()
    auto_generate_for_exercice(code, annee_str)

    ref_map = {o["code"]: o for o in get_ref_obligations(active_only=False)}

    with connect(code) as c:
        ensure_dossier_table(c)
        rows = c.execute("""
            SELECT id, exercice, code_obligation, concerne, date_depot,
                   ref_quittance, montant, observations, created_at, updated_at
            FROM SuiviObligations
            WHERE exercice = ?
        """, (annee_str,)).fetchall()

    enriched = []
    for r in rows:
        d = dict(r)
        ref = ref_map.get(d["code_obligation"], {})
        d["libelle"] = ref.get("libelle", d["code_obligation"])
        d["organisme"] = ref.get("organisme", "AUTRE")
        d["delai_legal"] = ref.get("delai_legal", "—")
        d["mois_echeance"] = ref.get("mois_echeance", 4)
        d["jour_echeance"] = ref.get("jour_echeance", 30)
        d["decalage_annee"] = ref.get("decalage_annee", 1)
        d["ordre"] = ref.get("ordre", 99)
        d["actif"] = ref.get("actif", 1)
        enriched.append(_compute_status(d))

    enriched.sort(key=lambda x: (x.get("ordre", 99), x.get("organisme", ""), x.get("code_obligation", "")))

    concernés = [x for x in enriched if x["concerne"]]
    déposés = [x for x in concernés if x["statut"] == "depose"]
    retards = [x for x in concernés if x["statut"] == "retard"]
    en_attente = [x for x in concernés if x["statut"] in ("en_cours", "urgent")]

    total_c = len(concernés)
    total_d = len(déposés)
    taux = round((total_d / total_c) * 100) if total_c > 0 else 100

    return {
        "dossier": code,
        "exercice": annee_str,
        "items": enriched,
        "stats": {
            "total_obligations": len(enriched),
            "total_concernes": total_c,
            "total_deposes": total_d,
            "total_retards": len(retards),
            "total_en_attente": len(en_attente),
            "taux_conformite": taux,
        },
    }


def update_dossier_obligation(code: str, item_id: int, data: dict[str, Any]) -> dict[str, Any]:
    """Met à jour un enregistrement de suivi (date dépôt, quittance, concerne...)."""
    with connect(code) as c:
        ensure_dossier_table(c)
        r = c.execute("SELECT * FROM SuiviObligations WHERE id = ?", (item_id,)).fetchone()
        if not r:
            raise HTTPException(404, "Enregistrement d'obligation introuvable")

        now_iso = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        updates = {"updated_at": now_iso}

        if "concerne" in data:
            updates["concerne"] = 1 if data["concerne"] in (1, True, "1", "true") else 0
        if "date_depot" in data:
            v = str(data["date_depot"] or "").strip()
            updates["date_depot"] = v if v else None
        if "ref_quittance" in data:
            updates["ref_quittance"] = str(data["ref_quittance"] or "").strip()
        if "montant" in data:
            try:
                updates["montant"] = float(data["montant"]) if data["montant"] not in (None, "") else 0.0
            except ValueError:
                updates["montant"] = 0.0
        if "observations" in data:
            updates["observations"] = str(data["observations"] or "").strip()

        set_clause = ", ".join(f'"{k}" = ?' for k in updates)
        c.execute(f"UPDATE SuiviObligations SET {set_clause} WHERE id = ?", (*updates.values(), item_id))
        c.commit()

        updated_row = c.execute("SELECT * FROM SuiviObligations WHERE id = ?", (item_id,)).fetchone()
        ref_map = {o["code"]: o for o in get_ref_obligations(active_only=False)}
        d = dict(updated_row)
        ref = ref_map.get(d["code_obligation"], {})
        d["libelle"] = ref.get("libelle", d["code_obligation"])
        d["organisme"] = ref.get("organisme", "AUTRE")
        d["delai_legal"] = ref.get("delai_legal", "—")
        d["mois_echeance"] = ref.get("mois_echeance", 4)
        d["jour_echeance"] = ref.get("jour_echeance", 30)
        d["decalage_annee"] = ref.get("decalage_annee", 1)
        return _compute_status(d)


# ------------------------------------------------------------------ Matrice consolidée multi-sociétés

def matrice_consolidee(exercice: str) -> dict[str, Any]:
    """Construit la matrice complète de conformité pour tous les dossiers sur un exercice."""
    annee_str = str(exercice).strip()
    all_dossiers = dossiers.list_dossiers()
    ref_list = get_ref_obligations(active_only=True)

    dossiers_data = []
    totaux_par_obl: dict[str, dict[str, int]] = {
        o["code"]: {"concernes": 0, "deposes": 0, "retards": 0, "en_attente": 0}
        for o in ref_list
    }

    for d in all_dossiers:
        code = d["code"]
        res = list_dossier_obligations(code, annee_str)
        items_by_code = {item["code_obligation"]: item for item in res["items"]}

        # Mettre à jour les totaux par obligation
        for o in ref_list:
            c = o["code"]
            it = items_by_code.get(c)
            if it and it.get("concerne"):
                totaux_par_obl[c]["concernes"] += 1
                if it["statut"] == "depose":
                    totaux_par_obl[c]["deposes"] += 1
                elif it["statut"] == "retard":
                    totaux_par_obl[c]["retards"] += 1
                elif it["statut"] in ("en_cours", "urgent"):
                    totaux_par_obl[c]["en_attente"] += 1

        dossiers_data.append({
            "code": code,
            "rs": d.get("rs") or code,
            "nif": d.get("nif") or "",
            "fj": d.get("fj") or "",
            "stats": res["stats"],
            "obligations": items_by_code,
        })

    return {
        "exercice": annee_str,
        "ref_obligations": ref_list,
        "dossiers": dossiers_data,
        "totaux_par_obligation": totaux_par_obl,
        "total_societes": len(dossiers_data),
    }
