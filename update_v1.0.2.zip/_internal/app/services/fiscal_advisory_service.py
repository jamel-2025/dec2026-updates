"""Fiscal Advisory & Contentious System (الاستشارة والنزاعات الجبائية).

Provides:
1. Optimization Simulators:
   - Arbitrage Salaire de Gérance vs Dividendes (Optimal Tax Mix)
   - Choix de la Forme Juridique (Personne Physique vs Auto-entrepreneur vs SARL/EURL)
   - Financement d'actifs (Leasing vs Achat direct & plafonds d'amortissement)
2. Prescription Fiscale Radar (Délai quadriennal 4 ans Art. 39 CPF)
3. Notifications de Redressement (Modèles 152 / 153) & Éditeur de Réponses juridiques
4. Réclamations Contentieuses & Recours (Art. 72 CPF, Sursis 20%, Commissions Daïra/Wilaya)
5. Base juridique et modèles de courriers officiels

Persisted in data/audit.sqlite.
"""
from __future__ import annotations

import io
import json
import re
import shutil
import sqlite3
import zipfile
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS fiscal_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dossier TEXT NOT NULL,
    type_notification TEXT NOT NULL DEFAULT 'MODELE_152',
    reference_lettre TEXT NOT NULL DEFAULT '',
    inspecteur_service TEXT NOT NULL DEFAULT '',
    date_reception TEXT NOT NULL,
    delai_jours INTEGER NOT NULL DEFAULT 40,
    date_echeance TEXT NOT NULL,
    annee_verifiee TEXT NOT NULL DEFAULT '',
    montant_rappele REAL NOT NULL DEFAULT 0.0,
    penalites REAL NOT NULL DEFAULT 0.0,
    montant_total REAL NOT NULL DEFAULT 0.0,
    motifs TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'en_attente',
    reponse_contenu TEXT NOT NULL DEFAULT '',
    date_reponse TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fisc_notif_dossier ON fiscal_notifications(dossier);
CREATE INDEX IF NOT EXISTS idx_fisc_notif_status ON fiscal_notifications(status);
CREATE INDEX IF NOT EXISTS idx_fisc_notif_echeance ON fiscal_notifications(date_echeance);

CREATE TABLE IF NOT EXISTS fiscal_reclamations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dossier TEXT NOT NULL,
    notification_id INTEGER,
    reference_reclamation TEXT NOT NULL DEFAULT '',
    type_recours TEXT NOT NULL DEFAULT 'DIRECTEUR_WILAYA',
    date_depot TEXT NOT NULL,
    accuse_reception_num TEXT NOT NULL DEFAULT '',
    montant_conteste REAL NOT NULL DEFAULT 0.0,
    demande_sursis INTEGER NOT NULL DEFAULT 1,
    montant_garantie_20 REAL NOT NULL DEFAULT 0.0,
    statut TEXT NOT NULL DEFAULT 'en_cours',
    montant_decharge REAL NOT NULL DEFAULT 0.0,
    montant_maintenu REAL NOT NULL DEFAULT 0.0,
    decision_date TEXT,
    decision_ref TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(notification_id) REFERENCES fiscal_notifications(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_fisc_recl_dossier ON fiscal_reclamations(dossier);
CREATE INDEX IF NOT EXISTS idx_fisc_recl_statut ON fiscal_reclamations(statut);

CREATE TABLE IF NOT EXISTS fiscal_demandes_c20 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dossier TEXT NOT NULL,
    motif_cle TEXT NOT NULL DEFAULT 'banque',
    motif_titre_ar TEXT NOT NULL DEFAULT '',
    motif_titre_fr TEXT NOT NULL DEFAULT '',
    destinataire_type TEXT NOT NULL DEFAULT 'INSPECTION',
    destinataire_nom TEXT NOT NULL DEFAULT '',
    regime_fiscal TEXT NOT NULL DEFAULT 'REEL',
    date_debut_activite TEXT NOT NULL DEFAULT '',
    annees_demandees TEXT NOT NULL DEFAULT '',
    chiffres_affaires_json TEXT NOT NULL DEFAULT '[]',
    avec_pieces_jointes INTEGER NOT NULL DEFAULT 1,
    pieces_jointes_json TEXT NOT NULL DEFAULT '[]',
    statut TEXT NOT NULL DEFAULT 'en_attente',
    date_demande TEXT NOT NULL,
    numero_enregistrement TEXT NOT NULL DEFAULT '',
    texte_ar TEXT NOT NULL DEFAULT '',
    texte_fr TEXT NOT NULL DEFAULT '',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fisc_c20_dossier ON fiscal_demandes_c20(dossier);
CREATE INDEX IF NOT EXISTS idx_fisc_c20_statut ON fiscal_demandes_c20(statut);

CREATE TABLE IF NOT EXISTS fiscal_dossier_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dossier TEXT NOT NULL,
    categorie TEXT NOT NULL,
    type_document TEXT NOT NULL,
    titre TEXT NOT NULL,
    reference TEXT NOT NULL DEFAULT '',
    exercice TEXT NOT NULL DEFAULT '',
    date_emission TEXT NOT NULL DEFAULT '',
    date_expiration TEXT NOT NULL DEFAULT '',
    fichier_nom TEXT NOT NULL,
    fichier_rel_path TEXT NOT NULL,
    taille_octets INTEGER NOT NULL DEFAULT 0,
    mime_type TEXT NOT NULL DEFAULT 'application/pdf',
    source_capture TEXT NOT NULL DEFAULT 'upload',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fisc_doc_dossier ON fiscal_dossier_documents(dossier);
CREATE INDEX IF NOT EXISTS idx_fisc_doc_categorie ON fiscal_dossier_documents(categorie);
CREATE INDEX IF NOT EXISTS idx_fisc_doc_type ON fiscal_dossier_documents(type_document);
CREATE INDEX IF NOT EXISTS idx_fisc_doc_exercice ON fiscal_dossier_documents(exercice);
"""


def _conn() -> sqlite3.Connection:
    config.AUDIT_DB.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(config.AUDIT_DB), timeout=10.0, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init():
    with _conn() as c:
        try:
            c.execute("ALTER TABLE fiscal_dossier_documents ADD COLUMN exercice TEXT NOT NULL DEFAULT ''")
        except Exception:
            pass
        c.executescript(_SCHEMA)
        c.commit()


try:
    init()
except Exception as e:
    print(f"Warning: Could not initialize fiscal advisory schema: {e}")


def _get_dossier_name(dossier_code: str) -> str:
    if not dossier_code:
        return ""
    try:
        from ..core.db import connect
        with connect(dossier_code) as c:
            r = c.execute("SELECT rs FROM clients LIMIT 1").fetchone()
            if r and r["rs"]:
                return str(r["rs"]).strip()
    except Exception:
        pass
    return ""


# ---------------------------------------------------------------------------
# 1. NOTIFICATIONS DE REDRESSEMENT
# ---------------------------------------------------------------------------

def list_notifications(dossier: Optional[str] = None, status: Optional[str] = None) -> List[Dict[str, Any]]:
    today = date.today()
    with _conn() as c:
        query = "SELECT * FROM fiscal_notifications WHERE 1=1"
        params: List[Any] = []
        if dossier and dossier != "all":
            query += " AND dossier = ?"
            params.append(dossier)
        if status and status != "all":
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY CASE status WHEN 'en_attente' THEN 1 ELSE 2 END, date_echeance ASC"
        rows = c.execute(query, params).fetchall()

    results = []
    for r in rows:
        d = dict(r)
        d["rs"] = _get_dossier_name(d["dossier"])
        # Compute countdown
        try:
            ech = datetime.strptime(d["date_echeance"], "%Y-%m-%d").date()
            diff = (ech - today).days
            d["jours_restants"] = diff
            d["is_overdue"] = diff < 0
            d["is_urgent"] = 0 <= diff <= 10
        except Exception:
            d["jours_restants"] = 0
            d["is_overdue"] = False
            d["is_urgent"] = False
        results.append(d)
    return results


def create_notification(data: Dict[str, Any]) -> Dict[str, Any]:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    reception = data.get("date_reception", date.today().strftime("%Y-%m-%d"))
    t_notif = data.get("type_notification", "MODELE_1")
    default_delai = 30 if t_notif in ("MODELE_2", "MODELE_3", "MODELE_153", "MISE_EN_DEMEURE") else (15 if t_notif == "AVIS_151" else 40)
    delai = int(data.get("delai_jours") or default_delai)
    try:
        rec_date = datetime.strptime(reception, "%Y-%m-%d").date()
        echeance = (rec_date + timedelta(days=delai)).strftime("%Y-%m-%d")
    except Exception:
        echeance = (date.today() + timedelta(days=delai)).strftime("%Y-%m-%d")

    rappele = float(data.get("montant_rappele", 0.0))
    penalites = float(data.get("penalites", 0.0))
    total = rappele + penalites

    with _conn() as c:
        cur = c.execute(
            """INSERT INTO fiscal_notifications (
                dossier, type_notification, reference_lettre, inspecteur_service,
                date_reception, delai_jours, date_echeance, annee_verifiee,
                montant_rappele, penalites, montant_total, motifs, status,
                reponse_contenu, date_reponse, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("dossier", "S1"),
                data.get("type_notification", "MODELE_1"),
                data.get("reference_lettre", "").strip(),
                data.get("inspecteur_service", "").strip(),
                reception,
                delai,
                echeance,
                data.get("annee_verifiee", "").strip(),
                rappele,
                penalites,
                total,
                data.get("motifs", "").strip(),
                data.get("status", "en_attente"),
                data.get("reponse_contenu", ""),
                data.get("date_reponse"),
                now,
                now,
            ),
        )
        c.commit()
        new_id = cur.lastrowid

    return get_notification(new_id)  # type: ignore


def get_notification(notif_id: int) -> Optional[Dict[str, Any]]:
    today = date.today()
    with _conn() as c:
        r = c.execute("SELECT * FROM fiscal_notifications WHERE id = ?", (notif_id,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["rs"] = _get_dossier_name(d["dossier"])
    try:
        ech = datetime.strptime(d["date_echeance"], "%Y-%m-%d").date()
        diff = (ech - today).days
        d["jours_restants"] = diff
        d["is_overdue"] = diff < 0
        d["is_urgent"] = 0 <= diff <= 10
    except Exception:
        d["jours_restants"] = 0
        d["is_overdue"] = False
        d["is_urgent"] = False
    return d


def update_notification(notif_id: int, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    reception = data.get("date_reception")
    delai = data.get("delai_jours")
    echeance = None
    if reception and delai:
        try:
            rec_date = datetime.strptime(reception, "%Y-%m-%d").date()
            echeance = (rec_date + timedelta(days=int(delai))).strftime("%Y-%m-%d")
        except Exception:
            pass

    rappele = data.get("montant_rappele")
    penalites = data.get("penalites")
    total = None
    if rappele is not None and penalites is not None:
        total = float(rappele) + float(penalites)

    with _conn() as c:
        fields = []
        params = []
        for col, val in [
            ("dossier", data.get("dossier")),
            ("type_notification", data.get("type_notification")),
            ("reference_lettre", data.get("reference_lettre")),
            ("inspecteur_service", data.get("inspecteur_service")),
            ("date_reception", reception),
            ("delai_jours", delai),
            ("date_echeance", echeance),
            ("annee_verifiee", data.get("annee_verifiee")),
            ("montant_rappele", rappele),
            ("penalites", penalites),
            ("montant_total", total),
            ("motifs", data.get("motifs")),
            ("status", data.get("status")),
            ("reponse_contenu", data.get("reponse_contenu")),
            ("date_reponse", data.get("date_reponse")),
            ("updated_at", now),
        ]:
            if val is not None:
                fields.append(f"{col} = ?")
                params.append(val)

        if not fields:
            return get_notification(notif_id)

        params.append(notif_id)
        c.execute(f"UPDATE fiscal_notifications SET {', '.join(fields)} WHERE id = ?", params)
        c.commit()

    return get_notification(notif_id)


def delete_notification(notif_id: int) -> bool:
    with _conn() as c:
        c.execute("DELETE FROM fiscal_notifications WHERE id = ?", (notif_id,))
        c.commit()
    return True


# ---------------------------------------------------------------------------
# 2. RÉCLAMATIONS CONTENTIEUSES & RECOURS
# ---------------------------------------------------------------------------

def list_reclamations(dossier: Optional[str] = None, statut: Optional[str] = None) -> List[Dict[str, Any]]:
    with _conn() as c:
        query = "SELECT * FROM fiscal_reclamations WHERE 1=1"
        params: List[Any] = []
        if dossier and dossier != "all":
            query += " AND dossier = ?"
            params.append(dossier)
        if statut and statut != "all":
            query += " AND statut = ?"
            params.append(statut)
        query += " ORDER BY date_depot DESC"
        rows = c.execute(query, params).fetchall()

    results = []
    for r in rows:
        d = dict(r)
        d["rs"] = _get_dossier_name(d["dossier"])
        results.append(d)
    return results


def create_reclamation(data: Dict[str, Any]) -> Dict[str, Any]:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conteste = float(data.get("montant_conteste", 0.0))
    sursis = int(data.get("demande_sursis", 1))
    garantie_20 = round(conteste * 0.20, 2) if sursis else 0.0

    with _conn() as c:
        cur = c.execute(
            """INSERT INTO fiscal_reclamations (
                dossier, notification_id, reference_reclamation, type_recours,
                date_depot, accuse_reception_num, montant_conteste, demande_sursis,
                montant_garantie_20, statut, montant_decharge, montant_maintenu,
                decision_date, decision_ref, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("dossier", "S1"),
                data.get("notification_id"),
                data.get("reference_reclamation", "").strip(),
                data.get("type_recours", "DIRECTEUR_WILAYA"),
                data.get("date_depot", date.today().strftime("%Y-%m-%d")),
                data.get("accuse_reception_num", "").strip(),
                conteste,
                sursis,
                garantie_20,
                data.get("statut", "en_cours"),
                float(data.get("montant_decharge", 0.0)),
                float(data.get("montant_maintenu", 0.0)),
                data.get("decision_date"),
                data.get("decision_ref", "").strip(),
                data.get("notes", "").strip(),
                now,
                now,
            ),
        )
        c.commit()
        new_id = cur.lastrowid

    return get_reclamation(new_id)  # type: ignore


def get_reclamation(rec_id: int) -> Optional[Dict[str, Any]]:
    with _conn() as c:
        r = c.execute("SELECT * FROM fiscal_reclamations WHERE id = ?", (rec_id,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["rs"] = _get_dossier_name(d["dossier"])
    return d


def update_reclamation(rec_id: int, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with _conn() as c:
        fields = []
        params = []
        for col in [
            "dossier", "notification_id", "reference_reclamation", "type_recours",
            "date_depot", "accuse_reception_num", "montant_conteste", "demande_sursis",
            "montant_garantie_20", "statut", "montant_decharge", "montant_maintenu",
            "decision_date", "decision_ref", "notes"
        ]:
            if col in data:
                fields.append(f"{col} = ?")
                params.append(data[col])
        if not fields:
            return get_reclamation(rec_id)
        fields.append("updated_at = ?")
        params.append(now)
        params.append(rec_id)
        c.execute(f"UPDATE fiscal_reclamations SET {', '.join(fields)} WHERE id = ?", params)
        c.commit()
    return get_reclamation(rec_id)


def delete_reclamation(rec_id: int) -> bool:
    with _conn() as c:
        c.execute("DELETE FROM fiscal_reclamations WHERE id = ?", (rec_id,))
        c.commit()
    return True


# ---------------------------------------------------------------------------
# 3. STATISTIQUES GLOBALES CONSEIL & CONTENTIEUX
# ---------------------------------------------------------------------------

def get_contentieux_summary() -> Dict[str, Any]:
    today_str = date.today().strftime("%Y-%m-%d")
    with _conn() as c:
        # Notifications
        notif_total = c.execute("SELECT COUNT(*) FROM fiscal_notifications").fetchone()[0]
        notif_en_attente = c.execute("SELECT COUNT(*) FROM fiscal_notifications WHERE status = 'en_attente'").fetchone()[0]
        notif_urgentes = c.execute(
            """SELECT COUNT(*) FROM fiscal_notifications
               WHERE status = 'en_attente' AND date(date_echeance) >= date(?)
               AND julianday(date_echeance) - julianday(?) <= 10""",
            (today_str, today_str),
        ).fetchone()[0]
        notif_overdue = c.execute(
            "SELECT COUNT(*) FROM fiscal_notifications WHERE status = 'en_attente' AND date(date_echeance) < date(?)",
            (today_str,),
        ).fetchone()[0]
        total_rappele = c.execute("SELECT COALESCE(SUM(montant_total), 0) FROM fiscal_notifications").fetchone()[0]

        # Reclamations
        recl_total = c.execute("SELECT COUNT(*) FROM fiscal_reclamations").fetchone()[0]
        recl_en_cours = c.execute("SELECT COUNT(*) FROM fiscal_reclamations WHERE statut = 'en_cours'").fetchone()[0]
        total_conteste = c.execute("SELECT COALESCE(SUM(montant_conteste), 0) FROM fiscal_reclamations").fetchone()[0]
        total_gagne = c.execute("SELECT COALESCE(SUM(montant_decharge), 0) FROM fiscal_reclamations").fetchone()[0]
        total_sursis = c.execute("SELECT COALESCE(SUM(montant_garantie_20), 0) FROM fiscal_reclamations WHERE statut = 'en_cours'").fetchone()[0]

    return {
        "notifications": {
            "total": notif_total,
            "en_attente": notif_en_attente,
            "urgentes": notif_urgentes,
            "overdue": notif_overdue,
            "montant_rappele_total": round(total_rappele, 2),
        },
        "reclamations": {
            "total": recl_total,
            "en_cours": recl_en_cours,
            "montant_conteste_total": round(total_conteste, 2),
            "montant_gagne_total": round(total_gagne, 2),
            "montant_garantie_sursis": round(total_sursis, 2),
        },
    }


# ---------------------------------------------------------------------------
# 4. SIMULATEURS D'OPTIMISATION FISCALE
# ---------------------------------------------------------------------------

def _calc_irg_salaires_annuel(salaire_mensuel_brut: float) -> float:
    """Calcul de l'IRG Salaires selon le barème officiel algérien progressif."""
    if salaire_mensuel_brut <= 20000:
        return 0.0

    # Tranches mensuelles
    base = salaire_mensuel_brut
    impot = 0.0
    if base > 320000:
        impot += (base - 320000) * 0.35
        base = 320000
    if base > 160000:
        impot += (base - 160000) * 0.33
        base = 160000
    if base > 80000:
        impot += (base - 80000) * 0.30
        base = 80000
    if base > 40000:
        impot += (base - 40000) * 0.27
        base = 40000
    if base > 20000:
        impot += (base - 20000) * 0.23

    # Abattement 40% (min 1000 DA, max 1500 DA/mois)
    abattement = impot * 0.40
    if abattement < 1000.0:
        abattement = 1000.0
    if abattement > 1500.0:
        abattement = 1500.0

    impot_mensuel = max(0.0, impot - abattement)
    return round(impot_mensuel * 12, 2)


def _calc_casnos_annuel(remuneration_annuelle: float) -> float:
    """Cotisation CASNOS (15% avec plancher 3xSNMG et plafond 20xSNMG)."""
    snmg_annuel = 20000.0 * 12  # 240,000 DA
    plancher = 3 * snmg_annuel  # 720,000 DA assiette min -> 108,000 DA cotis
    plafond = 20 * snmg_annuel  # 4,800,000 DA assiette max -> 720,000 DA cotis
    assiette = max(plancher, min(plafond, remuneration_annuelle))
    return round(assiette * 0.15, 2)


def simulate_arbitrage_salaire_dividendes(
    benefice_annuel_brut: float,
    taux_ibs: float = 0.26,
    salaire_mensuel_propose: float = 150000.0,
) -> Dict[str, Any]:
    """Compare Scenario A (Salaire de gérance) vs Scenario B (Dividendes) vs Scenario C (Optimal Mix)."""
    taux_rcm_dividendes = 0.10  # 10% IRG/RCM libératoire

    # --- SCENARIO 1 : 100% DIVIDENDES (Aucun salaire) ---
    ibs_sc1 = round(benefice_annuel_brut * taux_ibs, 2)
    bénéfice_distribuable_sc1 = max(0.0, benefice_annuel_brut - ibs_sc1)
    irg_rcm_sc1 = round(bénéfice_distribuable_sc1 * taux_rcm_dividendes, 2)
    net_poche_sc1 = round(bénéfice_distribuable_sc1 - irg_rcm_sc1, 2)
    total_prelevements_sc1 = round(ibs_sc1 + irg_rcm_sc1, 2)

    # --- SCENARIO 2 : SALAIRE PROPOSÉ + RESTE EN DIVIDENDES ---
    salaire_annuel = salaire_mensuel_propose * 12
    salaire_annuel_effectif = min(benefice_annuel_brut, salaire_annuel)
    casnos_sc2 = _calc_casnos_annuel(salaire_annuel_effectif)
    irg_salaire_sc2 = _calc_irg_salaires_annuel(salaire_mensuel_propose)

    # Déduction fiscale de l'IBS
    charge_deductible = salaire_annuel_effectif + casnos_sc2
    benefice_imposable_sc2 = max(0.0, benefice_annuel_brut - charge_deductible)
    ibs_sc2 = round(benefice_imposable_sc2 * taux_ibs, 2)
    solde_distribuable_sc2 = max(0.0, benefice_imposable_sc2 - ibs_sc2)
    irg_rcm_sc2 = round(solde_distribuable_sc2 * taux_rcm_dividendes, 2)
    dividendes_nets_sc2 = round(solde_distribuable_sc2 - irg_rcm_sc2, 2)

    net_salaire_sc2 = max(0.0, salaire_annuel_effectif - casnos_sc2 - irg_salaire_sc2)
    net_poche_sc2 = round(net_salaire_sc2 + dividendes_nets_sc2, 2)
    total_prelevements_sc2 = round(casnos_sc2 + irg_salaire_sc2 + ibs_sc2 + irg_rcm_sc2, 2)

    # --- SCENARIO 3 : RECHERCHE DU MIX OPTIMAL (Point d'équilibre) ---
    # Recherche par pas de 10 000 DA
    meilleur_net = net_poche_sc1
    meilleur_salaire_m = 0.0
    for sal_m in range(0, int(benefice_annuel_brut / 12) + 1, 10000):
        s_ann = sal_m * 12
        c_cas = _calc_casnos_annuel(s_ann)
        c_irg = _calc_irg_salaires_annuel(sal_m)
        b_imp = max(0.0, benefice_annuel_brut - s_ann - c_cas)
        c_ibs = b_imp * taux_ibs
        solde_dist = max(0.0, b_imp - c_ibs)
        c_rcm = solde_dist * taux_rcm_dividendes
        net_tot = (s_ann - c_cas - c_irg) + (solde_dist - c_rcm)
        if net_tot > meilleur_net:
            meilleur_net = net_tot
            meilleur_salaire_m = float(sal_m)

    economie_potentielle = round(meilleur_net - net_poche_sc1, 2)

    return {
        "benefice_annuel_brut": benefice_annuel_brut,
        "taux_ibs": taux_ibs,
        "scenario_dividendes": {
            "salaire_annuel": 0,
            "casnos": 0,
            "irg_salaires": 0,
            "ibs": ibs_sc1,
            "irg_rcm": irg_rcm_sc1,
            "net_en_poche": net_poche_sc1,
            "total_prelevements": total_prelevements_sc1,
            "pression_fiscale_pct": round((total_prelevements_sc1 / benefice_annuel_brut) * 100, 1) if benefice_annuel_brut > 0 else 0,
        },
        "scenario_salaire_propose": {
            "salaire_mensuel": salaire_mensuel_propose,
            "salaire_annuel": salaire_annuel_effectif,
            "casnos": casnos_sc2,
            "irg_salaires": irg_salaire_sc2,
            "ibs": ibs_sc2,
            "irg_rcm": irg_rcm_sc2,
            "net_en_poche": net_poche_sc2,
            "total_prelevements": total_prelevements_sc2,
            "pression_fiscale_pct": round((total_prelevements_sc2 / benefice_annuel_brut) * 100, 1) if benefice_annuel_brut > 0 else 0,
        },
        "mix_optimal": {
            "salaire_mensuel_optimal": meilleur_salaire_m,
            "net_en_poche_optimal": round(meilleur_net, 2),
            "gain_annuel_vs_dividendes": max(0.0, economie_potentielle),
            "recommandation_ar": (
                f"أفضل توليفة جبائية هي سحب راتب شهري قدره {meilleur_salaire_m:,.0f} دج وتوزيع الباقي كأرباح، "
                f"مما يحقق لك زيادة صافية في السيولة بمبلغ {max(0.0, economie_potentielle):,.0f} دج سنوياً!"
                if economie_potentielle > 0 else
                "توزيع الأرباح بالكامل بنسبة 10% IRG/RCM هو الخيار الأوفر والأبسط في حالتك الحالية."
            ),
            "recommandation_fr": (
                f"Le mix optimal consiste à fixer une rémunération mensuelle de {meilleur_salaire_m:,.0f} DA et distribuer le solde en dividendes. "
                f"Gain net de trésorerie pour le dirigeant : +{max(0.0, economie_potentielle):,.0f} DA/an."
                if economie_potentielle > 0 else
                "La distribution intégrale en dividendes (IRG/RCM 10%) reste l'option la plus économique pour ce niveau de résultat."
            ),
        },
    }


def simulate_forme_juridique(
    chiffre_affaires: float,
    marge_nette_pct: float = 20.0,
    secteur: str = "services",
) -> Dict[str, Any]:
    """Compare Personne Physique Réel vs Auto-Entrepreneur vs SARL/EURL."""
    taux_marge = marge_nette_pct / 100.0
    benefice_estime = chiffre_affaires * taux_marge

    # 1. Auto-entrepreneur (plafonné à 5,000,000 DA)
    auto_eligible = chiffre_affaires <= 5000000.0 and secteur in ("services", "digital", "conseil", "artisanat")
    auto_impot = round(chiffre_affaires * 0.05, 2) if auto_eligible else None
    auto_net = round(benefice_estime - auto_impot, 2) if auto_eligible and auto_impot is not None else None

    # 2. Personne physique (Régime Réel - Barème IRG)
    casnos_pp = _calc_casnos_annuel(benefice_estime)
    irg_pp = _calc_irg_salaires_annuel(benefice_estime / 12)
    tot_pp = casnos_pp + irg_pp
    net_pp = round(benefice_estime - tot_pp, 2)

    # 3. SARL / EURL (IBS 26% ou 23% ou 19%)
    taux_ibs = 0.19 if secteur == "production" else (0.23 if secteur == "btph" else 0.26)
    ibs_sarl = round(benefice_estime * taux_ibs, 2)
    distrib = benefice_estime - ibs_sarl
    rcm_sarl = round(distrib * 0.10, 2)
    tot_sarl = ibs_sarl + rcm_sarl
    net_sarl = round(distrib - rcm_sarl, 2)

    return {
        "chiffre_affaires": chiffre_affaires,
        "benefice_estime": benefice_estime,
        "auto_entrepreneur": {
            "eligible": auto_eligible,
            "impot_5_pct": auto_impot,
            "net_restant": auto_net,
            "commentaire": "Régime ultra-simplifié sans comptabilité complexe (Plafond 5M DA)." if auto_eligible else "Non éligible (Dépassement du plafond de 5M DA ou activité exclue).",
        },
        "personne_physique_reel": {
            "irg": irg_pp,
            "casnos": casnos_pp,
            "total_prelevements": tot_pp,
            "net_restant": net_pp,
            "responsabilite": "Illimitée sur le patrimoine personnel de l'exploitant.",
        },
        "sarl_eurl": {
            "taux_ibs": taux_ibs,
            "ibs": ibs_sarl,
            "irg_rcm": rcm_sarl,
            "total_prelevements": tot_sarl,
            "net_restant": net_sarl,
            "responsabilite": "Limitée aux apports sociaux (Protection du patrimoine personnel).",
        },
    }


def simulate_leasing_vs_achat(
    valeur_acquisition: float,
    duree_annees: int = 5,
    type_bien: str = "equipement",
) -> Dict[str, Any]:
    """Compare Crédit-Bail / Leasing vs Achat direct & Amortissement."""
    # Plafond fiscal véhicule de tourisme en Algérie : 1,000,000 DA (ou 3,000,000 DA selon mise à jour LF)
    plafond_fiscal_auto = 3000000.0 if type_bien == "tourisme" else valeur_acquisition
    surplus_non_deductible = max(0.0, valeur_acquisition - plafond_fiscal_auto)

    # Achat direct
    amort_annuel_comptable = valeur_acquisition / duree_annees
    amort_annuel_deductible = plafond_fiscal_auto / duree_annees
    reintegration_annuelle = amort_annuel_comptable - amort_annuel_deductible

    # Leasing : Loyer annuel estimé (valeur + marge financière ~8% / ans)
    loyer_annuel_estime = (valeur_acquisition * 1.15) / duree_annees

    return {
        "valeur_acquisition": valeur_acquisition,
        "duree_annees": duree_annees,
        "type_bien": type_bien,
        "achat_direct": {
            "amortissement_annuel": round(amort_annuel_comptable, 2),
            "part_deductible_ibs": round(amort_annuel_deductible, 2),
            "reintegration_fiscale_annuelle": round(reintegration_annuelle, 2),
            "observations_ar": "يخضع لقيود سقف الاهتلاك المقبول جبائياً في حال السيارات السياحية." if reintegration_annuelle > 0 else "الاهتلاك مخصوم بالكامل بنسبة 100% من النتيجة الجبائية.",
        },
        "leasing": {
            "loyer_annuel_estime": round(loyer_annuel_estime, 2),
            "deductibilite": "Les redevances de crédit-bail sont intégralement admises en déduction des charges d'exploitation (Art. 169 CIDTA).",
            "tva_recuperable": "TVA déductible mensuellement sur chaque quittance de loyer.",
            "impact_tresorerie": "Préservation de la trésorerie et capacité d'emprunt bancaire intacte.",
        },
    }


def get_prescription_radar(annee_en_cours: int = 2026) -> Dict[str, Any]:
    """Calcule le radar de prescription quadriennale (Art. 39 CPF)."""
    annee_critique = annee_en_cours - 4  # 2022 en 2026
    annees_ouvertes = [annee_en_cours - i for i in range(1, 5)]  # 2025, 2024, 2023, 2022
    annees_prescrites = [annee_critique - i for i in range(1, 6)]

    return {
        "annee_courante": annee_en_cours,
        "annee_qui_prescrit_fin_annee": annee_critique,
        "date_prescription_totale": f"31/12/{annee_en_cours}",
        "annees_sous_risque_controle": [
            {
                "annee": annee_critique,
                "statut": "EXPIRATION_IMMINENTE",
                "label_ar": f"سنة {annee_critique} — تسقط بالتقادم التام في 31 ديسمبر {annee_en_cours}",
                "label_fr": f"Exercice {annee_critique} — Prescription définitive au 31/12/{annee_en_cours}",
                "badge": "warning",
                "conseil": "Veiller à ce qu'aucun avis de vérification ou acte interruptif ne soit notifié avant le 31 décembre.",
            },
            *[
                {
                    "annee": yr,
                    "statut": "OUVERTE",
                    "label_ar": f"سنة {yr} — مفتوحة للرقابة الجبائية",
                    "label_fr": f"Exercice {yr} — Ouvert au contrôle fiscal",
                    "badge": "info",
                    "conseil": "Tenir les justificatifs et pièces comptables à disposition.",
                }
                for yr in annees_ouvertes if yr != annee_critique
            ],
        ],
        "annees_prescrites": annees_prescrites,
    }


# ---------------------------------------------------------------------------
# 5. BASE JURIDIQUE & TEXTES FISCAUX ALGÉRIENS
# ---------------------------------------------------------------------------

LEGAL_ARTICLES = [
    {
        "id": "cidta_104",
        "code": "CIDTA",
        "article": "Article 104 & 107",
        "titre_ar": "الضريبة على مداخيل رؤوس الأموال المنقولة (IRG/RCM)",
        "titre_fr": "Distribution des dividendes & Retenue à la source",
        "description_ar": "تخضع الأرباح الموزعة من قبل شركات الأموال (SARL, EURL, SPA) لاقتطاع من المصدر بنسبة 10% محررة من أي تصريح إضافي.",
        "description_fr": "Les dividendes distribués par les sociétés de capitaux sont soumis à une retenue à la source libératoire de l'IRG au taux de 10%.",
    },
    {
        "id": "cidta_142_bis",
        "code": "CIDTA",
        "article": "Article 142 bis",
        "titre_ar": "إعادة استثمار الأرباح المعفاة من الـ IBS",
        "titre_fr": "Obligation de réinvestissement des bénéfices",
        "description_ar": "إلزامية إعادة استثمار 30% من الأرباح المستفيدة من إعفاءات أو تخفيضات في عتاد الإنتاج أو الأسهم خلال مهلة 4 سنوات.",
        "description_fr": "Obligation de réinvestir 30% des bénéfices ayant bénéficié d'exonérations dans des actifs de production dans un délai de 4 ans.",
    },
    {
        "id": "cidta_169",
        "code": "CIDTA",
        "article": "Article 169",
        "titre_ar": "شروط خصم الأعباء من النتيجة الجبائية",
        "titre_fr": "Déductibilité des charges d'exploitation",
        "description_ar": "لقبول خصم النفقات جبائياً يجب أن ترتبط مباشرة بمصلحة الاستغلال، وتكون مبررة بفواتير قانونية، وتدخل ضمن السنة المالية.",
        "description_fr": "Les charges déductibles doivent être engagées dans l'intérêt direct de l'entreprise, appuyées de pièces régulières et constatées dans l'exercice.",
    },
    {
        "id": "cpf_39",
        "code": "CPF",
        "article": "Article 39",
        "titre_ar": "التقادم الجبائي الرباعي (4 سنوات)",
        "titre_fr": "Délai de prescription quadriennale",
        "description_ar": "يسقط حق الإدارة الجبائية في تدارك الإغفالات والأخطاء بمرور 4 سنوات من نهاية السنة التي وجب فيها التصريح.",
        "description_fr": "Le droit de reprise de l'administration fiscale s'exerce pendant un délai de quatre ans à compter de la fin de l'année d'imposition.",
    },
    {
        "id": "cpf_74",
        "code": "CPF",
        "article": "Article 74",
        "titre_ar": "تأجيل الدفع والضمان القانوني (20%)",
        "titre_fr": "Sursis de paiement & Garantie légale de 20%",
        "description_ar": "يمكن للمكلف الذي يقدم شكوى نزاعية طلب تأجيل دفع الضرائب المتنازع عليها مقابل إيداع ضمان قدره 20% من المبلغ المتنازع عليه.",
        "description_fr": "Le contribuable réclamant peut solliciter le sursis de paiement des droits contestés en constituant une garantie équivalente à 20% des impositions.",
    },
    {
        "id": "ctca_29",
        "code": "CTCA",
        "article": "Article 29 & 30",
        "titre_ar": "حق استرجاع وخصم الرسم على القيمة المضافة (TVA)",
        "titre_fr": "Droit à déduction de la TVA",
        "description_ar": "تخصم الـ TVA المسددة على المشتريات والخدمات شريطة وجود فواتير قانونية تتضمن NIF وطريقة الدفع، وعدم سقوط حق الاسترجاع.",
        "description_fr": "La taxe ayant grevé les éléments du prix d'une opération imposable est déductible de la taxe applicable à cette opération.",
    },
]


def get_legal_articles() -> List[Dict[str, Any]]:
    return LEGAL_ARTICLES


# ---------------------------------------------------------------------------
# 5. ATTESTATION D'ACTIVITÉ (C20)
# ---------------------------------------------------------------------------

C20_MOTIFS_CATALOG: List[Dict[str, Any]] = [
    {
        "id": "banque",
        "icon": "Landmark",
        "badge_ar": "🏦 المعاملات والتوطين البنكي",
        "badge_fr": "🏦 Domiciliation & Banques",
        "titre_ar": "المعاملات البنكية، فتح الحسابات المهنية والتوطين للاستيراد والتصدير",
        "titre_fr": "Opérations bancaires, ouverture de compte, crédits & domiciliation",
        "desc_ar": "طلب شهادة النشاط (C20) لفتح حساب تجاري، طلب قرض استثماري، أو التوطين البنكي لعمليات التجارة الخارجية.",
        "desc_fr": "Délivrance de C20 pour compte bancaire professionnel, crédit d'investissement ou domiciliation d'import/export.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "role", "g50", "bail"],
        "texte_modele_ar": """يشرفني أن أتقدم إلى سيادتكم المحترمة بهذا الطلب قصد التفضل بتسليمي شهادة النشاط (C20) الخاصة بشركتنا المقيدة بمصالحكم تحت رقم المادة ورقم التعريف الجبائي الموضحين أعلاه.

نحيطكم علماً بأن المؤسسة تمارس نشاطها بصفة قانونية وفعلية ومنتظمة، وهي مستوفية لكافة التزاماتها وتصريحاتها الجبائية الدورية. وتلزمنا هذه الشهادة لتقديمها ضمن الملف المصرفي المودع لدى مصالح البنك في إطار (فتح حساب بنكي مهني / طلب تمويل استثماري / إجراءات التوطين البنكي لعمليات التجارة الخارجية).""",
        "texte_modele_fr": """J'ai l'honneur de solliciter par la présente votre bienveillance afin de bien vouloir me délivrer un Certificat d'Existence et d'Activité (C20) relatif à notre entreprise dûment immatriculée auprès de vos services sous les références citées ci-dessus.

Nous tenons à vous préciser que notre entreprise exerce son activité de manière réelle, continue et régulière, et se trouve en situation fiscale parfaitement conforme au regard de ses obligations déclaratives. Cette attestation nous est indispensable pour la constitution d'un dossier bancaire (ouverture de compte professionnel / demande de financement d'investissement / domiciliation bancaire pour le commerce extérieur).""",
    },
    {
        "id": "casnos",
        "icon": "Shield",
        "badge_ar": "🛡️ صندوق الضمان CASNOS",
        "badge_fr": "🛡️ Sécurité Sociale CASNOS",
        "titre_ar": "صندوق الضمان الاجتماعي لغير الأجراء (CASNOS)",
        "titre_fr": "Régularisation auprès de la CASNOS (Cotisations & Chifa)",
        "desc_ar": "إثبات الدخل الخاضع للضريبة لتسوية اشتراكات الضمان الاجتماعي السنوية وتحديث بطاقة الشفاء.",
        "desc_fr": "Justification des revenus nets déclarés pour le calcul de l'assiette de cotisation et la carte Chifa.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "g50"],
        "texte_modele_ar": """يشرفني أن أتقدم إلى مصالحكم المحترمة بطلبي هذا قصد استخراج شهادة النشاط (C20) لشركتنا، وذلك من أجل الإدلاء بها لدى مصالح الصندوق الوطني للضمان الاجتماعي لغير الأجراء (CASNOS).

تتيح هذه الشهادة تسوية الوضعية السنوية للاشتراكات وتحديث التغطية الاجتماعية وبطاقة الشفاء وفقاً للمداخيل والأرباح المحققة والمصرح بها قانوناً بمصالحكم.""",
        "texte_modele_fr": """J'ai l'honneur de solliciter la délivrance d'un Certificat d'Existence et d'Activité (C20) relatif à notre entité, destiné à être produit auprès des services de la Caisse Nationale de Sécurité Sociale des Non-Salariés (CASNOS).

Ce document est requis pour la mise à jour annuelle de la situation d'affiliation et le calcul des cotisations sociales sur la base des revenus déclarés auprès de votre inspection.""",
    },
    {
        "id": "marches_publics",
        "icon": "Briefcase",
        "badge_ar": "🏛️ الصفقات والمناقصات العمومية",
        "badge_fr": "🏛️ Marchés Publics",
        "titre_ar": "الصفقات والمناقصات العمومية واستشارات الهيئات الإدارية",
        "titre_fr": "Soumission aux Marchés Publics & Consultations Administratives",
        "desc_ar": "إثبات الأهلية القانونية والنشاط الفعلي للمشاركة في المناقصات والصفقات العمومية.",
        "desc_fr": "Preuve d'existence fiscale et de régularité pour les dossiers d'appels d'offres publics.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "role", "g50"],
        "texte_modele_ar": """نتشرف بالتقدم إلى سيادتكم المحترمة بطلب تسليم شهادة النشاط (C20) الخاصة بمؤسستنا، وذلك لإيداعها ضمن ملف التأهيل والمشاركة في الصفقات والمناقصات العمومية.

تأتي هذه الشهادة إثباتاً للوجود القانوني والنشاط الفعلي للمؤسسة وامتثالها التام لأحكام المرسوم الرئاسي المنظم للصفقات العمومية وتفويضات المرفق العام.""",
        "texte_modele_fr": """Nous avons l'honneur de solliciter la délivrance d'un Certificat d'Existence et d'Activité (C20) afin de compléter le dossier de qualification et de soumission aux marchés publics.

Cette attestation fait foi de l'existence juridique et matérielle de l'entreprise conformément aux exigences du décret présidentiel régissant les marchés publics et délégations de service public.""",
    },
    {
        "id": "douanes",
        "icon": "Ship",
        "badge_ar": "🚢 مصالح الجمارك والتجارة الخارجية",
        "badge_fr": "🚢 Douanes & Import-Export",
        "titre_ar": "مصالح الجمارك والتخليص الجمركي لعمليات الاستيراد والتصدير",
        "titre_fr": "Administration des Douanes & Dédouanement des Marchandises",
        "desc_ar": "تأكيد الوجود الجبائي القانوني للتخليص الجمركي واستلام البضائع والمعدات والمواد الأولية.",
        "desc_fr": "Conformité fiscale exigée pour le dédouanement et la levée des marchandises sous douane.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "role", "bail"],
        "texte_modele_ar": """يشرفني أن أطلب من مصالحكم التفضل بتسليمنا شهادة النشاط (C20) الموجهة لمصالح الجمارك الجزائرية.

تعتبر هذه الشهادة مطلوبة رسمياً لإتمام إجراءات التخليص الجمركي ورفع البضائع والعتاد والمواد الأولية المستوردة في إطار ممارسة النشاط الاقتصادي المعتمد لشركتنا.""",
        "texte_modele_fr": """J'ai l'honneur de vous demander la délivrance d'un Certificat d'Existence et d'Activité (C20) requis par l'Administration des Douanes algériennes.

Ce document est indispensable pour l'accomplissement des formalités de dédouanement et d'enlèvement des marchandises et équipements nécessaires à l'exercice normal de notre activité.""",
    },
    {
        "id": "logement",
        "icon": "Home",
        "badge_ar": "🏠 برامج السكن الترقوي والمدعم",
        "badge_fr": "🏠 Logement Public (AADL / LPA)",
        "titre_ar": "ملفات برامج السكن الترقوي والمدعم من الدولة (عدل AADL / LPA / LPP)",
        "titre_fr": "Dossiers de Logement Aidé par l'État (AADL / LPA / LPP)",
        "desc_ar": "إثبات الدخل السنوي والنشاط المهني للمكتتبين الخواص وأصحاب المؤسسات المصغرة.",
        "desc_fr": "Justificatif d'activité et de niveau de revenu pour les souscripteurs de logements publics.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "g50"],
        "texte_modele_ar": """أتقدم إلى سيادتكم المحترمة بهذا الطلب قصد التفضل بتسليمي شهادة النشاط (C20)، مع بيان أرقام الأعمال والمداخيل المصرح بها.

إن هذه الشهادة لازمة لإتمام الملف الإداري الخاص بالاستفادة من السكن الترقوي/المدعم من الدولة بصفتي مهنياً/تاجراً حراً يمارس نشاطه بصفة رسمية بموجب المادة الجبائية المذكورة أعلاه.""",
        "texte_modele_fr": """J'ai l'honneur de solliciter un Certificat d'Existence et d'Activité (C20) mentionnant les éléments d'activité et de revenus déclarés, indispensable pour la constitution de mon dossier de logement aidé par l'État (formule AADL / LPA / LPP).""",
    },
    {
        "id": "visa",
        "icon": "Plane",
        "badge_ar": "✈️ التأشيرة والسفر المهني",
        "badge_fr": "✈️ Visa d'Affaires & Étranger",
        "titre_ar": "ملفات التأشيرة المهنية والسفر للمهمات الاقتصادية والمعارض الدولية",
        "titre_fr": "Dossiers de Visa Professionnel & Missions Économiques",
        "desc_ar": "إثبات الملاءة المالية واستمرارية نشاط الشركة أمام الهيئات القنصلية والدبلوماسية.",
        "desc_fr": "Attestation d'exercice effectif et solvabilité requise par les services consulaires.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "role", "g50"],
        "texte_modele_ar": """يشرفني أن أتقدم بطلبي هذا قصد استخراج شهادة النشاط (C20) لشركتنا، بغرض تقديمها لدى المصالح القنصلية والدبلوماسية.

تصف هذه الوثيقة استمرارية وملاءة النشاط التجاري الفعلي للمؤسسة لغرض الحصول على تأشيرة السفر للمهام المهنية والشراكات الاقتصادية الدولية.""",
        "texte_modele_fr": """J'ai l'honneur de solliciter la délivrance d'un Certificat d'Existence et d'Activité (C20) destiné aux services consulaires pour l'obtention d'un visa professionnel, attestant de l'exercice réel, continu et probant de notre activité commerciale.""",
    },
    {
        "id": "grands_comptes",
        "icon": "Building2",
        "badge_ar": "🤝 الشراكات وكبريات المؤسسات",
        "badge_fr": "🤝 Grands Comptes & Partenariats",
        "titre_ar": "الشراكات التجارية والتأهيل لدى كبريات المؤسسات الوطنية والخاصة",
        "titre_fr": "Agrément & Référencement Fournisseur Grands Comptes",
        "desc_ar": "تأكيد الامتثال والنقاء الجبائي لاعتماد الشركة كمورد معتمد لدى المؤسسات الوطنية الكبرى.",
        "desc_fr": "Conformité fiscale exigée pour le référencement fournisseur auprès des grands comptes.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "role", "g50"],
        "texte_modele_ar": """نتقدم إلى سيادتكم المحترمة بطلب تسليم شهادة النشاط (C20) الخاصة بشركتنا، وذلك قصد تقديمها ضمن ملف الاعتماد والتأهيل التجاري لدى كبريات المؤسسات والمتعاملين الاقتصاديين.

تثبت هذه الشهادة النقاء الجبائي للمؤسسة ومزاولتها للنشاط وفق المعايير والقوانين المعمول بها.""",
        "texte_modele_fr": """Nous sollicitons la délivrance d'un Certificat d'Existence et d'Activité (C20) requis pour le référencement fournisseur et la validation de nos accords commerciaux auprès de grands groupes et partenaires institutionnels.""",
    },
    {
        "id": "cessation",
        "icon": "AlertTriangle",
        "badge_ar": "⚠️ الشطب من السجل التجاري",
        "badge_fr": "⚠️ Cessation & Radiation CNRC",
        "titre_ar": "الشطب من السجل التجاري والتوقف النهائي عن ممارسة النشاط",
        "titre_fr": "Cessation d'Activité & Radiation du Registre de Commerce (CNRC)",
        "desc_ar": "طلب شهادة النشاط بتأشيرة التوقف عن النشاط لإتمام الشطب الرسمي في السجل التجاري.",
        "desc_fr": "Délivrance de C20 portant mention de cessation pour formaliser la radiation auprès du CNRC.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif", "role", "g50"],
        "texte_modele_ar": """يشرفني إعلام سيادتكم بأن المؤسسة قد قررت التوقف النهائي عن ممارسة نشاطها التجاري، وعليه نلتمس منكم التفضل بتسليمنا شهادة النشاط (C20) مؤشراً عليها بعبارة التوقف عن النشاط.

تعتبر هذه الوثيقة ضرورية لاستكمال الإجراءات الإدارية والقانونية الخاصة بالشطب النهائي من السجل التجاري على مستوى مصالح المركز الوطني للسجل التجاري (CNRC).""",
        "texte_modele_fr": """J'ai l'honneur de vous notifier la décision de cessation d'activité de notre entreprise et de solliciter la délivrance d'un Certificat d'Existence et d'Activité (C20) portant la mention de cessation d'activité.

Ce document est formellement exigé par le Centre National du Registre de Commerce (CNRC) pour procéder à la radiation définitive du registre.""",
    },
    {
        "id": "autre",
        "icon": "FileText",
        "badge_ar": "📋 غرض إداري مخصص",
        "badge_fr": "📋 Usage Administratif Général",
        "titre_ar": "غرض إداري مخصص أو استثنائي",
        "titre_fr": "Autre Démarche Administrative Spécifique",
        "desc_ar": "توليد طلب شهادة النشاط (C20) لأي ملف إداري أو قانوني مخصص.",
        "desc_fr": "Demande personnalisée de certificat C20 pour tout autre besoin administratif.",
        "destinataire_defaut_ar": "السيد رئيس مركز الضرائب",
        "destinataire_defaut_fr": "Monsieur le Chef du Centre des Impôts",
        "pieces_recommandees": ["rc", "nif"],
        "texte_modele_ar": """يشرفني أن أتقدم إلى سيادتكم المحترمة بهذا الطلب قصد التفضل بتسليمي شهادة النشاط (C20) الخاصة بشركتنا المقيدة بمصالحكم.

نحيطكم علماً بأن المؤسسة تمارس نشاطها بصفة قانونية وفعلية ومنتظمة، وتلزمنا هذه الشهادة لتقديمها ضمن ملف إداري خاص لدى المصالح المعنية.""",
    },
]


def get_c20_motifs() -> List[Dict[str, Any]]:
    return C20_MOTIFS_CATALOG


def list_demandes_c20(dossier: Optional[str] = None, statut: Optional[str] = None) -> List[Dict[str, Any]]:
    with _conn() as c:
        query = "SELECT * FROM fiscal_demandes_c20 WHERE 1=1"
        params: List[Any] = []
        if dossier and dossier != "all":
            query += " AND dossier = ?"
            params.append(dossier)
        if statut and statut != "all":
            query += " AND statut = ?"
            params.append(statut)
        query += " ORDER BY id DESC"
        rows = c.execute(query, params).fetchall()

    results = []
    for r in rows:
        d = dict(r)
        d["rs"] = _get_dossier_name(d["dossier"])
        try:
            d["chiffres_affaires"] = json.loads(d.get("chiffres_affaires_json") or "[]")
        except Exception:
            d["chiffres_affaires"] = []
        try:
            d["pieces_jointes"] = json.loads(d.get("pieces_jointes_json") or "[]")
        except Exception:
            d["pieces_jointes"] = []
        results.append(d)
    return results


def get_demande_c20(c20_id: int) -> Optional[Dict[str, Any]]:
    with _conn() as c:
        r = c.execute("SELECT * FROM fiscal_demandes_c20 WHERE id = ?", (c20_id,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["rs"] = _get_dossier_name(d["dossier"])
    try:
        d["chiffres_affaires"] = json.loads(d.get("chiffres_affaires_json") or "[]")
    except Exception:
        d["chiffres_affaires"] = []
    try:
        d["pieces_jointes"] = json.loads(d.get("pieces_jointes_json") or "[]")
    except Exception:
        d["pieces_jointes"] = []
    return d


def create_demande_c20(data: Dict[str, Any]) -> Dict[str, Any]:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    date_demande = data.get("date_demande", date.today().strftime("%Y-%m-%d"))

    ca_json = json.dumps(data.get("chiffres_affaires", []), ensure_ascii=False)
    pj_json = json.dumps(data.get("pieces_jointes", []), ensure_ascii=False)

    with _conn() as c:
        cur = c.execute(
            """INSERT INTO fiscal_demandes_c20 (
                dossier, motif_cle, motif_titre_ar, motif_titre_fr,
                destinataire_type, destinataire_nom, regime_fiscal,
                date_debut_activite, annees_demandees, chiffres_affaires_json,
                avec_pieces_jointes, pieces_jointes_json, statut,
                date_demande, numero_enregistrement, texte_ar, texte_fr,
                notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("dossier", "S1"),
                data.get("motif_cle", "banque"),
                data.get("motif_titre_ar", "").strip(),
                data.get("motif_titre_fr", "").strip(),
                data.get("destinataire_type", "INSPECTION"),
                data.get("destinataire_nom", "").strip(),
                data.get("regime_fiscal", "REEL"),
                data.get("date_debut_activite", "").strip(),
                data.get("annees_demandees", "").strip(),
                ca_json,
                1 if data.get("avec_pieces_jointes", True) else 0,
                pj_json,
                data.get("statut", "en_attente"),
                date_demande,
                data.get("numero_enregistrement", "").strip(),
                data.get("texte_ar", "").strip(),
                data.get("texte_fr", "").strip(),
                data.get("notes", "").strip(),
                now,
                now,
            ),
        )
        c.commit()
        new_id = cur.lastrowid

    return get_demande_c20(new_id)  # type: ignore


def update_demande_c20(c20_id: int, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with _conn() as c:
        fields = []
        params = []
        for col, key in [
            ("dossier", "dossier"),
            ("motif_cle", "motif_cle"),
            ("motif_titre_ar", "motif_titre_ar"),
            ("motif_titre_fr", "motif_titre_fr"),
            ("destinataire_type", "destinataire_type"),
            ("destinataire_nom", "destinataire_nom"),
            ("regime_fiscal", "regime_fiscal"),
            ("date_debut_activite", "date_debut_activite"),
            ("annees_demandees", "annees_demandees"),
            ("statut", "statut"),
            ("date_demande", "date_demande"),
            ("numero_enregistrement", "numero_enregistrement"),
            ("texte_ar", "texte_ar"),
            ("texte_fr", "texte_fr"),
            ("notes", "notes"),
        ]:
            if key in data and data[key] is not None:
                fields.append(f"{col} = ?")
                params.append(data[key])

        if "avec_pieces_jointes" in data:
            fields.append("avec_pieces_jointes = ?")
            params.append(1 if data["avec_pieces_jointes"] else 0)

        if "chiffres_affaires" in data:
            fields.append("chiffres_affaires_json = ?")
            params.append(json.dumps(data["chiffres_affaires"], ensure_ascii=False))

        if "pieces_jointes" in data:
            fields.append("pieces_jointes_json = ?")
            params.append(json.dumps(data["pieces_jointes"], ensure_ascii=False))

        if not fields:
            return get_demande_c20(c20_id)

        fields.append("updated_at = ?")
        params.append(now)
        params.append(c20_id)
        c.execute(f"UPDATE fiscal_demandes_c20 SET {', '.join(fields)} WHERE id = ?", params)
        c.commit()

    return get_demande_c20(c20_id)


def delete_demande_c20(c20_id: int) -> bool:
    with _conn() as c:
        c.execute("DELETE FROM fiscal_demandes_c20 WHERE id = ?", (c20_id,))
        c.commit()
    return True


# ---------------------------------------------------------------------------
# 6. DOSSIER FISCAL NUMÉRIQUE (الملف الرقمي للشركة)
# ---------------------------------------------------------------------------

DOCUMENT_CATEGORIES_CATALOG = [
    {
        "id": "general",
        "titre_ar": "الصور والوثائق الممسوحة (عامة)",
        "titre_fr": "Numérisations & Captures Mobiles (Général)",
        "icon": "Smartphone",
        "types": [
            {"id": "capture_mobile", "label_ar": "صورة ملتقطة بالهاتف (قابلة للتصنيف)", "label_fr": "Capture Smartphone (À classer)", "obligatoire": False, "expire": False},
            {"id": "scan_general", "label_ar": "وثيقة ممسوحة ضوئياً", "label_fr": "Document numérisé", "obligatoire": False, "expire": False},
            {"id": "autre", "label_ar": "وثيقة عامة أخرى", "label_fr": "Autre document", "obligatoire": False, "expire": False},
        ],
    },
    {
        "id": "juridique",
        "titre_ar": "الوثائق التأسيسية والقانونية",
        "titre_fr": "Documents Juridiques & Statutaires",
        "icon": "Building2",
        "types": [
            {"id": "rc", "label_ar": "السجل التجاري (RC)", "label_fr": "Registre de Commerce (RC)", "obligatoire": True, "expire": True},
            {"id": "statuts", "label_ar": "القانون الأساسي للشركة", "label_fr": "Statuts de la société", "obligatoire": True, "expire": False},
            {"id": "bail", "label_ar": "عقد الإيجار / سند الملكية", "label_fr": "Contrat de bail / Titre de propriété", "obligatoire": True, "expire": True},
            {"id": "identite_gerant", "label_ar": "بطاقة هوية المسيّر", "label_fr": "Pièce d'identité du gérant", "obligatoire": True, "expire": True},
            {"id": "pv_ag", "label_ar": "محاضر الجمعيات العامة (PV AG)", "label_fr": "Procès-verbaux d'Assemblées Générales", "obligatoire": False, "expire": False},
            {"id": "procuration", "label_ar": "وكالة رسمية / تفويض", "label_fr": "Procuration / Délégation de pouvoir", "obligatoire": False, "expire": True},
        ],
    },
    {
        "id": "fiscal",
        "titre_ar": "الوثائق والشهادات الجبائية",
        "titre_fr": "Documents & Certificats Fiscaux",
        "icon": "FileText",
        "types": [
            {"id": "nif", "label_ar": "بطاقة التعريف الجبائي (NIF)", "label_fr": "Carte d'immatriculation fiscale (NIF)", "obligatoire": True, "expire": False},
            {"id": "c20", "label_ar": "شهادة النشاط (C20)", "label_fr": "Attestation d'Activité (C20)", "obligatoire": True, "expire": True},
            {"id": "role", "label_ar": "مستخرج الجدول (Extrait de Rôle)", "label_fr": "Extrait de rôle fiscal", "obligatoire": True, "expire": True},
            {"id": "g50", "label_ar": "أرشيف التصريحات الجبائية (G50)", "label_fr": "Déclarations fiscales G50", "obligatoire": False, "expire": False},
            {"id": "bilan", "label_ar": "الميزانية الجبائية والتصريح السنوي", "label_fr": "Bilan fiscal et liasse fiscale", "obligatoire": False, "expire": False},
            {"id": "balance_tva", "label_ar": "جدول تتبع وتصفية الرسم على القيمة المضافة (Balance TVA)", "label_fr": "Tableau de suivi & Balance TVA", "obligatoire": False, "expire": False},
            {"id": "recap_g50_excel", "label_ar": "كشف إجمالي تصريحات G50 السنوية (Excel)", "label_fr": "Récapitulatif annuel G50 (Excel)", "obligatoire": False, "expire": False},
            {"id": "notification_fiscale", "label_ar": "إشعارات ومراسلات إدارة الضرائب", "label_fr": "Notifications & Correspondances fiscales", "obligatoire": False, "expire": False},
        ],
    },
    {
        "id": "comptable",
        "titre_ar": "الدفاتر والوثائق المحاسبية",
        "titre_fr": "Livres & Documents Comptables (SCF)",
        "icon": "BookOpen",
        "types": [
            {"id": "bilan", "label_ar": "الميزانية والحزمة الجبائية السنوية (Bilan / Liasse Fiscale)", "label_fr": "Bilan & Liasse Fiscale (Excel / PDF)", "obligatoire": True, "expire": False},
            {"id": "grand_livre", "label_ar": "دفتر الأستاذ العام (Grand Livre)", "label_fr": "Grand Livre Général (Excel / PDF)", "obligatoire": True, "expire": False},
            {"id": "balance", "label_ar": "ميزان المراجعة العام (Balance Générale)", "label_fr": "Balance Générale des comptes (Excel / PDF)", "obligatoire": True, "expire": False},
            {"id": "journaux", "label_ar": "دفاتر اليوميات واليوميات المساعدة (Journaux Auxiliaires)", "label_fr": "Journaux & Journaux Auxiliaires (Excel / PDF)", "obligatoire": True, "expire": False},
            {"id": "livre_inventaire", "label_ar": "دفتر الجرد والقوائم المالية (Livre d'Inventaire)", "label_fr": "Livre d'Inventaire coté et paraphé (Excel / PDF)", "obligatoire": False, "expire": False},
            {"id": "balance_auxiliaire", "label_ar": "ميزان مراجعة الأطراف (Clients / Fournisseurs)", "label_fr": "Balance Auxiliaire Tiers (Excel / PDF)", "obligatoire": False, "expire": False},
            {"id": "rapprochement_bancaire_comptable", "label_ar": "مذكرات تسوية ومطابقة الحسابات البنكية (ح/512)", "label_fr": "États de rapprochement bancaire (Cpt 512)", "obligatoire": False, "expire": False},
        ],
    },
    {
        "id": "social",
        "titre_ar": "الوثائق الاجتماعية والعمالية",
        "titre_fr": "Documents Sociaux (CNAS / CASNOS)",
        "icon": "Users",
        "types": [
            {"id": "cnas_affil", "label_ar": "شهادة الانتساب CNAS", "label_fr": "Attestation d'affiliation CNAS", "obligatoire": True, "expire": True},
            {"id": "casnos_affil", "label_ar": "شهادة الانتساب CASNOS للمسيّر", "label_fr": "Attestation d'affiliation CASNOS", "obligatoire": False, "expire": True},
            {"id": "cnas_mise_a_jour", "label_ar": "شهادة أداء المستحقات (Mise à jour)", "label_fr": "Attestation de mise à jour CNAS/CASNOS", "obligatoire": True, "expire": True},
            {"id": "contrats_travail", "label_ar": "عقود العمل وقائمة الأجراء", "label_fr": "Contrats de travail & État des salariés", "obligatoire": False, "expire": False},
            {"id": "etat_salaires_excel", "label_ar": "جدول الأجور ومصاريف المستخدمين (Livre de paie)", "label_fr": "Livre de paie et salaires (Excel)", "obligatoire": False, "expire": False},
        ],
    },
    {
        "id": "bancaire",
        "titre_ar": "الوثائق والشهادات البنكية",
        "titre_fr": "Documents & Données Bancaires",
        "icon": "Landmark",
        "types": [
            {"id": "rib", "label_ar": "كشف الهوية البنكية (RIB / RIP)", "label_fr": "Relevé d'Identité Bancaire (RIB/RIP)", "obligatoire": True, "expire": False},
            {"id": "releve_bancaire", "label_ar": "كشوفات الحسابات البنكية", "label_fr": "Relevés de comptes bancaires", "obligatoire": False, "expire": False},
            {"id": "attestation_bancaire", "label_ar": "شهادات بنكية وتسهيلات", "label_fr": "Attestations bancaires et cautions", "obligatoire": False, "expire": True},
            {"id": "rapprochement_bancaire", "label_ar": "جدول تسوية الحسابات البنكية (Rapprochement)", "label_fr": "État de rapprochement bancaire (Excel)", "obligatoire": False, "expire": False},
        ],
    },
    {
        "id": "commercial",
        "titre_ar": "الوثائق والملفات التجارية",
        "titre_fr": "Documents Commerciaux & Factures",
        "icon": "Receipt",
        "types": [
            {"id": "facture_modele", "label_ar": "نموذج الفاتورة القانوني المعتمد", "label_fr": "Modèle de facture homologué", "obligatoire": False, "expire": False},
            {"id": "tableur_achats_ventes", "label_ar": "كشوفات المبيعات والمشتريات (Excel)", "label_fr": "États des achats / ventes (Excel)", "obligatoire": False, "expire": False},
            {"id": "rapprochement_commercial", "label_ar": "جدول المطابقة الشهرية للعمليات (Rapprochement)", "label_fr": "Tableau de rapprochement mensuel", "obligatoire": False, "expire": False},
            {"id": "registre_factures", "label_ar": "دفتر الفواتير المرقم والمؤشر", "label_fr": "Registre des factures coté & paraphé", "obligatoire": False, "expire": False},
            {"id": "contrats_commerciaux", "label_ar": "عقود التوريد والصفقات", "label_fr": "Contrats de partenariat & Fourniture", "obligatoire": False, "expire": True},
        ],
    },
    {
        "id": "divers",
        "titre_ar": "تراخيص واعتمادات متنوعة",
        "titre_fr": "Agréments, Autorisations & Divers",
        "icon": "FolderArchive",
        "types": [
            {"id": "agrement", "label_ar": "رخصة الاستغلال / الاعتماد المهني", "label_fr": "Agrément professionnel / Licence", "obligatoire": False, "expire": True},
            {"id": "andi_ansej", "label_ar": "مقررات المزايا الجبائية (AAPI / ANADE)", "label_fr": "Décisions d'avantages fiscaux (AAPI/ANADE)", "obligatoire": False, "expire": True},
            {"id": "tableur_gestion", "label_ar": "جداول إكسل ومخرجات التسيير المالي للشركة", "label_fr": "Tableaux de bord & Synthèse financière (Excel)", "obligatoire": False, "expire": False},
            {"id": "autre", "label_ar": "وثيقة إضافية أخرى", "label_fr": "Autre document complémentaire", "obligatoire": False, "expire": False},
        ],
    },
]

MANDATORY_DOC_TYPES = {
    "rc": {"categorie": "juridique", "titre_ar": "السجل التجاري (RC)", "titre_fr": "Registre de Commerce"},
    "statuts": {"categorie": "juridique", "titre_ar": "القانون الأساسي للشركة", "titre_fr": "Statuts"},
    "bail": {"categorie": "juridique", "titre_ar": "عقد الإيجار / سند الملكية", "titre_fr": "Bail / Titre propriété"},
    "identite_gerant": {"categorie": "juridique", "titre_ar": "بطاقة هوية المسيّر", "titre_fr": "Pièce d'identité gérant"},
    "nif": {"categorie": "fiscal", "titre_ar": "بطاقة التعريف الجبائي (NIF)", "titre_fr": "Carte fiscale NIF"},
    "c20": {"categorie": "fiscal", "titre_ar": "شهادة النشاط (C20)", "titre_fr": "Attestation C20"},
    "role": {"categorie": "fiscal", "titre_ar": "مستخرج الجدول (Extrait de Rôle)", "titre_fr": "Extrait de rôle"},
    "rib": {"categorie": "bancaire", "titre_ar": "كشف الهوية البنكية (RIB)", "titre_fr": "RIB bancaire"},
}


def get_documents_dir(dossier: str) -> Path:
    """Return local directory for this dossier's uploaded documents."""
    societe_dir = config.SOCIETES_DIR / dossier
    if societe_dir.is_dir():
        d = societe_dir / "documents"
    else:
        d = config.DATA_DIR / "documents" / dossier
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_document_catalog() -> List[Dict[str, Any]]:
    return DOCUMENT_CATEGORIES_CATALOG


def compute_document_validity(date_expiration: str) -> str:
    """Calculate status based on date: valide, expire_bientot (<=30j), or expire."""
    if not date_expiration or not date_expiration.strip():
        return "valide"
    try:
        exp = date.fromisoformat(date_expiration.strip())
        today = date.today()
        if today > exp:
            return "expire"
        if exp <= today + timedelta(days=30):
            return "expire_bientot"
        return "valide"
    except Exception:
        return "valide"


def list_dossier_documents(
    dossier: str,
    categorie: Optional[str] = None,
    search: Optional[str] = None,
) -> List[Dict[str, Any]]:
    with _conn() as c:
        query = "SELECT * FROM fiscal_dossier_documents WHERE dossier = ?"
        params: List[Any] = [dossier]
        if categorie:
            query += " AND categorie = ?"
            params.append(categorie)
        if search and search.strip():
            s = f"%{search.strip()}%"
            query += " AND (titre LIKE ? OR reference LIKE ? OR notes LIKE ? OR fichier_nom LIKE ?)"
            params.extend([s, s, s, s])
        query += " ORDER BY created_at DESC"
        rows = c.execute(query, params).fetchall()

    docs = []
    for r in rows:
        d = dict(r)
        d["statut_validite"] = compute_document_validity(d.get("date_expiration", ""))
        docs.append(d)
    return docs


def get_dossier_documents_stats(dossier: str) -> Dict[str, Any]:
    """Calculate completeness score, missing mandatory documents, and expiring alerts."""
    all_docs = list_dossier_documents(dossier)
    total_docs = len(all_docs)

    # Categories breakdown
    cat_counts = {cat["id"]: 0 for cat in DOCUMENT_CATEGORIES_CATALOG}
    for doc in all_docs:
        cat = doc.get("categorie")
        if cat in cat_counts:
            cat_counts[cat] += 1

    # Check validity status
    valides = 0
    expires = []
    expire_bientot = []
    types_present = set()

    for doc in all_docs:
        types_present.add(doc.get("type_document"))
        st = doc.get("statut_validite")
        if st == "valide":
            valides += 1
        elif st == "expire_bientot":
            expire_bientot.append(doc)
        elif st == "expire":
            expires.append(doc)

    # Missing mandatory documents
    manquants = []
    mandatory_present = 0
    for doc_type, meta in MANDATORY_DOC_TYPES.items():
        if doc_type in types_present:
            mandatory_present += 1
        else:
            manquants.append({
                "type_document": doc_type,
                "categorie": meta["categorie"],
                "titre_ar": meta["titre_ar"],
                "titre_fr": meta["titre_fr"],
            })

    total_mandatory = len(MANDATORY_DOC_TYPES)
    completude_pct = round((mandatory_present / total_mandatory) * 100) if total_mandatory > 0 else 100

    return {
        "dossier": dossier,
        "dossier_nom": _get_dossier_name(dossier),
        "total_documents": total_docs,
        "taux_completude": completude_pct,
        "mandatory_present": mandatory_present,
        "mandatory_total": total_mandatory,
        "documents_valides": valides,
        "documents_expire_bientot": expire_bientot,
        "documents_expires": expires,
        "documents_manquants": manquants,
        "repartition_categories": cat_counts,
    }


def get_dossier_document(doc_id: int) -> Optional[Dict[str, Any]]:
    with _conn() as c:
        row = c.execute("SELECT * FROM fiscal_dossier_documents WHERE id = ?", (doc_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        d["statut_validite"] = compute_document_validity(d.get("date_expiration", ""))
        return d


def create_dossier_document(
    dossier: str,
    data: Dict[str, Any],
    file_bytes: bytes,
    original_filename: str,
    mime_type: str = "application/pdf",
    overwrite: bool = False,
) -> Dict[str, Any]:
    docs_dir = get_documents_dir(dossier)
    now = datetime.now().isoformat()
    now_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    categorie = data.get("categorie") or "divers"
    type_document = data.get("type_document") or "autre"
    exercice = str(data.get("exercice") or "").strip()
    is_overwrite = bool(overwrite or data.get("overwrite"))

    # Try to extract exercice from reference or titre if not explicitly passed
    if not exercice:
        m = re.search(r"\b(202[0-9]|201[5-9])\b", f"{data.get('reference', '')} {data.get('titre', '')}")
        if m:
            exercice = m.group(1)

    # ANTI-DUPLICATION GUARD FOR ACCOUNTING DOCUMENTS (Livres et Documents Comptables)
    existing = None
    if categorie == "comptable" and type_document:
        with _conn() as c:
            if exercice:
                existing = c.execute(
                    """SELECT * FROM fiscal_dossier_documents 
                       WHERE dossier = ? AND categorie = 'comptable' 
                       AND (type_document = ? OR (type_document = 'balance_generale' AND ? = 'balance') OR (type_document = 'balance' AND ? = 'balance_generale'))
                       AND (
                           (exercice != '' AND exercice = ?)
                           OR (exercice = '' AND (reference = ? OR reference LIKE ? OR titre LIKE ?))
                       )
                       ORDER BY id DESC LIMIT 1""",
                    (dossier, type_document, type_document, type_document, exercice, f"EXERCICE_{exercice}", f"%{exercice}%", f"%{exercice}%")
                ).fetchone()
            else:
                existing = c.execute(
                    """SELECT * FROM fiscal_dossier_documents 
                       WHERE dossier = ? AND categorie = 'comptable' 
                       AND (type_document = ? OR (type_document = 'balance_generale' AND ? = 'balance') OR (type_document = 'balance' AND ? = 'balance_generale'))
                       ORDER BY id DESC LIMIT 1""",
                    (dossier, type_document, type_document, type_document)
                ).fetchone()

    if existing and not is_overwrite:
        # Instead of blocking the user, auto-suffix the title with sequential page/part
        with _conn() as c:
            part_count = c.execute(
                """SELECT COUNT(*) FROM fiscal_dossier_documents 
                   WHERE dossier = ? AND categorie = ? AND type_document = ?""",
                (dossier, categorie, type_document)
            ).fetchone()[0]
        cur_titre = str(data.get("titre") or type_document).strip()
        part_suffix = f" (صفحة {part_count + 1})"
        if part_suffix not in cur_titre:
            data["titre"] = f"{cur_titre}{part_suffix}"

    # Clean filename & prepare path
    clean_name = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", original_filename)
    if not clean_name:
        clean_name = f"doc_{now_stamp}.bin"
    saved_filename = f"{now_stamp}_{clean_name}"
    target_path = docs_dir / saved_filename

    # Write file to storage
    target_path.write_bytes(file_bytes)
    rel_path = f"documents/{saved_filename}"

    with _conn() as c:
        if existing and is_overwrite:
            # Overwrite & update existing document record
            old_rel = existing["fichier_rel_path"]
            if old_rel:
                try:
                    old_path = config.PROJECT_ROOT / old_rel if not Path(old_rel).is_absolute() else Path(old_rel)
                    if not old_path.exists():
                        old_path = docs_dir / Path(old_rel).name
                    if old_path.exists() and old_path != target_path:
                        old_path.unlink()
                except Exception:
                    pass

            c.execute(
                """UPDATE fiscal_dossier_documents SET
                    titre = ?,
                    reference = ?,
                    exercice = ?,
                    date_emission = ?,
                    date_expiration = ?,
                    fichier_nom = ?,
                    fichier_rel_path = ?,
                    taille_octets = ?,
                    mime_type = ?,
                    source_capture = ?,
                    notes = ?,
                    updated_at = ?
                   WHERE id = ?""",
                (
                    data.get("titre") or original_filename,
                    data.get("reference") or (f"Exercice {exercice}" if exercice else ""),
                    exercice,
                    data.get("date_emission") or "",
                    data.get("date_expiration") or "",
                    original_filename,
                    rel_path,
                    len(file_bytes),
                    mime_type,
                    data.get("source_capture") or "upload",
                    data.get("notes") or "",
                    now,
                    existing["id"],
                ),
            )
            c.commit()
            doc_id = existing["id"]
        else:
            # Insert new record
            cur = c.execute(
                """INSERT INTO fiscal_dossier_documents (
                    dossier, categorie, type_document, titre, reference, exercice,
                    date_emission, date_expiration, fichier_nom, fichier_rel_path,
                    taille_octets, mime_type, source_capture, notes,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    dossier,
                    categorie,
                    type_document,
                    data.get("titre") or original_filename,
                    data.get("reference") or (f"Exercice {exercice}" if exercice else ""),
                    exercice,
                    data.get("date_emission") or "",
                    data.get("date_expiration") or "",
                    original_filename,
                    rel_path,
                    len(file_bytes),
                    mime_type,
                    data.get("source_capture") or "upload",
                    data.get("notes") or "",
                    now,
                    now,
                ),
            )
            c.commit()
            doc_id = cur.lastrowid

    # SYNC TO BILAN FISCAL & AUDIT COCKPIT: If it's an Excel Bilan, sync to company's BilanFiscal_{exercice}.xls
    if categorie == "comptable" and type_document == "bilan" and exercice:
        is_excel = original_filename.lower().endswith((".xls", ".xlsx")) or "excel" in mime_type.lower() or "spreadsheet" in mime_type.lower()
        if is_excel:
            try:
                soc_dir = config.SOCIETES_DIR / dossier
                soc_dir.mkdir(parents=True, exist_ok=True)
                bilan_target = soc_dir / f"BilanFiscal_{exercice}.xls"
                bilan_target.write_bytes(file_bytes)
            except Exception as ex_sync:
                print(f"Warning syncing BilanFiscal_{exercice}.xls: {ex_sync}")

    doc = get_dossier_document(doc_id)
    return doc or {}


def update_dossier_document(doc_id: int, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    now = datetime.now().isoformat()
    fields = []
    params = []
    for k in ["titre", "reference", "exercice", "date_emission", "date_expiration", "notes", "categorie", "type_document"]:
        if k in data and data[k] is not None:
            fields.append(f"{k} = ?")
            params.append(data[k])

    if not fields:
        return get_dossier_document(doc_id)

    fields.append("updated_at = ?")
    params.append(now)
    params.append(doc_id)

    with _conn() as c:
        c.execute(f"UPDATE fiscal_dossier_documents SET {', '.join(fields)} WHERE id = ?", params)
        c.commit()

    return get_dossier_document(doc_id)


def delete_dossier_document(doc_id: int) -> bool:
    doc = get_dossier_document(doc_id)
    if not doc:
        return False

    # Delete physical file
    try:
        p = get_document_file_path(doc_id)
        if p and p.is_file():
            p.unlink()
    except Exception:
        pass

    with _conn() as c:
        c.execute("DELETE FROM fiscal_dossier_documents WHERE id = ?", (doc_id,))
        c.commit()
    return True


def get_document_file_path(doc_id: int) -> Optional[Path]:
    doc = get_dossier_document(doc_id)
    if not doc:
        return None
    dossier = doc["dossier"]
    rel_path = doc["fichier_rel_path"]  # "documents/xyz"
    filename = Path(rel_path).name

    # Check societe dir first
    p1 = config.SOCIETES_DIR / dossier / "documents" / filename
    if p1.is_file():
        return p1

    # Check data/documents fallback
    p2 = config.DATA_DIR / "documents" / dossier / filename
    if p2.is_file():
        return p2

    return p1


def generate_dossier_zip(dossier: str) -> bytes:
    """Export complete digital archive as a structured ZIP file with HTML index."""
    docs = list_dossier_documents(dossier)
    dossier_name = _get_dossier_name(dossier)
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")

    folder_map = {
        "juridique": "01_الوثائق_التأسيسية_القانونية",
        "fiscal": "02_الوثائق_الجبائية",
        "comptable": "03_الدفاتر_والوثائق_المحاسبية",
        "social": "04_الوثائق_الاجتماعية",
        "bancaire": "05_الوثائق_البنكية",
        "commercial": "06_الوثائق_التجارية",
        "divers": "07_تراخيص_ووثائق_متنوعة",
    }

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # Add files
        rows_html = []
        for i, doc in enumerate(docs, 1):
            cat = doc.get("categorie", "divers")
            subfolder = folder_map.get(cat, "06_تراخيص_ووثائق_متنوعة")
            p = get_document_file_path(doc["id"])
            archive_path = f"{subfolder}/{doc['titre']}_{doc['id']}_{Path(doc['fichier_nom']).name}"

            if p and p.is_file():
                zf.write(str(p), arcname=archive_path)

            status_badge = (
                '<span style="color:#16a34a; font-weight:bold;">ساري المفعول</span>'
                if doc["statut_validite"] == "valide"
                else (
                    '<span style="color:#d97706; font-weight:bold;">ينتهي قريباً</span>'
                    if doc["statut_validite"] == "expire_bientot"
                    else '<span style="color:#dc2626; font-weight:bold;">منتهي الصلاحية</span>'
                )
            )

            rows_html.append(f"""
            <tr>
                <td style="text-align:center;">{i}</td>
                <td><strong>{doc['titre']}</strong></td>
                <td>{doc.get('reference') or '-'}</td>
                <td>{subfolder}</td>
                <td>{doc.get('date_emission') or '-'}</td>
                <td>{doc.get('date_expiration') or 'دائم'}</td>
                <td style="text-align:center;">{status_badge}</td>
                <td>{doc['fichier_nom']}</td>
            </tr>
            """)

        # Add HTML index
        index_html = f"""<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8">
<title>فهرس الملف الرقمي — {dossier_name}</title>
<style>
body {{ font-family: 'Segoe UI', Tahoma, Arial, sans-serif; margin: 30px; color: #1e293b; background: #fff; }}
h1 {{ color: #0f172a; border-bottom: 3px solid #0284c7; padding-bottom: 12px; margin-bottom: 8px; }}
.meta {{ margin-bottom: 24px; color: #64748b; font-size: 14px; }}
table {{ width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px; }}
th, td {{ border: 1px solid #cbd5e1; padding: 10px 12px; text-align: right; }}
th {{ background: #f8fafc; color: #0f172a; font-weight: 700; }}
tr:nth-child(even) {{ background: #f1f5f9; }}
.badge {{ display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 12px; }}
.footer {{ margin-top: 30px; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 10px; text-align: center; }}
</style>
</head>
<body>
<h1>📁 فهرس الأرشيف والملف الرقمي للشركة</h1>
<div class="meta">
    <strong>الشركة:</strong> {dossier_name} ({dossier}) &nbsp;|&nbsp;
    <strong>تاريخ التصدير:</strong> {now_str} &nbsp;|&nbsp;
    <strong>إجمالي الوثائق المرفقة:</strong> {len(docs)} وثيقة
</div>
<table>
<thead>
<tr>
    <th>#</th>
    <th>اسم الوثيقة</th>
    <th>رقم المرجع / القيد</th>
    <th>القسم والتصنيف</th>
    <th>تاريخ الإصدار</th>
    <th>تاريخ الانتهاء</th>
    <th>الحالة القانونية</th>
    <th>اسم الملف الأصلي</th>
</tr>
</thead>
<tbody>
{''.join(rows_html) if rows_html else '<tr><td colspan="8" style="text-align:center;">لا توجد وثائق في هذا الملف.</td></tr>'}
</tbody>
</table>
<div class="footer">
    تم استخراج هذا الأرشيف تلقائياً بواسطة منظومة Dec2026 — Dossier Fiscal Numérique.
</div>
</body>
</html>"""
        zf.writestr("فهرس_وثائق_الملف_الرقمي.html", index_html.encode("utf-8"))

    return buf.getvalue()


