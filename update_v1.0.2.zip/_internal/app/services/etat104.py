"""Service État 104 des clients (Série G., Modèle n° 3 & n° 3 bis).
Conforme rigoureusement aux imprimés officiels de l'Administration des Impôts (Algérie):
- Page 1 : Série G., Modèle n° 3 (Tête) — Page de garde officielle séparée sans lignes de clients
- Page 2+ : Série G., n° 3 bis (Intercalaires) — Tableaux détaillés des clients au format paysage (A4 Paysage)

Articles 224, 227, 228, 303 du Code des Impôts Directs (CID).
"""
from __future__ import annotations

import io
import math
import re
import sqlite3
from datetime import datetime
from typing import Any

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..core.db import connect
from . import dates, dossiers
from .g50 import _num
from .honoraires import nombre_en_lettres_ar, nombre_en_lettres_fr


def get_etat104_data(code: str, annee: str) -> dict[str, Any]:
    """Agrège toutes les factures de vente de l'exercice par client avec leurs coordonnées fiscales."""
    annee_str = str(annee).strip()
    soc = dossiers.societe(code)

    with connect(code) as c:
        query = """
            SELECT 
                COALESCE(c.rs, v.ClientsVente) AS client_nom,
                COALESCE(c.adresse, '') AS client_adresse,
                COALESCE(c.ai, '') AS client_ai,
                COALESCE(c.NIF, '') AS client_nif,
                COALESCE(c.rcom, '') AS client_rcom,
                COALESCE(c.activité, '') AS client_activite,
                v.IDClentventes AS client_id,
                SUM(v.ht) AS total_ht,
                SUM(v.tvadroits) AS total_tva,
                SUM(v.TTC) AS total_ttc,
                COUNT(v.IDFacturesVente) AS nb_factures
            FROM FacturesVentes v
            LEFT JOIN ClientrVentes c ON v.IDClentventes = c.IDclientvente
            WHERE (v."Année" = ? OR (COALESCE(v."Année", '') = '' AND substr(v.datrfature, 1, 4) = ?))
            GROUP BY COALESCE(v.IDClentventes, UPPER(TRIM(v.ClientsVente)))
            ORDER BY client_nom ASC
        """
        rows = [dict(r) for r in c.execute(query, (annee_str, annee_str)).fetchall()]

    items = []
    tot_ht = 0.0
    tot_tva = 0.0
    tot_ttc = 0.0

    for idx, r in enumerate(rows, start=1):
        ht = round(_num(r.get("total_ht")), 2)
        tva = round(_num(r.get("total_tva")), 2)
        ttc = round(_num(r.get("total_ttc")), 2)
        tot_ht += ht
        tot_tva += tva
        tot_ttc += ttc

        ht_da = int(ht)
        ht_cts = int(round((ht - ht_da) * 100))
        tva_da = int(tva)
        tva_cts = int(round((tva - tva_da) * 100))

        items.append({
            "num_ordre": idx,
            "client_nom": str(r.get("client_nom") or "").strip(),
            "client_adresse": str(r.get("client_adresse") or "").strip(),
            "client_rcom": str(r.get("client_rcom") or "").strip(),
            "client_ai": str(r.get("client_ai") or "").strip(),
            "client_nif": str(r.get("client_nif") or "").strip(),
            "client_activite": str(r.get("client_activite") or "").strip(),
            "total_ht": ht,
            "ht_da": f"{ht_da:,}".replace(",", " "),
            "ht_cts": f"{ht_cts:02d}",
            "total_tva": tva,
            "tva_da": f"{tva_da:,}".replace(",", " "),
            "tva_cts": f"{tva_cts:02d}",
            "total_ttc": ttc,
            "nb_factures": int(r.get("nb_factures") or 0),
        })

    tot_ht_da = int(tot_ht)
    tot_ht_cts = int(round((tot_ht - tot_ht_da) * 100))
    tot_tva_da = int(tot_tva)
    tot_tva_cts = int(round((tot_tva - tot_tva_da) * 100))

    return {
        "annee": annee_str,
        "societe": {
            "rs": soc.get("rs", ""),
            "adresse": soc.get("adresse", ""),
            "commune": soc.get("commune", ""),
            "wilaya": soc.get("wilaya", ""),
            "nif": soc.get("nif", ""),
            "ai": soc.get("ai", ""),
            "rcom": soc.get("rcom", ""),
            "nis": soc.get("nis", ""),
            "inspection": soc.get("inspection", "") or soc.get("commune", ""),
            "activite": soc.get("activité", ""),
        },
        "items": items,
        "totals": {
            "total_ht": tot_ht,
            "total_ht_da": f"{tot_ht_da:,}".replace(",", " "),
            "total_ht_cts": f"{tot_ht_cts:02d}",
            "total_tva": tot_tva,
            "total_tva_da": f"{tot_tva_da:,}".replace(",", " "),
            "total_tva_cts": f"{tot_tva_cts:02d}",
            "total_ttc": tot_ttc,
            "nb_clients": len(items),
            "nb_factures": sum(i["nb_factures"] for i in items),
        },
    }


def _render_boxes(val: str, length: int) -> str:
    clean = re.sub(r'[^0-9A-Za-z]', '', val or "").strip()
    clean = clean.ljust(length)
    boxes = []
    for char in clean[:length]:
        display_char = char if char != " " else "&nbsp;"
        boxes.append(f'<span class="box-digit">{display_char}</span>')
    return "".join(boxes)


def generate_etat104_html(code: str, annee: str) -> str:
    """Génère l'imprimé officiel HTML cloné à 100% sur les spécimens GN° 3 (Tête séparée) et GN° 3 BIS (Intercalaires Paysage)."""
    data = get_etat104_data(code, annee)
    soc = data["societe"]
    items = data["items"]
    totals = data["totals"]
    annee_val = data["annee"]
    tot_ht = totals["total_ht"]
    tot_tva = totals["total_tva"]

    # Montants en lettres (Tafqeet arabe et français)
    tot_ht_ar_words = nombre_en_lettres_ar(tot_ht)
    tot_ht_fr_words = nombre_en_lettres_fr(tot_ht)

    # Date du jour
    date_today = datetime.now().strftime("%d/%m/%Y")
    commune_val = soc["commune"] or soc["wilaya"] or "Alger"

    # Pagination des intercalaires:
    ROWS_PER_INTERCALAIRE = 20
    nb_intercalaires = max(1, math.ceil(len(items) / ROWS_PER_INTERCALAIRE))
    total_document_pages = 1 + nb_intercalaires + 1  # 1 Page de garde + N Intercalaires + 1 Page finale légale

    # Grille NIF (15 cases)
    nif_boxes = _render_boxes(soc["nif"], 15)

    # Grille Article d'imposition (11 cases)
    ai_raw = soc["ai"] or ""
    ai_letter = ai_raw[0] if (ai_raw and ai_raw[0].isalpha()) else " "
    ai_rest = ai_raw[1:] if (ai_raw and ai_raw[0].isalpha()) else ai_raw
    ai_letter_box = f'<span class="box-digit" style="background:#f0f0f0;">{ai_letter}</span>'
    ai_digits_boxes = _render_boxes(ai_rest, 10)

    html_parts = [f"""<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
<meta charset="utf-8"/>
<title>État Détaillé des Clients (G N° 3 & G N° 3 Bis) — {annee_val}</title>
<style>
@page {{
  size: A4 landscape;
  margin: 6mm 8mm;
}}
@page landscape-sheet {{
  size: A4 landscape;
  margin: 6mm 8mm;
}}
* {{ box-sizing: border-box; }}
body {{
  background: #525659;
  font-family: 'Times New Roman', Times, 'Traditional Arabic', serif;
  color: #000;
  margin: 0;
  padding: 15px 0;
}}
.ar {{
  font-family: 'Traditional Arabic', 'Amiri', 'Segoe UI', Tahoma, sans-serif;
  direction: rtl;
}}
.box-digit {{
  display: inline-block;
  width: 17px;
  height: 20px;
  line-height: 20px;
  text-align: center;
  border: 1.5px solid #000;
  font-family: 'Courier New', monospace;
  font-size: 13px;
  font-weight: bold;
  background: #fff;
  margin-right: -1.5px;
}}
.dots {{
  color: #666;
  letter-spacing: 2px;
}}
.val-fill {{
  font-weight: bold;
  color: #000;
  padding: 0 4px;
}}

/* Page 1: Tête (Landscape - A4 أفقي مثل الصفحة الداخلية) */
.page-cover {{
  width: 297mm;
  min-height: 209mm;
  margin: 0 auto 25px auto;
  background: #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.35);
  padding: 7mm 12mm;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  page: landscape-sheet;
  page-break-after: always;
  break-after: page;
}}

/* Pages 2+: Intercalaires (Landscape) */
.page-intercalaire {{
  width: 297mm;
  min-height: 209mm;
  margin: 0 auto 25px auto;
  background: #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.35);
  padding: 7mm 10mm;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  page: landscape-sheet;
  page-break-after: always;
  break-after: page;
}}

/* Page finale: Extraits légaux (Landscape) */
.page-finale {{
  width: 297mm;
  min-height: 209mm;
  margin: 0 auto 25px auto;
  background: #fff;
  box-shadow: 0 4px 15px rgba(0,0,0,0.35);
  padding: 7mm 12mm;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  page: landscape-sheet;
  page-break-after: auto;
  break-after: auto;
}}

/* Table Intercalaire */
.inter-table {{
  width: 100%;
  border-collapse: collapse;
  font-size: 10px;
  border: 2px solid #000;
  margin-top: 4px;
}}
.inter-table th, .inter-table td {{
  border: 1px solid #000;
  padding: 2.5px 3px;
}}
.inter-table th {{
  background: #fdfdfd;
  font-weight: bold;
  text-align: center;
  vertical-align: middle;
}}
.th-title-ar {{
  display: block;
  font-family: 'Traditional Arabic', 'Amiri', sans-serif;
  font-size: 11px;
  direction: rtl;
  font-weight: bold;
}}
.th-title-fr {{
  display: block;
  font-size: 9px;
  font-weight: bold;
}}
.num-da {{
  text-align: right;
  font-family: 'Courier New', monospace;
  font-size: 10px;
  font-weight: bold;
  white-space: nowrap;
}}
.cts-cell {{
  width: 22px;
  text-align: center;
  font-family: 'Courier New', monospace;
  font-size: 9px;
}}
.center-text {{
  text-align: center;
}}

@media print {{
  body {{
    background: transparent !important;
    padding: 0 !important;
  }}
  .no-print {{
    display: none !important;
  }}
  .page-cover, .page-intercalaire, .page-finale {{
    margin: 0 !important;
    box-shadow: none !important;
    width: 100% !important;
    height: 100vh !important;
    padding: 6mm 8mm !important;
  }}
  .page-cover {{
    page-break-after: always !important;
    break-after: page !important;
  }}
  .page-intercalaire {{
    page-break-after: always !important;
    break-after: page !important;
  }}
  .page-finale {{
    page-break-before: always !important;
    break-before: page !important;
    page-break-after: auto !important;
    break-after: auto !important;
  }}
}}
</style>
</head>
<body>

<!-- Barre d'outils interne -->
<div class="no-print" style="background:#1e293b; color:#fff; padding:9px 18px; display:flex; align-items:center; justify-content:space-between; position:sticky; top:0; z-index:999; box-shadow:0 2px 10px rgba(0,0,0,0.4);">
  <div style="font-weight:bold; font-size:13px; display:flex; align-items:center; gap:10px;">
    <span>🏛️ REPUBLIQUE ALGERIENNE — Imprimé Officiel Série G., Modèle N° 3 & N° 3 Bis</span>
    <span style="font-size:11.5px; color:#94a3b8;">· Exercice fiscal {annee_val} · ({total_document_pages} pages : 1 Page de garde + {nb_intercalaires} Intercalaire(s) + 1 Page finale légale)</span>
  </div>
  <div style="display:flex; align-items:center; gap:10px;">
    <a href="/api/dossiers/{code}/etat104/{annee_val}/export-excel" download="G3_Etat104_Clients_{annee_val}_{code}.xlsx" style="background:#059669; color:#fff; text-decoration:none; padding:6px 14px; border-radius:5px; font-weight:bold; font-size:12px; display:inline-flex; align-items:center; gap:6px; cursor:pointer; box-shadow:0 1px 3px rgba(0,0,0,0.25);">
      📊 تصدير Excel (.xlsx)
    </a>
    <button onclick="window.print()" style="background:#dc2626; color:#fff; border:none; padding:6px 14px; border-radius:5px; font-weight:bold; cursor:pointer; font-size:12px; display:inline-flex; align-items:center; gap:6px; box-shadow:0 1px 3px rgba(0,0,0,0.25);">
      📄 حفظ / تصدير PDF
    </button>
  </div>
</div>
"""]

    # =========================================================================
    # PAGE 1 : SÉRIE G., MODÈLE N° 3 (TÊTE) — PAGE DE GARDE SÉPARÉE (A4 PAYSAGE)
    # =========================================================================
    # =========================================================================
    # PAGE 1 : SÉRIE G., MODÈLE N° 3 (TÊTE) — PAGE DE GARDE SÉPARÉE (A4 PAYSAGE)
    # 100% CLONE DU SPÉCIMEN OFFICIEL D'IMPRIMERIE (Docs/GN°3 (1).pdf)
    # =========================================================================
    html_parts.append(f"""
    <div class="page-cover" style="font-family:'Times New Roman', 'Amiri', 'Traditional Arabic', serif; font-size:11px; line-height:1.25; position:relative;">
      
      <!-- EN-TÊTE SUPÉRIEUR : 3 COLONNES -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 2px;">
        <tr>
          <!-- Colonne Gauche : Ministère des finances / Wilaya / Commune / Inspection -->
          <td style="width: 26%; vertical-align: top; text-align: center; font-size: 10px;">
            <div class="ar" style="font-weight: bold; font-size: 12.5px; line-height: 1.1;">وزارة المـالـيـة</div>
            <div style="font-weight: bold; font-size: 9px; letter-spacing: 0.5px;">MINISTERE DES FINANCES</div>
            <div style="width: 35px; height: 1px; background: #000; margin: 3px auto;"></div>
            <div class="ar" style="font-weight: bold; font-size: 11.5px; line-height: 1.1;">إدارة الـضـرائـب</div>
            <div style="font-weight: bold; font-size: 8.5px; letter-spacing: 0.5px;">ADMINISTRATION DES IMPOTS</div>
            <div style="width: 35px; height: 1px; background: #000; margin: 3px auto 6px auto;"></div>

            <div style="margin-top: 4px; text-align: center;">
              <div class="ar" style="font-weight: bold; font-size: 12px;">ولايـــــــــــة</div>
              <div style="font-size: 8.5px; font-weight: bold;">WILAYA</div>
              <div style="text-align: left; font-size: 10px; margin-top: 1px; border-bottom: 1px dotted #000; padding: 1px 4px;">
                d. <b>{soc['wilaya'] or '................................................'}</b>
              </div>
              <div style="width: 25px; height: 1px; background: #000; margin: 3px auto 4px auto;"></div>
            </div>

            <div style="margin-top: 3px; text-align: center;">
              <div class="ar" style="font-weight: bold; font-size: 12px;">بلديـــــــــــة</div>
              <div style="font-size: 8.5px; font-weight: bold;">Commune</div>
              <div style="text-align: left; font-size: 10px; margin-top: 1px; border-bottom: 1px dotted #000; padding: 1px 4px;">
                d. <b>{soc['commune'] or '................................................'}</b>
              </div>
              <div style="width: 25px; height: 1px; background: #000; margin: 3px auto 4px auto;"></div>
            </div>

            <div style="margin-top: 3px; text-align: center;">
              <div class="ar" style="font-weight: bold; font-size: 12px;">مـفـتـشـيـــــــــــة</div>
              <div style="font-size: 8.5px; font-weight: bold;">INSPECTION</div>
              <div style="text-align: left; font-size: 10px; margin-top: 1px; border-bottom: 1px dotted #000; padding: 1px 4px;">
                d. <b>{soc['inspection'] or soc['commune'] or '................................................'}</b>
              </div>
              <div style="width: 25px; height: 1px; background: #000; margin: 3px auto 0 auto;"></div>
            </div>
          </td>

          <!-- Colonne Centrale : République + Article d'imposition + Titres Centrés -->
          <td style="width: 48%; vertical-align: top; text-align: center;">
            <div class="ar" style="font-size: 13.5px; font-weight: bold; letter-spacing: 0.5px;">الـجـمـهـوريـة الـجـزائـريـة الـديمـقـراطـيـة الـشـعـبـيـة</div>
            <div style="font-size: 9.5px; font-weight: bold; letter-spacing: 0.5px;">REPUBLIQUE ALGERIENNE DEMOCRATIQUE ET POPULAIRE</div>

            <!-- Grille Article d'imposition avec consignes à gauche et à droite -->
            <div style="margin: 6px auto 0 auto; display: inline-flex; align-items: center; justify-content: center; gap: 8px;">
              <div style="text-align: left; font-size: 8px; font-style: italic; line-height: 1.15; max-width: 145px;">
                Inscrivez ci-contre la lettre et le n° d'article de votre imposition établie au titre de <b>{annee_val}</b>
              </div>
              <div style="display: inline-flex; border: 1.5px solid #000; background: #fff;">
                {ai_letter_box}
                <span style="display:inline-block; width:4px; background:#ddd; border-right:1px solid #000; border-left:1px solid #000;"></span>
                {ai_digits_boxes}
              </div>
              <div class="ar" style="text-align: right; font-size: 8.5px; line-height: 1.15; max-width: 145px;">
                أكتب – إزاء هذا الحرف ورقم مادة الضريبة التي فرضت عليكم عن سنة : <b>{annee_val}</b>
              </div>
            </div>

            <!-- BLOC DES TITRES OFFICIELS RIGUREUSEMENT CENTRÉS ET EMPILÉS -->
            <div style="margin-top: 8px;">
              <div class="ar" style="font-size: 16px; font-weight: bold; line-height: 1.2;">الـرسـم عـلـى الـنـشـاط الـمـهـنـي</div>
              <div style="font-size: 12.5px; font-weight: bold; letter-spacing: 0.5px; line-height: 1.1;">TAXE SUR L'ACTIVITE PROFESSIONNELLE</div>
              
              <div class="ar" style="font-size: 15px; font-weight: bold; margin-top: 4px; line-height: 1.2;">مـبـيـعـات تـمـت بـشـروط الـجـمـلـة</div>
              <div style="font-size: 11.5px; font-weight: bold; letter-spacing: 0.5px; line-height: 1.1;">VENTES REALISEES DANS LES CONDITIONS DE GROS</div>
              
              <div class="ar" style="font-size: 22px; font-weight: 900; margin-top: 6px; line-height: 1.1; text-decoration: underline;">كـشـف تـفـصـيـلـي بـالـعـمـلاء</div>
              <div style="font-size: 17px; font-weight: 900; letter-spacing: 1px; line-height: 1.1;">ETAT DETAILLE DES CLIENTS</div>
              
              <div class="ar" style="font-size: 10px; font-weight: bold; margin-top: 3px;">(مادة 224 من قانون الضرائب المباشرة)</div>
              <div style="font-size: 9px; font-style: italic;">(Art. 224 du Code des Impôts Directs)</div>

              <div style="margin-top: 5px; font-size: 12px; font-weight: bold;">
                <span style="letter-spacing: 1px;">ANNEE</span> &nbsp; <span style="border-bottom: 1px dotted #000; padding: 0 15px;"><b>{annee_val}</b></span> &nbsp; <span class="ar">سـنـة</span>
              </div>
              <div style="font-size: 9.5px; margin-top: 2px;">
                ( &nbsp;<span class="ar">نتائج السنة</span> &nbsp;<span style="border-bottom: 1px dotted #000; padding: 0 10px;"><b>{annee_val}</b></span> &nbsp; <span class="ar">أو السنة المنتهية في</span> &nbsp;<span style="border-bottom: 1px dotted #000; padding: 0 10px;"><b>31/12/{annee_val}</b></span>&nbsp; )<br/>
                <span style="font-style: italic; font-size: 9px;">(Résultats de l'Année <b>{annee_val}</b> ou de l'Exercice clos en <b>31/12/{annee_val}</b>)</span>
              </div>
            </div>
          </td>

          <!-- Colonne Droite : Série G. Modèle n°3 + Timbre de l'inspecteur -->
          <td style="width: 26%; vertical-align: top; text-align: right;">
            <div style="font-size: 10.5px; font-weight: bold;">Série G., Modèle n° 3 (Tête)</div>
            <div style="font-size: 8.5px; color: #333; margin-top: 1px;">Imprimerie Officielle (2009)</div>

            <div style="margin-top: 10px; margin-left: auto; width: 145px; height: 95px; border: 1.5px solid #000; text-align: center; padding: 4px;">
              <div class="ar" style="font-size: 10.5px; font-weight: bold;">الـخـتـم ذو الـتـاريـخ لـلـمـفـتـش</div>
              <div style="font-size: 8px; font-style: italic; margin-top: 2px;">Timbre à date de l'Inspecteur</div>
            </div>
          </td>
        </tr>
      </table>

      <!-- NUMERO D'IDENTIFICATION FISCALE (Grille 15 chiffres alignée à droite) -->
      <div style="display: flex; justify-content: flex-end; margin: 2px 0 6px 0; padding-right: 5px;">
        <div style="text-align: center;">
          <div style="font-size: 10px; font-weight: bold; margin-bottom: 2px;">
            Numéro d'Identification Fiscale
          </div>
          <div style="display: flex; justify-content: flex-end;">
            {nif_boxes}
          </div>
        </div>
      </div>

      <!-- LES 5 LIGNES D'IDENTIFICATION AVEC ACCOLADES EN VIS-A-VIS ET DONNEES AU CENTRE -->
      <table style="width: 100%; border-collapse: collapse; font-size: 10px; margin: 4px 0;">
        <!-- Ligne 1 : Raison Sociale -->
        <tr>
          <td style="width: 35%; text-align: left; vertical-align: middle; white-space: nowrap; overflow: hidden;">
            Nom et prénoms du déclarant ou raison sociale de l'Entreprise <span class="dots">...................................</span>
          </td>
          <td style="width: 15px; text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#125;</td>
          <td style="text-align: center; vertical-align: middle; border-bottom: 1px dotted #000; padding: 0 4px; font-weight: bold; font-size: 11px;">
            {soc['rs']}
          </td>
          <td style="width: 15px; text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#123;</td>
          <td style="width: 35%; text-align: right; vertical-align: middle; white-space: nowrap; overflow: hidden; direction: rtl;" class="ar">
            <span class="dots">...................................................</span> لقب وإسم صاحب الإقرار أو إسم الشركة
          </td>
        </tr>

        <!-- Ligne 2 : Nature de l'Industrie -->
        <tr>
          <td style="text-align: left; vertical-align: middle; white-space: nowrap; overflow: hidden;">
            Nature de l'Industrie, du Commerce ou de la Profession <span class="dots">..........................................</span>
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#125;</td>
          <td style="text-align: center; vertical-align: middle; border-bottom: 1px dotted #000; padding: 0 4px; font-weight: bold; font-size: 10.5px;">
            {soc['activite'] or "Travaux / Prestations / Commerce"}
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#123;</td>
          <td style="text-align: right; vertical-align: middle; white-space: nowrap; overflow: hidden; direction: rtl;" class="ar">
            <span class="dots">...................................................</span> نوع الصناعة، التجارة، أو المهنة
          </td>
        </tr>

        <!-- Ligne 3 : Registre de Commerce -->
        <tr>
          <td style="text-align: left; vertical-align: middle; white-space: nowrap; overflow: hidden;">
            N° du Registre de Commerce et désignation du Tribunal où est tenu ce registre <span class="dots">.....</span>
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#125;</td>
          <td style="text-align: center; vertical-align: middle; border-bottom: 1px dotted #000; padding: 0 4px; font-weight: bold; font-size: 10.5px;">
            {soc['rcom']}
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#123;</td>
          <td style="text-align: right; vertical-align: middle; white-space: nowrap; overflow: hidden; direction: rtl;" class="ar">
            <span class="dots">...................................................</span> رقم السجل التجاري وإسم المحكمة الموجود بها هذا السجل
          </td>
        </tr>

        <!-- Ligne 4 : Etablissement Principal / Siège -->
        <tr>
          <td style="text-align: left; vertical-align: middle; white-space: nowrap; overflow: hidden;">
            Adresse de l'Etablissement principal ou du siège social <span class="dots">............................................</span>
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#125;</td>
          <td style="text-align: center; vertical-align: middle; border-bottom: 1px dotted #000; padding: 0 4px; font-weight: bold; font-size: 10px;">
            {soc['adresse']} {soc['commune']}
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#123;</td>
          <td style="text-align: right; vertical-align: middle; white-space: nowrap; overflow: hidden; direction: rtl;" class="ar">
            <span class="dots">...................................................</span> عنوان المؤسسة الرئيسية أو مركز الإدارة
          </td>
        </tr>

        <!-- Ligne 5 : Etablissement auquel se rapporte l'état -->
        <tr>
          <td style="text-align: left; vertical-align: middle; white-space: nowrap; overflow: hidden;">
            Adresse de l'Etablissement auquel se rapporte le présent état <span class="dots">....................................</span>
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#125;</td>
          <td style="text-align: center; vertical-align: middle; border-bottom: 1px dotted #000; padding: 0 4px; font-weight: bold; font-size: 10px;">
            {soc['adresse']} {soc['commune']}
          </td>
          <td style="text-align: center; font-size: 24px; font-family: serif; vertical-align: middle; line-height: 1;" dir="ltr">&#123;</td>
          <td style="text-align: right; vertical-align: middle; white-space: nowrap; overflow: hidden; direction: rtl;" class="ar">
            <span class="dots">...................................................</span> عنوان المؤسسة التي يتبعها هذا الكشف
          </td>
        </tr>
      </table>

      <!-- ARRETE DU PRESENT ETAT : 2 LIGNES IDENTIQUES AU SPECIMEN -->
      <div style="margin-top: 10px; font-size: 10px; line-height: 1.8;">
        <!-- Ligne Arabe -->
        <div style="display: flex; align-items: baseline; justify-content: space-between; direction: rtl;" class="ar">
          <div style="white-space: nowrap; font-size: 10.5px;">
            يوقف حساب هذا الكشف وهو يحتوي على عدد &nbsp;
            <b style="border-bottom: 1px dotted #000; padding: 0 6px;">{nb_intercalaires}</b>
            &nbsp; صفحة مرقمة من 1 إلى &nbsp;
            <b style="border-bottom: 1px dotted #000; padding: 0 6px;">{nb_intercalaires}</b>
          </div>
          <div style="flex-grow: 1; border-bottom: 1px dotted #000; margin: 0 8px; text-align: center; font-size: 10.5px;">
            مبلغ إجمالي قدره : <b style="font-size: 11px;">{totals['total_ht_da']} دج و {totals['total_ht_cts']} سنتيم</b> &nbsp;—&nbsp; ({tot_ht_ar_words})
          </div>
          <div style="white-space: nowrap; font-size: 10.5px;">مـبـلـغ</div>
        </div>

        <!-- Ligne Française -->
        <div style="display: flex; align-items: baseline; justify-content: space-between; margin-top: 2px;">
          <div style="white-space: nowrap;">
            Arrêté le présent état contenant &nbsp;
            <b style="border-bottom: 1px dotted #000; padding: 0 6px;">{nb_intercalaires}</b>
            &nbsp; page (s) numérotée(s) de 1 à &nbsp;
            <b style="border-bottom: 1px dotted #000; padding: 0 6px;">{nb_intercalaires}</b>
          </div>
          <div style="flex-grow: 1; border-bottom: 1px dotted #000; margin: 0 8px; text-align: center;">
            à la somme de : <b style="font-size: 11px;">{totals['total_ht_da']},{totals['total_ht_cts']} D.A.</b> &nbsp;—&nbsp; ({tot_ht_fr_words})
          </div>
        </div>
      </div>

      <!-- LIGNE DATE ET LIEU DE SIGNATURE -->
      <div style="margin-top: 10px; display: flex; justify-content: space-between; font-size: 10.5px;">
        <div style="width: 45%; text-align: left;">
          <div>A <b style="border-bottom: 1px dotted #000; padding: 0 12px;">{commune_val}</b>, le <b style="border-bottom: 1px dotted #000; padding: 0 12px;">{date_today}</b></div>
          <div style="margin-top: 3px; font-style: italic; font-size: 9px; padding-left: 20px;">(signature)</div>
        </div>
        <div style="width: 45%; text-align: right; direction: rtl;" class="ar">
          <div>حرر بـ <b style="border-bottom: 1px dotted #000; padding: 0 12px;">{commune_val}</b> في <b style="border-bottom: 1px dotted #000; padding: 0 12px;">{date_today}</b></div>
          <div style="margin-top: 3px; font-size: 9px; padding-right: 20px;">(الإمضاء)</div>
        </div>
      </div>

      <!-- BAS DE PAGE : CADRE AVIS IMPORTANT A GAUCHE / CERTIFICATION A DROITE SANS CADRE -->
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-top: 8px;">
        <!-- Cadre AVIS IMPORTANT à Gauche -->
        <div style="width: 48%; border: 2px solid #000; padding: 6px 10px; font-size: 9px; line-height: 1.3;">
          <div class="ar" style="text-align: center; font-weight: 900; font-size: 12.5px; letter-spacing: 2px;">تــنــبــيــــه هــــــام</div>
          <div class="ar" style="text-align: justify; direction: rtl; margin-top: 3px; font-size: 9.5px;">
            يجب أن يرفق هذا الكشف بالإقرار السنوي – ويرسل قبل أول أبريل – إلى مفتش الضرائب الواقع في دائرته مركز إدارة منشأة المعني بالأمر أو محل مؤسسته الرئيسية.
          </div>
          <div style="text-align: center; font-weight: bold; font-size: 9.5px; margin-top: 5px; letter-spacing: 1px;">
            AVIS IMPORTANT
          </div>
          <div style="text-align: justify; margin-top: 2px; font-size: 8.5px;">
            Le présent état à annexer à la déclaration annuelle doit parvenir avant le 1er avril à l'Inspecteur du lieu où l'intéressé a le siège de sa Direction ou de son principal établissement.
          </div>
        </div>

        <!-- Certification à Droite (OUVERTE SANS CADRE COMME DANS L'ORIGINAL) -->
        <div style="width: 46%; text-align: center; padding-top: 15px;">
          <div class="ar" style="font-weight: bold; font-size: 12px;">شهد بصحته الموقع أدناه</div>
          <div style="font-size: 9.5px; font-style: italic; margin-top: 2px;">Certifié exact par le soussigné</div>
          <div style="border-bottom: 1px dotted #000; width: 85%; margin: 8px auto 0 auto;"></div>
          <!-- Espace réservé au cachet et à la signature -->
          <div style="height: 50px;"></div>
        </div>
      </div>

    </div>
    """)

    # =========================================================================
    # PAGES 2+ : SÉRIE G., N° 3 BIS (INTERCALAIRES) — FORMAT PAYSAGE (LANDSCAPE)
    # =========================================================================
    for p_idx in range(1, nb_intercalaires + 1):
        start = (p_idx - 1) * ROWS_PER_INTERCALAIRE
        page_items = items[start:start + ROWS_PER_INTERCALAIRE]
        prev_items = items[:start]

        cumul_ht_prev = sum(it["total_ht"] for it in prev_items)
        cumul_tva_prev = sum(it["total_tva"] for it in prev_items)

        page_ht = sum(it["total_ht"] for it in page_items)
        page_tva = sum(it["total_tva"] for it in page_items)

        cumul_ht_end = cumul_ht_prev + page_ht
        cumul_tva_end = cumul_tva_prev + page_tva

        prev_ht_da = int(cumul_ht_prev)
        prev_ht_cts = int(round((cumul_ht_prev - prev_ht_da) * 100))
        prev_tva_da = int(cumul_tva_prev)
        prev_tva_cts = int(round((cumul_tva_prev - prev_tva_da) * 100))

        end_ht_da = int(cumul_ht_end)
        end_ht_cts = int(round((cumul_ht_end - end_ht_da) * 100))
        end_tva_da = int(cumul_tva_end)
        end_tva_cts = int(round((cumul_tva_end - end_tva_da) * 100))

        is_last_intercalaire = (p_idx == nb_intercalaires)

        html_parts.append(f"""
        <div class="page-intercalaire">
          <div>
            
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 4px;">
              <div style="font-size: 11px; font-weight: bold;">
                N° de Page : &nbsp; <b>{p_idx} / {nb_intercalaires}</b> &nbsp;&nbsp;
                <span class="ar">رقم الصفحة : <b>{p_idx}</b></span>
              </div>
              <div style="font-size: 10px; font-weight: bold; text-align: right;">
                Série G., &nbsp; n° 3 bis. Intercalaire &nbsp; - 2009 - &nbsp; Imp. Officielle, Alger
              </div>
            </div>

            
            <table class="inter-table">
              <thead>
                <tr>
                  
                  <th rowspan="2" style="width: 12%;">
                    <span class="th-title-ar">رقم السجل التجاري</span>
                    <span class="th-title-fr">Numéro du registre de commerce</span>
                  </th>

                  
                  <th rowspan="2" style="width: 10%;">
                    <span class="th-title-ar">رقم المادة للعميل</span>
                    <span class="th-title-fr">Numéro d'Article du Client</span>
                  </th>

                  
                  <th rowspan="2" style="width: 14%;">
                    <span class="th-title-ar">رقم التعريف الجبائي</span>
                    <span class="th-title-fr">Numéro d'Identification Fiscale</span>
                  </th>

                  
                  <th colspan="2" style="width: 40%;">
                    <span class="th-title-ar">الإسم الكامل للعميل <sup>(1)</sup></span>
                    <span class="th-title-fr">DESIGNATION EXACTE DU CLIENT <sup>(1)</sup></span>
                  </th>

                  
                  <th colspan="2" style="width: 12%;">
                    <span class="th-title-ar">المجموع السنوي للعمليات المحققة مع كل عميل</span>
                    <span class="th-title-fr">MONTANT ANNUEL des Opérations Réalisées avec chaque Client</span>
                  </th>

                  
                  <th colspan="2" style="width: 12%;">
                    <span class="th-title-ar">مجموع الرسم على القيمة المضافة المفوترة لكل عميل</span>
                    <span class="th-title-fr">MONTANT DE LA TAXE sur la Valeur Ajoutée facturée à chaque client</span>
                  </th>
                </tr>
                <tr>
                  
                  <th style="width: 22%;">
                    <span class="th-title-ar">اللقب، الأسماء أو إسم الشركة</span>
                    <span class="th-title-fr">NOM, Prénoms ou Raison Sociale</span>
                  </th>
                  <th style="width: 18%;">
                    <span class="th-title-ar">العنوان الكامل (الشارع، الرقم، العمارة، البلدية)</span>
                    <span class="th-title-fr">Adresse Complète (Rue, n°, Bt, Commune)</span>
                  </th>

                  
                  <th style="font-size: 8.5px;">D.A.</th>
                  <th class="cts-cell">Cts</th>

                  
                  <th style="font-size: 8.5px;">D.A.</th>
                  <th class="cts-cell">Cts</th>
                </tr>
              </thead>
              <tbody>
                
                <tr style="background: #f8fafc; font-weight: bold; height: 21px;">
                  <td colspan="5" style="text-align: right; padding-right: 12px;">
                    <span class="ar">الـتـرحـيـل مـن الـصـفـحـة الـسـابـقـة</span> &nbsp;/&nbsp; Report de la page précédente
                  </td>
                  <td class="num-da">{f"{prev_ht_da:,}".replace(",", " ") if p_idx > 1 else "—"}</td>
                  <td class="cts-cell">{f"{prev_ht_cts:02d}" if p_idx > 1 else "—"}</td>
                  <td class="num-da">{f"{prev_tva_da:,}".replace(",", " ") if p_idx > 1 else "—"}</td>
                  <td class="cts-cell">{f"{prev_tva_cts:02d}" if p_idx > 1 else "—"}</td>
                </tr>
        """)

        # Client lines
        for it in page_items:
            html_parts.append(f"""
                <tr style="height: 22px;">
                  <td class="center-text" style="font-family:'Courier New', monospace; font-size:10px;">{it['client_rcom'] or '—'}</td>
                  <td class="center-text" style="font-family:'Courier New', monospace; font-size:10px;">{it['client_ai'] or '—'}</td>
                  <td class="center-text" style="font-family:'Courier New', monospace; font-size:10px;">{it['client_nif'] or '—'}</td>
                  <td style="font-weight: 700; font-size: 10.5px;">{it['client_nom']}</td>
                  <td style="font-size: 9.5px; color: #222;">{it['client_adresse'] or '—'}</td>
                  <td class="num-da">{it['ht_da']}</td>
                  <td class="cts-cell">{it['ht_cts']}</td>
                  <td class="num-da">{it['tva_da']}</td>
                  <td class="cts-cell">{it['tva_cts']}</td>
                </tr>
            """)

        # Empty lines to complete the 20 rows
        empty_count = ROWS_PER_INTERCALAIRE - len(page_items)
        for _ in range(empty_count):
            html_parts.append("""
                <tr style="height: 22px;">
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                </tr>
            """)

        # Bottom Totals Row
        tot_label_ar = "الـمـجـمـوع الـعـام لـكـشـف الـعـمـلاء" if is_last_intercalaire else "المجموع المنقول إلى الصفحة التالية"
        tot_label_fr = "TOTAL GENERAL DE L'ETAT" if is_last_intercalaire else "Total à reporter"
        row_bg = "#e2e8f0" if is_last_intercalaire else "#f1f5f9"

        html_parts.append(f"""
                <tr style="background: {row_bg}; font-weight: bold; height: 24px; font-size: 10.5px;">
                  <td colspan="5" style="text-align: right; padding-right: 12px;">
                    <span class="ar" style="font-size: 11.5px;">{tot_label_ar}</span> &nbsp;/&nbsp; {tot_label_fr}
                  </td>
                  <td class="num-da" style="font-size: 11px;">{f"{end_ht_da:,}".replace(",", " ")}</td>
                  <td class="cts-cell" style="font-size: 10px;">{end_ht_cts:02d}</td>
                  <td class="num-da" style="font-size: 11px;">{f"{end_tva_da:,}".replace(",", " ")}</td>
                  <td class="cts-cell" style="font-size: 10px;">{end_tva_cts:02d}</td>
                </tr>
              </tbody>
            </table>
          </div>

          
          <div style="display: flex; justify-content: space-between; font-size: 8.5px; color: #444; margin-top: 4px;">
            <div>
              (1) Le nom et l'adresse complète doivent être mentionnés très lisiblement.
            </div>
            <div style="font-weight: bold;">
              Feuillet G N° 3 Bis · Société : {soc['rs']} (Exercice {annee_val})
            </div>
          </div>
        </div>
        """)

    # =========================================================================
    # PAGE FINALE : EXTRAITS DU CODE DES IMPOTS DIRECTS (PAGE LÉGALE OFFICIELLE)
    # =========================================================================
    html_parts.append(f"""
    <div class="page-finale">
      <div style="width: 100%; display: flex; justify-content: center; align-items: center; min-height: 195mm;">
        <div style="border: 2px solid #000; border-radius: 12px; padding: 18px 24px; width: 100%; max-width: 580px; background: #fff; direction: rtl; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.08);">
          
          <div class="ar" style="font-size: 17px; font-weight: 900; margin-bottom: 14px; letter-spacing: 0.5px; border-bottom: 1.5px solid #000; padding-bottom: 6px;">
            مستخرج من قانون الضرائب المباشرة
          </div>

          <div style="margin-bottom: 12px;">
            <div class="ar" style="font-size: 13px; font-weight: 900; margin-bottom: 4px;">المادة 227 - المقطع 2</div>
            <div class="ar" style="font-size: 11px; line-height: 1.6; text-align: justify;">
              «وعلاوة على ذلك، دون الإخلال بالغرامات المنصوص عليها فيما يلي، فإن عدم تقديم الكشف المنصوص عليه في البند الثالث من الفقرة 1 للمادة 224 يترتب عنه عدم الإستفادة من التخفيض المنصوص عليه في المادة 219.»
            </div>
          </div>

          <div style="margin-bottom: 12px;">
            <div class="ar" style="font-size: 13px; font-weight: 900; margin-bottom: 4px;">المادة 228 - الفقرة الأولى</div>
            <div class="ar" style="font-size: 11px; line-height: 1.6; text-align: justify;">
              «كل خطأ أو سهو أو بيان غير صحيح وجده في الكشف التفصيلي للعملاء المنصوص عليه في المادة 224 من قانون الضرائب المباشرة، يؤدي إلى تطبيق غرامة مالية تتراوح بين 1000 و10.000 د.ج. ويتكرر توقيع هذه الغرامة بعدد المرات التي يتكرر فيها الخطأ أو السهو، أو عدم صحة البيانات المطلوبة.»
            </div>
          </div>

          <div style="margin-bottom: 12px;">
            <div class="ar" style="font-size: 13px; font-weight: 900; margin-bottom: 4px;">الفقرة الثانية</div>
            <div class="ar" style="font-size: 11px; line-height: 1.6; text-align: justify;">
              «مع مراعاة العقوبات المنصوص عليها في المادة 303 من قانون الضرائب المباشرة، يعاقب، كل من يثبت عليه أنه إستعمل طرقا إحتيالية في الإدلاء بالمعلومات غير الصحيحة التي ذكرها في الكشف التفصيلي للعملاء، بقصد التهرب من الضريبة أو تصفيتها، بغرامة مالية تتراوح بين 5.000 و50.000 د.ج.<br/>
              وتطبق العقوبة السابقة إذا تبين أن عمليات الجملة كما هي ثابتة في الكشف التفصيلي للعملاء، تتضمن معلومات غير صحيحة من شأنها الإضرار بالرقابة على الإقرارات الضريبية المقدمة من عملائه.»
            </div>
          </div>

          <div style="border-top: 1.5px solid #000; padding-top: 10px; margin-top: 10px;">
            <div class="ar" style="font-size: 12px; font-weight: 900; line-height: 1.35; margin-bottom: 6px;">
              مستخرج من القانون رقم 01-21 المؤرخ في 22 ديسمبر 2001<br/>
              المتضمن قانون المالية لسنة 2002
            </div>
            <div class="ar" style="font-size: 11px; line-height: 1.6; text-align: justify;">
              <b>المادة 35 :</b> «دون الإخلال بالعقوبات المنصوص عليها في التشريع الجبائي المعمول به، يترتب على عدم تقديم رقم التعريف الإحصائي أو التصريح بمعلومات خاطئة تعليق :
              <div style="margin-top: 4px; padding-right: 12px;">
                — تسليم مختلف شهادات الإعفاء من الرسم على القيمة المضافة،<br/>
                — تسليم مستخرجات من جدول الضرائب،<br/>
                — التخفيضات المنصوص عليها في المادتين 219-1 و219 مكرر من قانون الضرائب المباشرة والرسوم المماثلة،<br/>
                — منح تأجيلات قانونية عن دفع الحقوق والرسوم،<br/>
                — اكتتاب استحقاقات للدفع.»
              </div>
            </div>
          </div>

          <div style="margin-top: 12px; font-size: 9px; color: #555; text-align: center; border-top: 1px dotted #ccc; padding-top: 4px;">
            Imprimerie Officielle — Série G., Modèle N° 3 (Page finale)
          </div>
        </div>
      </div>
    </div>
    """)

    html_parts.append("</body></html>")
    return "\n".join(html_parts)


def export_etat104_excel(code: str, annee: str) -> bytes:
    """Génère un classeur Excel (.xlsx) avec 2 feuilles distinctes :
    Feuille 1 : G3_Page_De_Garde (Modèle n° 3 Tête)
    Feuille 2 : G3_Bis_Intercalaires (Modèle n° 3 bis - Détails clients)
    """
    data = get_etat104_data(code, annee)
    soc = data["societe"]
    items = data["items"]
    totals = data["totals"]
    annee_val = data["annee"]

    wb = openpyxl.Workbook()

    # -------------------------------------------------------------
    # FEUILLE 1 : PAGE DE GARDE (MODÈLE N° 3 TÊTE)
    # -------------------------------------------------------------
    ws_garde = wb.active
    ws_garde.title = "Page_De_Garde_G3"
    ws_garde.views.sheetView[0].showGridLines = True

    f_title = Font(name="Arial", size=13, bold=True)
    f_sub = Font(name="Arial", size=10, bold=True)
    f_bold = Font(name="Arial", size=10, bold=True)
    f_body = Font(name="Arial", size=10)

    align_center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    align_left = Alignment(horizontal="left", vertical="center", wrap_text=True)
    align_right = Alignment(horizontal="right", vertical="center")

    thin_border = Border(
        left=Side(style="thin", color="000000"),
        right=Side(style="thin", color="000000"),
        top=Side(style="thin", color="000000"),
        bottom=Side(style="thin", color="000000"),
    )

    ws_garde.merge_cells("A1:G1")
    ws_garde["A1"] = "REPUBLIQUE ALGERIENNE DEMOCRATIQUE ET POPULAIRE — MINISTERE DES FINANCES"
    ws_garde["A1"].font = f_sub
    ws_garde["A1"].alignment = align_center

    ws_garde.merge_cells("A2:G2")
    ws_garde["A2"] = "DIRECTION GENERALE DES IMPOTS — TAXE SUR L'ACTIVITE PROFESSIONNELLE"
    ws_garde["A2"].font = f_bold
    ws_garde["A2"].alignment = align_center

    ws_garde.merge_cells("A4:G4")
    ws_garde["A4"] = f"ETAT DETAILLE DES CLIENTS (VENTES EN GROS) — SERIE G., MODELE N° 3 (TÊTE) — EXERCICE : {annee_val}"
    ws_garde["A4"].font = f_title
    ws_garde["A4"].alignment = align_center

    # Société
    ws_garde["A6"] = "Raison Sociale :"
    ws_garde["A6"].font = f_bold
    ws_garde["B6"] = soc["rs"]
    ws_garde["B6"].font = f_bold

    ws_garde["E6"] = "NIF (Identifiant Fiscal) :"
    ws_garde["E6"].font = f_bold
    ws_garde["F6"] = soc["nif"]
    ws_garde["F6"].font = f_bold

    ws_garde["A7"] = "Activité :"
    ws_garde["B7"] = soc["activite"]
    ws_garde["E7"] = "Article Imposition (AI) :"
    ws_garde["F7"] = soc["ai"]

    ws_garde["A8"] = "Adresse Siège :"
    ws_garde["B8"] = soc["adresse"]
    ws_garde["E8"] = "Registre Commerce (RC) :"
    ws_garde["F8"] = soc["rcom"]

    ws_garde["A9"] = "Wilaya / Commune :"
    ws_garde["B9"] = f"{soc['wilaya']} / {soc['commune']}"
    ws_garde["E9"] = "Inspection :"
    ws_garde["F9"] = soc["inspection"]

    # Arrêté
    nb_inter = max(1, math.ceil(len(items) / 20))
    ws_garde.merge_cells("A12:G12")
    ws_garde["A12"] = f"Arrêté le présent état contenant {nb_inter} page(s) d'intercalaires numérotée(s) de 1 à {nb_inter} à la somme de :"
    ws_garde["A12"].font = f_sub

    ws_garde["A13"] = "Total Ventes HT :"
    ws_garde["A13"].font = f_bold
    ws_garde["B13"] = totals["total_ht"]
    ws_garde["B13"].font = f_bold
    ws_garde["B13"].number_format = "#,##0.00"

    ws_garde["D13"] = "Total TVA Collectée :"
    ws_garde["D13"].font = f_bold
    ws_garde["E13"] = totals["total_tva"]
    ws_garde["E13"].font = f_bold
    ws_garde["E13"].number_format = "#,##0.00"

    ws_garde["A14"] = "Montant HT en lettres :"
    ws_garde["B14"] = nombre_en_lettres_fr(totals["total_ht"])
    ws_garde["B14"].font = Font(name="Arial", size=9, italic=True)

    ws_garde["A15"] = "المبلغ بالحروف العربية :"
    ws_garde["B15"] = nombre_en_lettres_ar(totals["total_ht"])
    ws_garde["B15"].font = Font(name="Arial", size=10, bold=True)

    ws_garde.column_dimensions["A"].width = 22
    ws_garde.column_dimensions["B"].width = 38
    ws_garde.column_dimensions["C"].width = 15
    ws_garde.column_dimensions["D"].width = 22
    ws_garde.column_dimensions["E"].width = 25
    ws_garde.column_dimensions["F"].width = 25
    ws_garde.column_dimensions["G"].width = 15

    # -------------------------------------------------------------
    # FEUILLE 2 : TABLEAU DES INTERCALAIRES (MODÈLE N° 3 BIS)
    # -------------------------------------------------------------
    ws_details = wb.create_sheet(title="G3_Bis_Intercalaires")
    ws_details.views.sheetView[0].showGridLines = True

    ws_details.merge_cells("A1:G1")
    ws_details["A1"] = f"SERIE G., N° 3 BIS (INTERCALAIRES) — DETAIL DES CLIENTS (VENTES EN GROS) — EXERCICE : {annee_val}"
    ws_details["A1"].font = f_sub
    ws_details["A1"].alignment = align_center

    headers = [
        ("N°", 6),
        ("DESIGNATION EXACTE DU CLIENT\n(Nom, Raison Sociale et Adresse)", 36),
        ("Numéro du RC\n(Registre Commerce)", 16),
        ("Article d'Imposition\n(AI du Client)", 16),
        ("Identifiant Fiscal\n(NIF du Client)", 18),
        ("Montant Annuel des\nOpérations HT (DA)", 20),
        ("Montant de la TVA\nFacturée (DA)", 18),
    ]

    fill_header = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")
    f_header = Font(name="Arial", size=9, bold=True)

    for col_idx, (h_text, width) in enumerate(headers, start=1):
        cell = ws_details.cell(row=3, column=col_idx, value=h_text)
        cell.font = f_header
        cell.alignment = align_center
        cell.fill = fill_header
        cell.border = thin_border
        col_letter = get_column_letter(col_idx)
        ws_details.column_dimensions[col_letter].width = width

    ws_details.row_dimensions[3].height = 28

    row_idx = 4
    for it in items:
        ws_details.cell(row=row_idx, column=1, value=it["num_ordre"]).alignment = align_center
        c_design = ws_details.cell(row=row_idx, column=2, value=f"{it['client_nom']}\n{it['client_adresse']}")
        c_design.alignment = align_left

        c_rc = ws_details.cell(row=row_idx, column=3, value=it["client_rcom"])
        c_rc.alignment = align_center
        c_rc.number_format = "@"

        c_ai = ws_details.cell(row=row_idx, column=4, value=it["client_ai"])
        c_ai.alignment = align_center
        c_ai.number_format = "@"

        c_nif = ws_details.cell(row=row_idx, column=5, value=it["client_nif"])
        c_nif.alignment = align_center
        c_nif.number_format = "@"

        c_ht = ws_details.cell(row=row_idx, column=6, value=it["total_ht"])
        c_ht.alignment = align_right
        c_ht.number_format = "#,##0.00"

        c_tva = ws_details.cell(row=row_idx, column=7, value=it["total_tva"])
        c_tva.alignment = align_right
        c_tva.number_format = "#,##0.00"

        for col_idx in range(1, 8):
            ws_details.cell(row=row_idx, column=col_idx).border = thin_border
            ws_details.cell(row=row_idx, column=col_idx).font = Font(name="Arial", size=9)

        row_idx += 1

    # Totaux
    ws_details.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=5)
    tot_cell = ws_details.cell(row=row_idx, column=1, value="TOTAL GENERAL DE L'EXERCICE / المجموع العام السنوي")
    tot_cell.font = f_bold
    tot_cell.alignment = Alignment(horizontal="right", vertical="center")
    tot_cell.fill = PatternFill(start_color="E6E6E6", end_color="E6E6E6", fill_type="solid")

    tot_ht_cell = ws_details.cell(row=row_idx, column=6, value=totals["total_ht"])
    tot_ht_cell.font = f_bold
    tot_ht_cell.alignment = align_right
    tot_ht_cell.number_format = "#,##0.00"
    tot_ht_cell.fill = PatternFill(start_color="E6E6E6", end_color="E6E6E6", fill_type="solid")

    tot_tva_cell = ws_details.cell(row=row_idx, column=7, value=totals["total_tva"])
    tot_tva_cell.font = f_bold
    tot_tva_cell.alignment = align_right
    tot_tva_cell.number_format = "#,##0.00"
    tot_tva_cell.fill = PatternFill(start_color="E6E6E6", end_color="E6E6E6", fill_type="solid")

    double_bottom = Border(
        left=Side(style="thin", color="000000"),
        right=Side(style="thin", color="000000"),
        top=Side(style="thin", color="000000"),
        bottom=Side(style="double", color="000000"),
    )
    for col_idx in range(1, 8):
        ws_details.cell(row=row_idx, column=col_idx).border = double_bottom

    stream = io.BytesIO()
    wb.save(stream)
    return stream.getvalue()
