"""Reçus d'honoraires — mise en page HTML haute fidélité (modèle officiel A4) pour affichage et impression / export PDF.

Structure :
1. En-tête : données du cabinet d'expertise comptable en haut
2. Sous les données du cabinet : Titre officiel centré « وصل استلام أتعاب », numéro de reçu et date
3. Boîte d'identification du client (SARL, NIF, RC, Activité, Adresse)
4. Attestation directe d'encaissement
5. Boîte du montant en chiffres (« 30.000,00 دج ») et en lettres (Tafqeet arabe sans « لا غير », et français)
6. Détails de l'imputation (tranche, exercice, mode de règlement, référence, quittance)
7. Lieu et date de délivrance, signatures et cachets officiels
"""
from __future__ import annotations

import base64
from html import escape
from pathlib import Path

from fastapi import HTTPException

from . import honoraires

FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def _font_face() -> str:
    faces = []
    for f, rng in (
        ("cairo-arabic-wght-normal.woff2", "U+0600-06FF,U+0750-077F,U+0870-08FF,U+FB50-FDFF,U+FE70-FEFF"),
        ("cairo-latin-wght-normal.woff2", "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+2000-206F,U+20AC"),
    ):
        p = FONTS / f
        if p.is_file():
            b64 = base64.b64encode(p.read_bytes()).decode()
            faces.append(
                f"@font-face{{font-family:'Cairo';font-weight:200 1000;src:url(data:font/woff2;base64,{b64}) format('woff2');unicode-range:{rng};}}"
            )
    return "".join(faces)


CSS = """@page{size:A4 portrait;margin:10mm 12mm}*{box-sizing:border-box}
body{margin:0;font-family:'Cairo','Segoe UI',Tahoma,Arial,sans-serif;color:#15140F;font-size:13px;line-height:1.6;background:#fff}
.doc{max-width:800px;margin:0 auto;padding:6px 10px}
.cab-header{text-align:center;border-bottom:2px solid #006233;padding-bottom:12px;margin-bottom:14px}
.cab-name{font-size:18px;font-weight:900;color:#0f172a;letter-spacing:-0.01em}
.cab-sub{font-size:12px;color:#475569;line-height:1.6;margin-top:4px}
.recu-title-box{text-align:center;border:1.5px solid #2B2A27;border-radius:6px;background:#FAF9F5;padding:12px 14px;margin-bottom:14px}
.recu-title{font-size:22px;font-weight:900;color:#006233;margin:0 0 2px;text-decoration:underline}
.recu-title-fr{font-size:10.5px;font-weight:700;color:#006233;letter-spacing:0.08em;font-family:'Inter',sans-serif;margin-bottom:6px}
.recu-meta{display:flex;justify-content:center;align-items:center;gap:18px;font-size:13px;color:#334155}
.recu-meta b{color:#0f172a;font-family:'Cairo','Inter',monospace}
.client-box{border:1.5px solid #2B2A27;border-radius:6px;padding:10px 14px;background:#FAF9F5;margin-bottom:12px;display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;font-size:12.5px;line-height:1.5}
.cl-lbl{font-weight:800;color:#006233}
.attest-text{font-size:13px;font-weight:700;color:#1e293b;margin:12px 0 8px}
.montant-box{background:#FAFDF7;border:2px dashed #006233;border-radius:8px;padding:10px 16px;margin:10px 0 14px;display:flex;align-items:center;justify-content:space-between;gap:14px}
.tafqeet-col{display:flex;flex-direction:column;gap:3px;flex:1}
.tafqeet-badge{display:inline-block;font-size:10.5px;font-weight:800;color:#047857;background:#d1fae5;padding:2px 7px;border-radius:4px;width:fit-content}
.tafqeet-ar{font-size:13.5px;font-weight:800;color:#15140F;line-height:1.5;margin-top:2px}
.tafqeet-fr{font-size:11px;color:#475569;font-style:italic;direction:ltr;text-align:start;font-family:'Inter',sans-serif}
.montant-digits{display:flex;align-items:baseline;gap:6px;font-size:24px;font-weight:900;color:#006233;white-space:nowrap}
.m-val{font-family:'Cairo','Inter',monospace;direction:ltr}
.m-cur{font-size:16px;font-weight:800}
.details-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:10px 14px;margin-bottom:12px;font-size:12.5px;display:flex;flex-direction:column;gap:7px}
.detail-row{display:flex;align-items:baseline;gap:8px;line-height:1.5}
.d-lbl{font-weight:800;color:#334155;min-width:140px}
.d-val{color:#0f172a;flex:1}
.tag-paid{color:#065f46;font-weight:800}
.tag-partial{color:#b45309;font-weight:800}
.closing{font-style:italic;font-size:11.5px;color:#475569;text-align:center;margin:12px 0;background:#f1f5f9;padding:6px 10px;border-radius:4px}
.signs{width:100%;margin-top:16px;border-collapse:separate;border-spacing:18px 0;break-inside:avoid}
.sbox{width:50%;text-align:center;vertical-align:top;border:1.5px solid #15140F;border-radius:6px;padding:10px 12px;height:105px;background:#fff}
.sbox b{font-size:12.5px;color:#15140F}
.sbox small{color:#64748b;font-size:11px}
.stamp-space{margin-top:36px;color:#94a3b8;font-size:10.5px;border-top:1px dashed #cbd5e1;padding-top:4px}
.footer{margin-top:14px;padding-top:6px;border-top:1px solid #cbd5e1;display:flex;justify-content:space-between;font-size:9.5px;color:#94a3b8}
@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}"""


def fmt_da_num(val: float | int) -> str:
    parts = f"{abs(float(val)):.2f}".split(".")
    int_p = ""
    s = parts[0]
    while len(s) > 3:
        int_p = "." + s[-3:] + int_p
        s = s[:-3]
    int_p = s + int_p
    return f"{'-' if val < 0 else ''}{int_p},{parts[1]}"


def render(code: str, params: dict) -> tuple[str, str]:
    """Génère le document HTML officiel du reçu de paiement d'honoraires."""
    ech_id = int(params.get("id") or 0)
    data = honoraires.get_recu_paiement(code, ech_id)

    cab = data["cabinet"]
    cli = data["client"]
    ech = data["echeance"]
    recu_num = escape(str(data["recu_num"]))
    date_recu = escape(str(data["date_recu"]))

    nom_cab = escape(str(cab.get("nom_cabinet") or "مكتب المحاسبة ومحافظة الحسابات"))
    expert = escape(str(cab.get("expert_comptable") or "الخبير المحاسبي المعتمد"))
    titre = escape(str(cab.get("titre") or "محاسب معتمد"))
    agrement = escape(str(cab.get("agrement") or ""))
    adresse = escape(str(cab.get("adresse") or ""))
    ville = escape(str(cab.get("ville") or ""))
    tel = escape(str(cab.get("telephone") or ""))

    cab_sub_parts = [f"<b>{expert}</b> — {titre}"]
    if agrement:
        cab_sub_parts.append(f" · رقم الاعتماد: <b>{agrement}</b>")
    sub_line1 = "".join(cab_sub_parts)

    sub_line2_parts = []
    if adresse or ville:
        sub_line2_parts.append(f"{adresse} {ville}".strip())
    if tel:
        sub_line2_parts.append(f" · هاتف: <span dir='ltr'>{tel}</span>")
    sub_line2 = "".join(sub_line2_parts)
    cab_sub_html = f"{sub_line1}<br>{sub_line2}" if sub_line2 else sub_line1

    cli_rs = escape(str(cli.get("rs") or f"Société {code}"))
    cli_fj = escape(str(cli.get("fj") or ""))
    cli_code = escape(str(cli.get("code") or code))
    cli_act = escape(str(cli.get("activite") or "—"))
    cli_nif = escape(str(cli.get("nif") or "—"))
    cli_rc = escape(str(cli.get("rc") or ""))
    cli_adr = escape(str(cli.get("adresse") or ""))

    client_rc_html = f"<div><span class='cl-lbl'>السجل التجاري (RC):</span> <b dir='ltr'>{cli_rc}</b></div>" if cli_rc else ""
    client_adr_html = f"<div><span class='cl-lbl'>المقر الاجتماعي:</span> <span>{cli_adr}</span></div>" if cli_adr else ""

    montant_regle = ech.get("montant_regle") or 0.0
    reste = ech.get("reste_a_payer") or 0.0
    montant_digits_str = fmt_da_num(montant_regle)
    montant_ar = escape(str(data.get("montant_en_lettres_ar") or "")).replace("فقط", "").replace("لا غير", "").strip()
    montant_fr = escape(str(data.get("montant_en_lettres_fr") or ""))

    lib_ech = escape(str(ech.get("libelle") or ""))
    ex_ech = escape(str(ech.get("exercice") or ""))
    mode_reg = ech.get("mode_reglement") or "especes"
    mode_str = (
        "نقداً بصندوق المكتب (Espèces)"
        if mode_reg == "especes"
        else "شيك بنكي تجاري (Chèque bancaire)"
        if mode_reg == "cheque"
        else "تحويل مصرفي (Virement bancaire)"
        if mode_reg == "virement"
        else "وسيلة تسديد أخرى"
    )
    ref_piece = escape(str(ech.get("ref_piece") or ""))
    ref_html = f" — المرجع / رقم السند: <b>{ref_piece}</b>" if ref_piece else ""

    if reste <= 0:
        status_html = "<span class='tag-paid'>✓ تم تسديد وإبراء ذمة هذا القسط بالكامل (Quittance de règlement intégral).</span>"
    else:
        status_html = f"<span class='tag-partial'>⚡ تسديد جزئي — الرصيد المتبقي على هذا القسط: <b>{fmt_da_num(reste)} دج</b></span>"

    obs = escape(str(ech.get("observations") or ""))
    obs_html = f"<div class='detail-row'><span class='d-lbl'>ملاحظات:</span><span class='d-val'>{obs}</span></div>" if obs else ""

    doc_title = f"{recu_num} — {cli_rs}"

    html_out = f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>{doc_title}</title>
<style>
{_font_face()}
{CSS}
</style>
</head>
<body>
<div class="doc">
  <!-- 1. En-tête : Données du Cabinet en premier (en haut) -->
  <div class="cab-header">
    <div>
      <div class="cab-name">{nom_cab}</div>
      <div class="cab-sub">{cab_sub_html}</div>
    </div>
  </div>

  <!-- 2. Sous les données du cabinet : Titre officiel centré et métadonnées du reçu -->
  <div class="recu-title-box">
    <h1 class="recu-title">وصل استلام أتعاب</h1>
    <div class="recu-title-fr">REÇU DE RÈGLEMENT D'HONORAIRES</div>
    <div class="recu-meta">
      <span>رقم الوصل: <b>{recu_num}</b></span>
      <span>•</span>
      <span>تاريخ التحرير: <b>{date_recu}</b></span>
    </div>
  </div>

  <!-- 3. Boîte d'identification du client -->
  <div class="client-box">
    <div><span class="cl-lbl">المؤسسة / العميل:</span> <b>{cli_rs}</b> {f"({cli_fj})" if cli_fj else ""}</div>
    <div><span class="cl-lbl">النشاط التجاري / المهني:</span> <span>{cli_act}</span></div>
    <div><span class="cl-lbl">رقم التعريف الجبائي (NIF):</span> <b dir="ltr">{cli_nif}</b></div>
    {client_rc_html}
    {client_adr_html}
  </div>

  <!-- 4. Phrase d'attestation directe -->
  <div class="attest-text">
    يشهد مكتب المحاسبة المذكور أعلاه بأنه استلم من المؤسسة الموكلة مبلغاً مالياً قدره:
  </div>

  <!-- 5. Boîte du montant et Tafqeet (Arabe sans 'لا غير' + Français) -->
  <div class="montant-box">
    <div class="tafqeet-col">
      <div class="tafqeet-badge">المبلغ الصافي المقبوض / Montant Encaissé</div>
      <div class="tafqeet-ar">{montant_ar}</div>
      <div class="tafqeet-fr">Arrêté la présente quittance à la somme de: <i>{montant_fr}</i></div>
    </div>
    <!-- Affichage corrigé : 30.000,00 دج (الرقم ثم دج) -->
    <div class="montant-digits">
      <span class="m-val" dir="ltr">{montant_digits_str}</span>
      <span class="m-cur">دج</span>
    </div>
  </div>

  <!-- 6. Détails de l'imputation et de la quittance -->
  <div class="details-box">
    <div class="detail-row">
      <span class="d-lbl">وذلك بعنوان / مقابل:</span>
      <span class="d-val"><b>{lib_ech}</b> (المتعلق بالتمرين المحاسبي والجبائي لسنة <b>{ex_ech}</b>)</span>
    </div>
    <div class="detail-row">
      <span class="d-lbl">طريقة وسند التسديد:</span>
      <span class="d-val"><b>{mode_str}</b>{ref_html}</span>
    </div>
    <div class="detail-row">
      <span class="d-lbl">الوضعية المالية للمخالصة:</span>
      <span class="d-val">{status_html}</span>
    </div>
    {obs_html}
  </div>

  <!-- 7. Formule de clôture -->
  <div class="closing">
    حرر هذا الوصل بـ: <b>{ville or 'الجزائر'}</b> بتاريخ: <b>{date_recu}</b> كوثيقة إثبات استلام ومخالصة مالية رسمية.
  </div>

  <!-- 8. Signatures officielles -->
  <table class="signs">
    <tr>
      <td class="sbox">
        <b>عن مكتب الخبير المحاسبي (الطرف المستلم)</b><br>
        <small>الختم الرسمي والتوقيع</small>
        <div class="stamp-space">مكان الختم والإمضاء</div>
      </td>
      <td class="sbox">
        <b>عن المؤسسة الموكلة (الطرف المسدد)</b><br>
        <small>توقيع ومصادقة المسير</small>
        <div class="stamp-space">توقيع المسير</div>
      </td>
    </tr>
  </table>

  <!-- 9. Pied de page -->
  <div class="footer">
    <span>وثيقة محاسبية وجبائية رسمية صالحة للإثبات المالي والمحاسبي</span>
    <span>•</span>
    <span>النظام المحاسبي والجبائي Dec2026</span>
  </div>
</div>
</body>
</html>"""
    return html_out, doc_title
