"""IRG (personnes physiques) — acomptes and solde de liquidation.

Delphi: uMain page 7, Unit8 (acomptes, table IRGAcomptes), Unit9 (solde, table IRGsolde),
report RIrg (dataset RecapIrg).

Rules (Unit9):
  * IRG = Irg2022(résultat taxable): progressive scale 0 / 23 / 27 / 30 / 33 / 35 %.
  * Deductions = 1er acompte + 2ème acompte (from IRGAcomptes) + acomptes versés + crédit d'impôt.
  * IRG > deductions → solde de liquidation, otherwise excédent de versement.
Logical additions: the computed IRG is stored in `droits` (printed by RIrg), and a solde can
be created (Delphi's « Ajouter » only edited an existing record).
"""
from __future__ import annotations

import sqlite3

from fastapi import HTTPException

from ..core.db import connect
from .g50 import Conflict, G50Error, _client, _next_id, _num

ACOMPTES = [("E3L20", "1er acompte"), ("E3L30", "2éme acompte")]
ALIASES = {"E3L20": ("1er acompte",), "E3L30": ("2éme acompte", "2eme acompte")}

# Unit9.Irg2022: (lower bound, rate %, cumulated tax at the lower bound)
SCALE = [(240000, 23, 0), (480000, 27, 55200), (960000, 30, 184800), (1920000, 33, 472800), (3840000, 35, 1106400)]


def irg2022(base: float) -> float:
    tax = 0.0
    for low, rate, cum in SCALE:
        if base >= low:
            tax = (base - low) * rate / 100 + cum
    return tax


def _code_of(row: dict) -> str | None:
    imp, code = str(row.get("impots") or "").strip().lower(), str(row.get("code") or "").strip().upper()
    for c, names in ALIASES.items():
        if code == c or imp in names:
            return c
    return None


def acomptes(c: sqlite3.Connection, exercice: str) -> list[dict]:
    rows = [dict(r) for r in c.execute('SELECT * FROM IRGAcomptes WHERE CAST("Exercice" AS TEXT) = ? ORDER BY code, "ID"', (str(exercice),))]
    for r in rows:
        r["_id"], r["_code"] = r["ID"], _code_of(r)
    return rows


def save_acompte(code: str, exercice: str, data: dict, acompte_id: int | None = None) -> dict:
    acode = str(data.get("code") or "").strip().upper()
    label = dict(ACOMPTES).get(acode)
    if not label:
        raise G50Error("Sélectionnez l’acompte (1er ou 2ème)")
    base, taux = _num(data.get("Revenusimposables")), _num(data.get("taux"))
    droits = _num(data.get("droits")) if data.get("droits") not in (None, "") else base * taux / 100
    with connect(code) as c:
        if any(r["_code"] == acode and r["ID"] != acompte_id for r in acomptes(c, exercice)):
            raise Conflict(f"Le {label} existe déjà pour l’exercice {exercice}")
        idc = str(_client(c).get("IDclients") or "")
        values = {"code": acode, "impots": label, "Revenusimposables": round(base), "taux": taux, "droits": round(droits),
                  "Exercice": str(exercice), "IDclients": idc, "ClientExercice": f"{idc} {exercice}",
                  "codeacompte": f"{idc} {acode} {exercice}", "refacompte": label.split()[0]}
        if acompte_id is None:
            values.update({"ID": _next_id(c, "IRGAcomptes", "ID"), "Idg50": 0})
            c.execute(f'INSERT INTO IRGAcomptes ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE IRGAcomptes SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} WHERE "ID" = ?',
                           (*values.values(), acompte_id)).rowcount:
            raise HTTPException(404, "Acompte introuvable")
        _sync(c, exercice)
    return state(code, exercice)


def delete_acompte(code: str, exercice: str, acompte_id: int) -> dict:
    with connect(code) as c:
        if not c.execute('DELETE FROM IRGAcomptes WHERE "ID" = ?', (acompte_id,)).rowcount:
            raise HTTPException(404, "Acompte introuvable")
        _sync(c, exercice)
    return state(code, exercice)


def _row(c: sqlite3.Connection, exercice: str) -> dict | None:
    r = c.execute('SELECT * FROM IRGsolde WHERE CAST("Exercice" AS TEXT) = ? ORDER BY "IDIRGsolde" LIMIT 1', (str(exercice),)).fetchone()
    return dict(r) if r else None


def _defaults(c: sqlite3.Connection, exercice: str) -> dict:
    acs = {r["_code"]: _num(r["droits"]) for r in acomptes(c, exercice)}
    return {"Acompte1": acs.get("E3L20", 0.0), "Acompte2": acs.get("E3L30", 0.0)}


INPUTS = ("Résultat_taxable", "Acompte1", "Acompte2", "Acomptes_versés", "Credit_impôt", "ilm")


def _write(c: sqlite3.Connection, exercice: str, v: dict, row_id: int | None) -> None:
    out = {k: (round(_num(v[k])) if v.get(k) not in (None, "") else None) for k in INPUTS}
    droits = irg2022(_num(v.get("Résultat_taxable")))
    ded = sum(_num(out.get(k)) for k in ("Acompte1", "Acompte2", "Acomptes_versés", "Credit_impôt"))
    idc = str(_client(c).get("IDclients") or "")
    out.update({"droits": round(droits), "Montantglobaldéduire": round(ded), "Exercice": int(exercice),
                "Soldedeliquidation": round(droits - ded) if droits > ded else None,
                "Excédentversement": None if droits > ded else round(ded - droits),
                "Codeacompte1": f"{idc} E3L20 {exercice}", "Codeacompte2": f"{idc} E3L30 {exercice}"})
    if row_id is None:
        out["IDIRGsolde"] = _next_id(c, "IRGsolde", "IDIRGsolde")
        c.execute(f'INSERT INTO IRGsolde ({", ".join(chr(34) + k + chr(34) for k in out)}) VALUES ({", ".join("?" for _ in out)})', tuple(out.values()))
    else:
        c.execute(f'UPDATE IRGsolde SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in out)} WHERE "IDIRGsolde" = ?', (*out.values(), row_id))


def _sync(c: sqlite3.Connection, exercice: str) -> None:
    row = _row(c, exercice)
    if row is not None:
        row.update(_defaults(c, exercice))
        _write(c, exercice, row, row["IDIRGsolde"])


def save_solde(code: str, exercice: str, data: dict) -> dict:
    with connect(code) as c:
        row = _row(c, exercice)
        values = dict(row or _defaults(c, exercice))
        values.update({k: data[k] for k in INPUTS if k in data})
        _write(c, exercice, values, row["IDIRGsolde"] if row else None)
    return state(code, exercice)


def refresh_solde(code: str, exercice: str) -> dict:
    """Unit9.Button1Click: acomptes of the exercice."""
    with connect(code) as c:
        row = _row(c, exercice)
        values = dict(row or {})
        values.update(_defaults(c, exercice))
        _write(c, exercice, values, row["IDIRGsolde"] if row else None)
    return state(code, exercice)


def delete_solde(code: str, exercice: str) -> dict:
    with connect(code) as c:
        if not c.execute('DELETE FROM IRGsolde WHERE CAST("Exercice" AS TEXT) = ?', (str(exercice),)).rowcount:
            raise HTTPException(404, "Aucun solde IRG à supprimer")
    return state(code, exercice)


def state(code: str, exercice: str) -> dict:
    with connect(code) as c:
        return {"exercice": str(exercice), "acomptes": acomptes(c, exercice), "solde": _row(c, exercice),
                "defaults": _defaults(c, exercice), "acompte_types": [{"code": c, "label": l} for c, l in ACOMPTES],
                "scale": [{"from": low, "rate": rate} for low, rate, _ in SCALE]}
