"""Gestion des modèles de factures récurrentes (loyers, abonnements, maintenance, honoraires).
Permet la génération sélective en 1 clic pour un mois donné avec vérification anti-doublon.
"""
from __future__ import annotations

import sqlite3
from typing import Any

from fastapi import HTTPException

from ..core.db import connect
from . import dates, ref, ventes
from .g50 import G50Error, _num

DEFAULT_TEMPLATES = [
    {
        "titre": "عقد كراء المقر الإداري / التجاري (Loyer Commercial)",
        "ClientsVente": "BAILLEUR / PROPRIETAIRE DU LOCAL",
        "ht": 45000.0,
        "TauxTva": 0,
        "periodicite": "mensuelle",
        "notes": "Loyer mensuel non assujetti ou prestation sous bail",
    },
    {
        "titre": "عقد الصيانة والدعم المعلوماتي (Maintenance Informatique)",
        "ClientsVente": "CLIENT MAINTENANCE IT",
        "ht": 25000.0,
        "TauxTva": 19,
        "periodicite": "mensuelle",
        "notes": "Maintenance réseau, matériel et logiciels de gestion",
    },
    {
        "titre": "أتعاب المتابعة المحاسبية والجبائية (Honoraires Comptables)",
        "ClientsVente": "CLIENT SUIVI COMPTABLE",
        "ht": 35000.0,
        "TauxTva": 19,
        "periodicite": "mensuelle",
        "notes": "Prestations de tenue et déclarations G50 mensuelles",
    },
    {
        "titre": "خدمات الحراسة والأمن والنظافة (Sécurité & Nettoyage)",
        "ClientsVente": "CLIENT GARDIENNAGE",
        "ht": 30000.0,
        "TauxTva": 19,
        "periodicite": "mensuelle",
        "notes": "Prestations mensuelles de surveillance et d'entretien",
    },
]


def _init_table(c: sqlite3.Connection) -> None:
    c.execute("""
        CREATE TABLE IF NOT EXISTS FacturesRecurrentes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titre TEXT NOT NULL,
            IDClentventes INTEGER,
            ClientsVente TEXT NOT NULL,
            ht REAL NOT NULL DEFAULT 0.0,
            TauxTva INTEGER NOT NULL DEFAULT 19,
            periodicite TEXT NOT NULL DEFAULT 'mensuelle',
            actif INTEGER NOT NULL DEFAULT 1,
            notes TEXT DEFAULT ''
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS FacturesRecurrentesMeta (
            cle TEXT PRIMARY KEY,
            valeur TEXT
        )
    """)
    # Ne charger les modèles par défaut qu'une seule et unique fois lors de l'initialisation
    seeded = c.execute("SELECT valeur FROM FacturesRecurrentesMeta WHERE cle = 'seeded'").fetchone()
    if not seeded:
        for t in DEFAULT_TEMPLATES:
            c.execute("""
                INSERT INTO FacturesRecurrentes (titre, ClientsVente, ht, TauxTva, periodicite, actif, notes)
                VALUES (?, ?, ?, ?, ?, 1, ?)
            """, (t["titre"], t["ClientsVente"], t["ht"], t["TauxTva"], t["periodicite"], t["notes"]))
        c.execute("INSERT OR REPLACE INTO FacturesRecurrentesMeta (cle, valeur) VALUES ('seeded', '1')")


def list_modeles(code: str) -> list[dict[str, Any]]:
    with connect(code) as c:
        _init_table(c)
        rows = [dict(r) for r in c.execute("SELECT * FROM FacturesRecurrentes ORDER BY id ASC").fetchall()]
    return rows


def save_modele(code: str, data: dict[str, Any], item_id: int | None = None) -> dict[str, Any]:
    titre = str(data.get("titre") or "").strip()
    client = str(data.get("ClientsVente") or "").strip()
    if not titre:
        raise G50Error("Veuillez saisir un intitulé pour le modèle")
    if not client:
        raise G50Error("Veuillez saisir ou sélectionner le client")

    ht = _num(data.get("ht"))
    taux = int(_num(data.get("TauxTva") if data.get("TauxTva") not in (None, "") else 19))
    periodicite = str(data.get("periodicite") or "mensuelle").strip()
    actif = 1 if data.get("actif", True) else 0
    id_client = data.get("IDClentventes") or None
    notes = str(data.get("notes") or "").strip()

    if item_id is None and data.get("id"):
        try:
            item_id = int(data["id"])
        except (ValueError, TypeError):
            pass

    with connect(code) as c:
        _init_table(c)
        if item_id is None:
            cur = c.execute("""
                INSERT INTO FacturesRecurrentes (titre, IDClentventes, ClientsVente, ht, TauxTva, periodicite, actif, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (titre, id_client, client, ht, taux, periodicite, actif, notes))
            item_id = cur.lastrowid
        else:
            c.execute("""
                UPDATE FacturesRecurrentes
                SET titre = ?, IDClentventes = ?, ClientsVente = ?, ht = ?, TauxTva = ?, periodicite = ?, actif = ?, notes = ?
                WHERE id = ?
            """, (titre, id_client, client, ht, taux, periodicite, actif, notes, int(item_id)))

    return {"id": item_id, "titre": titre, "ClientsVente": client, "ht": ht, "TauxTva": taux}


def delete_modele(code: str, item_id: int) -> None:
    with connect(code) as c:
        _init_table(c)
        c.execute("DELETE FROM FacturesRecurrentes WHERE id = ?", (int(item_id),))


def generer_factures(code: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Génère les factures pour les modèles sélectionnés pour le mois indiqué."""
    annee = str(payload.get("annee") or "").strip()
    mois = str(payload.get("mois") or "").strip()
    date_f = str(payload.get("date_facture") or "").strip()
    modele_ids = [int(i) for i in payload.get("modele_ids") or []]
    prefix = str(payload.get("prefix") or "F").strip()

    if not annee or not mois or not date_f:
        raise G50Error("Année, mois et date de facture sont obligatoires")
    if not modele_ids:
        raise G50Error("Veuillez sélectionner au moins un modèle à générer")

    created = []
    skipped = []

    with connect(code) as c:
        _init_table(c)
        # Trouver le numéro séquentiel actuel pour cet exercice
        existing_nums = [r[0] for r in c.execute(
            'SELECT nfacture FROM FacturesVentes WHERE "Année" = ? OR substr(datrfature, 1, 4) = ?',
            (annee, annee)
        ).fetchall()]

    # Calculer le prochain numéro séquentiel
    max_seq = 0
    for num_str in existing_nums:
        digits = "".join(ch for ch in str(num_str) if ch.isdigit())
        if digits:
            try:
                v = int(digits)
                if v > max_seq:
                    max_seq = v
            except ValueError:
                pass

    current_seq = max_seq

    # Récupérer les modèles
    all_modeles = list_modeles(code)
    selected = [m for m in all_modeles if m["id"] in modele_ids and m["actif"]]

    for mod in selected:
        current_seq += 1
        num_facture = f"{prefix}{annee[-2:]}-{current_seq:03d}"

        body = {
            "nfacture": num_facture,
            "datrfature": date_f,
            "ClientsVente": mod["ClientsVente"],
            "IDClentventes": mod["IDClentventes"],
            "ht": mod["ht"],
            "TauxTva": mod["TauxTva"],
            "leMois": mois,
            "Année": annee,
        }

        try:
            res = ventes.save(code, body)
            created.append({
                "modele": mod["titre"],
                "nfacture": num_facture,
                "client": mod["ClientsVente"],
                "ht": mod["ht"],
                "id": res.get("id"),
            })
        except Exception as e:
            skipped.append({
                "modele": mod["titre"],
                "client": mod["ClientsVente"],
                "raison": str(e),
            })

    return {
        "success": True,
        "nb_crees": len(created),
        "nb_ignores": len(skipped),
        "factures_creees": created,
        "factures_ignorees": skipped,
    }
