# Inventaire des actions Delphi (généré)

### uBatchGen — Génération Automatique des Dossiers

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnBrowseWinDev` | TButton | Parcourir... | btnBrowseWinDevClick |
| `btnDirectImport` | TButton | Étape 1 : Importer toutes les tables Win | btnDirectImportClick |
| `btnConnect` | TButton | Vérifier DB\G50.mdb | btnConnectClick |
| `btnBatchImport` | TButton | Étape 2 : Démarrer la Génération des Dos | btnBatchImportClick |
| `btnClose` | TButton | Fermer | btnCloseClick |

### uBeneficiaireEffectif — إستمارتين المستفيد الحقيقي (Bénéficiaire Effectif CNRC)

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnNew` | TButton | جديد (Nouveau) | btnNewClick |
| `btnEdit` | TButton | تعديل (Modifier) | btnEditClick |
| `btnSave` | TButton | حفظ (Sauver) | btnSaveClick |
| `btnDelete` | TButton | حذف (Suppr) | btnDeleteClick |
| `btnSetDefault` | TButton | حفظ كقالب افتراضي | btnSetDefaultClick |
| `btnApplyDefault` | TButton | توليد من القالب الافتراضي | btnApplyDefaultClick |
| `btnPrint4Pages` | TButton | طباعة الوتيقة كاملة (4 صفحات) | btnPrint4PagesClick |
| `btnExportPDF` | TButton | تصدير PDF | btnExportPDFClick |
| `btnClose` | TButton | خروج (Fermer) | btnCloseClick |
| `rbEstDansRC_Oui` | TRadioButton | نعم (OUI) | rbEstDansRCClick |
| `rbEstDansRC_Non` | TRadioButton | لا (NON) | rbEstDansRCClick |
| `chkCritere1` | TCheckBox | (1) حياذة حصة ملكية مسيطرة فعلياً بطريقة | chkCritere1Click |

### uContrats — منظومة عقود العمل (الأصناف السبعة المعتمدة) - Gestion des Contrats

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnNew` | TButton | ➕ عقد جديد | btnNewClick |
| `btnEdit` | TButton | ✏️ تعديل | btnEditClick |
| `btnDelete` | TButton | ️ حذف | btnDeleteClick |
| `btnPrint` | TButton | معاينة وطباعة | btnPrintClick |
| `btnExportPDF` | TButton |  تصدير إلى PDF | btnExportPDFClick |
| `btnExportWord` | TButton |  تصدير إلى Word | btnExportWordClick |
| `btnDesign` | TButton | ️ تصميم التقرير | btnDesignClick |
| `btnRefresh` | TButton |  تحديث | btnRefreshClick |
| `btnSave` | TButton |  حفظ العقد | btnSaveClick |
| `btnCancel` | TButton | ❌ إلغاء | btnCancelClick |
| `btnClose` | TButton | إغلاق | btnCloseClick |
| `dbgContrats` | TDBGrid |  | dbgContratsDblClick |

### uEmployes — إدارة العمال والأجراء - Répertoire des Salariés

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnNew` | TButton | ➕ عامل جديد | btnNewClick |
| `btnEdit` | TButton | ✏️ تعديل | btnEditClick |
| `btnDelete` | TButton | ️ حذف | btnDeleteClick |
| `btnContracts` | TButton |  عقود العمل لهذا العامل | btnContractsClick |
| `btnRefresh` | TButton |  تحديث | btnRefreshClick |
| `dbgEmployes` | TDBGrid |  | dbgEmployesDblClick |
| `btnSave` | TButton |  حفظ التعديلات | btnSaveClick |
| `btnCancel` | TButton | ❌ إلغاء | btnCancelClick |
| `btnClose` | TButton | إغلاق | btnCloseClick |

### uForm11_Lotis — Situation Globale 

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButtonClose` | TSpeedButton | Retour | SpeedButtonCloseClick |

### uForm12_Lotis — Versements

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButtonClose` | TSpeedButton | Retour | SpeedButtonCloseClick |
| `scComboBox2` | TscComboBox |  | scComboBox2Select |
| `searchLots_Lotis` | TSearchBox |  | searchLots_LotisChange |

### uForm13_Lotis — Créances

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButtonClose` | TSpeedButton | Retour | SpeedButtonCloseClick |
| `searchLots_Lotis` | TSearchBox |  | searchLots_LotisChange |

### uForm3_Lotis — Form3_Lotis

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `Button1` | TButton | Valider | Button1Click |
| `Button2` | TButton | Annuler | Button2Click |
| `Bcalc` | TButton | Calcul | BcalcClick |
| `FJ` | TscGPDBComboBox |  | FJCloseUp |

### uForm4_Lotis — Calcul /Lot

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `RzButton2` | TRzButton | Calcul | RzButton2Click |
| `dateActe` | TDBDateTimeEditEh |  | dateActeExit |
| `Button9` | TButton | Ajouter | Button9Click |
| `Button10` | TButton | Modifier | Button10Click |
| `Button11` | TButton | Supprimer | Button11Click |
| `Button1` | TButton | Valider | Button1Click |
| `Button2` | TButton | Annuler | Button2Click |

### uForm7_Lotis — Versement

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `DBDateTimeEditEh1` | TDBDateTimeEditEh |  | DBDateTimeEditEh1CloseUp |
| `RzButton2` | TRzButton | Anuller | RzButton2Click |
| `RzButton1` | TRzButton | Valider | RzButton1Click |

### uForm8_Lotis — Sitaution Annuelle

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `DBex` | TDBGrid |  | DBexCellClick |
| `SpeedButtonClose` | TSpeedButton | Retour | SpeedButtonCloseClick |

### uForm9_Lotis — Activation du logiciel

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnSave` | TButton | Activer | btnSaveClick |
| `Button1` | TButton | Annuler | Button1Click |

### uImportHFSQL — Génération Dossiers - Import HFSQL

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnBrowse` | TButton | Parcourir... | btnBrowseClick |
| `btnConnect` | TButton | Connexion Source | btnConnectClick |
| `rbModeFile` | TRadioButton | Fichiers HFSQL (.FIC) | rbModeChange |
| `rbModeDSN` | TRadioButton | Source ODBC (DSN) | rbModeChange |
| `btnClose` | TButton | Fermer | btnCloseClick |

### uImportLotis — Liste des Lots

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `BtnExit` | TButton | Annuler | BtnExitClick |
| `Button2` | TButton | Importer | Button2Click |
| `Btn_OpenFile` | TButton | Parcourir | Btn_OpenFileClick |
| `CBSheet` | TComboBox |  | Btn_LoadExcelClick |

### uMain — Multi-Sociétés 2026

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton3` | TSpeedButton | Ajouter | SpeedButton3Click |
| `Modifier` | TSpeedButton | Modifier | ModifierClick |
| `SpeedButton5` | TSpeedButton | Supp | SpeedButton5Click |
| `SpeedButton10` | TSpeedButton | G50 | SpeedButton10Click |
| `SpeedButton6` | TSpeedButton | Etat TVA | SpeedButton15Click |
| `Recap` | TSpeedButton | Recap | RecapClick |
| `DBGrid6` | TDBGrid |  | AdvGlowButton29Click, DBGrid6CellClick |
| `SpeedButton29` | TSpeedButton |  | SpeedButton29Click |
| `SpeedButton25` | TSpeedButton | Supp | SpeedButton25Click |
| `SpeedButton24` | TSpeedButton | Solde | SpeedButton24Click |
| `DBGridEh3` | TDBGridEh |  | SpeedButton24Click |
| `SpeedButton17` | TSpeedButton | Ajouter | SpeedButton17Click |
| `SpeedButton18` | TSpeedButton | Modifier | SpeedButton18Click |
| `SpeedButton19` | TSpeedButton | Supp | SpeedButton19Click |
| `DBGridEh1` | TDBGridEh |  | SpeedButton18Click |
| `DBGridEh5` | TDBGridEh |  | SpeedButtonModifier_FVenteClick |
| `SpeedButtonPrint` | TSpeedButton | Imprimer | SpeedButtonPrint_FVenteClick |
| `SpeedButtonPDF_FVente` | TSpeedButton | Exp PDF | SpeedButtonPDF_FVenteClick |
| `SpeedButtonExcel_FVente` | TSpeedButton | Exp Excel | SpeedButtonExcel_FVenteClick |
| `edtClientSearch` | TSearchBox |  | ApplyFVenteFilter |
| `edtNFactureSearch` | TSearchBox |  | ApplyFVenteFilter |
| `SpeedButton32` | TSpeedButton | Modifier | SpeedButton32Click |
| `SpeedButton33` | TSpeedButton | Supp | SpeedButton33Click |
| `SpeedButton34` | TSpeedButton | Imp Decl | SpeedButton34Click |
| `SpeedButton31` | TSpeedButton | Ajouter | SpeedButton31Click |
| `DBGridEh7` | TDBGridEh |  | SpeedButton32Click |
| `DBGridEh8` | TDBGridEh |  | SpeedButton44Click |
| `SpeedButton41` | TSpeedButton | Ajouter | SpeedButton41Click |
| `SpeedButton44` | TSpeedButton | Modifier | SpeedButton44Click |
| `SpeedButton52` | TSpeedButton | Supp | SpeedButton52Click |
| `SpeedButton47` | TSpeedButton | Etat A | SpeedButton47Click |
| `SpeedButton2` | TSpeedButton | Etat M | SpeedButton2Click |
| `SpeedButton9` | TSpeedButton | PUPP | SpeedButton9Click |
| `SpeedButton35` | TSpeedButton | Imp Decl | SpeedButton35Click |
| `SpeedButton36` | TSpeedButton | Supp | SpeedButton36Click |
| `SpeedButton37` | TSpeedButton | Modifier | SpeedButton37Click |
| `SpeedButton20` | TSpeedButton | Ajouter | SpeedButton20Click |
| `SpeedButton21` | TSpeedButton | Modifier | SpeedButton21Click |
| `SpeedButton22` | TSpeedButton | Supp | SpeedButton22Click |
| `DBGridEh2` | TDBGridEh |  | SpeedButton18Click |
| `SpeedButton27` | TSpeedButton | Solde | SpeedButton27Click |
| `SpeedButton28` | TSpeedButton | Supp | SpeedButton28Click |
| `SpeedButton30` | TSpeedButton | Impr | SpeedButton30Click |
| `DBGridEh6` | TDBGridEh |  | SpeedButton27Click |
| `DBGridEh9` | TDBGridEh |  | SpeedButton401Click |
| `SpeedButton55` | TSpeedButton | Supp | SpeedButton33Click |
| `SpeedButton51` | TSpeedButton | Projets | SpeedButton51Click |
| `SpeedButton54` | TSpeedButton | Supp | SpeedButton54Click |
| `SpeedButton56` | TSpeedButton | Etat | SpeedButton56Click |
| `SpeedButton401` | TSpeedButton | Modifier | SpeedButton401Click |
| `SpeedButton38` | TSpeedButton | Ajouter | SpeedButton381Click |
| `SpeedButton40` | TSpeedButton | Projets | SpeedButton40Click |
| `SearchBox2` | TSearchBox |  | SearchBox2Change |
| `boxProj` | TscDBLookupComboBox |  | boxProjCloseUp |
| `scGPCheckBox1` | TscGPCheckBox | Déctiver filter | scGPCheckBox1Click |
| `gridSubdiv_Lotis` | TDBGrid |  | gridSubdiv_LotisDblClick |
| `SpeedButton12` | TSpeedButton | Ajouter | SpeedButton12Click |
| `SpeedButton57` | TSpeedButton | Modifier | SpeedButton57Click |
| `SpeedButton58` | TSpeedButton | Supp | SpeedButton58Click |
| `searchSubdiv_Lotis` | TSearchBox |  | searchSubdiv_LotisChange |
| `SpeedButton46` | TSpeedButton | Situation | SpeedButton46Click |
| `SpeedButton48` | TSpeedButton | Verseements | SpeedButton48Click |
| `SpeedButton49` | TSpeedButton | Créances | SpeedButton49Click |
| `SpeedButton50` | TSpeedButton | Situaion Annuelle | SpeedButton50Click |
| `SpeedButton53` | TSpeedButton | Imprimer | SpeedButton53Click |
| `gridLots_Lotis` | TDBGridEh |  | SpeedButton14Click |
| `SpeedButton4` | TSpeedButton | Ajouter | SpeedButton4Click |
| `SpeedButton14` | TSpeedButton | Modifier | SpeedButton14Click |
| `SpeedButton43` | TSpeedButton | Supp | SpeedButton43Click |
| `SpeedButton45` | TSpeedButton | Imp Exc | SpeedButton45Click |
| `SpeedButton42` | TSpeedButton | Retour | SpeedButton42Click, SpeedButton42DblClick |
| `searchLots_Lotis` | TSearchBox |  | searchLots_LotisChange |
| `SpeedButton39` | TSpeedButton | Modifier | SpeedButton39Click |
| `SpeedButton16` | TSpeedButton | Répertoire | SpeedButton16Click |
| `SpeedButton11` | TSpeedButton | Exercices | SpeedButton11Click |
| `SpeedButton7` | TSpeedButton | Récap An | SpeedButton1Click |
| `SpeedButton13` | TSpeedButton | Etat TVA An | SpeedButton13Click |
| `O1` | TMenuItem | Ouvrir | O1Click |
| `N3` | TMenuItem | Nouveau | N3Click |
| `P1` | TMenuItem | Parcourir | P1Click |
| `N1` | TMenuItem | G50 | N1Click |
| `G501` | TMenuItem | TAPP | G501Click |
| `N2` | TMenuItem | Solde IBS | N2Click |
| `S1` | TMenuItem | Solde IRG | S1Click |
| `T2` | TMenuItem | Tableau de Bord | T2Click |
| `SauvgareretRestaurer1` | TMenuItem | Sauvgarer et  &Restaurer | SauvgareretRestaurer1Click |
| `mnuBatchGen` | TMenuItem | &Génération Massive (Batch)... | mnuBatchGenClick |
| `T1` | TMenuItem | Themes | T1Click |
| `mnuQuitter` | TMenuItem | &Quitter | mnuQuitterClick |
| `G1` | TMenuItem | G50 | G1Click |
| `I1` | TMenuItem | IBS | I1Click |
| `I2` | TMenuItem | IRG | I2Click |
| `T4` | TMenuItem | TAPP-TFP | T4Click |
| `P2` | TMenuItem | Decl Pharma | P2Click |
| `S2` | TMenuItem | Station Services | S2Click |
| `S3` | TMenuItem | Suivi Promotion | S3Click |
| `N4` | TMenuItem | F-vente | N4Click |
| `T3` | TMenuItem | Fournisseurs TVA | T3Click |
| `C1` | TMenuItem | Clients | C1Click |
| `mnuSalaries` | TMenuItem | Salariés et Contrats de Travail | btnMainEmployesClick |
| `mnuBeneficiaireDecl` | TMenuItem | Bénéficiaire Effectif | btnMainBeneficiaireClick |
| `a1` | TMenuItem | A propos | a1Click |

### uMissingG50 — Entreprises sans declarations G50

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnSearch` | TButton | Chercher | btnSearchClick |
| `btnClose` | TButton | Fermer | btnCloseClick |
| `sgResults` | TStringGrid |  | sgResultsDblClick |

### UmissingIBS — Sociétés sans IBS

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnSearch` | TButton | Chercher | btnSearchClick |
| `btnClose` | TButton | Fermer | btnCloseClick |

### UmissingIRG — Suivi IRG - Personnes Physiques

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnSearch` | TButton | Chercher | btnSearchClick |
| `btnClose` | TButton | Fermer | btnCloseClick |

### UmmingTAPP — Entreprises manquantes - TAPP

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnSearch` | TButton | Rechercher | btnSearchClick |
| `btnClose` | TButton | Fermer | btnCloseClick |

### uNewSociete — Nouveau Dossier - Création Société

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnSave` | TButton | Enregistrer | btnSaveClick |
| `btnCancel` | TButton | Annuler | btnCancelClick |

### Unit1 — Sauv-Restore

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `BtnSauvegarder` | TButton | Sauvegarder | BtnSauvegarderClick |
| `BtnRestaurer` | TButton | Restaurer | BtnRestaurerClick |
| `Button1` | TButton | Fermer | Button1Click |

### Unit10 — F Société

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |

### Unit11 — Form11

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `scGPLabel90` | TscGPLabel | TAPP-TFP | Button1Click |
| `SpeedButton3` | TSpeedButton | Annuler | SpeedButton1Click |
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `scGPDBComboBox1` | TscGPDBComboBox |  | scGPDBComboBox1CloseUp |

### Unit12 — Form12

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton3` | TSpeedButton | Annuler | SpeedButton3Click |
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |

### Unit13 — F Exercices

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `DBex` | TDBGrid |  | Button1Click, DBexCellClick |
| `AdvGlowButton3` | TAdvGlowButton | Supprimer | AdvGlowButton3Click |
| `modifTAP` | TAdvGlowButton | Modifier | modifTAPClick |
| `AdvGlowButton1` | TAdvGlowButton | Nouveau | AdvGlowButton1Click |
| `AdvGlowButton2` | TAdvGlowButton | Fermer | AdvGlowButton2Click |

### Unit14 — Station - Nouveau

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton13` | TSpeedButton | Annuler | SpeedButton13Click |
| `SpeedButton14` | TSpeedButton | Valider | Button1Click |
| `SpeedButton1` | TSpeedButton | Annuler | SpeedButton13Click |
| `SpeedButton2` | TSpeedButton | Valider | Button1Click |

### Unit15 — FormG50

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton4` | TSpeedButton | Valider | SpeedButton4Click |
| `SpeedButton2` | TSpeedButton | Annuler | SpeedButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Supprimer | AdvGlowButton3Click |
| `AdvGlowButton1` | TAdvGlowButton | Nouveau | AdvGlowButton1Click |
| `modifTAP` | TAdvGlowButton | Modifier | modifTAPClick |
| `DBGridEh1` | TDBGridEh |  | modifTAPClick |
| `DBGridEh4` | TDBGridEh |  | AdvGlowButton5Click |
| `AdvGlowButton2` | TAdvGlowButton | Supprimer | AdvGlowButton2Click |
| `AdvGlowButton5` | TAdvGlowButton | Modifier | AdvGlowButton5Click |
| `AdvGlowButton11` | TAdvGlowButton | Nouveau | AdvGlowButton11Click |
| `DBGridEh2` | TDBGridEh |  | AdvGlowButton8Click |
| `AdvGlowButton6` | TAdvGlowButton | Nouveau | AdvGlowButton6Click |
| `AdvGlowButton8` | TAdvGlowButton | Modifier | AdvGlowButton8Click |
| `AdvGlowButton9` | TAdvGlowButton | Supprimer | AdvGlowButton3Click |
| `DBGridEh5` | TDBGridEh |  | modifTAPClick |
| `AdvGlowButton12` | TAdvGlowButton | Supprimer | AdvGlowButton3Click |
| `AdvGlowButton13` | TAdvGlowButton | Modifier | AdvGlowButton13Click |
| `AdvGlowButton14` | TAdvGlowButton | Nouveau | AdvGlowButton14Click |
| `Button5` | TButton | CalcTdroits | Button5Click |
| `Button6` | TButton | Button6 | Button6Click |
| `Button4` | TButton | Calcul | Button4Click |
| `DBGridEh3` | TDBGridEh |  | AdvGlowButton7Click |
| `AdvGlowButton4` | TAdvGlowButton | Supprimer | AdvGlowButton3Click |
| `AdvGlowButton7` | TAdvGlowButton | Modifier | AdvGlowButton7Click |
| `AdvGlowButton10` | TAdvGlowButton | Nouveau | AdvGlowButton10Click |

### Unit17 — Fprojet

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `BtnAdd` | TsSpeedButton | Ajouter | BtnAddClick |
| `BtnDelete` | TsSpeedButton | Supprimer | BtnDeleteClick |
| `sSpeedButton1` | TsSpeedButton | Retour | sSpeedButton1Click |
| `BtnPost` | TsSpeedButton | Etat de Projet | BtnPostClick |

### Unit18 — FSuivi Encaissement

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |
| `Taux` | TscDBLookupComboBox | Sélectionner le taux TVA | TauxCloseUp |

### Unit19 — Form19

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit2 — Déclaration Fiscale Mensuelle G50

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `OptionTAP` | TscGPDBCheckBox | TAP | OptionTAPClick |
| `DBGridEh2` | TDBGridEh |  | modifTAPClick |
| `AdvGlowButton1` | TAdvGlowButton | Nouveau | AdvGlowButton1Click |
| `modifTAP` | TAdvGlowButton | Modifier | modifTAPClick |
| `AdvGlowButton3` | TAdvGlowButton | Supprimer | AdvGlowButton3Click |
| `DBGridEh7` | TDBGridEh |  | AdvGlowButton22Click |
| `AdvGlowButton21` | TAdvGlowButton | Supprimer | AdvGlowButton21Click |
| `AdvGlowButton22` | TAdvGlowButton | Modifier | AdvGlowButton22Click |
| `AdvGlowButton23` | TAdvGlowButton | Nouveau | AdvGlowButton23Click |
| `AdvGlowButton2` | TAdvGlowButton | Nouveau | AdvGlowButton2Click |
| `AdvGlowButton4` | TAdvGlowButton | Modifier | AdvGlowButton4Click |
| `AdvGlowButton5` | TAdvGlowButton | Supprimer | AdvGlowButton5Click |
| `DBGridEh6` | TDBGridEh |  | AdvGlowButton4Click |
| `AdvGlowButton6` | TAdvGlowButton | Nouveau | AdvGlowButton6Click |
| `AdvGlowButton7` | TAdvGlowButton | Modifier | AdvGlowButton7Click |
| `AdvGlowButton8` | TAdvGlowButton | Supprimer | AdvGlowButton8Click |
| `DBGridEh1` | TDBGridEh |  | AdvGlowButton7Click |
| `AdvGlowButton9` | TAdvGlowButton | Nouveau | AdvGlowButton9Click |
| `AdvGlowButton10` | TAdvGlowButton | Modifier | AdvGlowButton10Click |
| `AdvGlowButton11` | TAdvGlowButton | Supprimer | AdvGlowButton11Click |
| `DBGridEh3` | TDBGridEh |  | AdvGlowButton10Click |
| `AdvGlowButton12` | TAdvGlowButton | Nouveau | AdvGlowButton12Click |
| `AdvGlowButton13` | TAdvGlowButton | Modifier | AdvGlowButton13Click |
| `AdvGlowButton14` | TAdvGlowButton | Supprimer | AdvGlowButton14Click |
| `DBGridEh5` | TDBGridEh |  | AdvGlowButton13Click |
| `Button5` | TButton | Manuel | Button5Click |
| `Button6` | TButton | Etat de Recuperation | Button6Click |
| `AdvGlowButton15` | TAdvGlowButton | Nouveau | AdvGlowButton15Click |
| `AdvGlowButton16` | TAdvGlowButton | Modifier | AdvGlowButton16Click |
| `AdvGlowButton17` | TAdvGlowButton | Supprimer | AdvGlowButton17Click |
| `AdvGlowButton19` | TAdvGlowButton | Actualiser | AdvGlowButton19Click |
| `SearchBox1` | TSearchBox |  | SearchBox1Change |
| `DBGridEh4` | TDBGridEh |  | AdvGlowButton16Click |
| `AdvGlowButton24` | TAdvGlowButton | Actualiser | AdvGlowButton15Click |
| `AdvGlowButton25` | TAdvGlowButton | Modifier | AdvGlowButton25Click |
| `AdvGlowButton27` | TAdvGlowButton | Nouveau | AdvGlowButton27Click |
| `SearchBox2` | TSearchBox |  | SearchBox2Change |
| `DBGridEh8` | TDBGridEh |  | DBGridEh8DblClick |
| `AdvGlowButton20` | TAdvGlowButton | Fermer | AdvGlowButton20Click |
| `AdvGlowButton18` | TAdvGlowButton | Imprimer G50 | AdvGlowButton18Click |
| `MenuItem2` | TMenuItem | Nouveau | AdvGlowButton1Click |
| `MenuItem1` | TMenuItem | Modifier | modifTAPClick |
| `MenuItem3` | TMenuItem | Supprimer | AdvGlowButton3Click |
| `MenuItem4` | TMenuItem | Nouveau | AdvGlowButton2Click |
| `MenuItem5` | TMenuItem | Modifier | AdvGlowButton4Click |
| `MenuItem6` | TMenuItem | Supprimer | AdvGlowButton5Click |
| `MenuItem7` | TMenuItem | Nouveau | AdvGlowButton6Click |
| `MenuItem8` | TMenuItem | Modifier | AdvGlowButton7Click |
| `MenuItem9` | TMenuItem | Supprimer | AdvGlowButton8Click |
| `MenuItem10` | TMenuItem | Nouveau | AdvGlowButton9Click |
| `MenuItem11` | TMenuItem | Modifier | AdvGlowButton10Click |
| `MenuItem12` | TMenuItem | Supprimer | AdvGlowButton11Click |
| `MenuItem13` | TMenuItem | Nouveau | AdvGlowButton12Click |
| `MenuItem14` | TMenuItem | Modifier | AdvGlowButton13Click |
| `MenuItem15` | TMenuItem | Supprimer | AdvGlowButton14Click |
| `MenuItem16` | TMenuItem | Nouveau | AdvGlowButton19Click |
| `MenuItem17` | TMenuItem | Modifier | AdvGlowButton16Click |
| `MenuItem18` | TMenuItem | Supprimer | AdvGlowButton17Click |

### Unit21 — CA Station de Services

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit22 — F Exercice

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton13` | TSpeedButton | Annuler | SpeedButton13Click |
| `SpeedButton14` | TSpeedButton | Valider | SpeedButton14Click |

### Unit23 — Nouveau G50

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton13` | TSpeedButton | Annuler | SpeedButton13Click |
| `SpeedButton14` | TSpeedButton | Valider | Button1Click |

### Unit24 — F IRG/Salaires

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `DBLook` | TDBLookupComboBox |  | DBLookClick |
| `AdvGlowButton2` | TAdvGlowButton | Valider | SpeedButton4Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | SpeedButton2Click |

### Unit25 — Form25

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `AdvGlowButton2` | TAdvGlowButton | Valider | SpeedButton4Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | SpeedButton2Click |

### Unit26 — Form26

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `AdvDBLookupComboBox1` | TAdvDBLookupComboBox |  | AdvDBLookupComboBox1CloseUp |
| `AdvGlowButton2` | TAdvGlowButton | Valider | SpeedButton4Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | SpeedButton2Click |

### Unit27 — Autres Taxes

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `DBLook` | TAdvDBLookupComboBox |  | AdvDBLookupComboBox1CloseUp |
| `AdvGlowButton2` | TAdvGlowButton | Valider | SpeedButton4Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | SpeedButton2Click |

### Unit28 — Form28

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit29 — Fiche Modification Sociéte

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `PageControl1` | TPageControl |  | PageControl1Change |
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |

### Unit3 — Form3

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton11` | TSpeedButton | Exercices | SpeedButton11Click |
| `BtnOpen` | TButton | Open tables | BtnOpenClick |
| `AdvGlowButton30` | TAdvGlowButton | Nouveau G50 | AdvGlowButton30Click |
| `AdvGlowButton29` | TAdvGlowButton | Modifier G50 | AdvGlowButton29Click |
| `DBGrid6` | TDBGrid |  | AdvGlowButton29Click |

### Unit30 — Form30

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton41` | TSpeedButton | Ajouter | SpeedButton41Click |
| `SpeedButton44` | TSpeedButton | Modifier | SpeedButton44Click |
| `SpeedButton45` | TSpeedButton | Supprimer | SpeedButton45Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |
| `SearchBox2` | TSearchBox |  | SearchBox2Change |
| `DBGridEh9` | TDBGridEh |  | SpeedButton44Click |

### Unit31 — Form31

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |

### Unit32 — Form32

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit33 — Form33

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnModelClassique` | TSpeedButton | Classique | btnModelClassiqueClick |
| `btnModelJibayatic` | TSpeedButton | Jibayatic | btnModelJibayaticClick |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |

### Unit37 — Recap G50 

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit38 — Form38

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit39 — Form39

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `sSpeedButton1` | TsSpeedButton | Retour | sSpeedButton1Click |

### Unit4 — Déduction TVA

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `BtnAddClient` | TSpeedButton | + Ajouter Fournisseur | BtnAddClientClick |
| `Taux` | TscDBLookupComboBox |  | TauxCloseUp |
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |

### Unit40 — Facture de Ventes - Taxe sur la Valeur Ajoutée

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `BtnAddClient` | TSpeedButton | + Ajouter Client | BtnAddClientClick |
| `Taux` | TscDBLookupComboBox |  | TauxCloseUp |
| `AdvGlowButton1` | TAdvGlowButton | Annuler | AdvGlowButton3Click |
| `AdvGlowButton4` | TAdvGlowButton | Valider | AdvGlowButton2Click |

### Unit41 — Table des Clients

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton41` | TSpeedButton | Ajouter | SpeedButton41Click |
| `SpeedButton44` | TSpeedButton | Modifier | SpeedButton44Click |
| `SpeedButton45` | TSpeedButton | Supprimer | SpeedButton45Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |
| `SearchBox2` | TSearchBox |  | SearchBox2Change |
| `DBGridEh1` | TDBGridEh |  | DBGridEh1DblClick |

### Unit42 — Fiche Client

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `AdvGlowButton1` | TAdvGlowButton | Annuler | AdvGlowButton3Click |
| `AdvGlowButton4` | TAdvGlowButton | Valider | AdvGlowButton2Click |

### Unit43 — Etat des Ventes Annuelles

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButtonAjouter` | TSpeedButton | Ajouter | SpeedButtonAjouterClick |
| `SpeedButtonModifier` | TSpeedButton | Modifier | SpeedButtonModifierClick |
| `SpeedButtonSupprimer` | TSpeedButton | Supp | SpeedButtonSupprimerClick |
| `SpeedButtonPrint` | TSpeedButton | Imprimer | SpeedButtonPrintClick |
| `SpeedButtonPDF` | TSpeedButton | Exp PDF | SpeedButtonPDFClick |
| `SpeedButtonExcel` | TSpeedButton | Exp Excel | SpeedButtonExcelClick |
| `SpeedButtonClose` | TSpeedButton | Retour | SpeedButtonCloseClick |
| `edtClientSearch` | TSearchBox |  | ApplyFilter |
| `edtNFactureSearch` | TSearchBox |  | ApplyFilter |
| `DBGridEh1` | TDBGridEh |  | SpeedButtonModifierClick |

### Unit44 — Impression Etat des Ventes Annuelles

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit45 — Solde IBS

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton1` | TSpeedButton | Annuler | SpeedButton1Click |
| `SpeedButton2` | TSpeedButton | Valider | SpeedButton10Click |
| `Button1` | TButton | Maj Donnéés Ant | Button1Click |

### Unit46 — Form46

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |

### Unit47 — A propos

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `Button1` | TButton | Fermer | Button1Click |

### Unit5 — Detail Chiffres d'Affaires

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `BtnAddsp` | TSpeedButton | Ajouter | BtnAddClick |
| `SpeedButton44` | TSpeedButton | Annuler | BtnCancelClick |
| `SpeedButton1` | TSpeedButton | Enregistrer | BtnPostClick |
| `SpeedButton2` | TSpeedButton | Ajouter | BtnAddLClick |
| `SpeedButton3` | TSpeedButton | Annuler | BtnCancelLClick |
| `SpeedButton4` | TSpeedButton | Supprimer | BtnDeleteLClick |
| `SpeedButton5` | TSpeedButton | Enregistrer | BtnPostLClick |
| `BtnAddps` | TSpeedButton | Ajouter | BtnAddpsClick |
| `BtnSuppps` | TSpeedButton | Supprimer | BtnSupppsClick |
| `BTNSaveps` | TSpeedButton | Enregistrer | BTNSavepsClick |
| `Btncancelps` | TSpeedButton | Annuler | BtncancelpsClick |
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton18Click |
| `AdvGlowButton1` | TAdvGlowButton | Annuler | AdvGlowButton20Click |

### Unit6 — Form6

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton8` | TSpeedButton | Exp PDF | SpeedButton8Click |
| `SpeedButton9` | TSpeedButton | Exp Excel | SpeedButton9Click |
| `SpeedButton12` | TSpeedButton | Imp Etat | SpeedButton12Click |
| `SpeedButton1` | TSpeedButton | Retour | SpeedButton1Click |

### Unit7 — Acomptes IBS

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `scGPDBComboBox1` | TscGPDBComboBox |  | scGPDBComboBox1CloseUp |
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |

### Unit8 — Acomptes IRG

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `scGPDBComboBox1` | TscGPDBComboBox |  | scGPDBComboBox1CloseUp |
| `AdvGlowButton2` | TAdvGlowButton | Valider | AdvGlowButton2Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | AdvGlowButton3Click |

### Unit9 — Form9

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `SpeedButton1` | TSpeedButton | Annuler | SpeedButton1Click |
| `SpeedButton2` | TSpeedButton | Valider | SpeedButton2Click |
| `Button1` | TButton | Maj Donnéés Ant | Button1Click |

### UnitaP — F TAP

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `DBLook` | TDBLookupComboBox |  | DBLookCloseUp, DBLookExit |
| `AdvGlowButton2` | TAdvGlowButton | Valider | SpeedButton4Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | SpeedButton2Click |

### UnitThemes — Fthemes

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `cbb1` | TComboBox |  | cbb1Select |
| `annull` | TButton | Annuller | annullClick |
| `Button1` | TButton | Ok | Button1Click |

### UnitTsl — F TSL

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `DBLook` | TDBLookupComboBox |  | DBLookCloseUp, DBLookExit |
| `AdvGlowButton2` | TAdvGlowButton | Valider | SpeedButton4Click |
| `AdvGlowButton3` | TAdvGlowButton | Annuler | SpeedButton2Click |

### uOpenSociete — Ouvrir un Dossier de Société

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `sgCompanies` | TStringGrid |  | sgCompaniesDblClick |
| `AdvGlowButton18` | TAdvGlowButton | Actualiser | btnRefreshClick |
| `AdvGlowButton1` | TAdvGlowButton | Ouvrir Repertoire | btnOpenFolderClick |
| `AdvGlowButton4` | TAdvGlowButton | Supp Dossier | AdvGlowButton4Click |
| `AdvGlowButton2` | TAdvGlowButton | Annuler | btnCancelClick |
| `AdvGlowButton3` | TAdvGlowButton | Ouvrir Dossier | btnOpenClick |
| `miSyncDb` | TMenuItem | Mettre à jour && Synchroniser la base de | miSyncDbClick |
| `miOpenFolderDb` | TMenuItem | Ouvrir Dossier | btnOpenClick |
| `miOpenDir` | TMenuItem | Ouvrir Repertoire | btnOpenFolderClick |
| `miSuppFolder` | TMenuItem | Supprimer Dossier | AdvGlowButton4Click |

### uSocieteEdit — Fiche Société

| Contrôle | Classe | Libellé | Gestionnaire |
|---|---|---|---|
| `btnEdit` | TButton | Modifier | btnEditClick |
| `btnSave` | TButton | Enregistrer | btnSaveClick |
| `btnCancel` | TButton | Fermer | btnCancelClick |
