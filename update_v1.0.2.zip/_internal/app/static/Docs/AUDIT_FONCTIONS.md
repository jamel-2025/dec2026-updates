# مراجعة شاملة لوظائف التطبيق الأصلي (Delphi) ← Dec2026

> المصدر: `Docs/inventaire_delphi.md` (مولَّد آلياً بـ `tools/audit_inventory.py` من كل الاستمارات:
> 437 إجراء مرئي في 67 استمارة). كل سطر هنا = وظيفة يجب أن تكون موجودة.
> الحالة: ✅ موجود · 🔧 أُضيف في هذه المراجعة · ⏳ قيد الإنجاز · ⛔ مستبعد (مع السبب)

## 1. الهيكل والقوائم (uMain)
| الوظيفة | المصدر | الحالة |
|---|---|---|
| قائمة Fichier / Déclarations / Autres / Help بنفس البنود وقواعد الإظهار | uMain menu | ✅ |
| Dossiers ▸ Ouvrir / Nouveau / Parcourir | O1 · N3 (Unit10) · P1 | ✅ |
| فتح ملف: Actualiser · Ouvrir Répertoire · Supp Dossier (مع نسخة أمان) · Mettre à jour & synchroniser la base | uOpenSociete | ✅ |
| لوحة «Dossier»: RS · NIF · Activité · Adresse · Modifier · Répertoire | Panel10 | ✅ |
| Exercices (جدول السنوات: Nouveau · **Modifier** · Supprimer) · Récap An · Etat TVA An | Panel29 · Unit13 · Unit22 | ✅ |
| Tableau de bord · Déclarations manquantes (G50 · TAPP · IBS · IRG) | Card3 · uMissing* | ✅ |
| Sauvegarder et restaurer | Unit1 | ✅ |
| Génération massive (Batch): Étape 1 WinDev → base centrale · Étape 2 توزيع الملفات | uBatchGen · uImportHFSQL | ✅ (pilote HFSQL 32-bit · ترميز Windows-1252 · لا استبدال للملفات الموجودة إلا بطلب + نسخة أمان) |
| Thèmes · A propos · Guide d'utilisation (F1) · Quitter (Ctrl+Q) | T1 · Unit47 · G2 · mnuQuitter | ✅ |
| Activation du logiciel | uForm9_Lotis | ⛔ ترخيص خاص بنسخة الدلفي |

## 2. التصدير والطباعة (كل نوافذ المعاينة: Imp Etat · Exp PDF · Exp Excel)
القاعدة الأصلية: الملف يُحفظ في `<مجلد الشركة>\Rapports\<السنة>\<الصنف>\<الاسم>` ثم يُفتح المجلد.

| التقرير | المصدر | اسم الملف الأصلي | الحالة |
|---|---|---|---|
| G50 | Unit33 | `Rapports\<an>\G50\G50 <ma>` | ✅ |
| Etat TVA mensuel | Unit6 | `Rapports\<an>\Etat TVA\EtatTva <ma>` | ✅ |
| Etat TVA annuel | Unit38 | `Rapports\<an>\Etat TVA\EtatTva Année <an>` | ✅ |
| Recap G50 | Unit37 | `Rapports\<an>\Recap G50\Recap G50 <ma>` | ✅ |
| Récap annuel | Unit28 | `Rapports\<an>\Recap Annee <an>` | ✅ |
| Etat des ventes | Unit43/44 | `Rapports\<an>\Etat Ventes\…` | ✅ |
| Station mensuel / annuel | Unit32 · Unit21 | `CA Station Mois <ma>` · `Etat CA Station de Servive <an>` | ✅ |
| Suivi des versements (promotion) | Unit19 | `Etat Suivi de Versement <an>` | ✅ |
| Pharmacie · IBS · IRG · TAPP · Lotissement · Projet | Unit12 · Unit45 · Unit9 · Unit11 · Unit36 · Unit17 | (طباعة فقط في الدلفي) | ✅ PDF/Excel مضافان للتوحيد |
| Contrat de travail: PDF · Word (RTF .doc) | uContrats | `Contrats_Word\عقد_عمل_<nom>_<n°>.doc` | ✅ |
| Bénéficiaire effectif: PDF | uBeneficiaireEffectif | `Beneficiaire_Effectif_<an>_<nom>.pdf` | ✅ |
| قوائم المحطة (Naftal · Lubrifiants) → Excel — وعُمّم «Exporter Excel» على كل جداول التطبيق | Unit5 | `Rapports\<an>\Listes\Export Naftal …` | ✅ |

## 3. الوحدات
| الوحدة | الوظائف | الحالة |
|---|---|---|
| G50 (Unit2/23/4/24–27/aP/Tsl/15) | إنشاء · كل الأسطر · 90 يدوي · Etat de récupération · بحث الموردين · Actualiser | ✅ |
| IBS (Unit7/45) | أقساط · رصيد · Maj données antérieures | ✅ |
| IRG (Unit8/9) | أقساط · رصيد · Maj données antérieures | ✅ |
| TAPP (Unit11) | سداسي · TF/TAP · طباعة | ✅ |
| Pharma (Unit12) | إدخال · طباعة | ✅ |
| Station (Unit14/5/39/21/32) | شهري · 3 جداول · PUPP · حالتان · تصدير القوائم | ✅ |
| Promotion (Unit17/18/19) | مشاريع · تحصيلات · فلترة مشروع/زبون · «إلغاء الفلتر» · حالتان | ✅ |
| Lotissement (uForm3…17, Import) | دراسة · قطع · دفعات · ديون · TCR · استيراد · طباعة · **بحث/فلترة الدفعات حسب الطريقة** | ✅ |
| Fournisseurs · Clients (Unit30/31/41/42) | CRUD · بحث | ✅ |
| F-ventes (Unit40/43/44) | فواتير · بحث زبون/رقم · طباعة · PDF · Excel | ✅ |
| Salariés · Contrats · Bénéficiaire | كامل + طباعة | ✅ |

## 4. الحيوية والتجربة
- رسائل نجاح مع زر «Ouvrir le dossier» بعد كل تصدير، تقدّم مرئي أثناء العمليات الطويلة،
  انتقالات وحركات خفيفة، عدّادات متحركة في لوحة القيادة، تلميحات اختصارات لوحة المفاتيح.
