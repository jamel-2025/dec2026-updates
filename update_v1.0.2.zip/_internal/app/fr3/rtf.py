"""Editable Word export (RTF saved as .doc, like uContrats.btnExportWordClick) built from rendered pages:
text objects become paragraphs in reading order, with alignment, right-to-left direction, bold/italic
and font size; one page break between report pages."""
from __future__ import annotations

from .engine import Page


def _esc(text: str) -> str:
    out = []
    for ch in text:
        o = ord(ch)
        if ch in "\\{}":
            out.append("\\" + ch)
        elif ch == "\n":
            out.append("\\line ")
        elif o < 128:
            out.append(ch)
        else:
            out.append(f"\\u{o if o < 32768 else o - 65536}?")
    return "".join(out)


def _rtl(text: str) -> bool:
    return any("؀" <= ch <= "ۿ" for ch in text)


def pages_to_rtf(pages: list[Page]) -> bytes:
    parts = [r"{\rtf1\ansi\ansicpg1252\deff0{\fonttbl{\f0\fswiss\fcharset0 Arial;}{\f1\fnil\fcharset178 Arial;}}"
             r"\paperw11906\paperh16838\margl1134\margr1134\margt1134\margb1134 "]
    for n, p in enumerate(pages):
        if n:
            parts.append(r"\page ")
        items = sorted((it for it in p.items if it.kind == "text" and it.text.strip()), key=lambda it: (round(it.y / 4), -it.x if _rtl(it.text) else it.x))
        for it in items:
            s = it.style
            rtl = s.get("rtl") or _rtl(it.text)
            align = {"center": r"\qc", "right": r"\qr", "justify": r"\qj"}.get(s.get("halign", "left"), r"\ql")
            if rtl and align == r"\ql":
                align = r"\qr"
            size = int(round(s.get("font_size", 13.0) * 0.75 * 2))
            fmt = (r"\b" if s.get("bold") else "") + (r"\i" if s.get("italic") else "") + (r"\ul" if s.get("underline") else "")
            direction = r"\rtlpar" if rtl else r"\ltrpar"
            rtlch = r"\rtlch" if rtl else ""
            parts.append("{" + r"\pard" + direction + align + r"\sa60\f" + str(1 if rtl else 0) + r"\fs" + str(size)
                         + fmt + rtlch + " " + _esc(it.text.strip()) + r"\par}")
    parts.append("}")
    return "\n".join(parts).encode("ascii")
