"""Render engine pages to a printable HTML document (exact page size, absolute layout)."""
from __future__ import annotations

import base64
import html as _h

from ..core import config
from .engine import MM, Item, Page

IMG_URL = "/api/reports/img/"
_INLINE = False


def _src(name: str) -> str:
    """Image reference: URL of the preview server, or data URI for a standalone export (PDF)."""
    if _INLINE:
        p = config.CACHE_DIR / "fr3img" / name
        if p.is_file():
            return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode()
    return IMG_URL + _h.escape(name)


def _px(v: float) -> str:
    return f"{v:.2f}px"


def _border(fr: dict | None) -> str:
    if not fr:
        return ""
    w = max(fr.get("width", 1.0), 0.5)
    spec = f'{w:.2f}px {fr.get("style", "solid")} {fr.get("color", "#000")}'
    out = []
    for side in ("left", "right", "top", "bottom"):
        if fr.get(side):
            out.append(f"border-{side}:{spec};")
    return "".join(out)


def _text(it: Item) -> str:
    s = it.style
    css = [f"left:{_px(it.x)};top:{_px(it.y)};width:{_px(it.w)};height:{_px(it.h)};"]
    fs = s.get("font_size", 13.0)
    css.append(f"font-family:'{s.get('font_family', 'Arial')}',Arial,sans-serif;font-size:{fs:.2f}px;")
    css.append(f"line-height:{fs * 1.15 + s.get('line_spacing', 2.0):.2f}px;")
    if s.get("color"):
        css.append(f"color:{s['color']};")
    if s.get("bold"):
        css.append("font-weight:700;")
    if s.get("italic"):
        css.append("font-style:italic;")
    deco = " ".join(d for d, k in (("underline", "underline"), ("line-through", "strike")) if s.get(k))
    if deco:
        css.append(f"text-decoration:{deco};")
    if s.get("fill"):
        css.append(f"background:{s['fill']};")
    css.append(_border(s.get("frame")))
    css.append(f"padding:{_px(s.get('gap_y', 1))} {_px(s.get('gap_x', 2))};")
    css.append({"top": "justify-content:flex-start;", "center": "justify-content:center;",
                "bottom": "justify-content:flex-end;"}[s.get("valign", "top")])
    css.append(f"text-align:{s.get('halign', 'left')};")
    css.append("white-space:pre-wrap;" if s.get("wrap", True) else "white-space:pre;")
    if s.get("rtl"):
        css.append("direction:rtl;")
    if s.get("overflow"):                      # filled-in values may be taller than the form's tiny cells
        css.append("overflow:visible;")
    rot = s.get("rotation", 0) % 360
    if rot == 90:
        css.append("writing-mode:vertical-rl;transform:rotate(180deg);")
    elif rot == 270:
        css.append("writing-mode:vertical-rl;")
    body = it.text if s.get("html") else _h.escape(it.text)
    return f'<div class="t" style="{"".join(css)}"><span>{body}</span></div>'


def _item(it: Item) -> str:
    if it.kind == "text":
        return _text(it)
    s = it.style
    geo = f"left:{_px(it.x)};top:{_px(it.y)};width:{_px(it.w)};height:{_px(it.h)};"
    if it.kind == "image":
        fit = "fill" if s.get("stretch") and not s.get("keep_aspect") else ("contain" if s.get("stretch") else "none")
        pos = "center" if s.get("center") else "left top"
        return (f'<img class="i" src="{_src(it.text)}" '
                f'style="{geo}object-fit:{fit};object-position:{pos};{_border(s.get("frame"))}">')
    if it.kind == "line":
        c, w = s.get("color", "#000"), max(s.get("width", 1.0), 0.5)
        if it.w and it.h and s.get("diagonal"):
            return (f'<svg class="i" style="{geo}overflow:visible"><line x1="0" y1="0" x2="{it.w:.2f}" '
                    f'y2="{it.h:.2f}" stroke="{c}" stroke-width="{w}"/></svg>')
        if abs(it.h) < 0.01:
            return f'<div class="i" style="left:{_px(it.x)};top:{_px(it.y)};width:{_px(it.w)};border-top:{w}px solid {c};"></div>'
        return f'<div class="i" style="left:{_px(it.x)};top:{_px(it.y)};height:{_px(it.h)};border-left:{w}px solid {c};"></div>'
    if it.kind == "rect":
        radius = "border-radius:50%;" if s.get("shape") == "skEllipse" else (
            "border-radius:8px;" if s.get("shape") == "skRoundRectangle" else "")
        fill = f"background:{s['fill']};" if s.get("fill") else ""
        return f'<div class="i" style="{geo}{fill}{_border(s.get("frame"))}{radius}box-sizing:border-box;"></div>'
    return ""


def _branding_footer() -> str:
    branding_file = config.DATA_DIR / "office_branding.json"
    if not branding_file.is_file():
        return ""
    try:
        import json
        b = json.loads(branding_file.read_text("utf-8"))
        name = b.get("office_name") or b.get("office_name_ar") or ""
        phone = b.get("phone") or ""
        if not name:
            return ""
        contact = f" · Tél: {phone}" if phone else ""
        return f'<div class="branded-footer" style="position:absolute;bottom:4px;right:16px;font-size:9px;color:#64748b;font-family:Arial,sans-serif;pointer-events:none;">Établi par : {_h.escape(name)}{_h.escape(contact)}</div>'
    except Exception:
        return ""


def render(pages: list[Page], title: str = "Rapport", inline_images: bool = False) -> str:
    global _INLINE
    _INLINE = inline_images
    sizes = {}
    out = []
    b_foot = _branding_footer()
    for p in pages:
        key = f"p{round(p.width / MM)}x{round(p.height / MM)}"
        sizes[key] = (p.width / MM, p.height / MM)
        bg = f'<img class="bg" src="{_src(p.background)}">' if p.background else ""
        items = "".join(_item(it) for it in p.items)
        out.append(f'<section class="page {key}" style="width:{_px(p.width)};height:{_px(p.height)}">{bg}{items}{b_foot}</section>')
    page_rules = "".join(f"@page {k}{{size:{w:.1f}mm {h:.1f}mm;margin:0}} .{k}{{page:{k}}}" for k, (w, h) in sizes.items())
    return f"""<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><title>{_h.escape(title)}</title>
<style>
*{{box-sizing:border-box}}
html,body{{margin:0;padding:0}}
body{{background:#e6e8ec;font-family:Arial,sans-serif}}
.page{{position:relative;overflow:hidden;background:#fff;margin:24px auto;box-shadow:0 2px 14px rgba(0,0,0,.18)}}
.page .bg{{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:fill}}
.page .t{{position:absolute;display:flex;flex-direction:column;overflow:hidden;box-sizing:border-box}}
.page .t span{{display:block}}
.page .i{{position:absolute;box-sizing:border-box}}
{page_rules}
@media print{{
  body{{background:none}}
  .page{{margin:0;box-shadow:none;break-after:page}}
  .page:last-child{{break-after:auto}}
}}
</style></head><body>{''.join(out)}</body></html>"""
