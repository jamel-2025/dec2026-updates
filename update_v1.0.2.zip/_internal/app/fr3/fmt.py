"""Delphi value formatting as used by FastReport DisplayFormat (Algerian French locale:
thousand separator = space, decimal separator = comma)."""
from __future__ import annotations

import re
from datetime import date, datetime
from decimal import ROUND_HALF_UP, Decimal

THOUSAND = " "   # non-breaking space, never wraps inside an amount
DECIMAL = ","


def _group(intpart: str) -> str:
    neg = intpart.startswith("-")
    digits = intpart.lstrip("-")
    out = []
    while len(digits) > 3:
        out.insert(0, digits[-3:])
        digits = digits[:-3]
    out.insert(0, digits)
    return ("-" if neg else "") + THOUSAND.join(out)


def to_number(v):
    if v is None or v == "":
        return None
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip().replace(" ", "").replace(" ", "")
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    if re.fullmatch(r"-?\d*[.,]\d+", s):
        return float(s.replace(",", "."))
    return None


def fixed(v: float, decimals: int, grouped: bool) -> str:
    # Delphi FloatToText rounds half away from zero (Python's format would round half to even)
    q = Decimal(1).scaleb(-decimals)
    s = str(Decimal(repr(float(v))).quantize(q, rounding=ROUND_HALF_UP))
    ip, _, dp = s.partition(".")
    if ip in ("-0",) and not dp.strip("0"):
        ip = "0"
    ip = _group(ip) if grouped else ip
    return ip + (DECIMAL + dp if decimals else "")


def delphi_format(spec: str, v) -> str:
    """Format('%2.0n', [v]) and friends: d, f, n, m, g, e, s, x."""
    m = re.fullmatch(r"%(-?)(\d*)(?:\.(\d+))?([dfnmgesxDFNMGESX])", spec.strip())
    if not m:
        part = re.search(r"%-?\d*(?:\.\d+)?[dfnmgesxDFNMGESX]", spec)   # literal text around the spec: '%2.2n M²'
        if part:
            return spec[:part.start()] + delphi_format(part.group(0), v) + spec[part.end():]
        return str(v)
    _, width, prec, conv = m.groups()
    conv = conv.lower()
    if conv == "s":
        return str(v if v is not None else "")
    n = to_number(v)
    if n is None:
        n = 0
    if conv == "d":
        s = str(int(round(n)))
    elif conv == "x":
        s = format(int(n), "X")
    elif conv == "f":
        s = fixed(float(n), int(prec) if prec is not None else 2, False)
    elif conv in ("n", "m"):
        s = fixed(float(n), int(prec) if prec is not None else 2, True)
        if conv == "m":
            s += " DA"
    elif conv == "e":
        s = f"{float(n):.{int(prec) if prec else 15}E}".replace(".", DECIMAL)
    else:  # g
        s = general(n)
    if width and len(s) < int(width):
        s = s.rjust(int(width))
    return s


def general(n) -> str:
    """FloatToStr: shortest representation, comma decimal."""
    if isinstance(n, float) and n.is_integer():
        return str(int(n))
    if isinstance(n, float):
        return repr(round(n, 15)).replace(".", DECIMAL)
    return str(n)


def format_float(mask: str, v) -> str:
    """FormatFloat('#,##0.00', v)."""
    n = to_number(v) or 0
    sections = mask.split(";")
    if n < 0 and len(sections) > 1:
        mask, n = sections[1], -n
    elif n == 0 and len(sections) > 2:
        return sections[2]
    else:
        mask = sections[0]
    core = re.search(r"[#0,.]+", mask)
    if not core:
        return mask
    pat = core.group()
    grouped = "," in pat
    dec = pat.split(".", 1)[1] if "." in pat else ""
    decimals = len(dec)
    min_dec = dec.count("0")
    s = fixed(float(n), decimals, grouped)
    if decimals > min_dec and DECIMAL in s:   # optional '#' decimals are trimmed
        ip, dp = s.split(DECIMAL)
        dp = dp.rstrip("0")
        dp = dp + "0" * max(0, min_dec - len(dp))
        s = ip + (DECIMAL + dp if dp else "")
    int_zeros = pat.split(".")[0].replace(",", "").count("0")
    if int_zeros == 0 and s.lstrip("-").startswith("0" + DECIMAL):
        s = s.replace("0" + DECIMAL, DECIMAL, 1)
    elif int_zeros == 0 and s in ("0", "-0"):
        s = ""
    return mask[:core.start()] + s + mask[core.end():]


def format_date(mask: str, v) -> str:
    if v in (None, ""):
        return ""
    if isinstance(v, str):
        mm = re.match(r"(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}):?(\d{2})?)?", v)
        if not mm:
            return v
        y, mo, d, hh, mi, ss = mm.groups()
        v = datetime(int(y), int(mo), int(d), int(hh or 0), int(mi or 0), int(ss or 0))
    if isinstance(v, date) and not isinstance(v, datetime):
        v = datetime(v.year, v.month, v.day)
    tokens = [("yyyy", "%Y"), ("yy", "%y"), ("mmmm", "%B"), ("mmm", "%b"), ("mm", "%m"),
              ("dddd", "%A"), ("ddd", "%a"), ("dd", "%d"), ("hh", "%H"), ("nn", "%M"), ("ss", "%S")]
    out, i, low = "", 0, mask.lower()
    while i < len(mask):
        for tok, py in tokens:
            if low.startswith(tok, i):
                out += v.strftime(py)
                i += len(tok)
                break
        else:
            ch = mask[i]
            if low.startswith("d", i):
                out += str(v.day)
            elif low.startswith("m", i):
                out += str(v.month)
            else:
                out += ch
            i += 1
    return out


def display(value, kind: str | None, fmt: str | None) -> str:
    """Apply a memo DisplayFormat (Kind fkNumeric/fkDateTime/fkText) to a value."""
    if value is None:
        return ""
    if kind == "fkNumeric" and fmt:
        if "%" in fmt:
            return delphi_format(fmt, value)
        return format_float(fmt, value)
    if kind == "fkDateTime" and fmt:
        return format_date(fmt, value)
    if isinstance(value, float):
        return general(value)
    if isinstance(value, str):
        mm = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})T00:00:00", value)
        if mm:   # bare DateTime field → ShortDateFormat
            return f"{mm.group(3)}/{mm.group(2)}/{mm.group(1)}"
    return str(value)
