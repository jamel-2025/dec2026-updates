"""FastReport (.fr3) layout engine.

Takes a report template and datasets (name -> list of rows) and produces positioned
pages (pixels at 96 dpi, the native FastReport unit). The output is independent of the
target format; ``html.py`` turns it into printable HTML.

Supported: report pages (paper size, margins, orientation, background picture), bands
(ReportTitle, PageHeader/Footer, Header/Footer, MasterData/DetailData, GroupHeader/Footer
with conditions, ReportSummary, Child), memos with expressions and display formats,
table objects with col/row spans, pictures, lines and shapes, page overflow.
"""
from __future__ import annotations

import logging
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import expr, fmt, picture

log = logging.getLogger("fr3")

MM = 96 / 25.4  # pixels per millimetre (FastReport works at 96 dpi)

BAND_TAGS = {
    "TfrxReportTitle", "TfrxReportSummary", "TfrxPageHeader", "TfrxPageFooter", "TfrxHeader",
    "TfrxFooter", "TfrxMasterData", "TfrxDetailData", "TfrxSubdetailData", "TfrxGroupHeader",
    "TfrxGroupFooter", "TfrxColumnHeader", "TfrxColumnFooter", "TfrxOverlay", "TfrxChild",
    "TfrxReportTitleBand", "TfrxDataBand",
}
DATA_BANDS = {"TfrxMasterData", "TfrxDetailData", "TfrxSubdetailData", "TfrxDataBand"}
SYSTEM_COLORS = {
    -16777208: "#000000", -16777211: "#ffffff", -16777201: "#f0f0f0", -16777198: "#000000",
    -16777200: "#a0a0a0", -16777212: "#ffffff", -16777203: "#0078d7", -16777202: "#ffffff",
}


# ----------------------------------------------------------------------------- output model
@dataclass
class Item:
    kind: str                     # text | image | rect | line
    x: float
    y: float
    w: float
    h: float
    text: str = ""
    style: dict[str, Any] = field(default_factory=dict)


@dataclass
class Page:
    width: float
    height: float
    background: str | None = None  # cached PNG name
    items: list[Item] = field(default_factory=list)


# ----------------------------------------------------------------------------- helpers
def _f(el: ET.Element, key: str, default: float = 0.0) -> float:
    v = el.get(key)
    try:
        return float(v) if v not in (None, "") else default
    except ValueError:
        return default


def color(v: str | None, default: str | None = "#000000") -> str | None:
    if v in (None, ""):
        return default
    try:
        n = int(v)
    except ValueError:
        named = {"clBlack": "#000000", "clWhite": "#ffffff", "clRed": "#ff0000", "clNone": None,
                 "clGray": "#808080", "clSilver": "#c0c0c0", "clNavy": "#000080", "clBlue": "#0000ff",
                 "clWindowText": "#000000", "clWindow": "#ffffff", "clBtnFace": "#f0f0f0"}
        return named.get(v, default)
    if n == 536870911 or n == 0x1FFFFFFF:  # clNone
        return None
    if n < 0:
        return SYSTEM_COLORS.get(n, "#000000")
    r, g, b = n & 0xFF, (n >> 8) & 0xFF, (n >> 16) & 0xFF
    return f"#{r:02x}{g:02x}{b:02x}"


def font_style(el: ET.Element, inherited: dict) -> dict:
    st = dict(inherited)
    if el.get("ParentFont") == "True":
        return st
    if el.get("Font.Name"):
        st["font_family"] = el.get("Font.Name")
    if el.get("Font.Height"):
        st["font_size"] = abs(_f(el, "Font.Height"))
    elif el.get("Font.Size"):
        st["font_size"] = _f(el, "Font.Size") * 96 / 72
    if el.get("Font.Color") is not None:
        st["color"] = color(el.get("Font.Color"))
    if el.get("Font.Style") is not None:
        bits = int(_f(el, "Font.Style"))
        st["bold"], st["italic"], st["underline"], st["strike"] = bool(bits & 1), bool(bits & 2), bool(bits & 4), bool(bits & 8)
    return st


def box_style(el: ET.Element) -> dict:
    typ = int(_f(el, "Frame.Typ"))
    st: dict[str, Any] = {}
    if typ:
        st["frame"] = {
            "left": bool(typ & 1), "right": bool(typ & 2), "top": bool(typ & 4), "bottom": bool(typ & 8),
            "width": _f(el, "Frame.Width", 1.0),
            "color": color(el.get("Frame.Color")) or "#000000",
            "style": {"fsDash": "dashed", "fsDot": "dotted", "fsDouble": "double"}.get(el.get("Frame.Style", ""), "solid"),
        }
    fill = el.get("Fill.BackColor") or el.get("Color")
    if fill is not None:
        c = color(fill, None)
        if c:
            st["fill"] = c
    return st


# ----------------------------------------------------------------------------- data context
class DataContext(expr.Context):
    def __init__(self, datasets: dict[str, list[dict]], variables: dict[str, Any]):
        self.datasets = {k.lower(): v for k, v in datasets.items()}
        self.pos: dict[str, int] = {}
        self.variables = {k.lower(): v for k, v in variables.items()}
        self.agg_scope: list[tuple[str, list[int]]] = []   # (dataset, row indexes) for aggregates
        self.band_ds: dict[str, str] = {}                     # data band name -> dataset (summary aggregates)
        self.missing: set[str] = set()

    def row(self, ds: str) -> dict | None:
        rows = self.datasets.get(ds.lower())
        if not rows:
            return None
        i = self.pos.get(ds.lower(), 0)
        return rows[i] if 0 <= i < len(rows) else None

    def field(self, ds: str, name: str):
        r = self.row(ds)
        if r is None:
            if ds.lower() not in self.datasets:
                self.missing.add(f"{ds}")
            return None
        if name in r:
            return r[name]
        low = name.lower()
        for k, v in r.items():
            if k.lower() == low:
                return v
        self.missing.add(f'{ds}."{name}"')
        return None

    def var(self, name: str):
        return self.variables.get(name.lower())

    def aggregate(self, kind, fn, band):
        ds, idxs = self.agg_scope[-1] if self.agg_scope else ("", [])
        if not ds and band and band.lower() in self.band_ds:     # report summary: whole dataset of the band
            ds = self.band_ds[band.lower()]
            idxs = list(range(len(self.datasets.get(ds.lower()) or [])))
        if not ds:
            return 0
        key = ds.lower()
        saved = self.pos.get(key, 0)
        vals = []
        for i in idxs:
            self.pos[key] = i
            v = fn()
            if kind == "count":
                vals.append(1)
            else:
                n = fmt.to_number(v)
                if n is not None:
                    vals.append(n)
        self.pos[key] = saved
        if kind in ("sum", "count"):
            return sum(vals)
        if not vals:
            return 0
        return {"avg": sum(vals) / len(vals), "min": min(vals), "max": max(vals)}[kind]


# ----------------------------------------------------------------------------- engine
class Report:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.root = ET.parse(self.path).getroot()

    @property
    def datasets(self) -> list[str]:
        return sorted({el.get("DataSetName") for el in self.root.iter() if el.get("DataSetName")})

    @property
    def fields(self) -> set[str]:
        out = set()
        for el in self.root.iter():
            for part_is_expr, s in expr.split_text(el.get("Text", "")):
                if part_is_expr:
                    out.add(s)
        return out

    def render(self, datasets: dict[str, list[dict]], variables: dict[str, Any] | None = None,
               whole_amounts: bool = True, texts: dict[str, str] | None = None,
               hidden_pages: set[str] | None = None, bindings: dict[str, str] | None = None,
               hide_token: str = "", colors: dict | None = None) -> list[Page]:
        """whole_amounts: amounts printed in whole dinars (official forms state dinars without
        centimes); rates and ratios keep their decimals."""
        run = _Run(self, datasets, variables or {}, whole_amounts)
        run.texts = texts or {}               # object name -> text (what report scripts assign)
        run.hidden = hidden_pages or set()    # report pages hidden by the Delphi code
        run.bindings = bindings or {}         # object name -> expression text (corrected data bindings)
        run.hide_token = hide_token.upper()   # memos containing this token are hidden (CleanTAPFromReport)
        run.colors = colors or {}             # object name -> font colour, or a style override dict
        return run.run()


RATE_FIELD = re.compile(r"taux|ratio|pourcent|prorata|coef|marge|\"PU(?=[A-Z])", re.I)


def whole_mask(mask: str | None, expression: str) -> str | None:
    """Drop the decimals of an amount format ('%2.2n' -> '%2.0n', '#,##0.00' -> '#,##0'),
    leaving rates and ratios untouched."""
    if not mask or RATE_FIELD.search(expression):
        return mask
    if "%" in mask:
        return re.sub(r"%(-?\d*)\.\d+([nmf])", lambda m: f"%{m.group(1)}.0{m.group(2)}", mask)
    return re.sub(r"\.[0#]+", "", mask)


class _Run:
    def __init__(self, report: Report, datasets, variables, whole_amounts: bool = True):
        self.whole = whole_amounts
        self.texts: dict[str, str] = {}
        self.hidden: set[str] = set()
        self.bindings: dict[str, str] = {}
        self.hide_token = ""
        self.colors: dict = {}
        self.report = report
        self.ctx = DataContext(datasets, variables)
        self.pages: list[Page] = []
        self.ctx.variables.setdefault("date", None)

    # -- paging
    def run(self) -> list[Page]:
        for dp in self.report.root.iter("TfrxReportPage"):
            if dp.get("Visible") == "False" or dp.get("Name") in self.hidden:
                continue
            self._design_page(dp)
        total = len(self.pages)
        # second pass for <TotalPages#>: re-render page numbers only if used
        for p in self.pages:
            for it in p.items:
                if "\x00TOTALPAGES\x00" in it.text:
                    it.text = it.text.replace("\x00TOTALPAGES\x00", str(total))
        return self.pages

    def _design_page(self, dp: ET.Element):
        landscape = dp.get("Orientation") == "poLandscape"
        pw, ph = _f(dp, "PaperWidth", 297 if landscape else 210), _f(dp, "PaperHeight", 210 if landscape else 297)
        self.pw, self.ph = pw * MM, ph * MM
        self.ml, self.mt = _f(dp, "LeftMargin", 10) * MM, _f(dp, "TopMargin", 10) * MM
        self.mb = _f(dp, "BottomMargin", 10) * MM
        bg = picture.to_png(dp.get("BackPicture.PropData", ""))
        self.bg = bg[0] if bg else None
        self.page_font = font_style(dp, {"font_family": "Arial", "font_size": 13.0, "color": "#000000"})

        children = list(dp)
        bands = [c for c in children if c.tag in BAND_TAGS]
        self.loose = [c for c in children if c.tag not in BAND_TAGS]
        self.page_header = [b for b in bands if b.tag == "TfrxPageHeader"]
        self.page_footer = [b for b in bands if b.tag == "TfrxPageFooter"]
        self.overlays = [b for b in bands if b.tag == "TfrxOverlay"]
        flow = sorted((b for b in bands if b.tag not in ("TfrxPageHeader", "TfrxPageFooter", "TfrxOverlay")),
                      key=lambda b: _f(b, "Top"))
        self.footer_h = sum(_f(b, "Height") for b in self.page_footer)
        for b in bands:
            if b.tag in DATA_BANDS and b.get("DataSetName"):
                self.ctx.band_ds[b.get("Name", "").lower()] = b.get("DataSetName")
        # FastReport prints the report title above the page header unless TitleBeforeHeader = False
        self.title_first = [b for b in flow if b.tag == "TfrxReportTitle"] if dp.get("TitleBeforeHeader") != "False" else []
        flow = [b for b in flow if b not in self.title_first]
        self._new_page()

        i = 0
        while i < len(flow):
            b = flow[i]
            if b.tag in ("TfrxGroupHeader", "TfrxHeader") or b.tag in DATA_BANDS:
                j = i
                while j < len(flow) and flow[j].tag in ("TfrxGroupHeader", "TfrxHeader"):
                    j += 1
                if j < len(flow) and flow[j].tag in DATA_BANDS:
                    k = j + 1
                    while k < len(flow) and flow[k].tag in ("TfrxGroupFooter", "TfrxFooter", "TfrxChild",
                                                            "TfrxDetailData", "TfrxSubdetailData"):
                        k += 1
                    self._data_block(flow[i:j], flow[j], flow[j + 1:k])
                    i = k
                    continue
            if b.tag in ("TfrxReportSummary",):
                self.ctx.agg_scope.append(("", []))
            self._emit(b)
            if b.tag in ("TfrxReportSummary",):
                self.ctx.agg_scope.pop()
            i += 1
        self._finish_page()

    def _new_page(self):
        self.page = Page(self.pw, self.ph, self.bg)
        self.pages.append(self.page)
        self.ctx.variables["page#"] = len(self.pages)
        self.ctx.variables["page"] = len(self.pages)
        self.ctx.variables["totalpages#"] = "\x00TOTALPAGES\x00"
        self.y = self.mt
        for o in self.loose:
            self._object(o, self.ml, self.mt, self.page_font)
        titles, self.title_first = self.title_first, []
        for b in titles:
            self._emit(b, check=False)
        for b in self.page_header:
            self._emit(b, check=False)

    def _finish_page(self):
        y = self.ph - self.mb - self.footer_h
        for b in self.page_footer:
            self._place(b, y)
            y += _f(b, "Height")
        for b in self.overlays:
            self._place(b, self.mt + _f(b, "Top"))

    # -- band emission
    def _emit(self, band: ET.Element, check: bool = True):
        if band.get("Visible") == "False":
            return
        h = _f(band, "Height")
        if check and self.y + h > self.ph - self.mb - self.footer_h + 0.5 and self.y > self.mt + 1:
            self._finish_page()
            self._new_page()
        if band.get("StartNewPage") == "True" and self.y > self.mt + 1 + sum(_f(b, "Height") for b in self.page_header):
            self._finish_page()
            self._new_page()
        self._place(band, self.y)
        self.y += h

    def _place(self, band: ET.Element, y: float):
        st = box_style(band)
        x0 = self.ml + _f(band, "Left")
        if st:
            self.page.items.append(Item("rect", x0, y, _f(band, "Width"), _f(band, "Height"), style=st))
        for o in band:
            self._object(o, x0, y, self.page_font)

    def _data_block(self, headers, data_band, footers):
        ds = data_band.get("DataSetName") or ""
        rows = self.ctx.datasets.get(ds.lower())
        if rows is None:
            n = int(_f(data_band, "RowCount"))
            rows = [{}] * n
            if n:
                self.ctx.datasets[ds.lower() or "__rows__"] = rows
                ds = ds or "__rows__"
        group_headers = [h for h in headers if h.tag == "TfrxGroupHeader"]
        plain_headers = [h for h in headers if h.tag == "TfrxHeader"]
        group_footers = [f for f in footers if f.tag == "TfrxGroupFooter"]
        plain_footers = [f for f in footers if f.tag == "TfrxFooter"]
        details = [f for f in footers if f.tag in ("TfrxChild", "TfrxDetailData", "TfrxSubdetailData")]
        if not rows:
            if data_band.get("PrintIfDetailEmpty") == "True":
                for h in plain_headers:
                    self._emit(h)
            return
        key = ds.lower()
        for h in plain_headers:
            self._emit(h)
        current: list[Any] = [object()] * len(group_headers)
        group_rows: list[list[int]] = [[] for _ in group_headers]

        def close_groups(from_level: int):
            # footers are nested in reverse order of headers: GH0 GH1 MD GF1 GF0
            for lvl in range(len(group_headers) - 1, from_level - 1, -1):
                fi = len(group_headers) - 1 - lvl
                if fi < len(group_footers) and group_rows[lvl]:
                    self.ctx.agg_scope.append((ds, group_rows[lvl]))
                    saved = self.ctx.pos.get(key, 0)
                    self.ctx.pos[key] = group_rows[lvl][-1]
                    self._emit(group_footers[fi])
                    self.ctx.pos[key] = saved
                    self.ctx.agg_scope.pop()
                group_rows[lvl] = []

        for idx in range(len(rows)):
            self.ctx.pos[key] = idx
            for lvl, gh in enumerate(group_headers):
                cond = gh.get("Condition", "")
                try:
                    val = expr.evaluate(cond, self.ctx) if cond else None
                except Exception:
                    val = None
                if val != current[lvl]:
                    if idx:
                        self.ctx.pos[key] = idx - 1
                        close_groups(lvl)
                        self.ctx.pos[key] = idx
                    for l2 in range(lvl, len(group_headers)):
                        c2 = group_headers[l2].get("Condition", "")
                        try:
                            current[l2] = expr.evaluate(c2, self.ctx) if c2 else None
                        except Exception:
                            current[l2] = None
                        self._emit(group_headers[l2])
                    break
            for g in group_rows:
                g.append(idx)
            self._emit(data_band)
            for d in details:
                self._emit(d)
        self.ctx.pos[key] = len(rows) - 1
        close_groups(0)
        self.ctx.agg_scope.append((ds, list(range(len(rows)))))
        for f in plain_footers:
            self._emit(f)
        self.ctx.agg_scope.pop()

    # -- objects
    def _object(self, o: ET.Element, x0: float, y0: float, parent_font: dict):
        if o.get("Visible") == "False":
            return
        tag = o.tag
        x, y, w, h = x0 + _f(o, "Left"), y0 + _f(o, "Top"), _f(o, "Width"), _f(o, "Height")
        if tag in ("TfrxMemoView", "TfrxSysMemoView", "TfrxDMPMemoView", "TfrxRichView"):
            self._memo(o, x, y, w, h, parent_font)
        elif tag == "TfrxTableObject":
            self._table(o, x, y, parent_font)
        elif tag == "TfrxPictureView":
            img = picture.to_png(o.get("Picture.PropData", ""))
            if img:
                self.page.items.append(Item("image", x, y, w, h, text=img[0], style={
                    "stretch": o.get("Stretch", "True") != "False",
                    "keep_aspect": o.get("KeepAspectRatio", "True") != "False",
                    "center": o.get("Center") == "True", **box_style(o)}))
        elif tag == "TfrxLineView":
            self.page.items.append(Item("line", x, y, w, h, style={
                "width": _f(o, "Frame.Width", 1.0), "color": color(o.get("Frame.Color")) or "#000000",
                "diagonal": o.get("Diagonal") == "True"}))
        elif tag == "TfrxShapeView":
            st = box_style(o)
            st.setdefault("frame", {"left": True, "right": True, "top": True, "bottom": True, "width": _f(o, "Frame.Width", 1.0),
                                    "color": color(o.get("Frame.Color")) or "#000000", "style": "solid"})
            st["shape"] = o.get("Shape", "skRectangle")
            self.page.items.append(Item("rect", x, y, w, h, style=st))
        elif tag in BAND_TAGS:
            return
        else:
            for c in o:   # containers (e.g. TfrxCrossView not supported: render children if any)
                self._object(c, x, y, parent_font)

    def memo_text(self, o: ET.Element) -> str:
        if o.get("Name") in self.texts:
            return self.texts[o.get("Name")]
        raw = self.bindings.get(o.get("Name"), o.get("Text", ""))
        if not raw and o.get("DataField"):
            raw = f'[{o.get("DataSetName", "")}."{o.get("DataField")}"]'
        kind, mask = o.get("DisplayFormat.Kind"), o.get("DisplayFormat.FormatStr")
        hide_zeros = o.get("HideZeros") == "True"
        out = []
        for is_expr, s in expr.split_text(raw):
            if not is_expr:
                out.append(s)
                continue
            try:
                v = expr.evaluate(s, self.ctx)
            except Exception as e:  # keep rendering, report the faulty expression
                log.warning("fr3 %s: expression %r: %s", self.report.path.name, s, e)
                self.ctx.missing.add(f"[{s}]")
                v = None
            if hide_zeros and fmt.to_number(v) == 0:
                v = ""
            if isinstance(v, str) and kind != "fkDateTime":
                out.append(fmt.display(v, None, None))
            else:
                m = whole_mask(mask, s) if self.whole and kind == "fkNumeric" else mask
                out.append(fmt.display(v, kind, m) if v is not None else "")
        return "".join(out).replace("\r\n", "\n").replace("\r", "\n")

    def _memo(self, o, x, y, w, h, parent_font, extra: dict | None = None):
        if self.hide_token and (self.hide_token in (o.get("Text") or "").upper()
                                or self.hide_token in (o.get("DataField") or "").upper()):
            return                                # uMain.CleanTAPFromReport: memo cleared and hidden
        st = font_style(o, parent_font)
        st.update(box_style(o))
        st["halign"] = {"haRight": "right", "haCenter": "center", "haBlock": "justify"}.get(o.get("HAlign", ""), "left")
        st["valign"] = {"vaCenter": "center", "vaBottom": "bottom"}.get(o.get("VAlign", ""), "top")
        st["wrap"] = o.get("WordWrap", "True") != "False"
        st["gap_x"] = _f(o, "GapX", 2.0)
        st["gap_y"] = _f(o, "GapY", 1.0)
        st["line_spacing"] = _f(o, "LineSpacing", 2.0)
        st["rtl"] = o.get("RTLReading") == "True"
        st["rotation"] = int(_f(o, "Rotation"))
        st["html"] = o.get("AllowHTMLTags") == "True"
        st["underlines"] = o.get("Underlines") == "True"
        if extra:
            st.update(extra)
        override = self.colors.get(o.get("Name"))
        if isinstance(override, str):
            st["color"] = override
        elif override:                                  # style override: colour, size, bold, alignment, frame sides
            frame = override.get("frame")
            st.update({k: v for k, v in override.items() if k != "frame"})
            if frame:
                base = st.get("frame") or {"width": 1.0, "color": "#0000ff", "style": "solid"}
                st["frame"] = {**base, **frame}
        self.page.items.append(Item("text", x, y, w, h, text=self.memo_text(o), style=st))

    def _table(self, t: ET.Element, x: float, y: float, parent_font: dict):
        cols = [_f(c, "Width") for c in t if c.tag == "TfrxTableColumn"]
        rows = [r for r in t if r.tag == "TfrxTableRow"]
        heights = [_f(r, "Height") for r in rows]
        xs = [x]
        for cw in cols:
            xs.append(xs[-1] + cw)
        ys = [y]
        for rh in heights:
            ys.append(ys[-1] + rh)
        covered: set[tuple[int, int]] = set()
        tfont = font_style(t, parent_font)
        for ri, r in enumerate(rows):
            cells = [c for c in r if c.tag == "TfrxTableCell"]
            for ci, cell in enumerate(cells):
                if (ri, ci) in covered or ci >= len(cols):
                    continue
                cs, rs = max(1, int(_f(cell, "ColSpan", 1))), max(1, int(_f(cell, "RowSpan", 1)))
                cs, rs = min(cs, len(cols) - ci), min(rs, len(rows) - ri)
                for dr in range(rs):
                    for dc in range(cs):
                        covered.add((ri + dr, ci + dc))
                cx, cy = xs[ci], ys[ri]
                self._memo(cell, cx, cy, xs[ci + cs] - cx, ys[ri + rs] - cy, tfont)
