"""Decode FastReport/Delphi picture blobs (``Picture.PropData``, ``BackPicture.PropData``).

The hex blob is a Delphi DefineBinaryProperty stream (TPicture: class name, size, image
bytes). Rather than depend on the exact framing, we locate the first known image
signature and let Pillow decode from there. Converted PNGs are cached on disk."""
from __future__ import annotations

import hashlib
import io
from pathlib import Path

from PIL import Image

from ..core import config

_SIGNATURES = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"GIF8", b"BM")


def _find_image(blob: bytes) -> bytes | None:
    best = None
    for sig in _SIGNATURES:
        i = blob.find(sig, 0, 256)
        if i >= 0 and (best is None or i < best):
            best = i
    return blob[best:] if best is not None else None


def to_png(prop_hex: str) -> tuple[str, int, int] | None:
    """Return (cache file name, width, height) of the decoded picture as PNG."""
    if not prop_hex:
        return None
    key = hashlib.sha1(prop_hex.encode("ascii", "ignore")).hexdigest()[:20]
    out = config.CACHE_DIR / "fr3img" / f"{key}.png"
    if out.exists():
        with Image.open(out) as im:
            return out.name, im.width, im.height
    try:
        raw = bytes.fromhex(prop_hex)
    except ValueError:
        return None
    data = _find_image(raw)
    if data is None:
        return None
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception:
        return None
    out.parent.mkdir(parents=True, exist_ok=True)
    if im.mode not in ("RGB", "RGBA", "L", "LA", "P"):
        im = im.convert("RGB")
    im.save(out, "PNG", optimize=True)
    return out.name, im.width, im.height


def cache_path(name: str) -> Path | None:
    p = config.CACHE_DIR / "fr3img" / Path(name).name
    return p if p.is_file() else None
