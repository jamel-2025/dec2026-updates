"""Excel export of rendered report pages — same principle as FastReport's TfrxXLSXExport used by the
Delphi forms (« Exp Excel »): every positioned text object is placed on a grid built from the object
edges; spans become merged cells; fonts, alignment, borders and fills are kept; amounts are written
as numbers so that the sheet can be computed on.
"""
from __future__ import annotations

import re
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .engine import Item, Page

SNAP = 3.0                      # px: object edges closer than this share a grid line
NUMBER = re.compile(r"^-?(?:\d{1,3}(?:[   ]\d{3})+|\d+)(?:,\d+)?$")


def _edges(values: list[float]) -> list[float]:
    out: list[float] = []
    for v in sorted(values):
        if not out or v - out[-1] > SNAP:
            out.append(v)
    return out


def _index(edges: list[float], v: float) -> int:
    best = 0
    for i, e in enumerate(edges):
        if abs(e - v) < abs(edges[best] - v):
            best = i
    return best


def _value(text: str):
    t = text.strip()
    if NUMBER.match(t) and not (len(t) > 1 and t.startswith("0") and not t.startswith("0,")):
        n = t.replace(" ", "").replace(" ", "").replace(" ", "").replace(",", ".")
        try:
            v = float(n)
        except ValueError:
            return text, None
        decimals = len(n.split(".")[1]) if "." in n else 0
        return (int(v) if decimals == 0 else v), ("#,##0" if decimals == 0 else "#,##0." + "0" * decimals)
    return text, None


def _color(c: str | None) -> str | None:
    if not c or not c.startswith("#") or len(c) not in (4, 7):
        return None
    c = c[1:]
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    return "FF" + c.upper()


def _side(fr: dict, name: str) -> Side:
    if not fr or not fr.get(name):
        return Side()
    w = fr.get("width", 1.0)
    return Side(style="medium" if w >= 2 else "thin", color=_color(fr.get("color")) or "FF000000")


def pages_to_xlsx(pages: list[Page], title: str = "Rapport") -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\\/*?:\[\]]", " ", title)[:31] or "Rapport"
    ws.sheet_view.showGridLines = False
    texts: list[tuple[float, Item]] = []
    offset = 0.0
    for p in pages:
        for it in p.items:
            if it.kind == "text" and it.w > 0 and it.h > 0:
                texts.append((offset, it))
        offset += p.height + 20
    if not texts:
        bio = BytesIO()
        wb.save(bio)
        return bio.getvalue()
    xs = _edges([it.x for _, it in texts] + [it.x + it.w for _, it in texts])
    ys = _edges([o + it.y for o, it in texts] + [o + it.y + it.h for o, it in texts])
    for i in range(len(xs) - 1):
        ws.column_dimensions[get_column_letter(i + 1)].width = max((xs[i + 1] - xs[i]) / 7.0, 0.6)
    for j in range(len(ys) - 1):
        ws.row_dimensions[j + 1].height = max((ys[j + 1] - ys[j]) * 0.75, 3)
    used: set[tuple[int, int]] = set()
    for o, it in sorted(texts, key=lambda t: (t[0] + t[1].y, t[1].x)):
        c1, c2 = _index(xs, it.x) + 1, max(_index(xs, it.x + it.w), _index(xs, it.x) + 1)
        r1, r2 = _index(ys, o + it.y) + 1, max(_index(ys, o + it.y + it.h), _index(ys, o + it.y) + 1)
        if (r1, c1) in used:
            continue
        s = it.style
        cell = ws.cell(row=r1, column=c1)
        text = re.sub(r"<[^>]+>", "", it.text) if s.get("html") else it.text
        value, fmt = _value(text)
        if text.strip():
            cell.value = value
        if fmt:
            cell.number_format = fmt
        cell.font = Font(name=s.get("font_family", "Arial"), size=round(s.get("font_size", 13.0) * 0.75, 1),
                         bold=bool(s.get("bold")), italic=bool(s.get("italic")), underline="single" if s.get("underline") else None,
                         color=_color(s.get("color")))
        cell.alignment = Alignment(horizontal={"left": "left", "center": "center", "right": "right", "justify": "justify"}.get(s.get("halign", "left"), "left"),
                                   vertical={"top": "top", "center": "center", "bottom": "bottom"}.get(s.get("valign", "top"), "top"),
                                   wrap_text=bool(s.get("wrap", True)), readingOrder=2 if s.get("rtl") else 0)
        fill = _color(s.get("fill"))
        fr = s.get("frame") or {}
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                used.add((r, c))
                cc = ws.cell(row=r, column=c)
                if fill:
                    cc.fill = PatternFill("solid", fgColor=fill)
                if fr:
                    cc.border = Border(left=_side(fr, "left") if c == c1 else Side(), right=_side(fr, "right") if c == c2 else Side(),
                                       top=_side(fr, "top") if r == r1 else Side(), bottom=_side(fr, "bottom") if r == r2 else Side())
        if r2 > r1 or c2 > c1:
            ws.merge_cells(start_row=r1, start_column=c1, end_row=r2, end_column=c2)
    ws.page_setup.fitToWidth = 1
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToHeight = 0
    bio = BytesIO()
    wb.save(bio)
    return bio.getvalue()
