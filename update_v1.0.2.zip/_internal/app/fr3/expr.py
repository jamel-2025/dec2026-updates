"""FastReport expression evaluation.

Memo texts embed expressions between ``[`` and ``]``.  Expressions use FastScript
(Pascal) syntax: ``<DS."field">``, ``DS."field"``, ``<Page#>``, ``IIF(a, b, c)``,
``FormatFloat('#,##0.00', x)``, ``SUM(<DS."f">, MasterData1)``, ``=``, ``<>``, ``and``…
They are translated token by token to a Python expression evaluated with no builtins.
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime
from typing import Any, Callable

from . import fmt

_TOK = re.compile(r"""
    (?P<ws>\s+)
  | (?P<str>'(?:[^']|'')*')
  | (?P<field><\s*(?P<fds>[A-Za-z_][\w ]*?)\s*\.\s*"(?P<fname>[^"]*)"\s*>)
  | (?P<bfield>(?P<bds>[A-Za-z_]\w*)\."(?P<bname>[^"]*)")
  | (?P<var><(?P<vname>[A-Za-z_][\w#]*)>)
  | (?P<num>\d+\.\d+|\d+)
  | (?P<op><>|<=|>=|:=|[-+*/=<>(),])
  | (?P<ident>[A-Za-z_]\w*\#?)
  | (?P<other>.)
""", re.VERBOSE)

AGGREGATES = {"sum", "count", "avg", "min", "max"}
KEYWORDS = {"and": " and ", "or": " or ", "not": " not ", "div": "//", "mod": "%",
            "true": "True", "false": "False", "nil": "None", "null": "None"}


def _num(v):
    n = fmt.to_number(v)
    return 0 if n is None else n


def _iif(c, a, b):
    return a if c else b


def _copy(s, i, n):
    s = "" if s is None else str(s)
    i = int(i)
    return s[i - 1:i - 1 + int(n)]


def _pos(sub, s):
    return str(s or "").find(str(sub)) + 1


def _round(x):
    x = _num(x)
    return int(math.floor(x + 0.5)) if x >= 0 else -int(math.floor(-x + 0.5))


def _date_to_str(d):
    return fmt.format_date("dd/mm/yyyy", d)


FUNCTIONS: dict[str, Callable] = {
    "iif": _iif,
    "formatfloat": lambda m, v: fmt.format_float(m, v),
    "format": lambda s, args: fmt.delphi_format(s, args[0] if isinstance(args, list) and args else args),
    "formatdatetime": lambda m, v: fmt.format_date(m, v),
    "datetostr": _date_to_str,
    "copy": _copy,
    "length": lambda s: len("" if s is None else str(s)),
    "uppercase": lambda s: str(s or "").upper(),
    "lowercase": lambda s: str(s or "").lower(),
    "trim": lambda s: str(s or "").strip(),
    "inttostr": lambda x: str(int(_num(x))),
    "floattostr": lambda x: fmt.general(_num(x)),
    "strtofloat": lambda s: float(_num(s)),
    "strtoint": lambda s: int(_num(s)),
    "round": _round,
    "trunc": lambda x: int(_num(x)),
    "int": lambda x: float(int(_num(x))),
    "frac": lambda x: _num(x) - int(_num(x)),
    "abs": lambda x: abs(_num(x)),
    "pos": _pos,
    "date": lambda: date.today(),
    "now": lambda: datetime.now(),
    "vartostr": lambda v: "" if v is None else str(v),
}


class Context:
    """Supplies data to expressions. The engine subclasses / fills it."""

    def field(self, ds: str, name: str) -> Any:
        return None

    def var(self, name: str) -> Any:
        return None

    def aggregate(self, kind: str, fn: Callable[[], Any], band: str | None) -> Any:
        return None


def translate(src: str) -> str:
    toks = [(m.lastgroup, m) for m in _TOK.finditer(src) if m.lastgroup != "ws"]
    out: list[str] = []
    i = 0
    while i < len(toks):
        kind, m = toks[i]
        t = m.group()
        if kind == "str":
            out.append(repr(t[1:-1].replace("''", "'")))
        elif kind == "field":
            out.append(f"_f({m.group('fds').strip()!r},{m.group('fname')!r})")
        elif kind == "bfield":
            out.append(f"_f({m.group('bds')!r},{m.group('bname')!r})")
        elif kind == "var":
            out.append(f"_v({m.group('vname')!r})")
        elif kind == "num":
            out.append(t)
        elif kind == "op":
            out.append({"=": "==", "<>": "!=", ":=": "=", "/": "/"}.get(t, t))
        elif kind == "ident":
            low = t.lower()
            nxt = toks[i + 1][1].group() if i + 1 < len(toks) else ""
            if low in AGGREGATES and nxt == "(":
                # SUM(expr [, Band [, flags]])  ->  _agg('sum', lambda: (expr), 'Band')
                depth, j, args, cur = 0, i + 1, [], []
                while j < len(toks):
                    tj = toks[j][1].group()
                    if tj == "(":
                        depth += 1
                        if depth == 1:
                            j += 1
                            continue
                    elif tj == ")":
                        depth -= 1
                        if depth == 0:
                            break
                    if tj == "," and depth == 1:
                        args.append(cur)
                        cur = []
                    else:
                        cur.append(toks[j][1].group())
                    j += 1
                args.append(cur)
                inner = translate(" ".join(args[0]))
                band = "".join(args[1]).strip() if len(args) > 1 else ""
                out.append(f"_agg({low!r}, lambda: ({inner}), {band!r})")
                i = j + 1
                continue
            if low in KEYWORDS:
                out.append(KEYWORDS[low])
            elif low in FUNCTIONS:
                out.append(f"_fn[{low!r}]")
            else:
                out.append(f"_v({t!r})")
        else:
            out.append(t)
        i += 1
    return "".join(out).strip()


_cache: dict[str, Any] = {}


def evaluate(src: str, ctx: Context) -> Any:
    code = _cache.get(src)
    if code is None:
        code = compile(translate(src), "<fr3>", "eval")
        _cache[src] = code
    ns = {"__builtins__": {}, "_f": ctx.field, "_v": ctx.var, "_fn": FUNCTIONS, "_agg": ctx.aggregate}
    return eval(code, ns)  # noqa: S307 — code comes only from translate()


def split_text(text: str) -> list[tuple[bool, str]]:
    """Split a memo text into literal parts and [expressions] (nested brackets allowed)."""
    parts: list[tuple[bool, str]] = []
    buf, depth, expr = "", 0, ""
    in_str = False
    for ch in text:
        if depth == 0:
            if ch == "[":
                if buf:
                    parts.append((False, buf))
                    buf = ""
                depth, expr = 1, ""
            else:
                buf += ch
            continue
        if ch == "'" and depth:
            in_str = not in_str
        if not in_str:
            if ch == "[":
                depth += 1
            elif ch == "]":
                depth -= 1
                if depth == 0:
                    parts.append((True, expr))
                    continue
        expr += ch
    if depth:
        buf += "[" + expr
    if buf:
        parts.append((False, buf))
    return parts
