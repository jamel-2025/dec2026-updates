"""Routes FastAPI pour le module de Rapprochement Fiscal & Comptable et Détection d'Anomalies."""
from __future__ import annotations

import io
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, File, HTTPException, Query, UploadFile
from fastapi.responses import HTMLResponse, Response

from ..services import rapprochement_service

router = APIRouter(prefix="/api/rapprochement", tags=["Rapprochement Fiscal & Comptable"])


@router.get("/years")
def get_years(code: str = Query(..., description="Code du dossier société")):
    """Retourne les exercices fiscaux disponibles."""
    if not code:
        raise HTTPException(400, "Code dossier requis")
    years = rapprochement_service.get_available_years(code)
    return {"years": years}


@router.get("/data")
def get_rapprochement_data(
    code: str = Query(..., description="Code du dossier"),
    annee: str = Query(..., description="Année fiscale (ex: 2024)")
):
    """Retourne l'état complet du rapprochement pour l'année donnée."""
    if not code or not annee:
        raise HTTPException(400, "Code dossier et année requis")
    data = rapprochement_service.get_annual_rapprochement(code, annee)
    return data


@router.post("/save")
def save_rapprochement_data(
    code: str = Query(...),
    annee: str = Query(...),
    payload: Dict[str, Any] = ...
):
    """Enregistre les données comptables et notes d'audit."""
    if not code or not annee:
        raise HTTPException(400, "Code dossier et année requis")
    months = payload.get("mois", [])
    if not isinstance(months, list):
        raise HTTPException(400, "Liste des mois invalide")
    success = rapprochement_service.save_bulk_comptable(code, annee, months)
    return {"status": "ok", "saved": success}


@router.get("/trends")
def get_trends(code: str = Query(...)):
    """Retourne l'historique d'évolution multi-annuelle."""
    if not code:
        raise HTTPException(400, "Code dossier requis")
    trends = rapprochement_service.get_multiyear_trends(code)
    return {"trends": trends}


@router.get("/range")
def get_range_analysis(
    code: str = Query(...),
    start: str = Query(...),
    end: str = Query(...)
):
    """Retourne l'analyse pluriannuelle comparative de l'année A à l'année B."""
    if not code or not start or not end:
        raise HTTPException(400, "Code dossier, année début et année fin requis")
    data = rapprochement_service.get_multiyear_range_analysis(code, start, end)
    res = dict(data)
    res["ok"] = True
    res["data"] = data
    return res


@router.get("/export-excel")
def export_excel(
    code: str = Query(...),
    annee: str = Query(...)
):
    """Exporte le tableau de cadrage complet au format Excel officiel en flux direct."""
    if not code or not annee:
        raise HTTPException(400, "Code dossier et année requis")
    content = rapprochement_service.export_rapprochement_excel(code, annee)
    filename = f"Cadrage_Fiscal_Comptable_{code}_{annee}.xlsx"
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )


@router.post("/export-excel-file")
def export_excel_file(
    code: str = Query(...),
    annee: str = Query(...),
    ouvrir: bool = Query(True)
):
    """Génère le fichier Excel de cadrage sur le disque et l'ouvre directement pour l'utilisateur."""
    import os
    from pathlib import Path
    from ..services.exports import rapports_dir

    if not code or not annee:
        raise HTTPException(400, "Code dossier et année requis")

    content = rapprochement_service.export_rapprochement_excel(code, annee)

    folder = rapports_dir(code) / str(annee) / "Cadrage"
    folder.mkdir(parents=True, exist_ok=True)
    filename = f"Cadrage_Fiscal_{annee}_{code}.xlsx"
    out_path = folder / filename
    out_path.write_bytes(content)

    if ouvrir and hasattr(os, "startfile"):
        try:
            os.startfile(out_path)
        except Exception:
            try:
                os.startfile(folder)
            except Exception:
                pass

    rel = out_path.relative_to(rapports_dir(code)).as_posix()
    return {
        "ok": True,
        "path": str(out_path),
        "filename": filename,
        "rel": rel,
        "url": f"/api/dossiers/{code}/rapports/fichier?rel={rel}"
    }


@router.post("/import-balance")
async def import_balance_excel(
    code: str = Query(...),
    annee: str = Query(...),
    file: UploadFile = File(...)
):
    """Importe une balance comptable ou grand-livre Excel pour renseigner automatiquement les comptes."""
    import openpyxl
    content = await file.read()
    try:
        wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
    except Exception as e:
        raise HTTPException(400, f"Format Excel invalide: {e}")

    ws = wb.active
    # Recherche des colonnes par mots-clés ou compte
    # Comptes visés : 70 (Ventes), 4457 (TVA Coll), 38/60 (Achats), 44566 (TVA Achats), 21 (Immo), 44562 (TVA Immo), 63 (Salaires), 4421 (IRG)
    compta_values = {
        "ca_comptable": 0.0,
        "tva_collectee_comptable": 0.0,
        "achats_comptable": 0.0,
        "tva_achats_comptable": 0.0,
        "immo_comptable": 0.0,
        "tva_immo_comptable": 0.0,
        "salaires_comptable": 0.0,
        "irg_comptable": 0.0,
    }

    def _val(c):
        if c is None:
            return 0.0
        try:
            return float(str(c).replace(" ", "").replace(",", "."))
        except Exception:
            return 0.0

    for row in ws.iter_rows(values_only=True):
        if not row or len(row) < 2:
            continue
        c0 = str(row[0] or "").strip()
        c1 = str(row[1] or "").strip()
        # Dernier chiffre de la ligne ou solde débiteur/créditeur
        amt = 0.0
        for cell in reversed(row):
            v = _val(cell)
            if v != 0.0:
                amt = abs(v)
                break

        full_txt = f"{c0} {c1}".lower()
        if c0.startswith("70") or "ventes" in full_txt or "chiffre d'affaires" in full_txt:
            compta_values["ca_comptable"] += amt
        elif c0.startswith("4457") or "tva collectée" in full_txt:
            compta_values["tva_collectee_comptable"] += amt
        elif c0.startswith(("38", "60", "61", "62")) or "achats" in full_txt:
            compta_values["achats_comptable"] += amt
        elif c0.startswith("44566") or "tva déductible" in full_txt and "immo" not in full_txt:
            compta_values["tva_achats_comptable"] += amt
        elif c0.startswith("21") or "immobilisations" in full_txt or "investissements" in full_txt or "matériel" in full_txt:
            compta_values["immo_comptable"] += amt
        elif c0.startswith("44562") or "tva sur immo" in full_txt or "tva immobilisations" in full_txt:
            compta_values["tva_immo_comptable"] += amt
        elif c0.startswith("63") or "charges de personnel" in full_txt or "salaires" in full_txt:
            compta_values["salaires_comptable"] += amt
        elif c0.startswith("4421") or "irg / salaires" in full_txt or "irg salaires" in full_txt:
            compta_values["irg_comptable"] += amt

    # Répartir sur 12 mois si annuel ou mois par mois
    # Si le total a été détecté, on répartit équitablement sur les mois avec G50 ou sur 12
    months_payload = []
    for m in range(1, 13):
        months_payload.append({
            "mois": m,
            "ca_comptable": round(compta_values["ca_comptable"] / 12.0, 2),
            "tva_collectee_comptable": round(compta_values["tva_collectee_comptable"] / 12.0, 2),
            "achats_comptable": round(compta_values["achats_comptable"] / 12.0, 2),
            "tva_achats_comptable": round(compta_values["tva_achats_comptable"] / 12.0, 2),
            "immo_comptable": round(compta_values["immo_comptable"] / 12.0, 2),
            "tva_immo_comptable": round(compta_values["tva_immo_comptable"] / 12.0, 2),
            "salaires_comptable": round(compta_values["salaires_comptable"] / 12.0, 2),
            "irg_comptable": round(compta_values["irg_comptable"] / 12.0, 2),
            "notes": "Importé depuis Balance Excel",
        })

    rapprochement_service.save_bulk_comptable(code, annee, months_payload)
    return {"status": "ok", "imported_totals": compta_values}
