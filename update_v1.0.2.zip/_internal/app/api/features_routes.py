"""API routes for dossier notes, tax calculator, auto-backup, and weekly summary."""
from __future__ import annotations

import json
from fastapi import APIRouter, Query
from pydantic import BaseModel
from typing import Optional
from ..core import config

router = APIRouter(prefix="/api", tags=["features"])


# ═══════════════════════════════════════════════════════════════════
# 1. DOSSIER NOTES
# ═══════════════════════════════════════════════════════════════════
class NotePayload(BaseModel):
    title: str = ""
    content: str = ""
    category: str = "note"  # note | reminder | appointment | important | fiscal | missing_doc | social
    reminder_date: Optional[str] = None
    pinned: bool = False
    status: str = "pending"  # pending | in_progress | done
    priority: str = "normal"  # urgent | high | normal | low
    resolution_note: str = ""


class ResolveNotePayload(BaseModel):
    resolution_note: str = ""


class GlobalNotePayload(NotePayload):
    dossier: str = ""


@router.get("/notes-all")
def get_all_alerts(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    dossier: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
):
    from ..services.notes_service import list_all_notes
    return list_all_notes(status=status, priority=priority, dossier=dossier, category=category, search=search)


@router.get("/notes-summary")
def get_notes_summary_metrics():
    from ..services.notes_service import get_notes_summary
    return get_notes_summary()


@router.post("/notes-resolve/{note_id}")
def resolve_alert(note_id: int, body: Optional[ResolveNotePayload] = None):
    from ..services.notes_service import resolve_note
    note_text = body.resolution_note if body else ""
    return resolve_note(note_id, note_text)


@router.post("/notes-reopen/{note_id}")
def reopen_alert(note_id: int):
    from ..services.notes_service import reopen_note
    return reopen_note(note_id)


@router.post("/notes-global")
def create_global_alert(body: GlobalNotePayload):
    from ..services.notes_service import add_note
    data = body.dict()
    dossier = data.pop("dossier", "").strip()
    if not dossier:
        raise ValueError("Le code dossier est obligatoire")
    return add_note(dossier, data)


@router.get("/notes/{dossier}")
def get_notes(dossier: str):
    from ..services.notes_service import list_notes
    return list_notes(dossier)


@router.post("/notes/{dossier}")
def create_note(dossier: str, body: NotePayload):
    from ..services.notes_service import add_note
    return add_note(dossier, body.dict())


@router.put("/notes/{dossier}/{note_id}")
def edit_note(dossier: str, note_id: int, body: NotePayload):
    from ..services.notes_service import update_note
    return update_note(note_id, body.dict())


@router.delete("/notes/{dossier}/{note_id}")
def remove_note(dossier: str, note_id: int):
    from ..services.notes_service import delete_note
    return {"ok": delete_note(note_id)}


@router.post("/notes/pin/{note_id}")
def pin_note(note_id: int):
    from ..services.notes_service import toggle_pin
    return toggle_pin(note_id)


@router.get("/notes-reminders")
def reminders():
    from ..services.notes_service import get_reminders
    return get_reminders()


@router.get("/notes-counts")
def notes_counts():
    from ..services.notes_service import get_all_notes_count
    return get_all_notes_count()


# ═══════════════════════════════════════════════════════════════════
# 2. TAX CALCULATOR
# ═══════════════════════════════════════════════════════════════════
class TaxCalcPayload(BaseModel):
    mode: str  # ht_to_ttc | ttc_to_ht | ibs | irg
    montant: float
    taux_tva: float = 19.0
    taux_ibs: float = 26.0


@router.post("/tax-calc")
def tax_calculator(body: TaxCalcPayload):
    m = body.montant
    r: dict = {"montant_initial": m}
    
    if body.mode == "ht_to_ttc":
        tva = round(m * body.taux_tva / 100, 2)
        r.update(ht=m, tva=tva, ttc=round(m + tva, 2), taux=body.taux_tva)
    elif body.mode == "ttc_to_ht":
        ht = round(m / (1 + body.taux_tva / 100), 2)
        tva = round(m - ht, 2)
        r.update(ht=ht, tva=tva, ttc=m, taux=body.taux_tva)
    elif body.mode == "ibs":
        ibs = round(m * body.taux_ibs / 100, 2)
        acompte1 = round(ibs * 30 / 100, 2)
        acompte2 = round(ibs * 30 / 100, 2)
        solde = round(ibs - acompte1 - acompte2, 2)
        r.update(benefice=m, ibs=ibs, acompte1=acompte1, acompte2=acompte2, solde=solde, taux=body.taux_ibs)
    elif body.mode == "irg":
        # Barème IRG progressif algérien
        tranches = [
            (240000, 0), (480000, 23), (960000, 27),
            (1920000, 30), (3840000, 33), (float('inf'), 35),
        ]
        irg = 0.0
        prev = 0
        for limit, rate in tranches:
            taxable = min(m, limit) - prev
            if taxable <= 0:
                break
            irg += taxable * rate / 100
            prev = limit
        r.update(revenu=m, irg=round(irg, 2), net=round(m - irg, 2))
    
    return r


# ═══════════════════════════════════════════════════════════════════
# 3. AUTO-BACKUP CONFIGURATION
# ═══════════════════════════════════════════════════════════════════
import json
from pathlib import Path
from ..core import config

_AUTOBACKUP_FILE = config.DATA_DIR / "autobackup_config.json"


def _load_autobackup_config() -> dict:
    if _AUTOBACKUP_FILE.is_file():
        try:
            return json.loads(_AUTOBACKUP_FILE.read_text("utf-8"))
        except Exception:
            pass
    return {"enabled": False, "interval_hours": 24, "max_backups": 7, "target_dir": ""}


def _save_autobackup_config(cfg: dict):
    _AUTOBACKUP_FILE.parent.mkdir(parents=True, exist_ok=True)
    _AUTOBACKUP_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")


class AutoBackupConfig(BaseModel):
    enabled: bool = False
    interval_hours: int = 24
    max_backups: int = 7
    target_dir: str = ""


@router.get("/autobackup/config")
def get_autobackup_config():
    return _load_autobackup_config()


@router.post("/autobackup/config")
def save_autobackup_config(body: AutoBackupConfig):
    cfg = body.dict()
    _save_autobackup_config(cfg)
    return cfg


@router.post("/autobackup/run")
def run_autobackup():
    from ..services.sauvegarde import backup, history
    cfg = _load_autobackup_config()
    
    # Run backup
    result = backup(prefix="Auto_", target_dir=cfg.get("target_dir", ""))
    
    # Cleanup old auto-backups (keep max_backups)
    max_keep = cfg.get("max_backups", 7)
    all_backups = history(custom_dir=cfg.get("target_dir", ""))
    auto_backups = [b for b in all_backups if b["name"].startswith("Auto_")]
    if len(auto_backups) > max_keep:
        for old in auto_backups[max_keep:]:
            try:
                Path(old["path"]).unlink(missing_ok=True)
            except Exception:
                pass
    
    # Record last backup time
    cfg["last_backup"] = result.get("date", "")
    _save_autobackup_config(cfg)
    
    return result


@router.get("/autobackup/status")
def autobackup_status():
    cfg = _load_autobackup_config()
    from ..services.sauvegarde import history
    all_backups = history(custom_dir=cfg.get("target_dir", ""))
    auto_backups = [b for b in all_backups if b["name"].startswith("Auto_")]
    return {
        "config": cfg,
        "auto_backups_count": len(auto_backups),
        "last_backup": auto_backups[0] if auto_backups else None,
    }


# ═══════════════════════════════════════════════════════════════════
# 4. WEEKLY SUMMARY
# ═══════════════════════════════════════════════════════════════════
@router.get("/weekly-summary")
def weekly_summary():
    """Generate a weekly summary report of all dossiers and cabinet activity."""
    from ..services import dossiers, sauvegarde, manquantes
    from ..core.audit import _get_connection
    from datetime import datetime, timedelta
    
    now = datetime.now()
    week_ago = (now - timedelta(days=7)).strftime("%Y-%m-%d")
    
    # Get all dossier list
    all_dossiers = dossiers.list_dossiers()
    
    # G50 & fiscal status across dossiers
    try:
        dash = manquantes.dashboard(now.date())
        g50_card = next((c for c in dash.get("cards", []) if c.get("kind") == "g50"), None)
        fiscal_status = {
            "g50_label": g50_card.get("label", "") if g50_card else "",
            "g50_total": g50_card.get("total", 0) if g50_card else 0,
            "g50_filed": g50_card.get("filed", 0) if g50_card else 0,
            "g50_missing": len(g50_card.get("missing", [])) if g50_card else 0,
            "missing_list": [{"code": m.get("code"), "rs": m.get("rs")} for m in (g50_card.get("missing", []) if g50_card else [])[:8]],
            "days_left": dash.get("days_left", 0),
            "deadline": dash.get("deadline", ""),
        }
    except Exception:
        fiscal_status = {
            "g50_label": "",
            "g50_total": len(all_dossiers),
            "g50_filed": 0,
            "g50_missing": len(all_dossiers),
            "missing_list": [],
            "days_left": 0,
            "deadline": "",
        }
    
    # Get audit activity this week
    try:
        with _get_connection() as conn:
            activity_count = conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE created_at >= ?", (week_ago,)
            ).fetchone()[0]
            
            security_alerts = conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE created_at >= ? AND status IN ('warning', 'blocked', 'error')",
                (week_ago,),
            ).fetchone()[0]
            
            cloud_accesses = conn.execute(
                "SELECT COUNT(*) FROM audit_logs WHERE created_at >= ? AND source = 'cloud'",
                (week_ago,),
            ).fetchone()[0]
    except Exception:
        activity_count = 0
        security_alerts = 0
        cloud_accesses = 0
    
    # Get backup status
    try:
        backups = sauvegarde.history()
        recent_backups = [b for b in backups if b.get("date", "") >= week_ago.replace("-", "/")]
    except Exception:
        backups = []
        recent_backups = []
    
    # Get notes reminders
    try:
        from ..services.notes_service import get_reminders
        upcoming_reminders = get_reminders()
    except Exception:
        upcoming_reminders = []
    
    return {
        "period": {"from": week_ago, "to": now.strftime("%Y-%m-%d")},
        "dossiers": {
            "total": len(all_dossiers),
            "list": [{"code": d["code"], "rs": d.get("rs", "")} for d in all_dossiers[:20]],
        },
        "fiscal": fiscal_status,
        "activity": {
            "total_operations": activity_count,
            "security_alerts": security_alerts,
            "cloud_accesses": cloud_accesses,
        },
        "backups": {
            "total_this_week": len(recent_backups),
            "last": recent_backups[0] if recent_backups else (backups[0] if backups else None),
        },
        "reminders": upcoming_reminders[:10],
        "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
    }


# ═══════════════════════════════════════════════════════════════════
# 5. OFFICE BRANDING
# ═══════════════════════════════════════════════════════════════════
_BRANDING_FILE = config.DATA_DIR / "office_branding.json"


def _load_branding() -> dict:
    if _BRANDING_FILE.is_file():
        try:
            return json.loads(_BRANDING_FILE.read_text("utf-8"))
        except Exception:
            pass
    return {
        "office_name": "",
        "office_name_ar": "",
        "address": "",
        "phone": "",
        "email": "",
        "nif": "",
        "rc": "",
        "logo_base64": "",
        "primary_color": "#0d9488",
        "header_text": "",
        "footer_text": "",
    }


class BrandingPayload(BaseModel):
    office_name: str = ""
    office_name_ar: str = ""
    address: str = ""
    phone: str = ""
    email: str = ""
    nif: str = ""
    rc: str = ""
    logo_base64: str = ""
    primary_color: str = "#0d9488"
    header_text: str = ""
    footer_text: str = ""


@router.get("/branding")
def get_branding():
    return _load_branding()


@router.post("/branding")
def save_branding(body: BrandingPayload):
    data = body.dict()
    _BRANDING_FILE.parent.mkdir(parents=True, exist_ok=True)
    _BRANDING_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
    return data
