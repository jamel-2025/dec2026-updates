"""API routes for Invoice Scanning and Fiscal OCR."""
from __future__ import annotations

import base64
from typing import Optional
from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from pydantic import BaseModel

from ..services import invoice_ocr
from ..core import audit

router = APIRouter(tags=["ocr"])


class ScanRequest(BaseModel):
    image_base64: str
    mime_type: Optional[str] = "image/jpeg"
    api_key: Optional[str] = None
    target: Optional[str] = "fournisseur"  # "client" or "fournisseur"


class ConfigRequest(BaseModel):
    gemini_api_key: str


@router.get("/api/ocr/config")
@router.get("/ocr/config")
def get_ocr_config():
    key = invoice_ocr.get_gemini_api_key()
    return {
        "has_gemini_key": bool(key),
        "masked_key": f"{key[:6]}...{key[-4:]}" if len(key) > 10 else ("***" if key else ""),
    }


@router.post("/api/ocr/config")
@router.post("/ocr/config")
def save_ocr_config(body: ConfigRequest, request: Request):
    invoice_ocr.save_gemini_api_key(body.gemini_api_key)
    audit.record(
        action="UPDATE_OCR_CONFIG",
        category="config",
        description="Mise à jour de la clé API Gemini Vision pour l'OCR intelligent",
        request=request,
        status="success",
    )
    return {"success": True, "has_gemini_key": bool(body.gemini_api_key.strip())}


@router.post("/api/ocr/scan-tier")
@router.post("/ocr/scan-tier")
async def scan_tier(body: ScanRequest, request: Request):
    """Scan invoice image header from base64 string and extract fiscal identity."""
    raw_b64 = body.image_base64
    if "," in raw_b64:
        raw_b64 = raw_b64.split(",", 1)[1]

    try:
        image_bytes = base64.b64decode(raw_b64)
    except Exception as e:
        raise HTTPException(400, f"Données image base64 invalides : {e}")

    if len(image_bytes) > 15 * 1024 * 1024:
        raise HTTPException(400, "Image trop volumineuse (max 15 Mo)")

    try:
        result = await invoice_ocr.scan_invoice_header(
            image_bytes=image_bytes,
            mime_type=body.mime_type or "image/jpeg",
            custom_api_key=body.api_key,
            target=body.target or "fournisseur",
        )
        audit.record(
            action="SCAN_FACTURE_OCR",
            category="tier",
            description=f"Scan OCR facture effectué avec succès ({result.get('engine_label')})",
            request=request,
            status="success",
        )
        return result
    except Exception as e:
        audit.record(
            action="SCAN_FACTURE_OCR",
            category="tier",
            description=f"Échec du scan OCR facture : {e}",
            request=request,
            status="error",
        )
        raise HTTPException(500, f"Erreur lors de l'analyse OCR : {e}")


@router.post("/api/ocr/upload-scan-tier")
@router.post("/ocr/upload-scan-tier")
async def upload_scan_tier(request: Request, file: UploadFile = File(...), target: str = "fournisseur"):
    """Upload multipart image file directly from phone or browser and extract fiscal identity."""
    content = await file.read()
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(400, "Fichier trop volumineux (max 15 Mo)")

    mime = file.content_type or "image/jpeg"
    try:
        result = await invoice_ocr.scan_invoice_header(
            image_bytes=content,
            mime_type=mime,
            target=target,
        )
        audit.record(
            action="SCAN_FACTURE_OCR",
            category="tier",
            description=f"Scan OCR upload effectué ({result.get('engine_label')})",
            request=request,
            status="success",
        )
        return result
    except Exception as e:
        raise HTTPException(500, f"Erreur lors de l'analyse OCR : {e}")
