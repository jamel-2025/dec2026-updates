﻿"""Routes API pour la gestion des honoraires du cabinet comptable."""
from __future__ import annotations

from typing import Any
from fastapi import APIRouter, HTTPException, Request

from ..services import honoraires
from ..core import audit

router = APIRouter(prefix="", tags=["honoraires"])


# ------------------------------------------------------------------ Profil du Cabinet
@router.get("/honoraires/cabinet")
def get_cabinet_profile():
    return honoraires.get_cabinet_profile()


@router.put("/honoraires/cabinet")
def update_cabinet_profile(body: dict, request: Request):
    res = honoraires.update_cabinet_profile(body)
    try:
        audit.record(
            action="CABINET_PROFILE_UPDATE",
            category="system",
            description="Mise à jour des coordonnées du cabinet comptable",
            request=request,
            status="info",
        )
    except Exception:
        pass
    return res


# ------------------------------------------------------------------ Tableau de bord global multi-sociétés
@router.get("/honoraires/synthese")
def get_synthese_honoraires(annee: str):
    return honoraires.get_synthese_globale(annee)


# ------------------------------------------------------------------ Gestion par dossier / société
@router.get("/dossiers/{code}/honoraires")
def get_dossier_honoraires(code: str, annee: str):
    contrat = honoraires.get_contrat(code, annee)
    echeances = honoraires.list_echeances(code, annee)

    total_du = sum(e["montant_du"] for e in echeances)
    total_regle = sum(e["montant_regle"] for e in echeances)
    reste_a_payer = max(0.0, round(total_du - total_regle, 2))
    taux = round((total_regle / total_du * 100), 1) if total_du > 0 else 0.0

    return {
        "dossier": code,
        "exercice": annee,
        "contrat": contrat,
        "echeances": echeances,
        "stats": {
            "total_du": round(total_du, 2),
            "total_regle": round(total_regle, 2),
            "reste_a_payer": round(reste_a_payer, 2),
            "taux_recouvrement": taux,
            "nb_echeances": len(echeances),
            "nb_payees": sum(1 for e in echeances if e["statut"] == "paye"),
            "nb_partielles": sum(1 for e in echeances if e["statut"] == "partiel"),
            "nb_retard": sum(1 for e in echeances if e["statut"] == "en_retard"),
            "nb_attente": sum(1 for e in echeances if e["statut"] == "en_attente"),
        }
    }


@router.post("/dossiers/{code}/honoraires/contrat")
def save_dossier_contrat(code: str, body: dict, request: Request):
    annee = str(body.get("exercice") or "").strip()
    if not annee:
        raise HTTPException(400, "L'exercice est obligatoire")
    res = honoraires.save_contrat(code, annee, body)
    try:
        audit.record(
            action="HONORAIRES_CONTRAT_UPDATE",
            category="declaration",
            description=f"Convention d'honoraires {annee} mise à jour: {res.get('montant_annuel')} DA",
            request=request,
            dossier=code,
            status="info",
        )
    except Exception:
        pass
    return res


@router.post("/dossiers/{code}/honoraires/generer")
def generer_echeancier(code: str, body: dict, request: Request):
    annee = str(body.get("exercice") or "").strip()
    if not annee:
        raise HTTPException(400, "L'exercice est obligatoire")
    montant = float(body.get("montant_annuel") or 0.0)
    periodicite = str(body.get("periodicite") or "mensuel")
    jour = int(body.get("jour_echeance") or 5)
    replace = bool(body.get("replace", True))

    # Enregistrer le contrat d'abord
    honoraires.save_contrat(code, annee, {
        "montant_annuel": montant,
        "periodicite": periodicite,
        "jour_echeance": jour,
        "notes": body.get("notes", ""),
    })

    echeances = honoraires.generate_echeancier(code, annee, montant, periodicite, jour, replace=replace)
    try:
        audit.record(
            action="HONORAIRES_ECHEANCIER_GEN",
            category="declaration",
            description=f"Génération échéancier honoraires {annee} ({len(echeances)} tranches, {periodicite})",
            request=request,
            dossier=code,
            status="info",
        )
    except Exception:
        pass
    return {"status": "ok", "count": len(echeances), "items": echeances}


@router.post("/dossiers/{code}/honoraires/echeances")
def add_echeance(code: str, body: dict):
    annee = str(body.get("exercice") or "").strip()
    if not annee:
        raise HTTPException(400, "L'exercice est obligatoire")
    return honoraires.add_custom_echeance(code, annee, body)


@router.put("/dossiers/{code}/honoraires/echeances/{item_id}")
def update_echeance(code: str, item_id: int, body: dict):
    return honoraires.update_echeance(code, item_id, body)


@router.delete("/dossiers/{code}/honoraires/echeances/{item_id}")
def delete_echeance(code: str, item_id: int):
    return honoraires.delete_echeance(code, item_id)


@router.post("/dossiers/{code}/honoraires/echeances/{item_id}/regler")
def enregistrer_reglement(code: str, item_id: int, body: dict, request: Request):
    res = honoraires.enregistrer_reglement(code, item_id, body)
    try:
        audit.record(
            action="HONORAIRES_REGLEMENT",
            category="declaration",
            description=f"Règlement honoraires enregistré: {body.get('montant_paye')} DA ({body.get('mode_reglement')})",
            request=request,
            dossier=code,
            status="info",
            details={"echeance_id": item_id, "montant": body.get("montant_paye"), "mode": body.get("mode_reglement")},
        )
    except Exception:
        pass
    return res


@router.get("/dossiers/{code}/honoraires/echeances/{item_id}/recu")
def get_recu_paiement(code: str, item_id: int):
    return honoraires.get_recu_paiement(code, item_id)

