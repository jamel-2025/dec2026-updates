"""Routes API pour le système de mise à jour (Cloud & Offline Updater)."""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from pydantic import BaseModel

from ..services import updater_service

router = APIRouter(prefix="/api/updater", tags=["updater"])


class CheckUpdatePayload(BaseModel):
    custom_url: Optional[str] = None


class ApplyRemotePayload(BaseModel):
    download_url: str
    sha256: Optional[str] = ""
    new_version: Optional[str] = ""


@router.get("/version")
def get_version():
    """Retourne la version installée actuelle."""
    return updater_service.get_current_version_info()


@router.post("/check")
def check_update(payload: Optional[CheckUpdatePayload] = None):
    """Vérifie si une mise à jour est disponible sur le cloud."""
    custom_url = payload.custom_url if payload else None
    return updater_service.check_for_updates(custom_url)


@router.post("/apply-cloud")
def apply_cloud_update(payload: ApplyRemotePayload):
    """Télécharge et installe la mise à jour depuis le lien distant."""
    if not payload.download_url:
        raise HTTPException(status_code=400, detail="URL de téléchargement requise.")
    res = updater_service.download_and_apply_update(
        payload.download_url,
        payload.sha256 or "",
        new_version=payload.new_version or ""
    )
    if not res.get("success"):
        raise HTTPException(status_code=500, detail=res.get("error", "Erreur lors de la mise à jour"))
    return res


@router.post("/apply-file")
async def apply_file_update(file: UploadFile = File(...)):
    """Applique une mise à jour manuelle via un fichier ZIP ou PATCH importé."""
    if not file.filename.endswith((".zip", ".patch")):
        raise HTTPException(status_code=400, detail="Format de fichier non pris en charge (.zip ou .patch requis).")

    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
        tmp_path = Path(tmp.name)
        shutil.copyfileobj(file.file, tmp)

    try:
        res = updater_service.apply_zip_update(tmp_path)
        if not res.get("success"):
            raise HTTPException(status_code=500, detail=res.get("error", "Erreur"))
        return res
    finally:
        tmp_path.unlink(missing_ok=True)
