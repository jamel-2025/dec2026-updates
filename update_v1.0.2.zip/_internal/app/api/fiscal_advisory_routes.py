"""FastAPI Router for Fiscal Advisory & Contentious Management.

Endpoints for tax optimization simulators, notifications de redressement,
contentious claims, legal articles, and official response templates.
"""
from __future__ import annotations

import os
import base64
import time
import secrets
from datetime import datetime
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, File, Form, HTTPException, Query, Response, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ..core import access
from ..services import fiscal_advisory_service as service
from ..services import scanner_service

router = APIRouter(prefix="/api/fiscal", tags=["fiscal_advisory"])


class NotificationPayload(BaseModel):
    dossier: str
    type_notification: str = "MODELE_1"
    reference_lettre: str = ""
    inspecteur_service: str = ""
    date_reception: str
    delai_jours: int = 40
    annee_verifiee: str = ""
    montant_rappele: float = 0.0
    penalites: float = 0.0
    motifs: str = ""
    status: str = "en_attente"
    reponse_contenu: str = ""
    date_reponse: Optional[str] = None


class NotificationUpdatePayload(BaseModel):
    dossier: Optional[str] = None
    type_notification: Optional[str] = None
    reference_lettre: Optional[str] = None
    inspecteur_service: Optional[str] = None
    date_reception: Optional[str] = None
    delai_jours: Optional[int] = None
    annee_verifiee: Optional[str] = None
    montant_rappele: Optional[float] = None
    penalites: Optional[float] = None
    motifs: Optional[str] = None
    status: Optional[str] = None
    reponse_contenu: Optional[str] = None
    date_reponse: Optional[str] = None


class ReclamationPayload(BaseModel):
    dossier: str
    notification_id: Optional[int] = None
    reference_reclamation: str = ""
    type_recours: str = "DIRECTEUR_WILAYA"
    date_depot: str
    accuse_reception_num: str = ""
    montant_conteste: float = 0.0
    demande_sursis: int = 1
    statut: str = "en_cours"
    montant_decharge: float = 0.0
    montant_maintenu: float = 0.0
    decision_date: Optional[str] = None
    decision_ref: str = ""
    notes: str = ""


class ReclamationUpdatePayload(BaseModel):
    dossier: Optional[str] = None
    notification_id: Optional[int] = None
    reference_reclamation: Optional[str] = None
    type_recours: Optional[str] = None
    date_depot: Optional[str] = None
    accuse_reception_num: Optional[str] = None
    montant_conteste: Optional[float] = None
    demande_sursis: Optional[int] = None
    montant_garantie_20: Optional[float] = None
    statut: Optional[str] = None
    montant_decharge: Optional[float] = None
    montant_maintenu: Optional[float] = None
    decision_date: Optional[str] = None
    decision_ref: Optional[str] = None
    notes: Optional[str] = None


class ArbitrageSimPayload(BaseModel):
    benefice_annuel_brut: float = Field(..., gt=0)
    taux_ibs: float = 0.26
    salaire_mensuel_propose: float = 150000.0


class FormeJuridiqueSimPayload(BaseModel):
    chiffre_affaires: float = Field(..., gt=0)
    marge_nette_pct: float = 20.0
    secteur: str = "services"


class LeasingSimPayload(BaseModel):
    valeur_acquisition: float = Field(..., gt=0)
    duree_annees: int = 5
    type_bien: str = "equipement"


class C20Payload(BaseModel):
    dossier: str = "S1"
    motif_cle: str = "banque"
    motif_titre_ar: str = ""
    motif_titre_fr: str = ""
    destinataire_type: str = "INSPECTION"
    destinataire_nom: str = ""
    regime_fiscal: str = "REEL"
    date_debut_activite: str = ""
    annees_demandees: str = ""
    chiffres_affaires: List[Dict[str, Any]] = Field(default_factory=list)
    avec_pieces_jointes: bool = True
    pieces_jointes: List[str] = Field(default_factory=list)
    statut: str = "en_attente"
    date_demande: str = ""
    numero_enregistrement: str = ""
    texte_ar: str = ""
    texte_fr: str = ""
    notes: str = ""


class C20UpdatePayload(BaseModel):
    dossier: Optional[str] = None
    motif_cle: Optional[str] = None
    motif_titre_ar: Optional[str] = None
    motif_titre_fr: Optional[str] = None
    destinataire_type: Optional[str] = None
    destinataire_nom: Optional[str] = None
    regime_fiscal: Optional[str] = None
    date_debut_activite: Optional[str] = None
    annees_demandees: Optional[str] = None
    chiffres_affaires: Optional[List[Dict[str, Any]]] = None
    avec_pieces_jointes: Optional[bool] = None
    pieces_jointes: Optional[List[str]] = None
    statut: Optional[str] = None
    date_demande: Optional[str] = None
    numero_enregistrement: Optional[str] = None
    texte_ar: Optional[str] = None
    texte_fr: Optional[str] = None
    notes: Optional[str] = None


@router.get("/summary")
def get_summary():
    return service.get_contentieux_summary()


@router.get("/notifications")
def get_notifications(
    dossier: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
):
    return service.list_notifications(dossier=dossier, status=status)


@router.post("/notifications")
def add_notification(payload: NotificationPayload):
    return service.create_notification(payload.dict())


@router.get("/notifications/{notif_id}")
def read_notification(notif_id: int):
    n = service.get_notification(notif_id)
    if not n:
        raise HTTPException(status_code=404, detail="Notification introuvable")
    return n


@router.put("/notifications/{notif_id}")
def edit_notification(notif_id: int, payload: NotificationUpdatePayload):
    n = service.update_notification(notif_id, {k: v for k, v in payload.dict().items() if v is not None})
    if not n:
        raise HTTPException(status_code=404, detail="Notification introuvable")
    return n


@router.delete("/notifications/{notif_id}")
def remove_notification(notif_id: int):
    service.delete_notification(notif_id)
    return {"ok": True}


@router.get("/reclamations")
def get_reclamations(
    dossier: Optional[str] = Query(None),
    statut: Optional[str] = Query(None),
):
    return service.list_reclamations(dossier=dossier, statut=statut)


@router.post("/reclamations")
def add_reclamation(payload: ReclamationPayload):
    return service.create_reclamation(payload.dict())


@router.get("/reclamations/{rec_id}")
def read_reclamation(rec_id: int):
    r = service.get_reclamation(rec_id)
    if not r:
        raise HTTPException(status_code=404, detail="Réclamation introuvable")
    return r


@router.put("/reclamations/{rec_id}")
def edit_reclamation(rec_id: int, payload: ReclamationUpdatePayload):
    r = service.update_reclamation(rec_id, {k: v for k, v in payload.dict().items() if v is not None})
    if not r:
        raise HTTPException(status_code=404, detail="Réclamation introuvable")
    return r


@router.delete("/reclamations/{rec_id}")
def remove_reclamation(rec_id: int):
    service.delete_reclamation(rec_id)
    return {"ok": True}


@router.post("/simulate/arbitrage")
def run_arbitrage(payload: ArbitrageSimPayload):
    return service.simulate_arbitrage_salaire_dividendes(
        benefice_annuel_brut=payload.benefice_annuel_brut,
        taux_ibs=payload.taux_ibs,
        salaire_mensuel_propose=payload.salaire_mensuel_propose,
    )


@router.post("/simulate/forme-juridique")
def run_forme_juridique(payload: FormeJuridiqueSimPayload):
    return service.simulate_forme_juridique(
        chiffre_affaires=payload.chiffre_affaires,
        marge_nette_pct=payload.marge_nette_pct,
        secteur=payload.secteur,
    )


@router.post("/simulate/leasing")
def run_leasing(payload: LeasingSimPayload):
    return service.simulate_leasing_vs_achat(
        valeur_acquisition=payload.valeur_acquisition,
        duree_annees=payload.duree_annees,
        type_bien=payload.type_bien,
    )


@router.get("/prescription-radar")
def get_radar(annee: int = Query(2026)):
    return service.get_prescription_radar(annee_en_cours=annee)


@router.get("/legal-articles")
def get_articles():
    return service.get_legal_articles()


@router.get("/templates-courriers")
def get_templates():
    return [
        {
            "id": "reponse_ar_charges",
            "lang": "ar",
            "titre_ar": "رد بالعربية: تبرير أعباء الاستغلال ورفض إعادة الإدماج (المادة 169)",
            "titre_fr": "Réponse AR : Justification des charges (Art. 169)",
            "modele": "MODELE_1",
            "contenu": """تحية طيبة وبعد،

رداً على إشعاركم بإعادة التقييم المذكور في المرجع أعلاه، والمستلم بصفة رسمية بتاريخ {date_reception}، وطبقاً لأحكام المادة 191 من قانون الضرائب المباشرة والرسوم المماثلة (CIDTA) وأحكام قانون الإجراءات الجبائية، يشرفنا أن نوافيكم بملاحظاتنا ومبرراتنا القانونية والمحاسبية بشأن التعديلات المقترحة:

أولاً: بخصوص إعادة إدماج أعباء ونفقات الاستغلال:
نحيطكم علماً بأن كافة النفقات والأعباء التي طالها التعديل تستوفي الشروط القانونية الصريحة المنصوص عليها في المادة 169 من قانون الضرائب المباشرة:
1. تم صرفها والالتزام بها في إطار المصلحة المباشرة والحصرية للنشاط التجاري والاستثماري للمؤسسة.
2. مدعمة ومثبتة بفواتير نظامية ومستندات ثبوتية قانونية مستوفية لكافة البيانات الإلزامية (الاسم، العنوان، NIF، السجل التجاري).
3. تم تسديدها بالوسائل المصرفية والقانونية المعتمدة ومثبتة في كشوف الحسابات البنكية المرفقة طيه.

وعليه، نلتمس من سيادتكم التفضل بالتراجع عن إعادة إدماج هذه الأعباء، وتثبيت الحسابات والنتائج المصرح بها في جدول حسابات النتائج (TCR).

ثانياً: بخصوص الغرامات والزيادات الجبائية:
نلتمس إلغاء كافة الغرامات المطبقة استناداً إلى حسن النية التامة وثبوت الطابع الحقيقي والفعلي لكافة المعاملات المقيدة في السجلات المحاسبية الرسمية.

وفي انتظار فحصكم لهذه المبررات وقبول حججنا، تقبلوا منا سيدي المفتش فائق عبارات التقدير والاحترام.""",
        },
        {
            "id": "reponse_ar_tva",
            "lang": "ar",
            "titre_ar": "رد بالعربية: تثبيت حق خصم واسترجاع الرسم TVA (المادتين 29-30)",
            "titre_fr": "Réponse AR : Maintien déduction TVA",
            "modele": "MODELE_1",
            "contenu": """تحية طيبة وبعد،

نرفع إلى كريم عنايتكم هذا الرد للتعبير عن تحفظنا واعتراضنا القانوني والموضوعي على رفض خصم الرسم على القيمة المضافة (TVA) المسترجع عن مشتريات ونفقات دورة {annee_verifiee}.

تأسيساً على أحكام المادتين 29 و30 من قانون الرسوم على رقم الأعمال (CTCA)، فإن الحق في خصم الرسم الذي تحمله السلع والخدمات الضرورية للنشاط يشكل المبدأ الأساسي لحيادية الضريبة على الاستهلاك.

نرفق بهذا الرد الحجج والمستندات التالية:
1. نسخ مطابقة للأصل من فواتير الشراء القانونية المسلّمة من موردين نشطين بصفة نظامية يحوزون أرقام تعريف جبائي سارية ومحققة.
2. وصولات وأوامر التحويل والصكوك البنكية المثبتة لتسديد هذه المشتريات.
3. مستخرج جدول مشتريات الرسم على القيمة المضافة (جدول الموردين - État des fournisseurs).

وحيث أن حقيقة المشتريات وثبوت استلام البضائع والخدمات واستيفاء الفواتير مثبتة بما لا يدع مجالاً للشك، فإن إسقاط حق الخصم وإلزام المؤسسة بإعادة دفع الرسم والغرامات يعد غير ذي أساس قانوني سليم.

وعليه، نرجو من سيادتكم تثبيت الخصم وإلغاء الاسترداد المطلوب، وتقبلوا منا فائق التقدير والاحترام.""",
        },
        {
            "id": "reponse_ar_modele2_3",
            "lang": "ar",
            "titre_ar": "رد بالعربية: معارضة التقييم العادي والتلقائي وإلغاء الغرامات (النموذج 2 و 3)",
            "titre_fr": "Réponse AR : Contestation redressement normal / office",
            "modele": "MODELE_2",
            "contenu": """سيدي الرئيس،

رداً على إشعاركم الجبائي المذكور أعلاه والمستلم بتاريخ {date_reception}، يسعدنا أن نتقدم إليكم بملاحظاتنا الجوهرية طبقاً للمهلة القانونية المحددة بـ 30 يوماً:

1. نؤكد لكم انتظام محاسبة المؤسسة ومسكها وفقاً لأحكام النظام المحاسبي المالي (SCF) والمصادقة عليها من طرف محافظ الحسابات، مما يجعل اللجوء إلى التقييم الجزافي أو التلقائي غير مبرر قانوناً.
2. جميع عناصر رقم الأعمال والأرباح المصرح بها في التصريحات الشهرية (G50) والسنوية تتطابق كلياً مع العمليات الفعلية وتبريراتها البنكية.
3. التمسك بالاستفادة من التخفيضات والإعفاءات القانونية المخولة قانوناً لقطاع نشاطنا.

وعليه، نلتمس من مصالحكم الموقرة إعادة دراسة الملف على ضوء المبررات والوثائق المرفقة وإسقاط الفروقات المطالب بها والغرامات المترتبة عنها.

وفي انتظار ردكم الإيجابي، تفضلوا بقبول أسمى عبارات التقدير والاحترام.""",
        },
        {
            "id": "reclamation_ar_72_sursis",
            "lang": "ar",
            "titre_ar": "عريضة شكوى نزاعية بالعربية (المادة 72) مع طلب تأجيل الدفع (المادة 74)",
            "titre_fr": "Réclamation AR (Art. 72) & Sursis de paiement (Art. 74)",
            "modele": "RECLAMATION_72",
            "contenu": """سيدي المدير،

يشرفنا أن نرفع إلى سيادتكم هذه الشكوى النزاعية اعتراضاً على الضرائب والرسوم والغرامات الموجهة ضدنا بالجدول المذكور أعلاه، وذلك تطبيقاً لأحكام المادة 72 من قانون الإجراءات الجبائية.

أولاً: عرض الوقائع والأسانيد القانونية:
نوضح لسيادتكم عدم صحة الأسس التي بني عليها فرض هذه الحقوق والغرامات، حيث أن حساباتنا ممسوكة بانتظام ومثبتة بفواتير نظامية ومستندات قانونية ومصرح بها بصفة دورية في الآجال المحددة.

ثانياً: طلب تأجيل الدفع القانوني (المادة 74 من قانون الإجراءات الجبائية):
في انتظار الفصل في موضوع هذه الشكوى، نطلب صراحة وبموجب هذا السند الاستفادة من تأجيل دفع الحقوق المتنازع عليها والبالغة {montant_conteste} دج.
وتطبيقاً لأحكام القانون، نبدي استعدادنا التام لتقديم الضمانات القانونية الإلزامية لدى قابض الضرائب المختص بنسبة 20% من المبالغ المتنازع عليها، والمحددة بمبلغ: {montant_garantie_20} دج.

لكل هذه الأسباب، نلتمس من سيادتكم:
1. إصدار قراركم بوقف إجراءات التحصيل وتأجيل الدفع مؤقتاً.
2. إلغاء وإسقاط الضرائب والغرامات غير المبررة موضوع هذه الشكوى.

وتقبلوا منا، سيدي المدير، أسمى عبارات الاحترام والتقدير.""",
        },
        {
            "id": "reponse_fr_charges",
            "lang": "fr",
            "titre_ar": "رد بالفرنسية: تبرير أعباء الاستغلال (Art. 169 CIDTA)",
            "titre_fr": "Réponse FR : Justification des charges (Art. 169)",
            "modele": "MODELE_1",
            "contenu": """Monsieur l'Inspecteur,

Faisant suite à votre notification citée en référence reçue le {date_reception}, et conformément aux dispositions de l'article 191 du Code des Impôts Directs et Taxes Assimilées, nous avons l'honneur de vous soumettre nos observations et éléments de justification quant aux chefs de redressement envisagés :

1. Concernant le chef de redressement relatif aux charges d'exploitation réintégrées :
Nous tenons à vous préciser que l'ensemble des dépenses visées répondent rigoureusement aux critères fixés par l'article 169 du CIDTA :
- Elles ont été engagées dans l'intérêt direct et exclusif de l'exploitation commerciale de notre entreprise.
- Elles sont appuyées de factures probantes et régulières comportant toutes les mentions obligatoires.
- Le règlement a été effectué par les moyens légaux et figure clairement sur les relevés bancaires ci-joints.

En conséquence, nous vous demandons de bien vouloir abandonner les redressements proposés sur ces postes et maintenir les écritures comptables telles qu'initialement déclarées.

Restant à votre entière disposition pour tout examen complémentaire de pièces, nous vous prions d'agréer, Monsieur l'Inspecteur, l'expression de nos salutations distinguées.""",
        },
        {
            "id": "reponse_fr_tva",
            "lang": "fr",
            "titre_ar": "رد بالفرنسية: تثبيت حق خصم واسترجاع الرسم (Art. 29-30 CTCA)",
            "titre_fr": "Réponse FR : Maintien déduction TVA (Art. 29-30)",
            "modele": "MODELE_1",
            "contenu": """Monsieur l'Inspecteur,

Nous contestons respectueusement le rejet de la TVA déductible opéré au titre de l'exercice {annee_verifiee}.

Aux termes des articles 29 et 30 du Code des Taxes sur le Chiffre d'Affaires (CTCA), la déduction de la taxe ayant grevé les biens et services nécessaires à l'activité constitue un principe fondamental de neutralité fiscale. 

Nous joignons au présent pli :
1. Les copies conformes des factures d'achats concernées délivrées par des fournisseurs actifs au NIF régulier.
2. Les quittances de règlement bancaire correspondantes.
3. L'extrait de notre registre des achats (État des fournisseurs).

Dès lors que la réalité des livraisons et la régularité des factures sont établies, le rappel de TVA et les pénalités y afférentes ne sauraient être maintenus.

Comptant sur votre bienveillante appréciation, veuillez agréer, Monsieur l'Inspecteur, nos salutations respectueuses.""",
        },
        {
            "id": "reponse_fr_modele2_3",
            "lang": "fr",
            "titre_ar": "رد بالفرنسية: معارضة إعادة التقييم العادي والتلقائي (Modèle 2 / 3)",
            "titre_fr": "Réponse FR : Contestation redressement normal / d'office",
            "modele": "MODELE_2",
            "contenu": """Monsieur l'Inspecteur,

Faisant suite à la notification citée en référence reçue le {date_reception}, nous avons l'honneur de vous soumettre nos éléments d'opposition dans le délai légal imparti de 30 jours :

1. La comptabilité de l'entreprise est tenue de manière régulière et probante conformément aux normes SCF en vigueur, et certifiée par notre commissaire aux comptes.
2. L'évaluation d'office ou forfaitaire de notre chiffre d'affaires n'apparaît pas justifiée au regard des éléments réels déclarés mensuellement (G50).
3. Nous sollicitons l'abandon des pénalités d'assiette appliquées, notre entreprise ayant agi en toute bonne foi.

Restant à votre disposition pour toute communication de pièces comptables probantes, nous vous prions d'agréer, Monsieur l'Inspecteur, nos salutations distinguées.""",
        },
        {
            "id": "reclamation_fr_72_sursis",
            "lang": "fr",
            "titre_ar": "عريضة نزاعية بالفرنسية (Art. 72) مع تأجيل الدفع (Art. 74)",
            "titre_fr": "Réclamation FR (Art. 72) & Sursis de paiement (Art. 74)",
            "modele": "RECLAMATION_72",
            "contenu": """Monsieur le Directeur,

Nous avons l'honneur, par la présente, de former opposition formelle à l'encontre des impositions mises à notre charge par voie de rôle visé ci-dessus, et ce conformément à l'article 72 du Code des Procédures Fiscales.

I. EXPOSÉ DES FAITS ET MOYENS DE DROIT :
Nous tenons à vous préciser que les impositions contestées ne reposent pas sur des bases légales et comptables justifiées, notre comptabilité étant régulière et appuyée de l'ensemble des pièces probantes.

II. DEMANDE FORMELLE DE SURSIS DE PAIEMENT (Article 74 du CPF) :
Dans l'attente de votre décision sur le fond de la présente réclamation, nous sollicitons expressément le bénéfice du sursis de paiement des droits contestés à hauteur de {montant_conteste} DA.
À cet effet, nous déclarons nous conformer aux dispositions légales en constituant auprès de la recette des impôts la garantie obligatoire équivalente à 20% des impositions contestées, soit un montant de {montant_garantie_20} DA.

Par ces motifs, nous vous prions, Monsieur le Directeur :
- De bien vouloir ordonner le sursis des poursuites en recouvrement ;
- Prononcer la décharge intégrale des droits et pénalités indûment réclamés.

Veuillez agréer, Monsieur le Directeur, l'hommage de notre très haute considération.""",
        },
    ]


# ---------------------------------------------------------------------------
# C20 : ATTESTATION D'ACTIVITÉ & CERTIFICAT D'EXISTENCE
# ---------------------------------------------------------------------------

@router.get("/c20/motifs")
def get_c20_motifs():
    return service.get_c20_motifs()


@router.get("/c20")
def list_c20(
    dossier: Optional[str] = Query(None),
    statut: Optional[str] = Query(None),
):
    return service.list_demandes_c20(dossier=dossier, statut=statut)


@router.post("/c20")
def add_c20(payload: C20Payload):
    return service.create_demande_c20(payload.dict())


@router.get("/c20/{c20_id}")
def read_c20(c20_id: int):
    item = service.get_demande_c20(c20_id)
    if not item:
        raise HTTPException(status_code=404, detail="Demande C20 introuvable")
    return item


@router.put("/c20/{c20_id}")
def edit_c20(c20_id: int, payload: C20UpdatePayload):
    item = service.update_demande_c20(c20_id, {k: v for k, v in payload.dict().items() if v is not None})
    if not item:
        raise HTTPException(status_code=404, detail="Demande C20 introuvable")
    return item


@router.delete("/c20/{c20_id}")
def remove_c20(c20_id: int):
    service.delete_demande_c20(c20_id)
    return {"ok": True}


# ---------------------------------------------------------------------------
# DOSSIER FISCAL NUMÉRIQUE (الملف الرقمي للشركة)
# ---------------------------------------------------------------------------

class DocumentUpdatePayload(BaseModel):
    titre: Optional[str] = None
    reference: Optional[str] = None
    exercice: Optional[str] = None
    categorie: Optional[str] = None
    type_document: Optional[str] = None
    date_emission: Optional[str] = None
    date_expiration: Optional[str] = None
    notes: Optional[str] = None


class ScanHardwarePayload(BaseModel):
    device_id: str = ""
    color_mode: str = "color"
    dpi: int = 200


class DocumentCapturePayload(BaseModel):
    dossier: str
    categorie: str = "divers"
    type_document: str = "autre"
    exercice: str = ""
    titre: str = ""
    reference: str = ""
    date_emission: str = ""
    date_expiration: str = ""
    image_base64: str
    mime_type: str = "image/jpeg"
    source_capture: str = "scanner_webcam"
    notes: str = ""
    overwrite: bool = False


@router.get("/documents/catalog")
def get_documents_catalog():
    """Return structured catalogue of categories and standard document types."""
    return service.get_document_catalog()


@router.get("/documents")
def list_documents(
    dossier: str = Query(..., description="Code du dossier (S1..S10)"),
    categorie: Optional[str] = Query(None, description="Filtre par catégorie"),
    search: Optional[str] = Query(None, description="Recherche textuelle"),
):
    """List documents for a company with validity status."""
    return service.list_dossier_documents(dossier=dossier, categorie=categorie, search=search)


@router.get("/documents/stats")
def get_documents_stats(
    dossier: str = Query(..., description="Code du dossier (S1..S10)"),
):
    """Completeness score, missing mandatory documents, and expiration alerts."""
    return service.get_dossier_documents_stats(dossier=dossier)


@router.post("/documents/upload")
async def upload_document(
    file: UploadFile = File(...),
    dossier: str = Form(...),
    categorie: str = Form("divers"),
    type_document: str = Form("autre"),
    exercice: str = Form(""),
    titre: str = Form(""),
    reference: str = Form(""),
    date_emission: str = Form(""),
    date_expiration: str = Form(""),
    source_capture: str = Form("upload"),
    notes: str = Form(""),
    overwrite: bool = Form(False),
):
    """Upload PDF, Excel, or Image document via multipart form."""
    content = await file.read()
    if not content:
        raise HTTPException(400, "Le fichier est vide")
    if len(content) > 30 * 1024 * 1024:
        raise HTTPException(400, "Fichier trop volumineux (max 30 Mo)")

    try:
        doc = service.create_dossier_document(
            dossier=dossier,
            data={
                "categorie": categorie,
                "type_document": type_document,
                "exercice": exercice,
                "titre": titre or file.filename or "Document sans titre",
                "reference": reference,
                "date_emission": date_emission,
                "date_expiration": date_expiration,
                "source_capture": source_capture,
                "notes": notes,
                "overwrite": overwrite,
            },
            file_bytes=content,
            original_filename=file.filename or "document.bin",
            mime_type=file.content_type or "application/octet-stream",
            overwrite=overwrite,
        )
        return doc
    except ValueError as e:
        err_msg = str(e)
        if "DOCUMENT_DUPLICATE" in err_msg or "مسجلة مسبقاً" in err_msg:
            raise HTTPException(409, detail=err_msg)
        raise HTTPException(400, detail=err_msg)


@router.post("/documents/capture-base64")
def capture_document_base64(payload: DocumentCapturePayload):
    """Save document captured from scanner / webcam / phone camera in base64."""
    raw_b64 = payload.image_base64
    if "," in raw_b64:
        raw_b64 = raw_b64.split(",", 1)[1]

    try:
        image_bytes = base64.b64decode(raw_b64)
    except Exception as e:
        raise HTTPException(400, f"Données base64 invalides : {e}")

    if len(image_bytes) > 25 * 1024 * 1024:
        raise HTTPException(400, "Image capturée trop volumineuse (max 25 Mo)")

    ext = "jpg"
    if "png" in payload.mime_type.lower():
        ext = "png"
    elif "pdf" in payload.mime_type.lower():
        ext = "pdf"
    filename = f"capture_{payload.type_document}.{ext}"

    try:
        doc = service.create_dossier_document(
            dossier=payload.dossier,
            data={
                "categorie": payload.categorie,
                "type_document": payload.type_document,
                "exercice": payload.exercice,
                "titre": payload.titre or f"Numérisation {payload.type_document}",
                "reference": payload.reference,
                "date_emission": payload.date_emission,
                "date_expiration": payload.date_expiration,
                "source_capture": payload.source_capture or "scanner_hardware",
                "notes": payload.notes,
                "overwrite": payload.overwrite,
            },
            file_bytes=image_bytes,
            original_filename=filename,
            mime_type=payload.mime_type,
            overwrite=payload.overwrite,
        )
        return doc
    except ValueError as e:
        err_msg = str(e)
        if "DOCUMENT_DUPLICATE" in err_msg or "مسجلة مسبقاً" in err_msg:
            raise HTTPException(409, detail=err_msg)
        raise HTTPException(400, detail=err_msg)


@router.get("/documents/scanner-devices")
def get_scanner_devices():
    """Détecte et liste les scanners et imprimantes multifonctions connectés via WIA."""
    scanners = scanner_service.list_connected_scanners()
    return {"scanners": scanners, "count": len(scanners)}


@router.post("/documents/scan-hardware")
def trigger_hardware_scan(payload: ScanHardwarePayload):
    """Déclenche l'acquisition réelle depuis le scanner de bureau ou l'imprimante multifonction (WIA)."""
    res = scanner_service.scan_document_from_hardware(
        device_id=payload.device_id,
        color_mode=payload.color_mode,
        dpi=payload.dpi,
    )
    return res


MOBILE_PAIRING_SESSIONS: Dict[str, Dict[str, Any]] = {}


@router.get("/documents/mobile-pairing")
def get_mobile_pairing(
    dossier: str = Query("S1"),
    type_document: str = Query("autre"),
    categorie: Optional[str] = Query("general"),
    titre: Optional[str] = Query(""),
    exercice: Optional[str] = Query(""),
    reference: Optional[str] = Query(""),
):
    """Génère l'URL et le code QR d'appairage direct pour le téléversement depuis smartphone."""
    cfg = access.load()
    port = int(os.environ.get("PORT", "8790"))
    ips = access.get_local_ips()
    lan_ip = ips[0] if ips else "127.0.0.1"

    token = secrets.token_urlsafe(16)
    now = time.time()
    for k in list(MOBILE_PAIRING_SESSIONS.keys()):
        if now - MOBILE_PAIRING_SESSIONS[k]["created_at"] > 1800:
            MOBILE_PAIRING_SESSIONS.pop(k, None)

    cat = (categorie or "general").strip()
    typ = (type_document or "autre").strip()
    tit = (titre or "").strip()
    ex = (exercice or "").strip()
    ref_user = (reference or "").strip()

    MOBILE_PAIRING_SESSIONS[token] = {
        "token": token,
        "dossier": dossier,
        "categorie": cat,
        "type_document": typ,
        "titre": tit,
        "exercice": ex,
        "reference": ref_user,
        "created_at": now,
        "ready": False,
        "image_base64": None,
        "filename": None,
        "mime_type": None,
    }

    mobile_path = f"/mobile-upload?token={token}&dossier={dossier}&type={typ}"
    url_lan = f"http://{lan_ip}:{port}{mobile_path}"
    qr_data_uri = access.generate_qr_data_uri(url_lan)

    url_cloud = None
    cloud_qr_data_uri = None
    t_status = {"disponible": False, "actif": False, "en_cours": False, "url": None, "erreur": None}
    try:
        from ..core import tunnel
        t_status = tunnel.get_status()
        if t_status.get("actif") and t_status.get("url"):
            url_cloud = f"{t_status['url'].rstrip('/')}{mobile_path}"
            cloud_qr_data_uri = access.generate_qr_data_uri(url_cloud)
    except Exception as e:
        t_status["erreur"] = str(e)

    return {
        "token": token,
        "dossier": dossier,
        "categorie": cat,
        "type_document": typ,
        "titre": tit,
        "exercice": ex,
        "reference": ref_user,
        "url_lan": url_lan,
        "url_cloud": url_cloud,
        "lan_ip": lan_ip,
        "port": port,
        "qr_data_uri": qr_data_uri,
        "cloud_qr_data_uri": cloud_qr_data_uri,
        "tunnel": t_status,
        "acces_mobile_active": cfg.get("acces_mobile", True),
    }


@router.get("/documents/mobile-pairing-status")
def get_mobile_pairing_status(token: str = Query(...)):
    """Vérifie si une photo a été téléversée depuis le smartphone pour cette session d'appairage."""
    session = MOBILE_PAIRING_SESSIONS.get(token)
    if not session:
        return {"ready": False, "expired": True}
    if session.get("ready"):
        return {
            "ready": True,
            "image_base64": session.get("image_base64"),
            "filename": session.get("filename"),
            "mime_type": session.get("mime_type"),
            "doc_id": session.get("doc_id"),
        }
    return {"ready": False}


@router.post("/documents/mobile-direct-upload")
async def handle_mobile_direct_upload(
    token: str = Form(""),
    dossier: str = Form("S1"),
    type_document: str = Form("autre"),
    rotation: int = Form(0),
    file: UploadFile = File(...),
):
    """Reçoit la photo capturée par le smartphone et l'enregistre immédiatement dans le dossier fiscal."""
    try:
        session = MOBILE_PAIRING_SESSIONS.get(token)
        content = await file.read()
        if not content:
            raise HTTPException(400, "Le fichier photo reçu est vide.")

        if rotation and rotation % 360 != 0:
            try:
                import io
                from PIL import Image
                img = Image.open(io.BytesIO(content))
                img = img.rotate(-rotation, expand=True)
                bio = io.BytesIO()
                img.convert("RGB").save(bio, format="JPEG", quality=92)
                content = bio.getvalue()
            except Exception as e_rot:
                print(f"Warning rotation photo mobile: {e_rot}")

        mime = file.content_type or "image/jpeg"
        b64_str = base64.b64encode(content).decode("ascii")
        data_uri = f"data:{mime};base64,{b64_str}"

        target_dossier = (dossier or "").strip()
        if not target_dossier and session:
            target_dossier = session.get("dossier", "S1")
        if not target_dossier:
            target_dossier = "S1"

        # Sequential counter for mobile captures in this dossier
        seq_num = 1
        try:
            with service._conn() as c:
                row = c.execute(
                    "SELECT COUNT(*) FROM fiscal_dossier_documents WHERE dossier = ? AND (categorie = 'general' OR source_capture LIKE '%smartphone%' OR source_capture LIKE '%mobile%')",
                    (target_dossier,)
                ).fetchone()
                seq_num = (row[0] if row else 0) + 1
        except Exception:
            pass

        now_str = datetime.now().strftime("%d/%m/%Y %H:%M")
        today_iso = datetime.now().strftime("%Y-%m-%d")

        # Determine category and type: check session pre-selection first
        session_cat = (session.get("categorie") if session else None) or ""
        cat_id = session_cat if (session_cat and session_cat != "undefined") else "general"

        session_type = (session.get("type_document") if session else None) or ""
        target_type = session_type if (session_type and session_type != "undefined") else (type_document or "capture_mobile")

        # Track photo count in this pairing session
        if session:
            uploaded_count = session.get("uploaded_count", 0) + 1
            session["uploaded_count"] = uploaded_count
        else:
            uploaded_count = 1

        # Determine title
        session_titre = (session.get("titre") if session else None) or ""
        if session_titre and session_titre.strip():
            base_t = session_titre.strip()
            titre = f"{base_t} (صورة {uploaded_count})" if uploaded_count > 1 else base_t
        else:
            titre = f"وثيقة ملتقطة #{seq_num} ({now_str})"

        # Determine reference
        session_ref = (session.get("reference") if session else None) or ""
        if session_ref and session_ref.strip():
            base_r = session_ref.strip()
            ref = f"{base_r}-p{uploaded_count}" if uploaded_count > 1 else base_r
        else:
            ref = f"MOB-{seq_num:03d}"

        target_exercice = (session.get("exercice") if session else None) or ""

        ext = "jpg"
        if "png" in mime.lower():
            ext = "png"
        elif "pdf" in mime.lower():
            ext = "pdf"

        original_filename = file.filename or f"mobile_capture_{seq_num}_{int(time.time())}.{ext}"

        # DIRECT PERSISTENCE TO DOSSIER (Always creates a new distinct document):
        created_doc = service.create_dossier_document(
            dossier=target_dossier,
            data={
                "categorie": cat_id,
                "type_document": target_type,
                "exercice": target_exercice,
                "titre": titre,
                "reference": ref,
                "date_emission": today_iso,
                "date_expiration": "",
                "source_capture": "smartphone_camera",
                "notes": f"Photo #{seq_num} reçue depuis le smartphone ({cat_id} / {target_type})",
                "overwrite": False,
            },
            file_bytes=content,
            original_filename=original_filename,
            mime_type=mime,
            overwrite=False,
        )

        if not session and token:
            MOBILE_PAIRING_SESSIONS[token] = {
                "token": token,
                "dossier": target_dossier,
                "type_document": target_type,
                "created_at": time.time(),
            }
            session = MOBILE_PAIRING_SESSIONS[token]

        if session:
            session["ready"] = True
            session["image_base64"] = data_uri
            session["filename"] = original_filename
            session["mime_type"] = mime
            session["doc_id"] = created_doc.get("id") if isinstance(created_doc, dict) else None
            session["saved"] = True

        return {
            "status": "ok",
            "message": "Photo transmise et archivée avec succès dans le dossier.",
            "filename": original_filename,
            "document_id": created_doc.get("id"),
            "bytes": len(content),
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(400, f"Erreur lors du traitement de la photo : {str(e)}")


@router.get("/documents/{doc_id}")
def read_document(doc_id: int):
    doc = service.get_dossier_document(doc_id)
    if not doc:
        raise HTTPException(404, "Document introuvable")
    return doc


@router.put("/documents/{doc_id}")
def edit_document(doc_id: int, payload: DocumentUpdatePayload):
    doc = service.update_dossier_document(doc_id, {k: v for k, v in payload.dict().items() if v is not None})
    if not doc:
        raise HTTPException(404, "Document introuvable")
    return doc


@router.delete("/documents/{doc_id}")
def delete_document(doc_id: int):
    ok = service.delete_dossier_document(doc_id)
    if not ok:
        raise HTTPException(404, "Document introuvable")
    return {"ok": True}


@router.get("/documents/{doc_id}/download")
def download_document(
    doc_id: int,
    disposition: str = Query("inline", description="inline ou attachment"),
):
    """Stream document file for browser preview or direct download."""
    doc = service.get_dossier_document(doc_id)
    if not doc:
        raise HTTPException(404, "Document introuvable")

    file_path = service.get_document_file_path(doc_id)
    if not file_path or not file_path.is_file():
        raise HTTPException(404, "Fichier physique introuvable sur le disque")

    return FileResponse(
        path=file_path,
        media_type=doc.get("mime_type", "application/octet-stream"),
        filename=doc.get("fichier_nom"),
        content_disposition_type=disposition,
    )


@router.get("/documents/{doc_id}/export-pdf")
def export_document_as_pdf(doc_id: int):
    """Export document as PDF. If image, converts automatically to A4 PDF via Pillow."""
    doc = service.get_dossier_document(doc_id)
    if not doc:
        raise HTTPException(404, "Document introuvable")

    file_path = service.get_document_file_path(doc_id)
    if not file_path or not file_path.is_file():
        raise HTTPException(404, "Fichier physique introuvable sur le disque")

    mime = doc.get("mime_type", "").lower()
    titre_raw = doc.get("titre") or "Document"
    titre_safe = "".join(c for c in titre_raw if c.isalnum() or c in (" ", "_", "-")).strip() or "document"
    pdf_filename = f"{titre_safe}.pdf"

    if "pdf" in mime:
        return FileResponse(
            path=file_path,
            media_type="application/pdf",
            filename=pdf_filename,
            content_disposition_type="attachment",
        )

    try:
        from PIL import Image
        import io

        with Image.open(file_path) as img:
            rgb_img = img.convert("RGB")
            buf = io.BytesIO()
            rgb_img.save(buf, format="PDF", resolution=150.0)
            buf.seek(0)
            pdf_bytes = buf.getvalue()

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="{pdf_filename}"'
            },
        )
    except Exception:
        return FileResponse(
            path=file_path,
            media_type=doc.get("mime_type", "application/octet-stream"),
            filename=doc.get("fichier_nom"),
            content_disposition_type="attachment",
        )


@router.get("/documents-export/zip")
def export_dossier_zip(
    dossier: str = Query(..., description="Code du dossier"),
):
    """Export complete organized ZIP archive of all documents in the company dossier."""
    zip_bytes = service.generate_dossier_zip(dossier)
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={
            "Content-Disposition": f"attachment; filename=Dossier_Fiscal_{dossier}_Complet.zip"
        },
    )


