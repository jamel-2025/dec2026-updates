"""API Routes pour l'archivage et le suivi des messages WhatsApp."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel

from app.core import audit
from app.services import whatsapp_service

router = APIRouter(prefix="/api/whatsapp", tags=["whatsapp"])


class ArchiveIn(BaseModel):
    dossier: Optional[str] = None
    client_name: str
    telephone: str
    category: str
    sujet: str
    message: str
    lang: Optional[str] = "ar"
    statut: Optional[str] = "envoye"


@router.post("/archiver")
def archiver_message(body: ArchiveIn, request: Request):
    """Archive un message WhatsApp envoyé."""
    record = whatsapp_service.archiver_message(
        dossier=body.dossier,
        client_name=body.client_name,
        telephone=body.telephone,
        category=body.category,
        sujet=body.sujet,
        message=body.message,
        lang=body.lang or "ar",
        statut=body.statut or "envoye",
    )
    audit.record(
        action="WHATSAPP_SENT",
        category="communication",
        description=f"Message WhatsApp envoyé à {body.client_name} ({body.sujet})",
        request=request,
        dossier=body.dossier,
        status="success",
        details={"tel": body.telephone, "category": body.category},
    )
    return {"status": "ok", "record": record}


@router.get("/historique")
def get_historique(dossier: Optional[str] = Query(None), limit: int = Query(200, ge=1, le=1000)):
    """Liste les messages archivés."""
    return {"items": whatsapp_service.lister_archives(dossier=dossier, limit=limit)}


@router.delete("/historique/{archive_id}")
def delete_historique(archive_id: int):
    """Supprime une entrée de l'historique."""
    success = whatsapp_service.supprimer_archive(archive_id)
    if not success:
        raise HTTPException(404, "Message non trouvé")
    return {"status": "ok", "deleted_id": archive_id}
