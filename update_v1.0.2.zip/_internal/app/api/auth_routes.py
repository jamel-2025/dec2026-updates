"""Routes API pour l'accès mobile : authentification, état, réseau et code QR."""
from __future__ import annotations

import shutil
import subprocess
from typing import Optional
from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import Response as RawResponse
from pydantic import BaseModel, Field

from ..core import access
from ..core import tunnel
from ..core import audit

router = APIRouter(tags=["Accès Mobile & Réseau"])


class LoginPayload(BaseModel):
    pin: str = Field(..., min_length=1)


class PinPayload(BaseModel):
    pin: str = Field(..., min_length=6)


class NetworkUpdatePayload(BaseModel):
    acces_mobile: Optional[bool] = None
    ecoute_lan: Optional[bool] = None
    lecture_seule: Optional[bool] = None
    session_heures: Optional[int] = None


@router.get("/api/auth/etat")
def get_auth_etat(request: Request):
    """Vérifie l'état d'accès actuel du client (local ou distant, authentifié ou non)."""
    is_local = access.is_desktop(request)
    cfg = access.load()
    token = request.cookies.get(access.COOKIE)
    is_auth = is_local or access.SESSIONS.valid(token)

    return {
        "local": is_local,
        "authentifie": is_auth,
        "acces_mobile": cfg.get("acces_mobile", True),
        "pin_defini": bool(cfg.get("pin_hash")),
        "lecture_seule": bool(cfg.get("lecture_seule", False)),
    }


@router.post("/api/auth/login")
def login(payload: LoginPayload, request: Request, response: Response):
    """Authentifie un client distant via son code PIN."""
    client_ip = request.client.host if request.client else "unknown"
    if access.THROTTLE.is_blocked(client_ip):
        audit.record(
            action="AUTH_THROTTLED",
            category="security",
            description=f"Tentative de connexion bloquée suite à des échecs répétés (IP: {client_ip})",
            request=request,
            status="blocked",
        )
        raise HTTPException(
            status_code=429,
            detail="Trop de tentatives, réessayez dans 5 minutes.",
        )

    cfg = access.load()
    if not cfg.get("acces_mobile", True):
        audit.record(
            action="AUTH_DISABLED",
            category="security",
            description="Tentative de connexion distante alors que l'accès réseau est désactivé",
            request=request,
            status="blocked",
        )
        raise HTTPException(
            status_code=403,
            detail="Accès depuis le réseau désactivé sur le poste principal.",
        )

    # Si aucun code PIN n'a encore été configuré, autoriser un code par défaut '000000' ou refuser
    pin_configured = bool(cfg.get("pin_hash"))
    if not pin_configured:
        # Initialise avec le code saisi s'il fait au moins 6 chiffres
        if len(payload.pin.strip()) >= 6:
            access.set_pin(payload.pin.strip())
            valid = True
        else:
            raise HTTPException(
                status_code=401,
                detail="Le code d'accès doit contenir au moins 6 chiffres.",
            )
    else:
        valid = access.check_pin(payload.pin)

    if not valid:
        access.THROTTLE.record_failure(client_ip)
        audit.record(
            action="AUTH_LOGIN_FAILED",
            category="security",
            description="Échec de connexion : code PIN incorrect",
            request=request,
            status="warning",
        )
        raise HTTPException(status_code=401, detail="Code incorrect.")

    access.THROTTLE.reset(client_ip)
    token = access.SESSIONS.create()

    session_hours = cfg.get("session_heures", 12)
    max_age = int(session_hours * 3600)
    is_https = request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https"

    response.set_cookie(
        key=access.COOKIE,
        value=token,
        max_age=max_age,
        httponly=True,
        samesite="lax",
        secure=is_https,
        path="/",
    )
    audit.record(
        action="AUTH_LOGIN_SUCCESS",
        category="security",
        description="Connexion à distance autorisée avec succès",
        request=request,
        status="success",
    )
    return {"ok": True, "message": "Connexion réussie"}


@router.post("/api/auth/logout")
def logout(request: Request, response: Response):
    """Déconnecte la session distante courante."""
    token = request.cookies.get(access.COOKIE)
    if token:
        access.SESSIONS.revoke(token)
    response.delete_cookie(key=access.COOKIE, path="/")
    audit.record(
        action="AUTH_LOGOUT",
        category="security",
        description="Déconnexion de la session distante",
        request=request,
        status="success",
    )
    return {"ok": True}


def _check_local_only(request: Request):
    """Garantit que la route n'est accessible que depuis le poste desktop local."""
    if not access.is_desktop(request):
        raise HTTPException(
            status_code=403,
            detail="Action disponible uniquement sur le poste principal.",
        )


@router.get("/api/reseau")
def get_reseau_status(request: Request):
    """Informations de connectivité réseau pour le dialogue Accès Mobile."""
    _check_local_only(request)
    cfg = access.load()
    ips = access.get_local_ips()
    port = cfg.get("port", 8790)

    # Choisir l'IP Wi-Fi/LAN principale (en évitant 192.168.56.* de VirtualBox)
    lan_ip = None
    for ip in ips:
        if not ip.startswith("192.168.56."):
            lan_ip = ip
            break
    if not lan_ip and ips:
        lan_ip = ips[0]
    lan_ip = lan_ip or "127.0.0.1"

    url_lan = f"http://{lan_ip}:{port}/"

    # Vérification Tailscale
    tailscale_info = {"installe": False, "connecte": False, "url": None}
    ts_exe = shutil.which("tailscale")
    if ts_exe:
        tailscale_info["installe"] = True
        try:
            res = subprocess.run([ts_exe, "status", "--json"], capture_output=True, text=True, timeout=2)
            if res.returncode == 0:
                import json
                ts_data = json.loads(res.stdout)
                tailscale_info["connecte"] = ts_data.get("BackendState") == "Running"
                self_node = ts_data.get("Self", {})
                dns_name = self_node.get("DNSName", "").rstrip(".")
                if dns_name:
                    tailscale_info["url"] = f"https://{dns_name}/"
        except Exception:
            pass

    qr_data_uri = access.generate_qr_data_uri(url_lan)

    return {
        "acces_mobile": cfg.get("acces_mobile", True),
        "ecoute_lan": cfg.get("ecoute_lan", True),
        "port": port,
        "pin_defini": bool(cfg.get("pin_hash")),
        "lecture_seule": cfg.get("lecture_seule", False),
        "adresses": ips,
        "ip_principale": lan_ip,
        "url_lan": url_lan,
        "qr_data_uri": qr_data_uri,
        "qr_png_data_uri": qr_data_uri,
        "tailscale": tailscale_info,
        "tunnel": tunnel.get_status(),
    }


@router.put("/api/reseau")
def update_reseau_settings(payload: NetworkUpdatePayload, request: Request):
    """Met à jour les paramètres d'écoute réseau et d'accès mobile."""
    _check_local_only(request)
    cfg = access.load()

    if payload.acces_mobile is not None:
        cfg["acces_mobile"] = payload.acces_mobile
    if payload.ecoute_lan is not None:
        cfg["ecoute_lan"] = payload.ecoute_lan
    if payload.lecture_seule is not None:
        cfg["lecture_seule"] = payload.lecture_seule
    if payload.session_heures is not None:
        cfg["session_heures"] = payload.session_heures

    access.save(cfg)
    return {"ok": True, "settings": cfg}


@router.put("/api/reseau/pin")
def update_pin(payload: PinPayload, request: Request):
    """Définit ou change le code PIN d'accès mobile."""
    _check_local_only(request)
    try:
        access.set_pin(payload.pin)
        return {"ok": True, "message": "Code PIN enregistré avec succès."}
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.post("/api/reseau/deconnecter")
def disconnect_all(request: Request):
    """Déconnecte tous les téléphones distants simultanément."""
    _check_local_only(request)
    access.SESSIONS.revoke_all()
    audit.record(
        action="AUTH_REVOKE_ALL",
        category="security",
        description="Révocation de toutes les sessions distantes",
        request=request,
        status="warning",
    )
    return {"ok": True, "message": "Toutes les sessions distantes ont été révoquées."}


@router.get("/api/reseau/qr.svg")
def get_qr_svg(url: str, request: Request):
    """Génère le code QR officiel au format SVG."""
    _check_local_only(request)
    svg_code = access.generate_qr_svg(url)
    return RawResponse(content=svg_code, media_type="image/svg+xml")


@router.get("/api/reseau/qr.png")
def get_qr_png(url: str, request: Request):
    """Génère le code QR officiel au format PNG."""
    _check_local_only(request)
    png_bytes = access.generate_qr_png_bytes(url)
    return RawResponse(content=png_bytes, media_type="image/png")


@router.get("/api/reseau/tunnel")
def get_tunnel_status(request: Request):
    """Obtient le statut du tunnel public Cloudflare."""
    _check_local_only(request)
    return tunnel.get_status()


@router.post("/api/reseau/tunnel/start")
def start_tunnel_endpoint(request: Request):
    """Démarre le tunnel public Cloudflare vers le serveur local."""
    _check_local_only(request)
    cfg = access.load()
    port = cfg.get("port", 8790)
    res = tunnel.start_tunnel(port=port)
    audit.record(
        action="TUNNEL_START",
        category="system",
        description=f"Démarrage du tunnel Cloudflare (Port {port})",
        request=request,
        status="success",
        details=res,
    )
    return res


@router.post("/api/reseau/tunnel/stop")
def stop_tunnel_endpoint(request: Request):
    """Arrête le tunnel public Cloudflare."""
    _check_local_only(request)
    res = tunnel.stop_tunnel()
    audit.record(
        action="TUNNEL_STOP",
        category="system",
        description="Arrêt du tunnel Cloudflare",
        request=request,
        status="success",
    )
    return res


