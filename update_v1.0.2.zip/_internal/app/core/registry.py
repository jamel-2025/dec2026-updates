"""Table registry built from spec/tables.json (extracted from the Delphi DFMs).

It is the single source for physical table names, field types and display formats, so
nothing about the data model is hand-written in the web code."""
from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache

from . import config

INT_TYPES = {"Integer", "SmallInt", "LargeInt", "AutoInc", "Word", "LongWord", "ShortInt"}
FLOAT_TYPES = {"Float", "Currency", "BCD", "FMTBCD", "Single", "Extended"}
DATE_TYPES = {"DateTime", "Date", "Time", "SQLTimeStamp"}
BOOL_TYPES = {"Boolean"}


@dataclass(frozen=True)
class Field:
    name: str
    type: str
    display_format: str | None = None
    size: int | None = None
    autoinc: bool = False

    @property
    def kind(self) -> str:
        if self.type in INT_TYPES:
            return "int"
        if self.type in FLOAT_TYPES:
            return "float"
        if self.type in DATE_TYPES:
            return "date"
        if self.type in BOOL_TYPES:
            return "bool"
        return "str"


@dataclass(frozen=True)
class Table:
    name: str
    fields: tuple[Field, ...]
    master_fields: str | None = None
    detail_fields: str | None = None

    def field(self, name: str) -> Field | None:
        low = name.lower()
        return next((f for f in self.fields if f.name.lower() == low), None)

    @property
    def key(self) -> Field | None:
        return next((f for f in self.fields if f.autoinc), None)


@lru_cache
def tables() -> dict[str, Table]:
    raw = json.loads((config.SPEC_DIR / "tables.json").read_text("utf-8"))
    out: dict[str, Table] = {}
    for t in raw:
        name = t.get("table")
        if not name:
            continue
        fields = tuple(
            Field(
                name=f["field"],
                type=f["type"],
                display_format=f.get("DisplayFormat"),
                size=f.get("Size"),
                autoinc=f.get("AutoGenerateValue") == "arAutoInc" or f["type"] == "AutoInc",
            )
            for f in t["fields"]
        )
        prev = out.get(name)
        if prev is None or len(fields) > len(prev.fields):  # keep the most complete declaration
            out[name] = Table(name, fields, t.get("master_fields"), t.get("detail_fields"))
    return out


def get(name: str) -> Table:
    t = tables().get(name)
    if t is None:
        raise KeyError(f"Table inconnue dans la spécification : {name}")
    return t


def coerce(field: Field, value):
    """Convert an incoming JSON value to the storage type of the Delphi field."""
    if value is None or value == "":
        return None
    k = field.kind
    if k == "int":
        return int(round(float(str(value).replace(" ", "").replace(",", "."))))
    if k == "float":
        return float(str(value).replace(" ", "").replace(",", "."))
    if k == "bool":
        return 1 if value in (True, 1, "1", "true", "True") else 0
    return str(value)
