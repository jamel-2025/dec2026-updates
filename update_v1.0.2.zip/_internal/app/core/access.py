"""Accès depuis le téléphone : réglages, code PIN, sessions, détection des requêtes locales et QR code."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import socket
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from fastapi import Request
import segno

from . import config

LOCAL_HOSTS = {"127.0.0.1", "::1", "localhost", "testclient"}
PROXY_HEADERS = ("x-forwarded-for", "x-forwarded-host", "x-real-ip", "tailscale-user-login")
COOKIE = "dec_session"

DEFAULT_SETTINGS = {
    "acces_mobile": True,
    "ecoute_lan": True,
    "port": 8790,
    "pin_hash": "",
    "pin_salt": "",
    "session_heures": 12,
    "lecture_seule": False,
}


def is_desktop(request: Request) -> bool:
    """True only for the desktop window itself: loopback client and no reverse-proxy headers."""
    host = request.client.host if request.client else ""
    if host not in LOCAL_HOSTS:
        return False
    return not any(h in request.headers for h in PROXY_HEADERS)


def load() -> dict:
    """Loads configuration from ACCESS_FILE with defaults."""
    p = config.ACCESS_FILE
    if not p.is_file():
        return dict(DEFAULT_SETTINGS)
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
            merged = dict(DEFAULT_SETTINGS)
            merged.update(data)
            return merged
    except Exception:
        return dict(DEFAULT_SETTINGS)


def save(cfg: dict) -> None:
    """Atomic write to ACCESS_FILE."""
    p = config.ACCESS_FILE
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    tmp.replace(p)


def hash_pin(pin: str, salt_bytes: bytes) -> str:
    """PBKDF2-HMAC-SHA256 with 200,000 iterations."""
    h = hashlib.pbkdf2_hmac("sha256", pin.strip().encode("utf-8"), salt_bytes, 200_000)
    return h.hex()


def set_pin(pin: str) -> None:
    """Sets a new PIN (must be at least 6 digits), revokes existing sessions."""
    clean = pin.strip()
    if len(clean) < 6:
        raise ValueError("Le code doit contenir au moins 6 chiffres.")
    salt = secrets.token_bytes(16)
    hashed = hash_pin(clean, salt)
    cfg = load()
    cfg["pin_hash"] = hashed
    cfg["pin_salt"] = salt.hex()
    save(cfg)
    SESSIONS.revoke_all()


def check_pin(pin: str) -> bool:
    """Validates the PIN securely using constant-time comparison."""
    cfg = load()
    stored_hash = cfg.get("pin_hash", "")
    stored_salt = cfg.get("pin_salt", "")
    if not stored_hash or not stored_salt:
        return False
    try:
        salt_bytes = bytes.fromhex(stored_salt)
        calc_hash = hash_pin(pin, salt_bytes)
        return hmac.compare_digest(calc_hash, stored_hash)
    except Exception:
        return False


@dataclass
class Sessions:
    ttl: float = 12 * 3600
    _items: dict[str, float] = field(default_factory=dict)
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def create(self) -> str:
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._items[token] = time.time() + self.ttl
        return token

    def valid(self, token: str | None) -> bool:
        if not token:
            return False
        now = time.time()
        with self._lock:
            exp = self._items.get(token)
            if exp and exp > now:
                # Sliding expiration
                self._items[token] = now + self.ttl
                return True
            if token in self._items:
                del self._items[token]
        return False

    def revoke(self, token: str | None) -> None:
        if not token:
            return
        with self._lock:
            self._items.pop(token, None)

    def revoke_all(self) -> None:
        with self._lock:
            self._items.clear()


SESSIONS = Sessions()


class Throttle:
    """Limits failed attempts: 5 failed attempts per IP -> blocked for 5 minutes."""
    def __init__(self, max_attempts: int = 5, lock_duration: float = 300):
        self.max_attempts = max_attempts
        self.lock_duration = lock_duration
        self._failures: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def is_blocked(self, ip: str) -> bool:
        now = time.time()
        with self._lock:
            history = [t for t in self._failures.get(ip, []) if now - t < self.lock_duration]
            self._failures[ip] = history
            return len(history) >= self.max_attempts

    def record_failure(self, ip: str) -> None:
        now = time.time()
        with self._lock:
            history = [t for t in self._failures.get(ip, []) if now - t < self.lock_duration]
            history.append(now)
            self._failures[ip] = history

    def reset(self, ip: str) -> None:
        with self._lock:
            self._failures.pop(ip, None)


THROTTLE = Throttle()


def get_local_ips() -> list[str]:
    """Returns local LAN IPv4 addresses, prioritized by the active outbound interface."""
    ips: list[str] = []

    # 1. Primary active outbound interface (connects to local Wi-Fi / LAN gateway)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(0.3)
            s.connect(("8.8.8.8", 80))
            sock_ip = s.getsockname()[0]
            if sock_ip and not sock_ip.startswith("127.") and not sock_ip.startswith("169.254."):
                ips.append(sock_ip)
    except Exception:
        pass

    # 2. Enumerate other host interfaces, excluding virtual adapters (192.168.56.* VirtualBox)
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127.") and not ip.startswith("169.254."):
                if not ip.startswith("192.168.56."):
                    ips.append(ip)
    except Exception:
        pass

    return ips or ["127.0.0.1"]


def generate_qr_svg(url: str) -> str:
    """Generates a complete standalone SVG document with XML and xmlns headers."""
    import io
    qrcode = segno.make(url, error="m")
    buff = io.BytesIO()
    qrcode.save(buff, kind="svg", scale=6)
    return buff.getvalue().decode("utf-8")


def generate_qr_png_bytes(url: str) -> bytes:
    """Generates a PNG image byte buffer for the QR code."""
    import io
    qrcode = segno.make(url, error="m")
    buff = io.BytesIO()
    qrcode.save(buff, kind="png", scale=6)
    return buff.getvalue()


def generate_qr_png_data_uri(url: str) -> str:
    """Generates a data:image/png;base64 URI (100% universal)."""
    qrcode = segno.make(url, error="m")
    return qrcode.png_data_uri(scale=6)


def generate_qr_data_uri(url: str) -> str:
    """Generates a data:image/png;base64 URI for maximum compatibility."""
    return generate_qr_png_data_uri(url)

