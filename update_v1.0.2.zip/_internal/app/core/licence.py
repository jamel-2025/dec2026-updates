"""Hardware-locked licensing and activation system for Dec2026.

Uses Windows native hardware fingerprints (MachineGuid + Volume Serial Number)
and HMAC-SHA256 signature verification to prevent software piracy.
"""
from __future__ import annotations

import ctypes
import datetime
import hashlib
import hmac
import json
import os
import platform
import uuid
from pathlib import Path

from . import config

# Master secret key used for signing activation keys (kept private to Dec2026)
SECRET_SALT = "DEC2026-G50-MULTI-FISCAL-SECRET-ALGERIE-KEY-9941"


def get_raw_fingerprint() -> str:
    """Collects hardware and Windows installation identifiers."""
    parts = []
    
    # 1. Windows MachineGuid from Registry (instant, unique per installation)
    if platform.system() == "Windows":
        try:
            import winreg
            sam = winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0x0100)
            try:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, sam)
            except Exception:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
            with k:
                guid, _ = winreg.QueryValueEx(k, "MachineGuid")
                if guid:
                    parts.append(str(guid).strip())
        except Exception:
            pass

        # 2. System drive Volume Serial Number via kernel32
        try:
            vol = ctypes.c_ulong()
            if ctypes.windll.kernel32.GetVolumeInformationW(r"C:\\", None, 0, ctypes.byref(vol), None, None, None, 0):
                parts.append(hex(vol.value))
        except Exception:
            pass

    # Fallback / additional components
    parts.append(platform.node())
    parts.append(str(uuid.getnode()))
    
    return ":".join(parts)


def get_machine_id() -> str:
    """Returns a clean, human-readable Machine ID: G50-XXXX-XXXX-XXXX-XXXX."""
    raw = get_raw_fingerprint()
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
    return f"G50-{digest[0:4]}-{digest[4:8]}-{digest[8:12]}-{digest[12:16]}"


def generate_activation_key(machine_id: str, client: str, serial: str, expiry: str = "LIFETIME") -> str:
    """Generates the official activation key for a given machine ID and client."""
    m_id = machine_id.strip().upper()
    c_name = client.strip()
    s_num = serial.strip().upper()
    exp = expiry.strip().upper()
    
    payload = f"{m_id}|{c_name}|{s_num}|{exp}"
    sig = hmac.new(SECRET_SALT.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest().upper()
    return f"ACT-{sig[0:4]}-{sig[4:8]}-{sig[8:12]}-{sig[12:16]}-{sig[16:20]}"


def verify_license_data(data: dict) -> tuple[bool, str]:
    """Validates the license dictionary against current machine hardware and signature."""
    current_machine = get_machine_id()
    
    saved_machine = str(data.get("machine_id", "")).strip().upper()
    client = str(data.get("client", "")).strip()
    serial = str(data.get("serial", "")).strip().upper()
    expiry = str(data.get("expiry", "LIFETIME")).strip().upper()
    key = str(data.get("activation_key", "")).strip().upper()

    if saved_machine != current_machine:
        return False, "Cette licence n'est pas valide pour cet ordinateur."

    expected_key = generate_activation_key(saved_machine, client, serial, expiry)
    if not hmac.compare_digest(key, expected_key):
        return False, "Clé d'activation invalide ou corrompue."

    if expiry != "LIFETIME":
        try:
            exp_date = datetime.date.fromisoformat(expiry)
            if datetime.date.today() > exp_date:
                return False, f"La licence a expiré le {exp_date.strftime('%d/%m/%Y')}."
        except ValueError:
            return False, "Format de date d'expiration invalide."

    return True, "Licence valide"


def get_license_status() -> dict:
    """Returns current activation status and details."""
    current_machine = get_machine_id()

    # Development or testing bypass (only if explicitly set in environment)
    if os.environ.get("DEC_DEV_MODE") == "1" or os.environ.get("DEC_SKIP_LICENCE") == "1":
        return {
            "activated": True,
            "machine_id": current_machine,
            "client": "Mode Développement (Bypass)",
            "serial": "DEV-2026",
            "expiry": "LIFETIME",
            "message": "Mode développement actif",
        }

    p = config.LICENCE_FILE
    if not p.is_file():
        return {
            "activated": False,
            "machine_id": current_machine,
            "client": "",
            "serial": "",
            "expiry": "",
            "message": "Logiciel non activé. Veuillez entrer votre clé d'activation.",
        }

    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        valid, msg = verify_license_data(data)
        return {
            "activated": valid,
            "machine_id": current_machine,
            "client": data.get("client", ""),
            "serial": data.get("serial", ""),
            "expiry": data.get("expiry", "LIFETIME"),
            "message": msg,
        }
    except Exception as e:
        return {
            "activated": False,
            "machine_id": current_machine,
            "client": "",
            "serial": "",
            "expiry": "",
            "message": f"Erreur de lecture de la licence : {e}",
        }


def activate(client: str, serial: str, activation_key: str, expiry: str = "LIFETIME") -> dict:
    """Attempts to activate the software and save the license file."""
    current_machine = get_machine_id()
    clean_client = client.strip()
    clean_serial = serial.strip().upper()
    clean_key = activation_key.strip().upper()
    clean_expiry = expiry.strip().upper()

    if not clean_client:
        raise ValueError("Le nom du client est obligatoire.")
    if not clean_serial:
        raise ValueError("Le numéro de série est obligatoire.")
    if not clean_key:
        raise ValueError("La clé d'activation est obligatoire.")

    data = {
        "machine_id": current_machine,
        "client": clean_client,
        "serial": clean_serial,
        "expiry": clean_expiry,
        "activation_key": clean_key,
        "activated_at": datetime.datetime.now().isoformat(),
    }

    valid, msg = verify_license_data(data)
    if not valid:
        raise ValueError(msg)

    config.LICENCE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(config.LICENCE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    return {
        "success": True,
        "message": "Activation réussie ! Merci d'avoir enregistré votre application.",
        "client": clean_client,
        "expiry": clean_expiry,
    }


def deactivate() -> dict:
    """Removes the license file."""
    if config.LICENCE_FILE.is_file():
        config.LICENCE_FILE.unlink()
    return {"success": True, "message": "Licence réinitialisée."}
