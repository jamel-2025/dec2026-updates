"""Per-dossier SQLite access. Each company (dossier) owns data/societes/<code>/G50.sqlite,
whose schema is the Delphi schema (same table and column names)."""
from __future__ import annotations

import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from fastapi import HTTPException

from . import config

_CODE = re.compile(r"^[\w\- ]{1,64}$")


def dossier_path(code: str) -> Path:
    if not code or not _CODE.match(code) or code.strip(" .") != code:
        raise HTTPException(400, f"Code dossier invalide : {code!r}")
    p = config.SOCIETES_DIR / code / config.DB_FILENAME
    if not p.is_file():
        raise HTTPException(404, f"Dossier introuvable : {code}")
    return p


@contextmanager
def connect(code: str):
    conn = sqlite3.connect(dossier_path(code))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def table_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    return [r[1] for r in conn.execute(f'PRAGMA table_info("{table}")')]
