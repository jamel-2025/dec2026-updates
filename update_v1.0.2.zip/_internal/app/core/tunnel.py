"""Cloudflare Quick Tunnel Manager for Dec2026.

Provides secure, on-demand public HTTPS remote access to the local Dec2026 server
from anywhere on the Internet without port-forwarding or configuration.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

_PROCESS: subprocess.Popen | None = None
_TUNNEL_URL: str | None = None
_TUNNEL_ERROR: str | None = None
_STARTING: bool = False
_STARTED_AT: float | None = None
_LOCK = threading.Lock()


def find_cloudflared_exe() -> str | None:
    """Finds the cloudflared executable in standard project locations or PATH."""
    candidates = [
        # In bundled app (_internal/tools or root)
        Path(sys.executable).parent / "cloudflared.exe" if getattr(sys, "frozen", False) else None,
        Path(sys.executable).parent / "_internal" / "tools" / "cloudflared.exe" if getattr(sys, "frozen", False) else None,
        Path(sys.executable).parent / "tools" / "cloudflared.exe" if getattr(sys, "frozen", False) else None,
        # In development / workspace tree
        Path(__file__).resolve().parents[2] / "cloudflared.exe",
        Path(__file__).resolve().parents[2] / "tools" / "cloudflared.exe",
        Path(__file__).resolve().parents[1] / "tools" / "cloudflared.exe",
        Path.cwd() / "cloudflared.exe",
        Path.cwd() / "tools" / "cloudflared.exe",
        Path("G:/Dec2026F/cloudflared.exe") if Path("G:/Dec2026F/cloudflared.exe").is_file() else None,
        # In system PATH
        Path(shutil.which("cloudflared") or ""),
    ]
    for c in candidates:
        if c and c.is_file():
            return str(c)
    return None


def get_status() -> dict:
    """Returns the current status of the Cloudflare tunnel."""
    global _PROCESS, _TUNNEL_URL, _TUNNEL_ERROR, _STARTING, _STARTED_AT
    with _LOCK:
        has_binary = bool(find_cloudflared_exe())
        is_running = False
        if _PROCESS is not None:
            if _PROCESS.poll() is None:
                is_running = True
            else:
                _PROCESS = None
                if not _TUNNEL_ERROR:
                    _TUNNEL_ERROR = "Le tunnel s'est arrêté inopinément."
                _TUNNEL_URL = None
                _STARTING = False

        return {
            "disponible": has_binary,
            "actif": is_running and bool(_TUNNEL_URL),
            "en_cours": _STARTING,
            "url": _TUNNEL_URL if is_running else None,
            "erreur": _TUNNEL_ERROR,
            "depuis": int(time.time() - _STARTED_AT) if (is_running and _STARTED_AT) else None,
        }


def _monitor_output(proc: subprocess.Popen):
    """Background thread to capture stdout/stderr and extract the public HTTPS URL."""
    global _TUNNEL_URL, _TUNNEL_ERROR, _STARTING
    url_pattern = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")

    try:
        for line in proc.stdout:
            if not line:
                continue
            line_str = line.strip()
            match = url_pattern.search(line_str)
            if match and not _TUNNEL_URL:
                with _LOCK:
                    _TUNNEL_URL = match.group(0)
                    _STARTING = False
                    _TUNNEL_ERROR = None
    except Exception as e:
        with _LOCK:
            _TUNNEL_ERROR = str(e)
    finally:
        with _LOCK:
            _STARTING = False


def start_tunnel(port: int = 8790) -> dict:
    """Starts a Cloudflare quick tunnel routing to http://127.0.0.1:{port}."""
    global _PROCESS, _TUNNEL_URL, _TUNNEL_ERROR, _STARTING, _STARTED_AT

    with _LOCK:
        if _PROCESS is not None and _PROCESS.poll() is None and _TUNNEL_URL:
            return get_status()

        exe = find_cloudflared_exe()
        if not exe:
            return {
                "disponible": False,
                "actif": False,
                "en_cours": False,
                "url": None,
                "erreur": "Exécutable cloudflared.exe introuvable.",
            }

        _TUNNEL_URL = None
        _TUNNEL_ERROR = None
        _STARTING = True
        _STARTED_AT = time.time()

        cmd = [
            exe,
            "tunnel",
            "--url",
            f"http://127.0.0.1:{port}",
            "--no-autoupdate",
        ]

        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            _PROCESS = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=flags,
            )
        except Exception as e:
            _STARTING = False
            _TUNNEL_ERROR = str(e)
            return get_status()

    # Start reader thread
    t = threading.Thread(target=_monitor_output, args=(_PROCESS,), daemon=True)
    t.start()

    # Wait up to 10 seconds for URL resolution
    for _ in range(50):
        time.sleep(0.2)
        with _LOCK:
            if _TUNNEL_URL or not _STARTING:
                break

    return get_status()


def stop_tunnel() -> dict:
    """Stops the active Cloudflare quick tunnel."""
    global _PROCESS, _TUNNEL_URL, _TUNNEL_ERROR, _STARTING, _STARTED_AT
    with _LOCK:
        if _PROCESS is not None:
            try:
                _PROCESS.terminate()
                _PROCESS.wait(timeout=2)
            except Exception:
                try:
                    _PROCESS.kill()
                except Exception:
                    pass
            _PROCESS = None

        _TUNNEL_URL = None
        _TUNNEL_ERROR = None
        _STARTING = False
        _STARTED_AT = None

    return get_status()


# Backward-compatible alias
get_tunnel_status = get_status
