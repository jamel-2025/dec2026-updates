"""Runtime paths. Every path can be overridden with an environment variable."""
import os
from pathlib import Path

PROJECT_ROOT = Path(os.environ.get("DEC_PROJECT_ROOT", Path(__file__).resolve().parents[3]))
DELPHI_ROOT = Path(os.environ.get("DEC_DELPHI_ROOT", PROJECT_ROOT.parent))

SOCIETES_DIR = Path(os.environ.get("DEC_SOCIETES_DIR", PROJECT_ROOT / "data" / "societes"))
RAPPORTS_DIR = Path(
    os.environ.get(
        "DEC_RAPPORTS_DIR",
        PROJECT_ROOT / "Rapports" if (PROJECT_ROOT / "Rapports").is_dir() else (DELPHI_ROOT / "Rapports")
    )
)
SPEC_DIR = Path(os.environ.get("DEC_SPEC_DIR", PROJECT_ROOT / "spec"))
DATA_DIR = Path(os.environ.get("DEC_DATA_DIR", PROJECT_ROOT / "data"))
CACHE_DIR = Path(os.environ.get("DEC_CACHE_DIR", PROJECT_ROOT / "data" / "cache"))
def _resolve_frontend_dist() -> Path:
    env_p = os.environ.get("DEC_FRONTEND_DIST")
    if env_p and Path(env_p).is_dir():
        return Path(env_p)
    candidates = [
        PROJECT_ROOT / "frontend" / "dist",
        PROJECT_ROOT / "_internal" / "frontend" / "dist",
        Path(__file__).resolve().parents[2] / "frontend" / "dist",
        Path(__file__).resolve().parent.parent / "static",
        PROJECT_ROOT / "_internal" / "app" / "static",
    ]
    for c in candidates:
        if c.is_dir() and (c / "index.html").is_file():
            return c
    return PROJECT_ROOT / "frontend" / "dist"

FRONTEND_DIST = _resolve_frontend_dist()

REF_DB = Path(os.environ.get("DEC_REF_DB", PROJECT_ROOT / "data" / "ref" / "G50ref.sqlite"))

DB_FILENAME = "G50.sqlite"
BACKUP_DIR = Path(os.environ.get("DEC_BACKUP_DIR", PROJECT_ROOT / "data" / "backups"))
LICENCE_FILE = Path(os.environ.get("DEC_LICENCE_FILE", PROJECT_ROOT / "data" / "licence.key"))
ACCESS_FILE = Path(os.environ.get("DEC_ACCESS_FILE", PROJECT_ROOT / "data" / "acces.json"))
AUDIT_DB = Path(os.environ.get("DEC_AUDIT_DB", PROJECT_ROOT / "data" / "audit.sqlite"))
