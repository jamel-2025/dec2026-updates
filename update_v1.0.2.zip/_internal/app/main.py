"""Dec2026 — application server (API + built frontend)."""
from __future__ import annotations

from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .api.routes import router
from .api.auth_routes import router as auth_router
from .api.audit_routes import router as audit_router
from .api.ocr_routes import router as ocr_router
from .api.whatsapp_routes import router as whatsapp_router
from .api.features_routes import router as features_router
from .api.fiscal_advisory_routes import router as fiscal_advisory_router
from .api.rapprochement_routes import router as rapprochement_router
from .api.updater_routes import router as updater_router
from .core import config, licence, access, audit

app = FastAPI(title="Dec2026", version="0.1.0")

@app.on_event("startup")
def on_startup():
    audit.init_db()
    audit.record(
        action="APP_START",
        category="system",
        description="Démarrage de l'application Dec2026 sur le poste principal (Port 8790)",
        source_override="local",
        status="success",
    )

PUBLIC_PREFIXES = ("/assets/", "/icons/")
PUBLIC_PATHS = {
    "/", "/index.html", "/manifest.webmanifest", "/sw.js", "/favicon.ico",
    "/api/health", "/api/auth/etat", "/api/auth/login", "/api/licence/status", "/api/licence/activate",
    "/mobile-upload", "/api/fiscal/documents/mobile-direct-upload", "/api/fiscal/documents/mobile-pairing-status"
}
LOCAL_ONLY = (
    "/api/reseau", "/api/quitter", "/api/batch", "/api/restauration",
    "/api/sauvegardes", "/api/societes/importer"
)

def _is_local_only_action(request: Request) -> bool:
    path = request.url.path
    if any(path.startswith(p) for p in LOCAL_ONLY):
        return True
    if request.method == "DELETE" and path.startswith("/api/dossiers/"):
        return True
    if path.endswith("/repertoire") or path.endswith("/rapports/ouvrir"):
        return True
    return False

@app.middleware("http")
async def access_guard(request: Request, call_next):
    path = request.url.path
    if access.is_desktop(request) or request.method == "OPTIONS":
        return await call_next(request)

    cfg = access.load()
    if not cfg.get("acces_mobile", True):
        return JSONResponse({"detail": "Accès depuis le réseau désactivé sur le poste principal"}, status_code=403)

    if _is_local_only_action(request):
        return JSONResponse({"detail": "Action disponible uniquement sur le poste principal"}, status_code=403)

    if path in PUBLIC_PATHS or path.startswith(PUBLIC_PREFIXES) or path.startswith("/api/fiscal/documents/mobile-") or not path.startswith("/api/"):
        return await call_next(request)

    token = request.cookies.get(access.COOKIE)
    if not access.SESSIONS.valid(token):
        return JSONResponse({"detail": "Authentification requise"}, status_code=401)

    if cfg.get("lecture_seule") and request.method not in ("GET", "HEAD", "OPTIONS"):
        audit.record(
            action="READONLY_BLOCKED",
            category="security",
            description=f"Tentative de modification bloquée ({request.method} {path})",
            request=request,
            status="blocked",
        )
        return JSONResponse({"detail": "Accès mobile en lecture seule"}, status_code=403)

    return await call_next(request)

@app.middleware("http")
async def licence_middleware(request: Request, call_next):
    path = request.url.path
    if (
        not path.startswith("/api/")
        or path in ("/api/licence/status", "/api/licence/activate", "/api/health", "/api/quitter", "/api/auth/etat", "/api/auth/login")
        or path.startswith("/api/fiscal/documents/mobile-")
        or request.method == "OPTIONS"
    ):
        return await call_next(request)

    status = licence.get_license_status()
    if not status.get("activated"):
        return JSONResponse(
            status_code=403,
            content={
                "detail": "Application non activée. Licence requise.",
                "license_required": True,
                "machine_id": status.get("machine_id"),
                "message": status.get("message"),
            },
        )
    return await call_next(request)


app.include_router(router)
app.include_router(auth_router)
app.include_router(audit_router)
app.include_router(ocr_router)
app.include_router(whatsapp_router)
app.include_router(features_router)
app.include_router(fiscal_advisory_router)
app.include_router(rapprochement_router)
app.include_router(updater_router)

import os
import sys

# Help ▸ Guide d'utilisation officiel bilingue (Dec G50 2026)
def _find_guide_images() -> Optional[Path]:
    meipass = getattr(sys, "_MEIPASS", None)
    img_candidates = [
        config.PROJECT_ROOT / "Docs" / "images",
        config.PROJECT_ROOT / "docs" / "images",
        Path(sys.executable).resolve().parent / "Docs" / "images" if getattr(sys, "frozen", False) else None,
        Path(meipass) / "Docs" / "images" if meipass else None,
        Path(__file__).resolve().parents[2] / "Docs" / "images",
        Path(__file__).resolve().parents[3] / "Docs" / "images",
    ]
    for p in img_candidates:
        if p and p.is_dir():
            return p
    return None

_guide_img_dir = _find_guide_images()
if _guide_img_dir and _guide_img_dir.is_dir():
    app.mount("/guide/images", StaticFiles(directory=_guide_img_dir), name="guide-images")


def _find_guide() -> Path:
    meipass = getattr(sys, "_MEIPASS", None)
    candidates = [
        config.FRONTEND_DIST / "guide.html",
        config.PROJECT_ROOT / "guide.html",
        config.PROJECT_ROOT / "Docs" / "guide.html",
        config.PROJECT_ROOT / "docs" / "guide.html",
        Path(sys.executable).resolve().parent / "guide.html" if getattr(sys, "frozen", False) else None,
        Path(sys.executable).resolve().parent / "Docs" / "guide.html" if getattr(sys, "frozen", False) else None,
        Path(meipass) / "guide.html" if meipass else None,
        Path(meipass) / "Docs" / "guide.html" if meipass else None,
        Path(meipass) / "frontend" / "dist" / "guide.html" if meipass else None,
        Path(__file__).resolve().parents[2] / "guide.html",
        Path(__file__).resolve().parents[3] / "guide.html",
        config.DELPHI_ROOT / "guide_fr.html",
    ]
    for p in candidates:
        if p and p.is_file():
            return p
    # Fallback default path
    return config.PROJECT_ROOT / "guide.html"


@app.get("/guide", include_in_schema=False)
@app.get("/guide/", include_in_schema=False)
@app.get("/guide.html", include_in_schema=False)
def guide():
    g = _find_guide()
    if not g.is_file():
        raise HTTPException(404, "Guide d'utilisation en cours d'initialisation")
    return FileResponse(g, media_type="text/html; charset=utf-8")


def _find_mobile_upload_html() -> Path:
    meipass = getattr(sys, "_MEIPASS", None)
    candidates = [
        Path(__file__).resolve().parent / "templates" / "mobile_upload.html",
        config.PROJECT_ROOT / "backend" / "app" / "templates" / "mobile_upload.html",
        Path(meipass) / "app" / "templates" / "mobile_upload.html" if meipass else None,
        Path(sys.executable).resolve().parent / "backend" / "app" / "templates" / "mobile_upload.html" if getattr(sys, "frozen", False) else None,
        Path(sys.executable).resolve().parent / "templates" / "mobile_upload.html" if getattr(sys, "frozen", False) else None,
    ]
    for p in candidates:
        if p and p.is_file():
            return p
    return Path(__file__).resolve().parent / "templates" / "mobile_upload.html"


@app.get("/mobile-upload", include_in_schema=False)
@app.get("/mobile-upload/", include_in_schema=False)
def mobile_upload():
    p = _find_mobile_upload_html()
    if not p.is_file():
        raise HTTPException(404, "Page de capture mobile introuvable")
    return FileResponse(p, media_type="text/html; charset=utf-8")



@app.post("/api/quitter", include_in_schema=False)
def quitter():
    """Fichier ▸ Quitter — stops the local server and closes application window (Delphi: ExitProcess)."""
    import os
    import threading
    import subprocess

    # 0. Set clean exit flag so desktop launcher knows the user intentionally quit
    try:
        import tempfile
        for f in Path(tempfile.gettempdir()).glob("Dec2026_clean_exit_*.flag"):
            try:
                f.touch(exist_ok=True)
            except Exception:
                pass
        (Path(tempfile.gettempdir()) / "Dec2026_clean_exit.flag").touch(exist_ok=True)
    except Exception:
        pass

    # 1. Close pywebview native window if active
    try:
        import webview
        for win in getattr(webview, "windows", []):
            try:
                win.destroy()
            except Exception:
                pass
    except Exception:
        pass

    # 2. Terminate any Edge/Chrome process running with Dec2026_EdgeApp profile
    try:
        subprocess.Popen(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'Dec2026_EdgeApp' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"],
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
    except Exception:
        pass

    # 3. Terminate backend server cleanly
    threading.Timer(0.15, lambda: os._exit(0)).start()
    return {"message": "Application fermée"}

if config.FRONTEND_DIST.is_dir():
    assets_dir = config.FRONTEND_DIST / "assets"
    if not assets_dir.is_dir():
        if any(config.FRONTEND_DIST.glob("*.css")) or any(config.FRONTEND_DIST.glob("*.js")):
            assets_dir = config.FRONTEND_DIST
        else:
            assets_dir.mkdir(parents=True, exist_ok=True)
    app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path == "api" or path.startswith("api/"):
            raise HTTPException(404, "Ressource API inconnue")
        f = config.FRONTEND_DIST / path
        if path and f.is_file() and config.FRONTEND_DIST in f.resolve().parents:
            if f.suffix.lower() in (".html", ".htm"):
                return FileResponse(
                    f,
                    headers={
                        "Cache-Control": "no-cache, no-store, must-revalidate",
                        "Pragma": "no-cache",
                        "Expires": "0",
                    },
                )
            return FileResponse(f)
        return FileResponse(
            config.FRONTEND_DIST / "index.html",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )
