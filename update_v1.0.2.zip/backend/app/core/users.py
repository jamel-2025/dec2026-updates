"""Dec2026 User Authentication & Role-Based Access Control (RBAC).

Provides secure user credentials (PBKDF2-HMAC-SHA256), roles (admin, comptable, saisie, lecture),
and offline-resilient local persistence in data/users.json.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import config

PERMISSIONS_CATALOG = [
    # 1. Dossier Numérique & Archives
    {
        "id": "doc_view",
        "category": "Dossier Numérique & Archives",
        "category_ar": "الملف الرقمي والأرشيف",
        "label_fr": "Consultation des documents & archives",
        "label_ar": "معاينة الوثائق والأرشيف",
        "desc_fr": "Visualiser les factures, statuts, contrats et pièces PDF/Excel.",
    },
    {
        "id": "doc_upload",
        "category": "Dossier Numérique & Archives",
        "category_ar": "الملف الرقمي والأرشيف",
        "label_fr": "Ajout & Numérisation (WIA / Mobile)",
        "label_ar": "إضافة وثائق ومسح ضوئي",
        "desc_fr": "Téléverser de nouveaux documents, scanner via WIA ou mobile QR.",
    },
    {
        "id": "doc_ocr",
        "category": "Dossier Numérique & Archives",
        "category_ar": "الملف الرقمي والأرشيف",
        "label_fr": "Extraction OCR & Catégorisation",
        "label_ar": "القراءة الذكية OCR والتصنيف",
        "desc_fr": "Extraire le texte des factures par OCR et classifier les documents.",
    },
    {
        "id": "doc_delete",
        "category": "Dossier Numérique & Archives",
        "category_ar": "الملف الرقمي والأرشيف",
        "label_fr": "Suppression de documents & pièces",
        "label_ar": "حذف وثائق من الأرشيف",
        "desc_fr": "Supprimer définitivement des fichiers archivés dans le dossier numérique.",
    },
    {
        "id": "doc_export",
        "category": "Dossier Numérique & Archives",
        "category_ar": "الملف الرقمي والأرشيف",
        "label_fr": "Téléchargement & Export d'archives",
        "label_ar": "تحميل وتصدير الأرشيف",
        "desc_fr": "Exporter et télécharger les dossiers complets de pièces comptables.",
    },

    # 2. Dossiers & Sociétés
    {
        "id": "dossier_open",
        "category": "Dossiers & Sociétés",
        "category_ar": "ملفات الشركات والسنوات",
        "label_fr": "Ouverture des dossiers affectés",
        "label_ar": "فتح واستعراض الشركات",
        "desc_fr": "Accéder aux dossiers et exercices comptables autorisés.",
    },
    {
        "id": "dossier_create",
        "category": "Dossiers & Sociétés",
        "category_ar": "ملفات الشركات والسنوات",
        "label_fr": "Création d'un nouveau dossier",
        "label_ar": "إنشاء شركة جديدة",
        "desc_fr": "Ajouter une nouvelle société dans la base de données.",
    },
    {
        "id": "dossier_edit",
        "category": "Dossiers & Sociétés",
        "category_ar": "ملفات الشركات والسنوات",
        "label_fr": "Modification Fiche Société & NIF/RC",
        "label_ar": "تعديل بطاقة الشركة والبيانات",
        "desc_fr": "Modifier les identifiants fiscaux, raison sociale et coordonnées bancaires.",
    },
    {
        "id": "dossier_delete",
        "category": "Dossiers & Sociétés",
        "category_ar": "ملفات الشركات والسنوات",
        "label_fr": "Suppression définitive d'un dossier",
        "label_ar": "حذف شركة بالكامل",
        "desc_fr": "Supprimer intégralement le dossier d'une société et ses exercices (Admin).",
    },
    {
        "id": "dossier_restrict",
        "category": "Dossiers & Sociétés",
        "category_ar": "ملفات الشركات والسنوات",
        "label_fr": "Restriction stricte aux dossiers affectés",
        "label_ar": "حصر الوصول بالشركات المخصصة فقط",
        "desc_fr": "Empêcher le collaborateur d'accéder aux sociétés qui ne lui sont pas assignées.",
    },

    # 3. G50 & Fiscalité
    {
        "id": "g50_view",
        "category": "G50 & Fiscalité",
        "category_ar": "تصريح G50 والجبايات",
        "label_fr": "Consultation des déclarations G50",
        "label_ar": "معاينة تصريحات G50",
        "desc_fr": "Visualiser les chiffres d'affaires et montants déclarés.",
    },
    {
        "id": "g50_edit",
        "category": "G50 & Fiscalité",
        "category_ar": "تصريح G50 والجبايات",
        "label_fr": "Saisie & modification G50",
        "label_ar": "إدخال وتعديل تصريح G50",
        "desc_fr": "Renseigner et modifier les lignes de déclaration (TVA, TAP, etc.).",
    },
    {
        "id": "g50_cloture",
        "category": "G50 & Fiscalité",
        "category_ar": "تصريح G50 والجبايات",
        "label_fr": "Clôture et validation finale G50",
        "label_ar": "غلق وتأكيد التصريح النهائي",
        "desc_fr": "Verrouiller la déclaration définitive et générer les bordereaux officiels.",
    },
    {
        "id": "g50_unlock",
        "category": "G50 & Fiscalité",
        "category_ar": "تصريح G50 والجبايات",
        "label_fr": "Déverrouillage d'une déclaration clôturée",
        "label_ar": "إعادة فتح تصريح مغلق",
        "desc_fr": "Autoriser la modification d'un G50 déjà clôturé pour rectification.",
    },
    {
        "id": "g50_jibayatic",
        "category": "G50 & Fiscalité",
        "category_ar": "تصريح G50 والجبايات",
        "label_fr": "Exportation portail Jibayatic",
        "label_ar": "تصدير ملف Jibayatic",
        "desc_fr": "Générer les fichiers numériques pour la télédéclaration DGI.",
    },
    {
        "id": "activites_spec",
        "category": "G50 & Fiscalité",
        "category_ar": "تصريح G50 والجبايات",
        "label_fr": "Activités spéciales (Pharma, Station, Promo, Lotis)",
        "label_ar": "الأنشطة الخاصة (صيدليات، محطات، عقار)",
        "desc_fr": "Gérer les déclarations spécifiques des officines, carburants et immobilier.",
    },

    # 4. Facturation & Tiers
    {
        "id": "achats_view",
        "category": "Facturation & Tiers",
        "category_ar": "فواتير المشتريات والمبيعات",
        "label_fr": "Consultation des achats & déductions",
        "label_ar": "معاينة فواتير المشتريات",
        "desc_fr": "Afficher les factures d'achat et le tableau des déductions TVA.",
    },
    {
        "id": "achats_edit",
        "category": "Facturation & Tiers",
        "category_ar": "فواتير المشتريات والمبيعات",
        "label_fr": "Saisie & modification des achats et fournisseurs",
        "label_ar": "إدخال وتعديل المشتريات والموردين",
        "desc_fr": "Enregistrer et modifier les factures d'achats et fournisseurs.",
    },
    {
        "id": "achats_delete",
        "category": "Facturation & Tiers",
        "category_ar": "فواتير المشتريات والمبيعات",
        "label_fr": "Droit de suppression d'achats",
        "label_ar": "حذف فواتير المشتريات",
        "desc_fr": "Supprimer définitivement des écritures d'achats.",
    },
    {
        "id": "ventes_view",
        "category": "Facturation & Tiers",
        "category_ar": "فواتير المشتريات والمبيعات",
        "label_fr": "Consultation des factures de vente",
        "label_ar": "معاينة فواتير المبيعات",
        "desc_fr": "Afficher les factures clients et chiffres d'affaires.",
    },
    {
        "id": "ventes_edit",
        "category": "Facturation & Tiers",
        "category_ar": "فواتير المشتريات والمبيعات",
        "label_fr": "Saisie & modification des ventes et clients",
        "label_ar": "تحرير وتعديل فواتير المبيعات",
        "desc_fr": "Ajouter et modifier les factures de vente et fiches clients.",
    },
    {
        "id": "ventes_delete",
        "category": "Facturation & Tiers",
        "category_ar": "فواتير المشتريات والمبيعات",
        "label_fr": "Droit de suppression des ventes",
        "label_ar": "حذف فواتير المبيعات",
        "desc_fr": "Supprimer définitivement des factures de vente émises.",
    },
    {
        "id": "etat104_generate",
        "category": "Facturation & Tiers",
        "category_ar": "فواتير المشتريات والمبيعات",
        "label_fr": "Génération et impression de l'État 104",
        "label_ar": "كشف الزبائن السنوي (حالة 104)",
        "desc_fr": "Établir et imprimer le relevé annuel des clients (État 104).",
    },

    # 5. RH & Paie
    {
        "id": "salaries_view",
        "category": "Ressources Humaines & Paie",
        "category_ar": "المستخدمون والرواتب وعقود العمل",
        "label_fr": "Consultation des salariés et dossiers RH",
        "label_ar": "معاينة قائمة العمال والبيانات الإدارية",
        "desc_fr": "Afficher la liste du personnel et les informations administratives.",
    },
    {
        "id": "salaries_view_amounts",
        "category": "Ressources Humaines & Paie",
        "category_ar": "المستخدمون والرواتب وعقود العمل",
        "label_fr": "Affichage des salaires & rémunérations",
        "label_ar": "الاطلاع على مبالغ الرواتب والأجور",
        "desc_fr": "Accès aux montants des salaires de base et primes (confidentialité).",
    },
    {
        "id": "salaries_edit",
        "category": "Ressources Humaines & Paie",
        "category_ar": "المستخدمون والرواتب وعقود العمل",
        "label_fr": "Saisie de la paie et retenues IRG",
        "label_ar": "إدخال وتعديل بيانات الأجور والـ IRG",
        "desc_fr": "Gérer les employés, la paie mensuelle et les retenues à la source IRG.",
    },
    {
        "id": "contracts_manage",
        "category": "Ressources Humaines & Paie",
        "category_ar": "المستخدمون والرواتب وعقود العمل",
        "label_fr": "Génération et impression des contrats de travail",
        "label_ar": "إنشاء وطباعة عقود العمل",
        "desc_fr": "Établir les contrats CDD, CDI, temps partiel et conventions SNAPO.",
    },
    {
        "id": "contracts_edit_text",
        "category": "Ressources Humaines & Paie",
        "category_ar": "المستخدمون والرواتب وعقود العمل",
        "label_fr": "Personnalisation des clauses et textes contractuels",
        "label_ar": "تخصيص بنود وشروط العقود",
        "desc_fr": "Modifier et personnaliser les articles et clauses juridiques des contrats.",
    },
    {
        "id": "salaries_delete",
        "category": "Ressources Humaines & Paie",
        "category_ar": "المستخدمون والرواتب وعقود العمل",
        "label_fr": "Suppression d'employés et de contrats",
        "label_ar": "حذف عامل أو عقد عمل",
        "desc_fr": "Supprimer définitivement la fiche d'un salarié ou un contrat de travail.",
    },

    # 6. Bilan & Conseil
    {
        "id": "bilan_fiscal_view",
        "category": "Bilan, Audit & Conseil",
        "category_ar": "الميزانية والتدقيق والاستشارة",
        "label_fr": "Consultation de la liasse fiscale SCF",
        "label_ar": "معاينة الميزانية الجبائية SCF",
        "desc_fr": "Consulter les états financiers et liasses fiscales sans modification.",
    },
    {
        "id": "bilan_fiscal_edit",
        "category": "Bilan, Audit & Conseil",
        "category_ar": "الميزانية والتدقيق والاستشارة",
        "label_fr": "Élaboration de la liasse fiscale et tableaux SCF",
        "label_ar": "إعداد وتعديل الميزانية والقوائم 12",
        "desc_fr": "Saisir et calculer les 12 tableaux de la liasse fiscale DGI.",
    },
    {
        "id": "rapprochement_audit",
        "category": "Bilan, Audit & Conseil",
        "category_ar": "الميزانية والتدقيق والاستشارة",
        "label_fr": "Cadrage fiscal & contrôle de cohérence",
        "label_ar": "المقاربة والتدقيق الجبائي والمحاسبي",
        "desc_fr": "Contrôler la cohérence entre G50, balance comptable et masse salariale.",
    },
    {
        "id": "c20_beneficiaires",
        "category": "Bilan, Audit & Conseil",
        "category_ar": "الميزانية والتدقيق والاستشارة",
        "label_fr": "Attestation C20 et Bénéficiaires Effectifs",
        "label_ar": "شهادة النشاط C20 والمستفيد الفعلي",
        "desc_fr": "Générer les demandes C20 et le registre CNRC des bénéficiaires.",
    },
    {
        "id": "honoraires_manage",
        "category": "Bilan, Audit & Conseil",
        "category_ar": "الميزانية والتدقيق والاستشارة",
        "label_fr": "Gestion des honoraires et recouvrement",
        "label_ar": "أتعاب ومداخيل المكتب",
        "desc_fr": "Établir les conventions d'honoraires et suivre les encaissements du cabinet.",
    },
    {
        "id": "conseil_fiscal",
        "category": "Bilan, Audit & Conseil",
        "category_ar": "الميزانية والتدقيق والاستشارة",
        "label_fr": "Conseil, contentieux fiscal et recours",
        "label_ar": "الاستشارات والنزاعات الجبائية",
        "desc_fr": "Préparer les réponses aux notifications de redressement et réclamations.",
    },

    # 7. Outils & Exports
    {
        "id": "print_reports",
        "category": "Outils & Exports",
        "category_ar": "الطباعة والتصدير",
        "label_fr": "Impression des états et bordereaux officiels",
        "label_ar": "طباعة النماذج والتقارير الرسمية",
        "desc_fr": "Imprimer les déclarations, bordereaux fiscaux et contrats de travail.",
    },
    {
        "id": "export_excel",
        "category": "Outils & Exports",
        "category_ar": "الطباعة والتصدير",
        "label_fr": "Export des tables et écritures vers Excel",
        "label_ar": "تصدير الجداول والدفاتر إلى Excel",
        "desc_fr": "Télécharger les données d'achats, ventes et déclarations sous format Excel.",
    },

    # 8. Administration & Sécurité
    {
        "id": "users_manage",
        "category": "Administration & Sécurité",
        "category_ar": "الأمان وإدارة النظام",
        "label_fr": "Gestion des comptes utilisateurs et permissions",
        "label_ar": "إدارة المستخدمين والأعوان والصلاحيات",
        "desc_fr": "Créer, modifier des comptes, mots de passe et affecter les dossiers.",
    },
    {
        "id": "backup_create",
        "category": "Administration & Sécurité",
        "category_ar": "الأمان وإدارة النظام",
        "label_fr": "Création de sauvegardes",
        "label_ar": "إنشاء نسخة احتياطية للقواعد",
        "desc_fr": "Créer des copies de sécurité compressées des dossiers.",
    },
    {
        "id": "backup_restore",
        "category": "Administration & Sécurité",
        "category_ar": "الأمان وإدارة النظام",
        "label_fr": "Restauration d'archives (Écrasement)",
        "label_ar": "استرجاع نسخة سابقة (خطر الاستبدال)",
        "desc_fr": "Restaurer une sauvegarde antérieure avec écrasement des données actuelles.",
    },
    {
        "id": "audit_view",
        "category": "Administration & Sécurité",
        "category_ar": "الأمان وإدارة النظام",
        "label_fr": "Consultation du journal d'audit",
        "label_ar": "معاينة سجل المراقبة وتتبع المتصلين",
        "desc_fr": "Consulter l'historique de traçabilité et connexions des utilisateurs.",
    },
    {
        "id": "audit_clear",
        "category": "Administration & Sécurité",
        "category_ar": "الأمان وإدارة النظام",
        "label_fr": "Réinitialisation du journal d'audit",
        "label_ar": "تفريغ ومسح سجل المراقبة",
        "desc_fr": "Vider l'historique complet des traces de sécurité.",
    },
    {
        "id": "locks_release",
        "category": "Administration & Sécurité",
        "category_ar": "الأمان وإدارة النظام",
        "label_fr": "Libération des verrous concurrents (LAN)",
        "label_ar": "فك حجز الملفات (Déverrouillage LAN)",
        "desc_fr": "Débloquer de force les dossiers ou écritures restés verrouillés.",
    },
    {
        "id": "import_windev",
        "category": "Administration & Sécurité",
        "category_ar": "الأمان وإدارة النظام",
        "label_fr": "Importation massive des tables WinDev",
        "label_ar": "الاستيراد الجماعي للبيانات من WinDev",
        "desc_fr": "Importer et convertir les fichiers WinDev historiques en dossiers SQLite.",
    },
]

ALL_PERM_IDS = [p["id"] for p in PERMISSIONS_CATALOG]

ROLES = {
    "admin": {
        "id": "admin",
        "label_fr": "Administrateur (Complet)",
        "label_ar": "المدير العام (صلاحيات كاملة)",
        "permissions": ["all"] + ALL_PERM_IDS,
        "color": "#10b981",
    },
    "comptable": {
        "id": "comptable",
        "label_fr": "Comptable Principal",
        "label_ar": "المحاسب الرئيسي",
        "permissions": [
            "doc_view", "doc_upload", "doc_ocr", "doc_export",
            "dossier_open", "dossier_create", "dossier_edit",
            "g50_view", "g50_edit", "g50_cloture", "g50_unlock", "g50_jibayatic", "activites_spec",
            "achats_view", "achats_edit", "achats_delete",
            "ventes_view", "ventes_edit", "ventes_delete", "etat104_generate",
            "salaries_view", "salaries_view_amounts", "salaries_edit", "contracts_manage", "contracts_edit_text", "salaries_delete",
            "bilan_fiscal_view", "bilan_fiscal_edit", "rapprochement_audit", "c20_beneficiaires", "honoraires_manage", "conseil_fiscal",
            "print_reports", "export_excel",
            "backup_create", "audit_view", "locks_release"
        ],
        "color": "#0ea5e9",
    },
    "saisie": {
        "id": "saisie",
        "label_fr": "Opérateur de Saisie & Numérisation",
        "label_ar": "مدخل فواتير وأرشيف",
        "permissions": [
            "doc_view", "doc_upload", "doc_ocr",
            "dossier_open",
            "g50_view", "g50_edit",
            "achats_view", "achats_edit",
            "ventes_view", "ventes_edit",
            "salaries_view", "contracts_manage",
            "print_reports", "export_excel"
        ],
        "color": "#f59e0b",
    },
    "rh": {
        "id": "rh",
        "label_fr": "Gestionnaire RH & Paie",
        "label_ar": "أمين الرواتب والمستخدمين",
        "permissions": [
            "doc_view", "doc_upload",
            "dossier_open",
            "salaries_view", "salaries_view_amounts", "salaries_edit",
            "contracts_manage", "contracts_edit_text", "salaries_delete",
            "print_reports", "export_excel"
        ],
        "color": "#ec4899",
    },
    "lecture": {
        "id": "lecture",
        "label_fr": "Auditeur / Consultation",
        "label_ar": "معاينة وقراءة فقط",
        "permissions": [
            "doc_view", "doc_export",
            "dossier_open",
            "g50_view",
            "achats_view",
            "ventes_view",
            "salaries_view",
            "bilan_fiscal_view",
            "print_reports", "export_excel"
        ],
        "color": "#8b5cf6",
    },
}


def _hash_secret(secret: str, salt_bytes: bytes) -> str:
    """PBKDF2-HMAC-SHA256 with 120,000 iterations."""
    return hashlib.pbkdf2_hmac("sha256", secret.strip().encode("utf-8"), salt_bytes, 120_000).hex()


def load_users() -> Dict[str, Dict[str, Any]]:
    """Loads all users from USERS_FILE, initializing defaults if absent."""
    p = config.USERS_FILE
    if not p.is_file():
        return init_default_users()
    try:
        with open(p, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
            if not data or not isinstance(data, dict):
                return init_default_users()
            return data
    except Exception:
        return init_default_users()


def save_users(users: Dict[str, Dict[str, Any]]) -> None:
    """Atomic write to USERS_FILE."""
    p = config.USERS_FILE
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2, ensure_ascii=False)
    tmp.replace(p)


def init_default_users() -> Dict[str, Dict[str, Any]]:
    """Creates the default user fleet if users.json does not exist."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _make_user(username: str, name_fr: str, name_ar: str, role: str, pwd: str, pin: str) -> Dict[str, Any]:
        pwd_salt = secrets.token_bytes(16)
        pin_salt = secrets.token_bytes(16)
        return {
            "username": username,
            "display_name_fr": name_fr,
            "display_name_ar": name_ar,
            "role": role,
            "password_hash": _hash_secret(pwd, pwd_salt),
            "password_salt": pwd_salt.hex(),
            "pin_hash": _hash_secret(pin, pin_salt),
            "pin_salt": pin_salt.hex(),
            "active": True,
            "created_at": now_str,
            "last_login": None,
        }

    defaults = {
        "admin": _make_user("admin", "Administrateur", "المدير العام", "admin", "admin", "123456"),
        "comptable": _make_user("comptable", "Comptable Principal", "المحاسب الرئيسي", "comptable", "123456", "123456"),
        "saisie": _make_user("saisie", "Opérateur de Saisie", "مدخل البيانات", "saisie", "123456", "123456"),
        "consultation": _make_user("consultation", "Auditeur / Consultation", "معاينة وقراءة فقط", "lecture", "123456", "123456"),
    }
    save_users(defaults)
    return defaults


def verify_secret(secret: str, stored_hash: str, stored_salt_hex: str) -> bool:
    """Constant-time password/PIN verification."""
    if not secret or not stored_hash or not stored_salt_hex:
        return False
    try:
        salt_bytes = bytes.fromhex(stored_salt_hex)
        calc_hash = _hash_secret(secret, salt_bytes)
        return hmac.compare_digest(calc_hash, stored_hash)
    except Exception:
        return False


def authenticate(username_or_pin: str, password: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Authenticates a user either via username+password or via single PIN."""
    users = load_users()
    clean_target = (username_or_pin or "").strip()

    # Case 1: Standard Username + Password
    if password is not None and clean_target:
        user = users.get(clean_target.lower())
        if user and user.get("active", True):
            if verify_secret(password, user.get("password_hash", ""), user.get("password_salt", "")):
                _update_last_login(user["username"])
                return sanitize_user(user)

    # Case 2: Quick PIN code
    for u in users.values():
        if not u.get("active", True):
            continue
        # Direct username match with password supplied as first arg
        if password is None:
            if verify_secret(clean_target, u.get("pin_hash", ""), u.get("pin_salt", "")) or verify_secret(clean_target, u.get("password_hash", ""), u.get("password_salt", "")):
                _update_last_login(u["username"])
                return sanitize_user(u)

    # Fallback Case 3: Admin fallback if password == 'admin' or '123456' for admin user
    admin_user = users.get("admin")
    if admin_user and (clean_target.lower() == "admin" or clean_target in ("123456", "admin")):
        test_pwd = password if password is not None else clean_target
        if verify_secret(test_pwd, admin_user.get("password_hash", ""), admin_user.get("password_salt", "")) or verify_secret(test_pwd, admin_user.get("pin_hash", ""), admin_user.get("pin_salt", "")):
            _update_last_login("admin")
            return sanitize_user(admin_user)

    return None


def _update_last_login(username: str) -> None:
    try:
        users = load_users()
        if username in users:
            users[username]["last_login"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            save_users(users)
    except Exception:
        pass


def has_permission(user: Optional[Dict[str, Any]], perm_id: str) -> bool:
    """Verifies whether a user has a specific granular permission or wildcard 'all'."""
    if not user:
        return False
    if user.get("role") == "admin":
        return True
    perms = set(user.get("permissions") or [])
    if "all" in perms:
        return True
    if perm_id in perms:
        return True
    # Backward compatibility aliases
    if perm_id.endswith("_delete") and "delete_record" in perms:
        return True
    if perm_id == "print_reports" and "print_docs" in perms:
        return True
    if perm_id.startswith("backup_") and "backup_manage" in perms:
        return True
    if perm_id.startswith("bilan_fiscal_") and "bilan_fiscal" in perms:
        return True
    return False


def get_user_from_request(request: Any) -> Optional[Dict[str, Any]]:
    """Retrieves authenticated user from session cookie or defaults to admin if local desktop."""
    from . import access
    tok = request.cookies.get(access.COOKIE) if hasattr(request, "cookies") else None
    if tok and access.SESSIONS.valid(tok):
        s_item = access.SESSIONS.get(tok)
        if s_item:
            all_u = load_users()
            u_db = all_u.get(s_item.username)
            if u_db:
                return sanitize_user(u_db)
            return {
                "username": s_item.username,
                "role": s_item.role,
                "permissions": ROLES.get(s_item.role, ROLES["lecture"])["permissions"],
                "active": True,
            }
    if hasattr(request, "client") and access.is_desktop(request):
        all_u = load_users()
        admin_u = all_u.get("admin")
        if admin_u:
            return sanitize_user(admin_u)
    return None


def require_permission(request: Any, perm_id: str) -> Dict[str, Any]:
    """Raises 403 Forbidden if current user lacks required permission."""
    from fastapi import HTTPException
    u = get_user_from_request(request)
    if not u or not has_permission(u, perm_id):
        raise HTTPException(status_code=403, detail=f"Action non autorisée : Permission requise [{perm_id}]")
    return u


def sanitize_user(user: Dict[str, Any]) -> Dict[str, Any]:
    """Returns safe user object omitting password hashes."""
    role_info = ROLES.get(user.get("role", "lecture"), ROLES["lecture"])
    is_admin = user.get("role") == "admin"
    user_perms = user.get("permissions")
    if user_perms is None:
        user_perms = role_info["permissions"]

    assigned = ["*"] if is_admin else (user.get("assigned_dossiers") or [])
    return {
        "username": user["username"],
        "display_name_fr": user.get("display_name_fr") or user["username"],
        "display_name_ar": user.get("display_name_ar") or user["username"],
        "role": user.get("role", "lecture"),
        "role_info": role_info,
        "permissions": user_perms,
        "assigned_dossiers": assigned,
        "assigned_count": len(assigned) if not is_admin else "all",
        "active": user.get("active", True),
        "created_at": user.get("created_at"),
        "last_login": user.get("last_login"),
    }


def list_users() -> List[Dict[str, Any]]:
    """Returns list of sanitized users."""
    users = load_users()
    return [sanitize_user(u) for u in users.values()]


def create_or_update_user(
    username: str,
    display_name_fr: str,
    display_name_ar: str,
    role: str,
    password: Optional[str] = None,
    pin: Optional[str] = None,
    active: bool = True,
    permissions: Optional[List[str]] = None,
    assigned_dossiers: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Creates a new user or updates an existing user profile and credentials."""
    users = load_users()
    key = username.strip().lower()
    if not key:
        raise ValueError("Le nom d'utilisateur est requis.")

    if role not in ROLES:
        role = "comptable"

    user = users.get(key)
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if not user:
        user = {
            "username": key,
            "display_name_fr": display_name_fr.strip() or key,
            "display_name_ar": display_name_ar.strip() or key,
            "role": role,
            "active": active,
            "created_at": now_str,
            "last_login": None,
            "permissions": permissions if permissions is not None else ROLES[role]["permissions"],
            "assigned_dossiers": assigned_dossiers if assigned_dossiers is not None else ([] if role != "admin" else ["*"]),
        }
        # Require password on create
        pwd = password.strip() if password else "123456"
        pwd_salt = secrets.token_bytes(16)
        user["password_hash"] = _hash_secret(pwd, pwd_salt)
        user["password_salt"] = pwd_salt.hex()

        p_val = pin.strip() if pin else pwd
        pin_salt = secrets.token_bytes(16)
        user["pin_hash"] = _hash_secret(p_val, pin_salt)
        user["pin_salt"] = pin_salt.hex()
    else:
        user["display_name_fr"] = display_name_fr.strip() or user.get("display_name_fr", key)
        user["display_name_ar"] = display_name_ar.strip() or user.get("display_name_ar", key)
        user["role"] = role
        user["active"] = active

        if permissions is not None:
            user["permissions"] = permissions

        if assigned_dossiers is not None:
            user["assigned_dossiers"] = ["*"] if role == "admin" else assigned_dossiers

        if password and password.strip():
            pwd_salt = secrets.token_bytes(16)
            user["password_hash"] = _hash_secret(password.strip(), pwd_salt)
            user["password_salt"] = pwd_salt.hex()

        if pin and pin.strip():
            pin_salt = secrets.token_bytes(16)
            user["pin_hash"] = _hash_secret(pin.strip(), pin_salt)
            user["pin_salt"] = pin_salt.hex()

    users[key] = user
    save_users(users)

    # Sync assignments meta
    if assigned_dossiers is not None and role != "admin":
        from . import assignments
        assignments.assign_dossiers_to_user(key, assigned_dossiers)

    return sanitize_user(user)


def delete_user(username: str) -> bool:
    """Deletes a user. Admin user cannot be deleted."""
    users = load_users()
    key = username.strip().lower()
    if key == "admin":
        raise ValueError("Le compte administrateur principal ne peut pas être supprimé.")
    if key in users:
        del users[key]
        save_users(users)
        return True
    return False
