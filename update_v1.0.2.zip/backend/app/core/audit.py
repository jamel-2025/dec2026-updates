"""Dec2026 Audit Log & Security Monitor Engine.

Tracks user activities, security events, and real-time remote/cloud access.
Stores records in an isolated, high-performance SQLite database (data/audit.sqlite).
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any

from starlette.requests import Request

from . import config

_TABLE_SCHEMA = """
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    timestamp REAL NOT NULL,
    source TEXT NOT NULL,         -- 'cloud' | 'lan' | 'local'
    ip TEXT NOT NULL,
    country TEXT,                 -- Cloudflare country code: 'DZ', 'FR', etc.
    device TEXT NOT NULL,         -- 'iPhone', 'Android', 'Windows PC', etc.
    user_agent TEXT,
    action TEXT NOT NULL,         -- e.g. 'AUTH_LOGIN_SUCCESS', 'VENTE_ADD', 'G50_UPDATE'
    category TEXT NOT NULL,       -- 'security', 'declarations', 'ventes', 'tiers', 'system'
    dossier TEXT,                 -- Dossier code e.g. 'S01'
    status TEXT NOT NULL,         -- 'success' | 'warning' | 'error' | 'blocked'
    description TEXT NOT NULL,    -- Human-friendly summary
    details_json TEXT             -- JSON metadata
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_source ON audit_logs (source);
CREATE INDEX IF NOT EXISTS idx_audit_dossier ON audit_logs (dossier);
"""


def _get_connection() -> sqlite3.Connection:
    config.AUDIT_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(config.AUDIT_DB), timeout=10.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def init_db() -> None:
    """Initialize audit database schema."""
    with _get_connection() as conn:
        conn.executescript(_TABLE_SCHEMA)
        try:
            cols = [r[1] for r in conn.execute("PRAGMA table_info(audit_logs)").fetchall()]
            if "username" not in cols:
                conn.execute("ALTER TABLE audit_logs ADD COLUMN username TEXT")
            if "user_role" not in cols:
                conn.execute("ALTER TABLE audit_logs ADD COLUMN user_role TEXT")
        except Exception:
            pass


# Ensure database and table exist at module import
try:
    init_db()
except Exception:
    pass


def parse_device(ua: str) -> str:
    """Detect client device family from User-Agent string."""
    if not ua:
        return "Inconnu / Direct"
    u = ua.lower()
    if "iphone" in u:
        return "iPhone"
    if "ipad" in u:
        return "iPad"
    if "android" in u:
        return "Android"
    if "windows" in u:
        return "Windows PC"
    if "macintosh" in u or "mac os" in u:
        return "Mac"
    if "linux" in u:
        return "Linux"
    return "Navigateur Web"


def extract_client_info(request: Request | None) -> dict[str, str | None]:
    """Inspect request headers to detect whether the user is connecting via Cloudflare, LAN Wi-Fi, or Local."""
    if request is None:
        return {
            "source": "local",
            "ip": "127.0.0.1",
            "country": None,
            "device": "Système / PC",
            "user_agent": "Desktop App",
        }

    headers = request.headers
    ua = headers.get("user-agent", "")
    device = parse_device(ua)

    # 1. Cloudflare Detection
    cf_ip = headers.get("cf-connecting-ip")
    cf_country = headers.get("cf-ipcountry")
    forwarded_host = headers.get("x-forwarded-host", "")
    host = headers.get("host", "")

    is_cloud = bool(
        cf_ip
        or "trycloudflare.com" in forwarded_host
        or "trycloudflare.com" in host
        or headers.get("cf-ray")
    )

    # Resolve Client IP
    if cf_ip:
        client_ip = cf_ip.strip()
    elif "x-forwarded-for" in headers:
        client_ip = headers["x-forwarded-for"].split(",")[0].strip()
    elif "x-real-ip" in headers:
        client_ip = headers["x-real-ip"].strip()
    elif request.client and request.client.host:
        client_ip = request.client.host
    else:
        client_ip = "127.0.0.1"

    # Source categorization
    if is_cloud:
        source = "cloud"
    elif client_ip in ("127.0.0.1", "::1", "localhost"):
        source = "local"
    else:
        source = "lan"

    return {
        "source": source,
        "ip": client_ip,
        "country": cf_country if is_cloud else None,
        "device": device,
        "user_agent": ua[:250] if ua else None,
    }


def record(
    action: str,
    category: str,
    description: str,
    request: Request | None = None,
    dossier: str | None = None,
    status: str = "success",
    details: dict[str, Any] | None = None,
    source_override: str | None = None,
    ip_override: str | None = None,
    username: str | None = None,
    user_role: str | None = None,
) -> int:
    """Record a new security or business activity event in the audit log."""
    info = extract_client_info(request)
    now = time.time()
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    src = source_override or info["source"] or "local"
    ip = ip_override or info["ip"] or "127.0.0.1"
    country = info["country"]
    device = info["device"] or "Inconnu"
    ua = info["user_agent"]
    details_str = json.dumps(details, ensure_ascii=False) if details else None

    # Auto-resolve username from request session if not passed
    user = username
    role = user_role
    if not user and request:
        try:
            from . import access
            tok = request.cookies.get(access.COOKIE)
            s_item = access.SESSIONS.get(tok)
            if s_item:
                user = s_item.username
                role = s_item.role
            elif access.is_desktop(request):
                user = "admin"
                role = "admin"
        except Exception:
            pass

    try:
        with _get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO audit_logs (
                    created_at, timestamp, source, ip, country, device,
                    user_agent, action, category, dossier, status, description, details_json,
                    username, user_role
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    created_at,
                    now,
                    src,
                    ip,
                    country,
                    device,
                    ua,
                    action,
                    category,
                    dossier,
                    status,
                    description,
                    details_str,
                    user or "system",
                    role or "system",
                ),
            )
            return cursor.lastrowid or 0
    except Exception as e:
        # Never break main app flow if audit logging fails
        return 0


def list_logs(
    limit: int = 150,
    offset: int = 0,
    source: str | None = None,
    category: str | None = None,
    dossier: str | None = None,
    q: str | None = None,
) -> dict[str, Any]:
    """Retrieve filtered audit log entries with pagination."""
    query = "SELECT * FROM audit_logs WHERE 1=1"
    count_query = "SELECT COUNT(*) FROM audit_logs WHERE 1=1"
    params: list[Any] = []

    if source and source != "all":
        query += " AND source = ?"
        count_query += " AND source = ?"
        params.append(source)

    if category and category != "all":
        query += " AND category = ?"
        count_query += " AND category = ?"
        params.append(category)

    if dossier:
        query += " AND dossier = ?"
        count_query += " AND dossier = ?"
        params.append(dossier)

    if q and q.strip():
        term = f"%{q.strip()}%"
        query += " AND (description LIKE ? OR ip LIKE ? OR action LIKE ? OR device LIKE ? OR username LIKE ?)"
        count_query += " AND (description LIKE ? OR ip LIKE ? OR action LIKE ? OR device LIKE ? OR username LIKE ?)"
        params.extend([term, term, term, term, term])

    with _get_connection() as conn:
        total = conn.execute(count_query, params).fetchone()[0]

        query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
        rows = conn.execute(query, [*params, limit, offset]).fetchall()

        items = []
        for r in rows:
            d = dict(r)
            if d.get("details_json"):
                try:
                    d["details"] = json.loads(d["details_json"])
                except Exception:
                    d["details"] = None
            else:
                d["details"] = None
            items.append(d)

    return {"total": total, "items": items}


def get_stats() -> dict[str, Any]:
    """Retrieve live statistics for dashboard and security overview."""
    today_prefix = f"{datetime.now().strftime('%Y-%m-%d')}%"
    with _get_connection() as conn:
        total_today = conn.execute(
            "SELECT COUNT(*) FROM audit_logs WHERE created_at LIKE ?", (today_prefix,)
        ).fetchone()[0]

        cloud_today = conn.execute(
            "SELECT COUNT(*) FROM audit_logs WHERE source = 'cloud' AND created_at LIKE ?",
            (today_prefix,),
        ).fetchone()[0]

        lan_today = conn.execute(
            "SELECT COUNT(*) FROM audit_logs WHERE source = 'lan' AND created_at LIKE ?",
            (today_prefix,),
        ).fetchone()[0]

        local_today = conn.execute(
            "SELECT COUNT(*) FROM audit_logs WHERE source = 'local' AND created_at LIKE ?",
            (today_prefix,),
        ).fetchone()[0]

        unique_cloud_ips = conn.execute(
            "SELECT COUNT(DISTINCT ip) FROM audit_logs WHERE source = 'cloud' AND created_at LIKE ?",
            (today_prefix,),
        ).fetchone()[0]

        last_cloud = conn.execute(
            "SELECT * FROM audit_logs WHERE source = 'cloud' ORDER BY timestamp DESC LIMIT 1"
        ).fetchone()

        warnings_today = conn.execute(
            "SELECT COUNT(*) FROM audit_logs WHERE status IN ('warning', 'blocked', 'error') AND created_at LIKE ?",
            (today_prefix,),
        ).fetchone()[0]

    return {
        "total_today": total_today,
        "cloud_today": cloud_today,
        "lan_today": lan_today,
        "local_today": local_today,
        "unique_cloud_ips": unique_cloud_ips,
        "warnings_today": warnings_today,
        "last_cloud": dict(last_cloud) if last_cloud else None,
    }


def clear_logs() -> bool:
    """Clear audit logs history cleanly and reset autoincrement sequence."""
    conn = _get_connection()
    try:
        with conn:
            conn.execute("DELETE FROM audit_logs")
            try:
                conn.execute("DELETE FROM sqlite_sequence WHERE name='audit_logs'")
            except Exception:
                pass
        conn.isolation_level = None
        conn.execute("VACUUM")
    except Exception:
        pass
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return True


def export_excel(limit: int = 1000) -> bytes:
    """Export audit log to Excel (.xlsx) file bytes with clean styles."""
    import openpyxl
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Journal d'audit Dec2026"

    # Header style
    header_fill = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Segoe UI", size=10)
    border_side = Side(border_style="thin", color="CBD5E1")
    cell_border = Border(left=border_side, right=border_side, top=border_side, bottom=border_side)

    headers = [
        "N°",
        "Date & Heure",
        "Canal / Source",
        "Adresse IP",
        "Pays",
        "Appareil / OS",
        "Catégorie",
        "Dossier",
        "Statut",
        "Description de l'opération",
    ]

    ws.append(headers)
    for col_num in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_num)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    with _get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()

    for r in rows:
        src_label = {
            "cloud": "🌐 Internet (Cloudflare)",
            "lan": "📶 Réseau Wi-Fi",
            "local": "💻 Local (PC)",
        }.get(r["source"], r["source"])

        stat_label = {
            "success": "✓ Succès",
            "warning": "⚠ Avertissement",
            "blocked": "🚫 Bloqué",
            "error": "❌ Erreur",
        }.get(r["status"], r["status"])

        row_vals = [
            r["id"],
            r["created_at"],
            src_label,
            r["ip"],
            r["country"] or "—",
            r["device"],
            r["category"],
            r["dossier"] or "—",
            stat_label,
            r["description"],
        ]
        ws.append(row_vals)

        row_idx = ws.max_row
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=row_idx, column=col_idx)
            c.font = data_font
            c.border = cell_border
            if col_idx in (1, 2, 5, 9):
                c.alignment = Alignment(horizontal="center", vertical="center")
            else:
                c.alignment = Alignment(vertical="center")

    # Auto column width
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            val = str(cell.value or "")
            if len(val) > max_len:
                max_len = len(val)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)

    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
