"""Dec2026 Dossier Portfolios & User Assignment Manager.

Handles assigning company dossiers (S1, S2, ...) to specific collaborators/agents,
tracking created_by and assigned_to metadata, and enforcing data segregation
between accounting staff.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import config, users

META_FILE = config.DATA_DIR / "dossiers_meta.json"


def load_meta() -> Dict[str, Dict[str, Any]]:
    """Loads dossiers metadata (assigned_to, created_by, updated_at)."""
    if not META_FILE.is_file():
        return {}
    try:
        with open(META_FILE, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_meta(meta: Dict[str, Dict[str, Any]]) -> None:
    """Atomic write to dossiers_meta.json."""
    META_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = META_FILE.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    tmp.replace(META_FILE)


def get_dossier_assignee(dossier_code: str) -> Optional[str]:
    """Returns the username of the collaborator assigned to this dossier."""
    meta = load_meta()
    d_info = meta.get(dossier_code.upper()) or meta.get(dossier_code.lower()) or meta.get(dossier_code)
    if d_info and isinstance(d_info, dict):
        return d_info.get("assigned_to")
    return None


def set_dossier_assignee(dossier_code: str, username: str, modifier: str = "admin") -> Dict[str, Any]:
    """Sets or transfers a dossier to a new collaborator."""
    code = dossier_code.upper()
    meta = load_meta()
    target_user = username.strip().lower() if username else ""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    entry = meta.get(code, {})
    entry["assigned_to"] = target_user if target_user != "*" else "*"
    entry["updated_at"] = now_str
    entry["updated_by"] = modifier
    if "created_by" not in entry:
        entry["created_by"] = modifier

    meta[code] = entry
    save_meta(meta)

    # Sync into users.json assigned_dossiers
    _sync_users_assigned_dossiers(meta)
    return entry


def assign_dossiers_to_user(username: str, dossier_codes: List[str], modifier: str = "admin") -> None:
    """Replaces the full portfolio of dossiers assigned to a specific user."""
    user_key = username.strip().lower()
    clean_codes = {c.strip().upper() for c in dossier_codes if c.strip()}
    meta = load_meta()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 1. Clear any previous assignments of this user
    for code, item in meta.items():
        if item.get("assigned_to") == user_key:
            if code not in clean_codes:
                item["assigned_to"] = ""
                item["updated_at"] = now_str
                item["updated_by"] = modifier

    # 2. Assign the target codes
    for code in clean_codes:
        item = meta.get(code, {})
        item["assigned_to"] = user_key
        item["updated_at"] = now_str
        item["updated_by"] = modifier
        if "created_by" not in item:
            item["created_by"] = modifier
        meta[code] = item

    save_meta(meta)
    _sync_users_assigned_dossiers(meta)


def on_dossier_created(dossier_code: str, creator_username: str) -> None:
    """Called when a new dossier is created to immediately link ownership."""
    code = dossier_code.upper()
    meta = load_meta()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    creator = (creator_username or "admin").strip().lower()

    meta[code] = {
        "created_by": creator,
        "assigned_to": creator,
        "created_at": now_str,
        "updated_at": now_str,
        "updated_by": creator,
    }
    save_meta(meta)
    _sync_users_assigned_dossiers(meta)


def _sync_users_assigned_dossiers(meta: Dict[str, Dict[str, Any]]) -> None:
    """Keeps users.json assigned_dossiers list synchronized."""
    try:
        all_u = users.load_users()
        # Invert meta mapping: user -> [dossiers]
        user_dossiers: Dict[str, List[str]] = {u: [] for u in all_u}
        for code, item in meta.items():
            assigned = (item.get("assigned_to") or "").lower()
            if assigned and assigned in user_dossiers:
                user_dossiers[assigned].append(code)

        changed = False
        for u_key, u_obj in all_u.items():
            if u_obj.get("role") == "admin":
                target_list = ["*"]
            else:
                target_list = sorted(user_dossiers.get(u_key, []))
            if u_obj.get("assigned_dossiers") != target_list:
                u_obj["assigned_dossiers"] = target_list
                changed = True
        if changed:
            users.save_users(all_u)
    except Exception:
        pass


def get_user_assigned_dossiers(username: str) -> List[str]:
    """Returns list of dossier codes assigned to the given user."""
    u_key = username.strip().lower()
    all_u = users.load_users()
    u_obj = all_u.get(u_key)
    if u_obj and u_obj.get("role") == "admin":
        return ["*"]

    meta = load_meta()
    assigned = []
    for code, item in meta.items():
        if (item.get("assigned_to") or "").lower() == u_key or item.get("assigned_to") == "*":
            assigned.append(code)
    return sorted(assigned)


def can_user_access_dossier(user_info: Optional[Dict[str, Any]], dossier_code: str) -> bool:
    """Verifies whether a user has permission to open/view a specific dossier."""
    if not user_info:
        return True
    if user_info.get("role") == "admin":
        return True
    assigned = user_info.get("assigned_dossiers") or []
    if "*" in assigned:
        return True
    d_clean = dossier_code.strip().upper()
    return d_clean in [c.upper() for c in assigned]
