"""Dec2026 Multi-User Concurrency & Conflict Prevention Engine (Distributed Lock Manager).

Prevents write conflicts when multiple users/workstations on the LAN access or edit
the same dossier, G50 declaration, or accounting documents concurrently.
Locks expire automatically after 60 seconds of inactivity unless heartbeated.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime
from typing import Any, Dict, List, Optional


class LockManager:
    def __init__(self, ttl: float = 60.0):
        self.ttl = ttl
        self._locks: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.Lock()

    def _cleanup_expired(self, now: float) -> None:
        expired = [k for k, v in self._locks.items() if now > v.get("expires_at", 0)]
        for k in expired:
            del self._locks[k]

    def acquire(
        self,
        resource_key: str,
        username: str,
        display_name: str,
        role: str,
        client_ip: str,
        device: str,
    ) -> Dict[str, Any]:
        """Attempts to acquire or renew an exclusive lock on a resource.
        
        resource_key e.g.:
          - 'dossier:S1'
          - 'g50:S1:2024:10'
          - 'doc:S1:14'
        """
        now = time.time()
        with self._lock:
            self._cleanup_expired(now)
            existing = self._locks.get(resource_key)

            if existing:
                # If held by the same user and IP, renew it
                if existing["username"] == username and existing["client_ip"] == client_ip:
                    existing["last_heartbeat"] = now
                    existing["expires_at"] = now + self.ttl
                    return {"acquired": True, "lock": existing, "conflict": False}

                # Conflict: resource is locked by another user
                time_remaining = max(0, int(existing["expires_at"] - now))
                return {
                    "acquired": False,
                    "conflict": True,
                    "locked_by": {
                        "username": existing["username"],
                        "display_name": existing["display_name"],
                        "role": existing["role"],
                        "client_ip": existing["client_ip"],
                        "device": existing["device"],
                        "since": existing["acquired_at_str"],
                        "time_remaining_seconds": time_remaining,
                    },
                }

            # Create new lock
            lock_obj = {
                "resource_key": resource_key,
                "username": username,
                "display_name": display_name,
                "role": role,
                "client_ip": client_ip,
                "device": device,
                "acquired_at": now,
                "acquired_at_str": datetime.now().strftime("%H:%M:%S"),
                "last_heartbeat": now,
                "expires_at": now + self.ttl,
            }
            self._locks[resource_key] = lock_obj
            return {"acquired": True, "lock": lock_obj, "conflict": False}

    def heartbeat(self, resource_key: str, username: str, client_ip: str) -> bool:
        """Extends lock lease if still owned by the caller."""
        now = time.time()
        with self._lock:
            self._cleanup_expired(now)
            lock = self._locks.get(resource_key)
            if lock and lock["username"] == username and lock["client_ip"] == client_ip:
                lock["last_heartbeat"] = now
                lock["expires_at"] = now + self.ttl
                return True
            return False

    def release(self, resource_key: str, username: str, client_ip: Optional[str] = None) -> bool:
        """Releases a lock held by the specified user."""
        with self._lock:
            lock = self._locks.get(resource_key)
            if not lock:
                return True
            if lock["username"] == username or (client_ip and lock["client_ip"] == client_ip):
                del self._locks[resource_key]
                return True
            return False

    def force_release(self, resource_key: str) -> bool:
        """Administrative unlock."""
        with self._lock:
            if resource_key in self._locks:
                del self._locks[resource_key]
                return True
            return False

    def list_active(self) -> List[Dict[str, Any]]:
        """Returns all currently active locks."""
        now = time.time()
        with self._lock:
            self._cleanup_expired(now)
            return [
                {
                    "resource_key": k,
                    "username": v["username"],
                    "display_name": v["display_name"],
                    "role": v["role"],
                    "client_ip": v["client_ip"],
                    "device": v["device"],
                    "since": v["acquired_at_str"],
                    "remaining_seconds": max(0, int(v["expires_at"] - now)),
                }
                for k, v in self._locks.items()
            ]


LOCK_MANAGER = LockManager(ttl=60.0)
