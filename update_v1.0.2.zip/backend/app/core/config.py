"""Runtime paths. Every path can be overridden with an environment variable."""
import os
from pathlib import Path

def _detect_project_root() -> Path:
    env_root = os.environ.get("DEC_PROJECT_ROOT")
    if env_root and Path(env_root).is_dir():
        return Path(env_root)
    try:
        import sys
        if getattr(sys, "frozen", False):
            return Path(sys.executable).resolve().parent
    except Exception:
        pass
    return Path(__file__).resolve().parents[3]

PROJECT_ROOT = _detect_project_root()
DELPHI_ROOT = Path(os.environ.get("DEC_DELPHI_ROOT", PROJECT_ROOT.parent))

SOCIETES_DIR = Path(os.environ.get("DEC_SOCIETES_DIR", PROJECT_ROOT / "data" / "societes"))
RAPPORTS_DIR = Path(
    os.environ.get(
        "DEC_RAPPORTS_DIR",
        PROJECT_ROOT / "Rapports" if (PROJECT_ROOT / "Rapports").is_dir() else (DELPHI_ROOT / "Rapports")
    )
)
SPEC_DIR = Path(os.environ.get("DEC_SPEC_DIR", PROJECT_ROOT / "spec"))
DATA_DIR = Path(os.environ.get("DEC_DATA_DIR", PROJECT_ROOT / "data"))
CACHE_DIR = Path(os.environ.get("DEC_CACHE_DIR", PROJECT_ROOT / "data" / "cache"))
def _resolve_frontend_dist() -> Path:
    env_p = os.environ.get("DEC_FRONTEND_DIST")
    if env_p and Path(env_p).is_dir():
        return Path(env_p)
    candidates = [
        PROJECT_ROOT / "frontend" / "dist",
        PROJECT_ROOT / "static",
        PROJECT_ROOT / "_internal" / "frontend" / "dist",
        PROJECT_ROOT / "_internal" / "app" / "static",
        PROJECT_ROOT / "backend" / "app" / "static",
        Path(__file__).resolve().parent.parent / "static",
        Path(__file__).resolve().parents[2] / "frontend" / "dist",
    ]
    for c in candidates:
        if c.is_dir() and (c / "index.html").is_file():
            return c
    return PROJECT_ROOT / "frontend" / "dist"

FRONTEND_DIST = _resolve_frontend_dist()

REF_DB = Path(os.environ.get("DEC_REF_DB", PROJECT_ROOT / "data" / "ref" / "G50ref.sqlite"))

DB_FILENAME = "G50.sqlite"
BACKUP_DIR = Path(os.environ.get("DEC_BACKUP_DIR", PROJECT_ROOT / "data" / "backups"))
LICENCE_FILE = Path(os.environ.get("DEC_LICENCE_FILE", PROJECT_ROOT / "data" / "licence.key"))
ACCESS_FILE = Path(os.environ.get("DEC_ACCESS_FILE", PROJECT_ROOT / "data" / ("acces.json" if (PROJECT_ROOT / "data" / "acces.json").is_file() else "access.json")))
AUDIT_DB = Path(os.environ.get("DEC_AUDIT_DB", PROJECT_ROOT / "data" / "audit.sqlite"))
USERS_FILE = Path(os.environ.get("DEC_USERS_FILE", PROJECT_ROOT / "data" / "users.json"))

def get_edition() -> str:
    env_ed = os.environ.get("DEC_EDITION")
    if env_ed:
        return env_ed.lower()
    f = DATA_DIR / "edition.txt"
    if f.is_file():
        try:
            return f.read_text(encoding="utf-8").strip().lower()
        except Exception:
            pass
    if "reseau" in str(PROJECT_ROOT).lower():
        return "reseau"
    return "solo"

EDITION = get_edition()

