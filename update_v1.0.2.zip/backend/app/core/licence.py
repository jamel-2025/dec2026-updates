"""Hardware-locked licensing and activation system for Dec2026.

Uses Windows native hardware fingerprints (MachineGuid + Volume Serial Number)
and HMAC-SHA256 signature verification to prevent software piracy.
Engineered for 100% offline resilience: NEVER requires an internet connection
and guarantees identical activation status regardless of network state (offline,
Wi-Fi disconnected, airplane mode, or cable unplugged).
"""
from __future__ import annotations

import ctypes
import datetime
import hashlib
import hmac
import json
import os
import platform
import uuid
from pathlib import Path

from . import config

# Master secret key used for signing activation keys (kept private to Dec2026)
SECRET_SALT = "DEC2026-G50-MULTI-FISCAL-SECRET-ALGERIE-KEY-9941"


def get_base_hardware() -> list[str]:
    """Collects permanent, offline-guaranteed Windows installation identifiers."""
    parts: list[str] = []

    # 1. Windows MachineGuid from Registry (permanent per installation, 100% offline)
    if platform.system() == "Windows":
        try:
            import winreg
            sam = winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0x0100)
            try:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, sam)
            except Exception:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
            with k:
                guid, _ = winreg.QueryValueEx(k, "MachineGuid")
                if guid:
                    parts.append(str(guid).strip())
        except Exception:
            pass

        # 2. System drive Volume Serial Number via kernel32 (permanent per disk partition, 100% offline)
        try:
            vol = ctypes.c_ulong()
            if ctypes.windll.kernel32.GetVolumeInformationW(r"C:\\", None, 0, ctypes.byref(vol), None, None, None, 0):
                parts.append(hex(vol.value))
        except Exception:
            pass

    # 3. Node Name / ComputerName
    node_name = platform.node() or os.environ.get("COMPUTERNAME", "")
    if node_name:
        parts.append(node_name.strip())

    return parts


def get_all_hardware_nodes() -> set[str]:
    """Retrieves all physical and registered network adapter MAC node integers.
    
    Uses direct Windows GetAdaptersInfo API which enumerates ALL adapters registered in
    the driver tables (both active and disconnected), ensuring identical results when offline.
    """
    nodes: set[str] = set()

    # 1. Direct kernel32/iphlpapi enumeration (all network adapters up or down)
    if platform.system() == "Windows":
        try:
            iphlpapi = ctypes.windll.iphlpapi

            class IP_ADAPTER_INFO(ctypes.Structure):
                pass

            IP_ADAPTER_INFO._fields_ = [
                ("Next", ctypes.POINTER(IP_ADAPTER_INFO)),
                ("ComboIndex", ctypes.c_ulong),
                ("AdapterName", ctypes.c_char * 260),
                ("Description", ctypes.c_char * 132),
                ("AddressLength", ctypes.c_uint),
                ("Address", ctypes.c_ubyte * 8),
                ("Index", ctypes.c_ulong),
                ("Type", ctypes.c_uint),
                ("DhcpEnabled", ctypes.c_uint),
                ("CurrentIpAddress", ctypes.c_void_p),
                ("IpAddressList", ctypes.c_char * 428),
                ("GatewayList", ctypes.c_char * 428),
                ("DhcpServer", ctypes.c_char * 428),
                ("HaveWins", ctypes.c_int),
                ("PrimaryWinsServer", ctypes.c_char * 428),
                ("SecondaryWinsServer", ctypes.c_char * 428),
                ("LeaseObtained", ctypes.c_long),
                ("LeaseExpires", ctypes.c_long),
            ]

            buf_len = ctypes.c_ulong(16384)
            buf = ctypes.create_string_buffer(buf_len.value)
            if iphlpapi.GetAdaptersInfo(ctypes.byref(buf), ctypes.byref(buf_len)) == 0:
                p = ctypes.cast(buf, ctypes.POINTER(IP_ADAPTER_INFO))
                while p:
                    info = p.contents
                    if info.AddressLength >= 6:
                        nv = 0
                        for b in info.Address[:6]:
                            nv = (nv << 8) | b
                        if nv != 0:
                            nodes.add(str(nv))
                    p = info.Next
        except Exception:
            pass

    # 2. uuid.getnode() as an additional candidate
    try:
        u = uuid.getnode()
        if u != 0:
            nodes.add(str(u))
    except Exception:
        pass

    # 3. Fallbacks: pure hardware base without MAC, and zero node
    nodes.add("")
    nodes.add("0")

    return nodes


def compute_machine_id(base_parts: list[str], node_str: str = "") -> str:
    """Computes a clean, human-readable Machine ID from base parts + node."""
    p = list(base_parts)
    if node_str and node_str.strip():
        p.append(node_str.strip())
    raw = ":".join(p)
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
    return f"G50-{digest[0:4]}-{digest[4:8]}-{digest[8:12]}-{digest[12:16]}"


def get_all_valid_machine_ids() -> set[str]:
    """Returns the set of all valid Machine IDs that belong to this physical machine."""
    base = get_base_hardware()
    mids: set[str] = set()
    for node in get_all_hardware_nodes():
        mids.add(compute_machine_id(base, node))
    return mids


def get_machine_id() -> str:
    """Returns a stable, offline-resilient Machine ID for Dec2026.
    
    If the machine already has an active, valid license file, it locks strictly
    to the saved machine ID so that network state changes never alter the visible ID.
    Otherwise, it returns the primary deterministic hardware ID.
    """
    valid_mids = get_all_valid_machine_ids()

    # If already activated and the saved machine ID belongs to this hardware, lock to it!
    p = config.LICENCE_FILE
    if p.is_file():
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            saved_machine = str(data.get("machine_id", "")).strip().upper()
            if saved_machine and saved_machine in valid_mids:
                return saved_machine
        except Exception:
            pass

    # Fallback to primary deterministic ID:
    # Prefer non-zero adapter nodes sorted deterministically, or pure base hardware
    base = get_base_hardware()
    sorted_nodes = sorted([n for n in get_all_hardware_nodes() if n and n != "0"])
    primary_node = sorted_nodes[0] if sorted_nodes else ""
    return compute_machine_id(base, primary_node)


def generate_activation_key(machine_id: str, client: str, serial: str, expiry: str = "LIFETIME") -> str:
    """Generates the official activation key for a given machine ID and client."""
    m_id = machine_id.strip().upper()
    c_name = client.strip()
    s_num = serial.strip().upper()
    exp = expiry.strip().upper()

    payload = f"{m_id}|{c_name}|{s_num}|{exp}"
    sig = hmac.new(SECRET_SALT.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest().upper()
    return f"ACT-{sig[0:4]}-{sig[4:8]}-{sig[8:12]}-{sig[12:16]}-{sig[16:20]}"


def verify_license_data(data: dict) -> tuple[bool, str]:
    """Validates the license dictionary against current machine hardware and signature.
    
    100% offline resilient: accepts any machine ID candidate that genuinely belongs
    to this computer, preventing network disconnection or adapter state changes from
    invalidating the license.
    """
    saved_machine = str(data.get("machine_id", "")).strip().upper()
    client = str(data.get("client", "")).strip()
    serial = str(data.get("serial", "")).strip().upper()
    expiry = str(data.get("expiry", "LIFETIME")).strip().upper()
    key = str(data.get("activation_key", "")).strip().upper()

    valid_mids = get_all_valid_machine_ids()
    if saved_machine not in valid_mids:
        return False, "Cette licence n'est pas valide pour cet ordinateur."

    expected_key = generate_activation_key(saved_machine, client, serial, expiry)
    if not hmac.compare_digest(key, expected_key):
        return False, "Clé d'activation invalide ou corrompue."

    if expiry != "LIFETIME":
        try:
            exp_date = datetime.date.fromisoformat(expiry)
            if datetime.date.today() > exp_date:
                return False, f"La licence a expiré le {exp_date.strftime('%d/%m/%Y')}."
        except ValueError:
            return False, "Format de date d'expiration invalide."

    return True, "Licence valide"


def get_license_status() -> dict:
    """Returns current activation status and details."""
    current_machine = get_machine_id()

    # Development or testing bypass (only if explicitly set in environment)
    if os.environ.get("DEC_DEV_MODE") == "1" or os.environ.get("DEC_SKIP_LICENCE") == "1":
        return {
            "activated": True,
            "machine_id": current_machine,
            "client": "Mode Développement (Bypass)",
            "serial": "DEV-2026",
            "expiry": "LIFETIME",
            "message": "Mode développement actif",
        }

    p = config.LICENCE_FILE
    if not p.is_file():
        return {
            "activated": False,
            "machine_id": current_machine,
            "client": "",
            "serial": "",
            "expiry": "",
            "message": "Logiciel non activé. Veuillez entrer votre clé d'activation.",
        }

    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        valid, msg = verify_license_data(data)
        saved_machine = str(data.get("machine_id", "")).strip().upper()
        return {
            "activated": valid,
            "machine_id": saved_machine if valid else current_machine,
            "client": data.get("client", ""),
            "serial": data.get("serial", ""),
            "expiry": data.get("expiry", "LIFETIME"),
            "message": msg,
        }
    except Exception as e:
        return {
            "activated": False,
            "machine_id": current_machine,
            "client": "",
            "serial": "",
            "expiry": "",
            "message": f"Erreur de lecture de la licence : {e}",
        }


def activate(client: str, serial: str, activation_key: str, expiry: str = "LIFETIME") -> dict:
    """Attempts to activate the software and save the license file.
    
    Supports activating for the current machine ID or any recognized valid candidate
    for this computer.
    """
    clean_client = client.strip()
    clean_serial = serial.strip().upper()
    clean_key = activation_key.strip().upper()
    clean_expiry = expiry.strip().upper()

    if not clean_client:
        raise ValueError("Le nom du client est obligatoire.")
    if not clean_serial:
        raise ValueError("Le numéro de série est obligatoire.")
    if not clean_key:
        raise ValueError("La clé d'activation est obligatoire.")

    current_machine = get_machine_id()
    valid_mids = get_all_valid_machine_ids()

    # Find which valid machine ID matches this key
    target_mid = current_machine
    matched = False
    for mid in [current_machine] + list(valid_mids):
        expected = generate_activation_key(mid, clean_client, clean_serial, clean_expiry)
        if hmac.compare_digest(clean_key, expected):
            target_mid = mid
            matched = True
            break

    data = {
        "machine_id": target_mid,
        "client": clean_client,
        "serial": clean_serial,
        "expiry": clean_expiry,
        "activation_key": clean_key,
        "activated_at": datetime.datetime.now().isoformat(),
    }

    valid, msg = verify_license_data(data)
    if not valid:
        raise ValueError(msg)

    config.LICENCE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(config.LICENCE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    return {
        "success": True,
        "message": "Activation réussie ! Merci d'avoir enregistré votre application.",
        "client": clean_client,
        "expiry": clean_expiry,
    }


def deactivate() -> dict:
    """Removes the license file."""
    if config.LICENCE_FILE.is_file():
        config.LICENCE_FILE.unlink()
    return {"success": True, "message": "Licence réinitialisée."}
