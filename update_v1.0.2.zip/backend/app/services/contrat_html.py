"""Contrats de travail — mise en page HTML (modèle fourni par l'utilisateur) à la place du rendu fr3.

Le contenu reste celui des modèles Delphi Rapports/Contrat_<type>.fr3 : les mémos y sont lus dans l'ordre
(titre, MemoP1_* employeur, MemoP2_* salarié, MemoArt<n>Head / MemoArt<n>* articles, tableaux T<k>_* des sanctions
du modèle SNAPO, observations, lieu et date, signatures) et les variables [SocRS]…[Observations] sont remplacées
comme dans uContrats.BuildContractReport. Seule la présentation change : sans la ligne « الجمهورية الجزائرية… »
ni le nom de la société en tête, dates en toutes lettres, montants en dinars entiers.
"""
from __future__ import annotations

import base64
import re
import sys
import xml.etree.ElementTree as ET
from functools import lru_cache
from html import escape
from pathlib import Path

from fastapi import HTTPException

from ..core import config
from . import salaries

FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"
VAR = re.compile(r"\[([A-Za-z]+)\]")
ART = re.compile(r"^MemoArt(\d+)(.*)$")
CELL = re.compile(r"^T(\d+)_(H|R\d+)_(Desc|C\d+)$")

AGREE = "اتفق الطرفان المتعاقدان بكامل إرادتهما وقواهما المعتبرة قانوناً على ما يلي:"
CLOSING = "حرر هذا العقد بـ: {lieu} بتاريخ: {date} في نسختين أصليتين، تسلم نسخة لكل طرف — قرئ وصودق عليه من الطرفين."


@lru_cache(maxsize=16)
def _memos(path: str, mtime: float) -> list[tuple[str, str]]:
    """(name, text) of every memo, page by page, top to bottom (right before left on the same line)."""
    root = ET.parse(path).getroot()
    out: list[tuple[str, str]] = []
    for page in root.iter("TfrxReportPage"):
        items = []
        for band in page:
            btop = float(band.get("Top") or 0)
            for m in band.iter("TfrxMemoView"):
                items.append((btop + float(m.get("Top") or 0), -float(m.get("Left") or 0), m.get("Name") or "", m.get("Text") or ""))
        out += [(n, t) for _, _, n, t in sorted(items)]
    return out


def _template_path(name: str) -> Path:
    candidates = [
        config.RAPPORTS_DIR / name,
        config.PROJECT_ROOT / "Rapports" / name,
        config.PROJECT_ROOT / "_internal" / "Rapports" / name,
        config.SPEC_DIR / "reports" / name,
        config.DELPHI_ROOT / name,
    ]
    if getattr(sys, "frozen", False):
        exe_dir = Path(sys.executable).resolve().parent
        candidates.extend([
            exe_dir / "Rapports" / name,
            exe_dir / "_internal" / "Rapports" / name,
            Path(getattr(sys, "_MEIPASS", "")) / "Rapports" / name,
        ])
    else:
        root = Path(__file__).resolve().parent.parent.parent.parent
        candidates.extend([
            root / "Rapports" / name,
            root / "Dec2026_Reseau" / "Rapports" / name,
            root / "Dec2026_Solo" / "Rapports" / name,
        ])
    for p in candidates:
        if p and p.is_file():
            return p
    raise HTTPException(500, f"Modèle introuvable : {name}")


def _is_pure_number(s: str) -> bool:
    """True only for standalone numbers or currency figures without Arabic text (e.g. '25 000', '10 %', '250').
    Arabic dates (e.g. '05 نوفمبر 2026') or durations ('03 أشهر') must NEVER use dir='ltr' as that inverts the date order.
    """
    if not s or re.search(r"[\u0600-\u06FF]", s):
        return False
    return bool(re.match(r"^[\d\s.,\-+/%]+$", s.strip()))


def _fill(text: str, v: dict) -> str:
    """Escaped text with the [Var] values in bold; empty « ( ) » left by a missing value removed."""
    parts, last = [], 0
    for m in VAR.finditer(text):
        parts.append(escape(text[last:m.start()]))
        val = str(v.get(m.group(1), "") or "").strip()
        if val and _is_pure_number(val):
            # Numbers in RTL text get visual transposition (e.g. 25 000 inverted to 000 25)
            # Unicode bidi isolate prevents the Arabic context from swapping thousands
            parts.append(f'<b dir="ltr" style="unicode-bidi:isolate;display:inline-block;">{escape(val)}</b>')
        elif val:
            parts.append(f"<b>{escape(val)}</b>")
        last = m.end()
    parts.append(escape(text[last:]))
    s = "".join(parts).replace("\r\n", "\n").strip()
    return re.sub(r"\(\s*\)", "", s).strip()


def _font_face() -> str:
    faces = []
    for f, rng in (("cairo-arabic-wght-normal.woff2", "U+0600-06FF,U+0750-077F,U+0870-08FF,U+FB50-FDFF,U+FE70-FEFF"),
                   ("cairo-latin-wght-normal.woff2", "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+2000-206F,U+20AC")):
        p = FONTS / f
        if p.is_file():
            b64 = base64.b64encode(p.read_bytes()).decode()
            faces.append(f"@font-face{{font-family:'Cairo';font-weight:200 1000;src:url(data:font/woff2;base64,{b64}) format('woff2');"
                         f"unicode-range:{rng}}}")
    return "".join(faces)


def _parse(memos: list[tuple[str, str]], v: dict) -> dict:
    doc: dict = {"title": "", "p1": [], "p2": [], "arts": [], "obs": "", "sig": {}, "extra": []}
    arts: dict[int, dict] = {}
    current: dict | None = None
    for name, raw in memos:
        if not raw.strip() and not name.startswith("MemoSig"):
            continue
        if name == "MemoTitle":
            doc["title"] = _fill(raw, v)
        elif name.startswith("MemoP1_") or name == "Memo1":
            doc["p1"].append((name, raw))
        elif name.startswith("MemoP2_"):
            doc["p2"].append((name, raw))
        elif name in ("MemoAgree", "MemoDateLieu"):
            continue                                   # rewritten (AGREE / CLOSING)
        elif name in ("MemoObs", "MemoObsBody"):
            doc["obs"] = _fill(raw, v)
        elif name.startswith("MemoSigHead"):
            doc["sig"][name] = raw.strip()
        elif name.startswith("MemoSig"):
            continue
        elif (m := ART.match(name)):
            n = int(m.group(1))
            art = arts.setdefault(n, {"head": "", "lines": [], "tables": {}})
            if art not in doc["arts"]:
                doc["arts"].append(art)
            if m.group(2) == "Head":
                art["head"] = _fill(raw, v)
            else:
                art["lines"].append(_fill(raw, v))
            current = art
        elif (m := CELL.match(name)):
            host = current or (doc["arts"][-1] if doc["arts"] else None)
            if host is None:
                continue
            table = host["tables"].setdefault(int(m.group(1)), {})
            table.setdefault(m.group(2), {})[m.group(3)] = _fill(raw, v)
        else:
            doc["extra"].append(_fill(raw, v))
    return doc


def _allowances(line: str) -> str:
    """« …منح التعويض: عن الضرر: 10 % | عن القفة: … » → one allowance per line."""
    if " | " not in line:
        return line
    line = re.sub(r"(منح التعويض:)\s*", r"\1\n- التعويض ", line, count=1)
    return line.replace(" | ", "\n- التعويض ")


def _party(parts: list[tuple[str, str]], v: dict, role: str, suffix: str, drop_label: bool) -> str:
    texts = []
    for name, raw in parts:
        if name in ("MemoP1_4", "MemoP2_5", "Memo1"):
            continue                                   # « من جهة » / « المسمى بالمستخدم » → suffix
        names = VAR.findall(raw)
        if names and not any(str(v.get(k) or "").strip() for k in names):
            continue                                   # e.g. « المسيرة من طرف: » with no manager recorded
        t = _fill(raw, v)
        if drop_label and name == "MemoP1_1" and ":" in t:
            t = t.split(":", 1)[1].strip()             # « المستخدم: » is the role label
        texts.append(t)
    return f'<div class="party"><span class="role">{role}</span><span class="ptext">{" · ".join(texts)} {suffix}</span></div>'


def _table(t: dict) -> str:
    cols = sorted({c for row in t.values() for c in row if c != "Desc"}, key=lambda c: int(c[1:]))
    head = t.get("H", {})
    rows = sorted((k for k in t if k != "H"), key=lambda k: int(k[1:]))
    th = "".join(f"<th>{head.get(c, '')}</th>" for c in ["Desc", *cols])
    body = "".join("<tr>" + "".join(f"<td>{t[r].get(c, '')}</td>" for c in ["Desc", *cols]) + "</tr>" for r in rows)
    return f'<table class="grid"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table>'


CSS = """@page{size:A4 portrait;margin:0 !important}*{box-sizing:border-box}
body{margin:0;font-family:'Cairo','Segoe UI',Tahoma,Arial,sans-serif;color:#15140F;font-size:13px;line-height:1.6;background:#fff;direction:rtl;text-align:right}
.doc{max-width:820px;margin:0 auto;padding:12mm 15mm;direction:rtl;text-align:right}
.head{text-align:center;border-bottom:2px solid #15140F;padding-bottom:12px;margin-bottom:16px}
.tt{font-size:22px;font-weight:900;text-decoration:underline;margin:6px 0}
.num{font-size:13px;color:#666}
.parties{border:1.5px solid #2B2A27;border-radius:6px;padding:12px 14px;background:#FAF9F5;margin-bottom:14px;direction:rtl;text-align:right}
.party{margin-bottom:8px;direction:rtl;text-align:right}.party+.party{border-top:1px dashed #D5D0C5;padding-top:8px;margin-bottom:0}
.role{font-weight:800;color:#006233}.ptext{font-size:13px;line-height:1.55}
.pre{font-weight:700;text-align:center;margin:14px 0;background:#EDE9DF;padding:8px 12px;border-radius:4px;border:1px solid #DBD5C7}
.art{margin-bottom:12px;border-bottom:1px solid #EAE6DC;padding-bottom:8px;break-inside:avoid;direction:rtl;text-align:right}
.art h4{color:#006233;margin:0 0 4px;font-size:14px;font-weight:800;text-align:right}
.art .body{white-space:pre-line;line-height:1.6;font-size:13px;text-align:justify;direction:rtl}
.grid{width:100%;border-collapse:collapse;margin:8px 0;font-size:11.5px}
.grid th,.grid td{border:1px solid #BDB7A8;padding:3px 6px;text-align:center;vertical-align:middle}
.grid th{background:#EDE9DF;font-weight:800}.grid td:first-child{text-align:right}
.obs{margin-top:10px;padding:8px 12px;border:1px dashed #D5D0C5;border-radius:4px}
.closing{margin-top:20px;font-style:italic;font-weight:600;text-align:center;padding:8px;background:#F6F4EE;border-radius:4px}
.signs{width:100%;margin-top:24px;border-collapse:separate;border-spacing:20px 0;break-inside:avoid}
.sbox{width:50%;text-align:center;vertical-align:top;border:1.5px solid #15140F;border-radius:6px;padding:12px;height:110px;background:#fff}
.sbox small{color:#777}
@media print{
  @page{size:A4 portrait;margin:0 !important}
  html,body{margin:0 !important;padding:0 !important;background:#fff !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .doc{max-width:100% !important;padding:12mm 15mm !important}
}"""


def render(code: str, params: dict, for_word: bool = False) -> tuple[str, str]:
    """(html, title) of the contract `params['id']`."""
    cid = int(params.get("id") or 0)
    d = salaries.print_data(code, cid)
    v = d["pretty"]
    p = _template_path(d["template"])
    doc = _parse(_memos(str(p), p.stat().st_mtime), v)

    custom = salaries.get_contrat_custom(code, cid)
    if custom and custom.get("CustomHTML") and custom["CustomHTML"].strip():
        content_body = custom["CustomHTML"]
    else:
        arts = []
        for a in doc["arts"]:
            body = "\n".join(_allowances(x) for x in a["lines"])
            tables = "".join(_table(t) for _, t in sorted(a["tables"].items()))
            arts.append(f'<div class="art"><h4>{a["head"]}</h4><div class="body">{body}</div>{tables}</div>')
        extra = "".join(f'<div class="art"><div class="body">{x}</div></div>' for x in doc["extra"] if x)
        obs = f'<div class="obs">{doc["obs"]}</div>' if doc["obs"] else ""
        content_body = f'{"".join(arts)}{extra}{obs}'

    sig_soc = doc["sig"].get("MemoSigHeadSoc") or "المستخدم"
    sig_emp = doc["sig"].get("MemoSigHeadEmp") or "العامل"
    lieu, date = escape(v.get("SocAdr") or ""), escape(v.get("DateContrat") or "")
    cnas = escape(str(v.get("EmpCNAS") or ""))
    p2_suffix = (f"· رقم الضمان الاجتماعي: <b>{cnas}</b> " if cnas else "") + "(المسمى بالعامل — من جهة أخرى)"

    title = escape(re.sub(r"<[^>]+>", "", doc["title"]) or d["title"])
    word_ns = ('xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" '
               'xmlns="http://www.w3.org/TR/REC-html40"') if for_word else ""
    html = f"""<!doctype html><html lang="ar" dir="rtl" {word_ns}><head><meta charset="utf-8">
<title>{escape(d["title"])}</title><style>{"" if for_word else _font_face()}{CSS}
.memo-editable-area{{min-height:120px;outline:none}}
.memo-editable-area[contenteditable="true"]:hover{{outline:1px dashed #006233;cursor:text}}
.memo-editable-area[contenteditable="true"]:focus{{outline:1.5px solid #006233;background:#fafcf9}}
@media print{{.memo-editable-area{{outline:none !important;background:transparent !important}}}}
</style></head>
<body><div class="doc">
<div class="head"><h1 class="tt">{title}</h1><div class="num">رقم العقد: <b>{escape(str(v.get("NumContrat") or ""))}</b></div></div>
<div class="parties">
{_party(doc["p1"], v, "المستخدم (الطرف الأول): ", "(المسمى بالمستخدم — من جهة)", True)}
{_party(doc["p2"], v, "العامل الأجير (الطرف الثاني): ", p2_suffix, False)}
</div>
<div class="pre">{AGREE}</div>
<div class="memo-editable-area" contenteditable="true" spellcheck="false">
{content_body}
</div>
<div class="closing">{CLOSING.format(lieu=lieu, date=date)}</div>
<table class="signs"><tr><td class="sbox"><b>عن {escape(sig_soc)}</b><br><small>(الختم الرسمي والإمضاء)</small></td>
<td class="sbox"><b>{escape(sig_emp)}</b><br><small>(قرئ وصودق عليه + الإمضاء)</small></td></tr></table>
</div></body></html>"""
    return html, d["title"]
