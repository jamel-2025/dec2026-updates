"""Déclarations manquantes — Delphi uMissingG50, UmmingTAPP, UmissingIBS, UmissingIRG.
Cross-dossier check: companies without a declaration for the chosen period.

  * G50: no G50 with Mois = m and Année = a (or ma = m+a / mm+a);
  * TAPP: no DeclarationTAPP with Exercice = a and ClientExercice = semester;
  * IBS: SARL / EURL / SPA without an IBSsolde for the exercice;
  * IRG: personnes physiques without an IRGsolde for the exercice.
Logical choice: the dossiers are read in read-only mode; unreadable dossiers are reported apart.
"""
from __future__ import annotations

import sqlite3

from ..core import config
from . import dossiers
from .g50 import G50Error

SEMESTRES = ["1er Semestre", "2éme Semestre"]
KINDS = ("g50", "tapp", "ibs", "irg")


def _has(c: sqlite3.Connection, kind: str, annee: str, periode: str) -> bool:
    if kind == "g50":
        m = int(periode)
        if c.execute('SELECT 1 FROM G50 WHERE CAST("Mois" AS INTEGER) = ? AND TRIM("Année") = ? LIMIT 1', (m, annee)).fetchone():
            return True
        return c.execute("SELECT 1 FROM G50 WHERE ma IN (?, ?) LIMIT 1", (f"{m}{annee}", f"{m:02d}{annee}")).fetchone() is not None
    if kind == "tapp":
        return c.execute("SELECT 1 FROM DeclarationTAPP WHERE TRIM(Exercice) = ? AND ClientExercice = ? LIMIT 1",
                         (annee, periode)).fetchone() is not None
    table, col = ("IBSsolde", "Exercice") if kind == "ibs" else ("IRGsolde", "exercice")
    return any(str(r[0]).strip() == annee for r in c.execute(f"SELECT {col} FROM {table}"))


def _concerned(kind: str, fj: str) -> bool:
    fj = (fj or "").strip().upper()
    if kind == "ibs":
        return fj in ("SARL", "EURL", "SPA")
    if kind == "irg":
        return "PERSONNE" in fj and "PHYSIQU" in fj
    return True


from typing import Optional


def search(kind: str, annee: str, periode: str = "", filter_user: Optional[str] = None) -> dict:
    if kind not in KINDS:
        raise G50Error("Type de déclaration inconnu")
    annee = str(annee or "").strip()
    if not annee.isdigit():
        raise G50Error("Veuillez saisir l’année.")
    if kind == "g50" and not (periode.isdigit() and 1 <= int(periode) <= 12):
        raise G50Error("Veuillez choisir un mois.")
    if kind == "tapp" and periode not in SEMESTRES:
        raise G50Error("Veuillez choisir le semestre.")
    missing, errors, filed, checked = [], [], [], 0
    for d in dossiers.list_dossiers(filter_user=filter_user):
        if not _concerned(kind, d.get("fj", "")):
            continue
        checked += 1
        try:
            c = sqlite3.connect(f"file:{config.SOCIETES_DIR / d['code'] / config.DB_FILENAME}?mode=ro", uri=True)
            try:
                ok = _has(c, kind, annee, periode)
            finally:
                c.close()
        except sqlite3.Error as e:
            errors.append({"code": d["code"], "rs": d.get("rs", ""), "error": str(e)})
            continue
        row = {
            "code": d["code"],
            "rs": d.get("rs", ""),
            "nif": d.get("nif", ""),
            "fj": d.get("fj", ""),
            "assigned_to": d.get("assigned_to", ""),
            "assigned_name": d.get("assigned_name", ""),
        }
        (filed if ok else missing).append(row)
    return {"missing": missing, "filed": filed, "checked": checked, "errors": errors}


def dashboard(today=None, filter_user: Optional[str] = None) -> dict:
    """uMain.ChargerStatistiques — declarations filed / dossiers for the current periods."""
    from datetime import date
    t = today or date.today()
    g50_m, g50_y = (12, t.year - 1) if t.month == 1 else (t.month - 1, t.year)
    sem = SEMESTRES[0 if t.month <= 6 else 1]
    months = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]
    plan = [("g50", "G50 mensuel", str(g50_y), str(g50_m), f"{months[g50_m - 1]} {g50_y}"),
            ("ibs", "IBS", str(t.year - 1), "", f"Exercice {t.year - 1}"),
            ("irg", "IRG", str(t.year - 1), "", f"Exercice {t.year - 1}"),
            ("tapp", "TAP / TFP", str(t.year), sem, f"{sem} {t.year}")]
    cards = []
    for kind, title, annee, periode, label in plan:
        r = search(kind, annee, periode, filter_user=filter_user)
        cards.append({"kind": kind, "title": title, "annee": annee, "periode": periode, "label": label,
                      "total": r["checked"], "filed": len(r["filed"]), "missing": r["missing"], "done": r["filed"]})
    deadline = date(t.year, t.month, 20)
    user_dossiers = dossiers.list_dossiers(filter_user=filter_user)
    return {
        "cards": cards,
        "deadline": deadline.isoformat(),
        "days_left": (deadline - t).days,
        "dossiers": len(user_dossiers),
        "filter_user": filter_user or "all",
    }
