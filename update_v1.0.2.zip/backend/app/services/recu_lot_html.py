"""Reçu de versement pour lot de lotissement — Modèle officiel A4 / A5 imprimable avec Tafqeet et adaptation selon la langue de l'interface (Arabe / Français).
"""
from __future__ import annotations

import base64
from html import escape
from pathlib import Path
from fastapi import HTTPException

from ..core.db import connect
from . import dates, dossiers, honoraires, passport

FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def _font_face() -> str:
    faces = []
    for f, rng in (
        ("cairo-arabic-wght-normal.woff2", "U+0600-06FF,U+0750-077F,U+0870-08FF,U+FB50-FDFF,U+FE70-FEFF"),
        ("cairo-latin-wght-normal.woff2", "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+2000-206F,U+20AC"),
    ):
        p = FONTS / f
        if p.is_file():
            b64 = base64.b64encode(p.read_bytes()).decode()
            faces.append(
                f"@font-face{{font-family:'Cairo';font-weight:200 1000;src:url(data:font/woff2;base64,{b64}) format('woff2');unicode-range:{rng};}}"
            )
    return "".join(faces)


CSS_BASE = """@page{size:A4 portrait;margin:12mm 15mm}*{box-sizing:border-box}
body{margin:0;font-family:'Cairo','Segoe UI',Tahoma,Arial,sans-serif;color:#15140F;font-size:13px;line-height:1.6;background:#fff}
.doc{max-width:800px;margin:0 auto;padding:6px 10px}
.soc-header{text-align:center;border-bottom:2.5px solid #047857;padding-bottom:12px;margin-bottom:16px}
.soc-name{font-size:20px;font-weight:900;color:#0f172a;letter-spacing:-0.01em}
.soc-sub{font-size:12px;color:#475569;line-height:1.6;margin-top:4px}
.recu-title-box{text-align:center;border:1.5px solid #1e293b;border-radius:8px;background:#f8fafc;padding:12px 16px;margin-bottom:16px}
.recu-title{font-size:22px;font-weight:900;color:#047857;margin:0 0 2px}
.recu-title-sub{font-size:11px;font-weight:700;color:#047857;letter-spacing:0.08em;font-family:'Inter',sans-serif;margin-bottom:6px}
.recu-meta{display:flex;justify-content:center;align-items:center;gap:20px;font-size:13.5px;color:#334155}
.recu-meta b{color:#0f172a;font-family:'Cairo','Inter',monospace}
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}
.info-card{border:1px solid #cbd5e1;border-radius:6px;padding:10px 14px;background:#FAF9F5;font-size:12.5px;line-height:1.6}
.info-card h4{margin:0 0 6px;color:#047857;font-size:13px;font-weight:800;border-bottom:1px solid #e2e8f0;padding-bottom:4px}
.cl-lbl{font-weight:800;color:#334155}
.montant-box{background:#f0fdf4;border:2px dashed #047857;border-radius:8px;padding:12px 18px;margin:14px 0 16px;display:flex;align-items:center;justify-content:space-between;gap:16px}
.tafqeet-col{display:flex;flex-direction:column;gap:4px;flex:1}
.tafqeet-badge{display:inline-block;font-size:10.5px;font-weight:800;color:#047857;background:#dcfce7;padding:2px 8px;border-radius:4px;width:fit-content}
.tafqeet-main{font-size:14px;font-weight:800;color:#0f172a;line-height:1.5;margin-top:2px}
.tafqeet-alt{font-size:11px;color:#475569;font-style:italic}
.montant-digits{display:flex;align-items:baseline;gap:6px;font-size:24px;font-weight:900;color:#047857;white-space:nowrap}
.m-val{font-family:'Cairo','Inter',monospace;direction:ltr}
.m-cur{font-size:16px;font-weight:800}
.solde-box{background:#f8fafc;border:1px solid #cbd5e1;border-radius:6px;padding:10px 14px;margin-bottom:16px;display:grid;grid-template-columns:repeat(4,1fr);gap:10px;text-align:center}
.solde-item span{display:block;font-size:11.5px;color:#64748b}
.solde-item b{font-size:13.5px;font-weight:800;color:#0f172a;font-family:'Cairo','Inter',monospace}
.signs{width:100%;margin-top:24px;border-collapse:separate;border-spacing:24px 0;break-inside:avoid}
.sbox{width:50%;text-align:center;vertical-align:top;border:1.5px solid #1e293b;border-radius:8px;padding:12px 14px;height:120px;background:#fff}
.sbox b{font-size:13px;color:#0f172a}
.stamp-space{margin-top:42px;color:#94a3b8;font-size:11px;border-top:1px dashed #cbd5e1;padding-top:6px}
.footer{margin-top:18px;padding-top:8px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;font-size:10px;color:#94a3b8}
@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}"""


def _fmt(val: float | int) -> str:
    parts = f"{abs(float(val)):.2f}".split(".")
    int_p = ""
    s = parts[0]
    while len(s) > 3:
        int_p = "." + s[-3:] + int_p
        s = s[:-3]
    int_p = s + int_p
    return f"{'-' if val < 0 else ''}{int_p},{parts[1]}"


def render(code: str, params: dict) -> tuple[str, str]:
    """Génère le document HTML officiel du reçu de versement de lot."""
    vid = int(params.get("vid") or 0)
    lot_id = int(params.get("lot_id") or 0)
    lang = str(params.get("lang") or "ar").lower().strip()
    is_fr = lang == "fr"

    with connect(code) as c:
        if vid:
            v_row = c.execute('SELECT * FROM VersClients WHERE "IDvers" = ?', (vid,)).fetchone()
            if not v_row:
                raise HTTPException(404, "Versement introuvable")
            v = dict(v_row)
            lot_id = v["IDclient"]
        else:
            # Dernier versement du lot
            v_row = c.execute('SELECT * FROM VersClients WHERE "IDclient" = ? ORDER BY "DateVer" DESC, "IDvers" DESC LIMIT 1', (lot_id,)).fetchone()
            if not v_row:
                raise HTTPException(404, "Aucun versement enregistré pour ce lot")
            v = dict(v_row)
            vid = v["IDvers"]

        lot_row = c.execute('SELECT * FROM Lots WHERE "ID" = ?', (lot_id,)).fetchone()
        if not lot_row:
            raise HTTPException(404, "Lot introuvable")
        lot = dict(lot_row)

        study_row = c.execute('SELECT * FROM Lotissement WHERE "ID" = ?', (lot.get("Idetude"),)).fetchone()
        st = dict(study_row) if study_row else {}

    soc = dossiers.societe(code)
    soc_rs = escape(str(soc.get("rs") or f"Entreprise {code}"))
    soc_fj = escape(str(soc.get("fj") or ""))
    soc_nif = escape(str(soc.get("NIF") or "—"))
    soc_rc = escape(str(soc.get("RC") or ""))
    soc_adr = escape(str(soc.get("adresse") or ""))
    soc_tel = escape(str(soc.get("telephone") or ""))

    mt_vers = float(v.get("Mtvers") or 0.0)
    prix_lot = float(lot.get("PcessionLot") or 0.0)
    total_verse = float(lot.get("TVersemU") or 0.0)
    reste_du = float(lot.get("ResteU") or 0.0)
    date_v = dates.to_display(v.get("DateVer")) or ""

    ar_words = honoraires.nombre_en_lettres_ar(mt_vers).replace("فقط", "").replace("لا غير", "").strip()
    fr_words = honoraires.nombre_en_lettres_fr(mt_vers)

    sub_parts = []
    if soc_fj: sub_parts.append(soc_fj)
    if soc_nif and soc_nif != "—": sub_parts.append(f"NIF : <b>{soc_nif}</b>")
    if soc_rc: sub_parts.append(f"RC : <b>{soc_rc}</b>")
    if soc_tel: sub_parts.append(f"Tél : <b>{soc_tel}</b>")
    sub_line = " · ".join(sub_parts)

    mode_raw = str(v.get("ModeVers") or "")
    # Mode de paiement bilingue
    if is_fr:
        mode_label = mode_raw if mode_raw else "Espèces"
    else:
        mode_label = mode_raw if mode_raw else "نقداً"

    # Libellés selon la langue
    if is_fr:
        dir_attr = 'dir="ltr"'
        lang_attr = 'lang="fr"'
        title = f"Reçu de Versement N° {v.get('NumVer', vid)} - Lot N° {lot.get('Nlot')}"
        recu_h1 = "REÇU DE VERSEMENT"
        recu_sub = "LOTISSEMENT & AMÉNAGEMENT FONCIER"
        lbl_num = "Reçu N° :"
        lbl_date = "Date :"
        lbl_mode = "Mode de versement :"
        acq_card_h4 = "Données de l'Acquéreur"
        acq_name_lbl = "Nom et Prénom :"
        lot_card_h4 = "Désignation de la Parcelle (Lot)"
        lot_lotis_lbl = "Lotissement :"
        lot_num_lbl = "Lot N° :"
        lot_sup_lbl = "Superficie :"
        lot_facades = f"({lot.get('Nfacade')} façade{'s' if (lot.get('Nfacade') or 0) > 1 else ''})" if lot.get('Nfacade') else ""
        badge_mt = "MONTANT VERSÉ ENCAISSÉ"
        tafqeet_main = f"{fr_words} Dinars Algériens"
        tafqeet_alt = f"{ar_words} دينار جزائري"
        lbl_cur = "DA"
        lbl_prix_tot = "Prix Total du Lot"
        lbl_ce_vers = "Ce Versement"
        lbl_cumul = "Total Versé"
        lbl_reste = "Reste à Payer"
        sign_acq_t = "Signature de l'Acquéreur"
        sign_acq_sub = "Lu et approuvé"
        sign_admin_t = "Cachet & Signature de l'Administration"
        sign_admin_sub = "Pour la gérance"
        doc_ref = f"Doc Ref: LOT-{lot.get('Idetude')}-{lot.get('Nlot')}-V{v.get('NumVer', vid)}"
    else:
        dir_attr = 'dir="rtl"'
        lang_attr = 'lang="ar"'
        title = f"وصل استلام دفعة رقم {v.get('NumVer', vid)} - القطعة رقم {lot.get('Nlot')}"
        recu_h1 = "وصل استلام دفعة مالية"
        recu_sub = "REÇU DE VERSEMENT — LOTISSEMENT"
        lbl_num = "وصل رقم:"
        lbl_date = "التاريخ:"
        lbl_mode = "طريقة الدفع:"
        acq_card_h4 = "بيانات المشتري (Acquéreur)"
        acq_name_lbl = "الاسم واللقب:"
        lot_card_h4 = "تعيين القطعة الأرضية (Lot)"
        lot_lotis_lbl = "رقم التجزئة:"
        lot_num_lbl = "القطعة رقم:"
        lot_sup_lbl = "المساحة:"
        lot_facades = f"({lot.get('Nfacade')} واجهة)" if lot.get('Nfacade') else ""
        badge_mt = "المبلغ المسدد المقبوض"
        tafqeet_main = f"{ar_words} دينار جزائري"
        tafqeet_alt = f"{fr_words} Dinars Algériens"
        lbl_cur = "دج"
        lbl_prix_tot = "سعر القطعة الإجمالي"
        lbl_ce_vers = "هذه الدفعة"
        lbl_cumul = "مجموع المدفوعات"
        lbl_reste = "المتبقي للدفع"
        sign_acq_t = "توقيع المشتري / المعني"
        sign_acq_sub = "Signature de l’acquéreur"
        sign_admin_t = "ختم وتوقيع إدارة التجزئة / الصندوق"
        sign_admin_sub = "Cachet & Signature habilitée"
        doc_ref = f"Doc Ref: LOT-{lot.get('Idetude')}-{lot.get('Nlot')}-V{v.get('NumVer', vid)}"

    passport_info = passport.generate_doc_passport(
        dossier=code,
        doc_type="recu_lot",
        doc_id=vid,
        ref_num=str(v.get('NumVer') or vid),
        montant=mt_vers,
        client=str(lot.get('Acquereur') or ''),
        date_doc=date_v,
    )
    passport_stamp_html = passport.render_passport_stamp_html(passport_info, is_ar=not is_fr, width_px=300)

    html = f"""<!DOCTYPE html>
<html {dir_attr} {lang_attr}>
<head>
<meta charset="utf-8">
<title>{escape(title)}</title>
<style>
{_font_face()}
{CSS_BASE}
</style>
</head>
<body>
<div class="doc">
  <header class="soc-header">
    <div class="soc-name">{soc_rs}</div>
    <div class="soc-sub">{sub_line}</div>
    {f'<div class="soc-sub" style="margin-top:2px">{soc_adr}</div>' if soc_adr else ''}
  </header>

  <div class="recu-title-box">
    <h1 class="recu-title">{recu_h1}</h1>
    <div class="recu-title-sub">{recu_sub}</div>
    <div class="recu-meta">
      <span>{lbl_num} <b>{v.get('NumVer', vid)}</b></span>
      <span>·</span>
      <span>{lbl_date} <b>{date_v}</b></span>
      <span>·</span>
      <span>{lbl_mode} <b>{escape(mode_label)}</b></span>
    </div>
  </div>

  <div class="info-grid">
    <div class="info-card">
      <h4>{acq_card_h4}</h4>
      <div><span class="cl-lbl">{acq_name_lbl}</span> <b>{escape(str(lot.get('Acquereur') or '—'))}</b></div>
    </div>
    <div class="info-card">
      <h4>{lot_card_h4}</h4>
      <div><span class="cl-lbl">{lot_lotis_lbl}</span> <b>{escape(str(st.get('Adresse') or 'Lotissement'))}</b></div>
      <div><span class="cl-lbl">{lot_num_lbl}</span> <b>{lot.get('Nlot')}</b> {lot_facades}</div>
      <div><span class="cl-lbl">{lot_sup_lbl}</span> <b>{_fmt(lot.get('SupLot', 0))} m²</b></div>
    </div>
  </div>

  <div class="montant-box">
    <div class="tafqeet-col">
      <span class="tafqeet-badge">{badge_mt}</span>
      <div class="tafqeet-main">{tafqeet_main}</div>
      <div class="tafqeet-alt" style="direction:ltr;text-align:{'left' if is_fr else 'right'}">{tafqeet_alt}</div>
    </div>
    <div class="montant-digits">
      <span class="m-val">{_fmt(mt_vers)}</span>
      <span class="m-cur">{lbl_cur}</span>
    </div>
  </div>

  <div class="solde-box">
    <div class="solde-item"><span>{lbl_prix_tot}</span><b>{_fmt(prix_lot)} {lbl_cur}</b></div>
    <div class="solde-item"><span>{lbl_ce_vers}</span><b style="color:#047857">{_fmt(mt_vers)} {lbl_cur}</b></div>
    <div class="solde-item"><span>{lbl_cumul}</span><b>{_fmt(total_verse)} {lbl_cur}</b></div>
    <div class="solde-item"><span>{lbl_reste}</span><b style="color:{'#b91c1c' if reste_du > 0 else '#047857'}">{_fmt(reste_du)} {lbl_cur}</b></div>
  </div>

  <table class="signs">
    <tr>
      <td class="sbox">
        <b>{sign_acq_t}</b><br>
        <small>{sign_acq_sub}</small>
        <div class="stamp-space">{"Nom & Qualité" if is_fr else "الاسم والصفة"}</div>
      </td>
      <td class="sbox">
        <b>{sign_admin_t}</b><br>
        <small>{sign_admin_sub}</small>
        <div class="stamp-space">{soc_rs}</div>
      </td>
    </tr>
  </table>

  <div style="display:flex;justify-content:space-between;align-items:center;margin-top:20px;border-top:1.5px dashed #cbd5e1;padding-top:12px;flex-wrap:wrap;gap:12px;">
    {passport_stamp_html}
    <div style="text-align:{'right' if is_fr else 'left'};font-size:10.5px;color:#64748b;line-height:1.6;">
      <div><b>Réf :</b> <span dir="ltr">{doc_ref}</span></div>
      <div><b>Empreinte SHA-256 :</b> <span dir="ltr" style="font-family:monospace;font-weight:700;color:#0f172a;">{passport_info['short_hash']}</span></div>
      <div style="color:#047857;font-weight:800;font-size:11px;">{"✓ وثيقة مالية رقمية أصيلة وغير قابلة للتزوير" if not is_fr else "✓ Document fiscal scellé & vérifiable par QR"}</div>
    </div>
  </div>

  <footer class="footer" style="margin-top:10px;">
    <span>Dec2026 Système de Gestion Fiscale & Promotion Foncière</span>
    <span dir="ltr">{doc_ref}</span>
  </footer>
</div>
</body>
</html>"""
    return html, title

