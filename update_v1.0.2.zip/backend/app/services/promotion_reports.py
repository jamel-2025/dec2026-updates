"""Promotion Immobilière Reports & Situations — Mises en page HTML haute fidélité (A4 portrait & paysage)
et exports Excel/PDF conformes pour la promotion immobilière (Loi 11-04) :
  - promotion_plan : المخطط الهيكلي ومسح العمارات (2D Élévation) مع شبكة الشقق والألوان والمفتاح الإحصائي
  - promotion_unites : قائمة الوحدات السكنية والتجارية والمرائب والتفاصيل التعاقدية
  - promotion_facturation : كشف رقم الأعمال المفوتر والمبيعات الموثقة (عقود البيع على التصاميم الرسمية)
  - promotion_versements : كشف المقبوضات الشهرية والسنوية والتسبيقات وطرق الدفع
  - promotion_creances : كشف ديون ومستحقات الزبائن غير المسددة
  - promotion_tcr : الوضعية السنوية والجبائية لحساب النتيجة (TCR / IBS)
"""
from __future__ import annotations

import base64
from datetime import datetime
from html import escape
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..core import config
from ..core.db import connect
from . import dates, dossiers, honoraires, promotion
from .g50 import G50Error, _num

FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def _font_face() -> str:
    faces = []
    for f, rng in (
        ("cairo-arabic-wght-normal.woff2", "U+0600-06FF,U+0750-077F,U+0870-08FF,U+FB50-FDFF,U+FE70-FEFF"),
        ("cairo-latin-wght-normal.woff2", "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+2000-206F,U+20AC"),
    ):
        p = FONTS / f
        if p.is_file():
            b64 = base64.b64encode(p.read_bytes()).decode()
            faces.append(
                f"@font-face{{font-family:'Cairo';font-weight:200 1000;src:url(data:font/woff2;base64,{b64}) format('woff2');unicode-range:{rng};}}"
            )
    return "".join(faces)


def money(v: float | int | None) -> str:
    val = round(float(v or 0), 2)
    return f"{val:,.2f}".replace(",", " ").replace(".", ",")


def money_int(v: float | int | None) -> str:
    val = round(float(v or 0))
    return f"{val:,}".replace(",", " ")


CSS_BASE = """
* { box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
body { margin: 0; font-family: 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif; color: #0f172a; font-size: 11px; line-height: 1.4; background: #fff; }
.doc { width: 100%; max-width: 1120px; margin: 0 auto; padding: 4px; }
.top-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f766e; padding-bottom: 8px; margin-bottom: 12px; gap: 12px; }
.header-company { flex: 1; }
.header-company h2 { margin: 0 0 4px; font-size: 16px; font-weight: 900; color: #0f766e; }
.header-company p { margin: 1px 0; font-size: 10.5px; color: #475569; }
.header-company b { color: #0f172a; }
.header-title-box { text-align: center; background: #f8fafc; border: 1.5px solid #cbd5e1; border-radius: 6px; padding: 8px 16px; min-width: 320px; }
.header-title-box h1 { margin: 0 0 3px; font-size: 15px; font-weight: 900; color: #0f172a; letter-spacing: -0.01em; }
.header-title-box p { margin: 0; font-size: 10.5px; font-weight: 700; color: #0f766e; }
.header-meta { text-align: end; font-size: 10px; color: #64748b; line-height: 1.5; min-width: 140px; }
.kpis-banner { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 12px; }
.kpi-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 10px; text-align: center; }
.kpi-card span { display: block; font-size: 10px; color: #64748b; margin-bottom: 2px; }
.kpi-card b { font-size: 13px; font-weight: 800; color: #0f172a; font-family: 'Cairo', monospace; }
.report-table { width: 100%; border-collapse: collapse; margin-top: 6px; font-size: 10.5px; }
.report-table th { background: #0f766e; color: #fff; font-weight: 700; padding: 6px 6px; border: 1px solid #0f766e; text-align: center; }
.report-table td { padding: 5px 6px; border: 1px solid #cbd5e1; vertical-align: middle; }
.report-table tr:nth-child(even) td { background: #f8fafc; }
.report-table tr.total-row td { background: #e2e8f0; font-weight: 800; border-top: 2px solid #0f172a; }
.num { font-family: 'Cairo', 'Consolas', monospace; text-align: right; white-space: nowrap; }
.center { text-align: center; }
.pill { display: inline-block; padding: 1px 6px; border-radius: 4px; font-size: 9.5px; font-weight: 800; color: #fff; }
.footer { margin-top: 14px; padding-top: 6px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 9.5px; color: #94a3b8; }
"""


def _doc_head(title: str, orientation: str = "portrait", is_ar: bool = True) -> str:
    page_css = f"@page {{ size: A4 {orientation}; margin: 8mm 10mm; }}"
    dir_attr = 'dir="rtl"' if is_ar else 'dir="ltr"'
    lang_attr = 'lang="ar"' if is_ar else 'lang="fr"'
    return f"""<!DOCTYPE html>
<html {dir_attr} {lang_attr}>
<head>
<meta charset="utf-8">
<title>{escape(title)}</title>
<style>
{_font_face()}
{page_css}
{CSS_BASE}
</style>
</head>
<body>
<div class="doc">
"""


def _doc_header(code: str, title: str, sub: str, is_ar: bool = True) -> str:
    soc = dossiers.societe(code)
    try:
        bld = honoraires.get_cabinet_profile()
        cab_name = bld.get("nom_cabinet") or "Cabinet d'Expertise Comptable"
    except Exception:
        cab_name = "Cabinet d'Expertise Comptable"
    rs = soc.get("rs") or soc.get("RS") or f"Société {code}"
    nif = soc.get("NIF") or "—"
    act = soc.get("activité") or "Promotion Immobilière"
    now_str = datetime.now().strftime("%d/%m/%Y %H:%M")

    align_start = "right" if is_ar else "left"
    align_end = "left" if is_ar else "right"

    return f"""
    <div class="top-header">
      <div class="header-company" style="text-align: {align_start};">
        <h2>{escape(rs)}</h2>
        <p><b>{'النشاط' if is_ar else 'Activité'}:</b> {escape(act)}</p>
        <p><b>NIF:</b> <span class="num">{escape(nif)}</span> · <b>{'الملف' if is_ar else 'Dossier'}:</b> {escape(code)}</p>
      </div>
      <div class="header-title-box">
        <h1>{escape(title)}</h1>
        <p>{escape(sub)}</p>
      </div>
      <div class="header-meta" style="text-align: {align_end};">
        <div><b>{escape(cab_name)}</b></div>
        <div>{'تاريخ الطباعة' if is_ar else 'Date d’édition'}: {now_str}</div>
        <div>{'الجمهورية الجزائرية الديمقراطية الشعبية' if is_ar else 'RÉPUBLIQUE ALGÉRIENNE'}</div>
      </div>
    </div>
    """


def _doc_footer(is_ar: bool = True) -> str:
    return f"""
    <div class="footer">
      <div>{'وثيقة محاسبية وجبائية مطابقة للقانون 11-04 المنظم للترقية العقارية والبيع على التصاميم VEFA' if is_ar else 'Document fiscal & comptable conforme à la loi 11-04 sur la promotion immobilière (VEFA)'}</div>
      <div>Dec2026 ERP Fiscal · Page 1/1</div>
    </div>
    </div>
    </body>
    </html>
    """


# ------------------------------------------------------------------ 1. المخطط الهيكلي ومسح العمارات (2D Plan)
def render_plan_html(code: str, params: dict) -> tuple[str, str]:
    pid = int(params.get("id") or 1)
    is_ar = params.get("lang") == "ar"

    with connect(code) as c:
        proj_row = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        proj_nom = proj_row[0] if proj_row else "Projet Immobilier"

    data = promotion.unites(code, pid)
    totals = data["totals"]
    elevation = data["elevation"]

    title = "المخطط الهيكلي ومسح الترقية العقارية (2D)" if is_ar else "Plan d'Élévation 2D de Promotion Immobilière"
    sub = f"{proj_nom} · مسح العمارات والشقق والوحدات" if is_ar else f"{proj_nom} · Élévation des Bâtiments & Lots"

    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    # KPIs Banner
    h.append(f"""
    <div class="kpis-banner">
      <div class="kpi-card">
        <span>{("إجمالي الوحدات" if is_ar else "Total Unités")}</span>
        <b>{totals['count_total']}</b>
      </div>
      <div class="kpi-card">
        <span>{("الوحدات الموثقة (عقود)" if is_ar else "Unités Actées")}</span>
        <b style="color: #059669;">{totals['count_vendus']}</b>
      </div>
      <div class="kpi-card">
        <span>{("الوحدات المحجوزة" if is_ar else "Réservées")}</span>
        <b style="color: #2563eb;">{totals['count_reserves']}</b>
      </div>
      <div class="kpi-card">
        <span>{("الوحدات المتاحة" if is_ar else "Disponibles")}</span>
        <b style="color: #64748b;">{totals['count_disponibles']}</b>
      </div>
      <div class="kpi-card">
        <span>{("المقبوضات الفعلية" if is_ar else "Total Encaissé")}</span>
        <b style="color: #047857;">{money(totals['total_versements'])} DA</b>
      </div>
    </div>
    """)

    # Matrice par étage
    h.append('<div style="display: flex; flex-direction: column; gap: 8px; margin-top: 10px;">')
    for fl in elevation:
        fl_label = fl["label_ar"] if is_ar else fl["label"]
        h.append(f"""
        <div style="border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 10px; background: #f8fafc;">
          <div style="font-weight: 800; font-size: 11.5px; color: #0f766e; margin-bottom: 6px; border-bottom: 1px solid #e2e8f0; padding-bottom: 3px;">
            🏢 {fl_label} ({len(fl['unites'])} {'وحدة' if is_ar else 'unités'})
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 6px;">
        """)
        for u in fl["unites"]:
            st = u.get("Statut")
            bg = "#10b981" if st == "vendu_solde" else ("#f59e0b" if st == "vendu_dette" else ("#3b82f6" if st == "reserve" else "#94a3b8"))
            st_text = "مسدد" if st == "vendu_solde" else ("مبيوع/دين" if st == "vendu_dette" else ("محجوز" if st == "reserve" else "متاح"))
            acq = u.get("Acquereur") or ""
            h.append(f"""
            <div style="border: 1.5px solid {bg}; border-radius: 6px; padding: 4px 6px; background: #fff; min-width: 110px; max-width: 140px; font-size: 9.5px;">
              <div style="display: flex; justify-content: space-between; font-weight: 800;">
                <span>{escape(u['Numero'])}</span>
                <span style="color: {bg}; font-size: 8.5px;">{st_text}</span>
              </div>
              <div style="color: #64748b; font-size: 9px;">{escape(u.get('TypeLogement') or u['TypeUnite'])} · {u['Superficie']} m²</div>
              <div style="font-weight: 700; color: #047857;">{money(u['PrixTTC'])}</div>
              {f'<div style="font-size: 8.5px; color: #334155; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">👤 {escape(acq)}</div>' if acq else ''}
            </div>
            """)
        h.append("</div></div>")
    h.append("</div>")

    h.append(_doc_footer(is_ar))
    return "".join(h), title


# ------------------------------------------------------------------ 2. قائمة الوحدات والشقق (Liste des Unités)
def render_unites_html(code: str, params: dict) -> tuple[str, str]:
    pid = int(params.get("id") or 1)
    is_ar = params.get("lang") == "ar"

    with connect(code) as c:
        proj_row = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        proj_nom = proj_row[0] if proj_row else "Projet Immobilier"

    data = promotion.unites(code, pid)
    items = data["items"]
    tot = data["totals"]

    title = "كشف الوحدات العقارية والشقق والمحلات" if is_ar else "Inventaire des Unités & Logements"
    sub = f"{proj_nom} · {tot['count_total']} وحدة عقارية" if is_ar else f"{proj_nom} · {tot['count_total']} unités"

    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th>{("رقم الوحدة" if is_ar else "N° Unité")}</th>
          <th>{("العمارة" if is_ar else "Bloc")}</th>
          <th>{("الطابق" if is_ar else "Étage")}</th>
          <th>{("الصنف" if is_ar else "Type")}</th>
          <th>{("المساحة م²" if is_ar else "Superficie")}</th>
          <th>{("سعر م²" if is_ar else "Prix / m²")}</th>
          <th>{("السعر TTC" if is_ar else "Prix TTC")}</th>
          <th>{("المشتري" if is_ar else "Acquéreur")}</th>
          <th>{("تاريخ العقد" if is_ar else "Date Acte")}</th>
          <th>{("رقم العقد والموثق" if is_ar else "N° Acte / Notaire")}</th>
          <th>{("المدفوعات" if is_ar else "Versements")}</th>
          <th>{("المتبقي" if is_ar else "Reste")}</th>
          <th>{("الحالة" if is_ar else "Statut")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for u in items:
        st = u.get("Statut")
        st_color = "#059669" if st == "vendu_solde" else ("#d97706" if st == "vendu_dette" else ("#2563eb" if st == "reserve" else "#64748b"))
        st_label = "مسدد" if st == "vendu_solde" else ("مبيوع/دين" if st == "vendu_dette" else ("محجوز" if st == "reserve" else "متاح"))
        h.append(f"""
        <tr>
          <td class="center"><b>{escape(u['Numero'])}</b></td>
          <td class="center">{escape(u.get('NomBloc') or '—')}</td>
          <td class="center">{u['Etage']}</td>
          <td class="center">{escape(u.get('TypeLogement') or u['TypeUnite'])}</td>
          <td class="num">{money(u['Superficie'])}</td>
          <td class="num">{money(u['PrixM2'])}</td>
          <td class="num" style="font-weight: 700; color: #047857;">{money(u['PrixTTC'])}</td>
          <td><b>{escape(u.get('Acquereur') or '—')}</b></td>
          <td class="center">{dates.to_display(u.get('DateActe')) or '—'}</td>
          <td>{escape(u.get('NumActe') or '—')} {f"({escape(u.get('Notaire') or '')})" if u.get('Notaire') else ''}</td>
          <td class="num" style="color: #0284c7;">{money(u.get('TVersem'))}</td>
          <td class="num" style="color: #b91c1c; font-weight: 700;">{money(u.get('Reste'))}</td>
          <td class="center"><span style="color: {st_color}; font-weight: 800;">{st_label}</span></td>
        </tr>
        """)

    h.append(f"""
      </tbody>
      <tfoot>
        <tr class="total-row">
          <td colspan="4" class="center">{'المجموع الإجمالي' if is_ar else 'TOTAL GÉNÉRAL'} ({len(items)} {'وحدة' if is_ar else 'unités'})</td>
          <td class="num">{money(tot['superficie_totale'])} m²</td>
          <td></td>
          <td class="num">{money(tot['ca_facture_ttc'])} DA</td>
          <td colspan="3"></td>
          <td class="num" style="color: #0284c7;">{money(tot['total_versements'])} DA</td>
          <td class="num" style="color: #b91c1c;">{money(tot['creances_reelles'])} DA</td>
          <td></td>
        </tr>
      </tfoot>
    </table>
    """)

    h.append(_doc_footer(is_ar))
    return "".join(h), title


# ------------------------------------------------------------------ 3. رقم الأعمال المفوتر (CA Facturé VEFA)
def render_facturation_html(code: str, params: dict) -> tuple[str, str]:
    pid = int(params.get("id") or 1)
    annee = str(params.get("annee") or "")
    mois = str(params.get("mois") or "")
    q = str(params.get("q") or "")
    is_ar = params.get("lang") == "ar"

    with connect(code) as c:
        proj_row = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        proj_nom = proj_row[0] if proj_row else "Projet Immobilier"

    data = promotion.ca_facture(code, pid, annee=annee, mois=mois, q=q)
    unites = data["items"]

    title = "وضعية رقم الأعمال المفوتر والمبيعات الموثقة (عقود البيع الرسمية)" if is_ar else "Chiffre d’Affaires Facturé (Actes Notariés VEFA)"
    sub = f"{proj_nom} · عقود البيع على التصاميم المشهرة" if is_ar else f"{proj_nom} · Actes Notariés Déclarés"

    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append(f"""
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px;">
      <div class="kpi-card">
        <span>{("الوحدات الموثقة" if is_ar else "Unités Actées")}</span>
        <b style="font-size: 16px;">{data['total_unites']}</b>
      </div>
      <div class="kpi-card">
        <span>{("المساحة الإجمالية المباعة" if is_ar else "Superficie Totale")}</span>
        <b style="font-size: 16px;">{money(data['total_sup'])} m²</b>
      </div>
      <div class="kpi-card">
        <span>{("سعر التنازل الإجمالي TTC" if is_ar else "Total Cession TTC")}</span>
        <b style="font-size: 16px; color: #047857;">{money(data['total_ttc'])} DA</b>
      </div>
      <div class="kpi-card">
        <span>{("رقم الأعمال خارج الرسم HT" if is_ar else "Total CA HT")}</span>
        <b style="font-size: 16px; color: #0284c7;">{money(data['total_ht'])} DA</b>
      </div>
    </div>
    """)

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th>{("تاريخ العقد" if is_ar else "Date Acte")}</th>
          <th>{("رقم العقد" if is_ar else "N° Acte")}</th>
          <th>{("الموثق" if is_ar else "Notaire")}</th>
          <th>{("الوحدة" if is_ar else "Unité")}</th>
          <th>{("العمارة" if is_ar else "Bloc")}</th>
          <th>{("الصنف" if is_ar else "Type")}</th>
          <th>{("المشتري" if is_ar else "Acquéreur")}</th>
          <th>{("المساحة" if is_ar else "Superficie")}</th>
          <th>{("المبلغ HT" if is_ar else "Montant HT")}</th>
          <th>{("حقوق TVA" if is_ar else "Droits TVA")}</th>
          <th>{("المبلغ TTC" if is_ar else "Montant TTC")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for u in unites:
        h.append(f"""
        <tr>
          <td class="center"><b>{u['date_display']}</b></td>
          <td class="center"><b>{escape(u.get('NumActe') or '—')}</b></td>
          <td>{escape(u.get('Notaire') or '—')}</td>
          <td class="center"><b>{escape(u['Numero'])}</b></td>
          <td class="center">{escape(u.get('NomBloc') or '—')}</td>
          <td class="center">{escape(u.get('TypeLogement') or u['TypeUnite'])}</td>
          <td><b>{escape(u.get('Acquereur') or '—')}</b></td>
          <td class="num">{money(u['Superficie'])} m²</td>
          <td class="num" style="color: #0284c7;">{money(u['PrixHT'])}</td>
          <td class="num" style="color: #047857;">{money(u['DroitsTVA'])}</td>
          <td class="num" style="font-weight: 700; color: #047857;">{money(u['PrixTTC'])}</td>
        </tr>
        """)

    h.append(f"""
      </tbody>
      <tfoot>
        <tr class="total-row">
          <td colspan="7" class="center">{'المجموع الإجمالي' if is_ar else 'TOTAL GÉNÉRAL'} ({len(unites)} {'وحدة' if is_ar else 'unités'})</td>
          <td class="num">{money(data['total_sup'])} m²</td>
          <td class="num" style="color: #0284c7;">{money(data['total_ht'])} DA</td>
          <td class="num" style="color: #047857;">{money(data['total_tva'])} DA</td>
          <td class="num" style="color: #047857;">{money(data['total_ttc'])} DA</td>
        </tr>
      </tfoot>
    </table>
    """)

    h.append(_doc_footer(is_ar))
    return "".join(h), title


# ------------------------------------------------------------------ 4. كشف المقبوضات والدفعات (CA Encaissé)
def render_versements_html(code: str, params: dict) -> tuple[str, str]:
    pid = int(params.get("id") or 1)
    annee = str(params.get("annee") or "")
    mois = str(params.get("mois") or "")
    mode = str(params.get("mode") or "")
    q = str(params.get("q") or "")
    is_ar = params.get("lang") == "ar"

    with connect(code) as c:
        proj_row = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        proj_nom = proj_row[0] if proj_row else "Projet Immobilier"

    data = promotion.encaissements_projet(code, pid, annee=annee, mois=mois, mode=mode, q=q)
    items = data["items"]

    title = "كشف المقبوضات والدفعات المستلمة (الخزينة)" if is_ar else "État des Encaissements & Règlements Reçus"
    sub = f"{proj_nom} · مجموع المقبوضات والتسبيقات النقدية" if is_ar else f"{proj_nom} · Trésorerie & Acomptes"

    h = [_doc_head(title, "portrait", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append(f"""
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;">
      <div class="kpi-card">
        <span>{("عدد الدفعات" if is_ar else "Nombre de Versements")}</span>
        <b style="font-size: 16px;">{data['count']}</b>
      </div>
      <div class="kpi-card">
        <span>{("المبلغ خارج الرسم HT" if is_ar else "Total HT")}</span>
        <b style="font-size: 16px; color: #0284c7;">{money(data['grand_total_ht'])} DA</b>
      </div>
      <div class="kpi-card">
        <span>{("المجموع المقبوض TTC" if is_ar else "Total Encaissé TTC")}</span>
        <b style="font-size: 16px; color: #047857;">{money(data['grand_total_ttc'])} DA</b>
      </div>
    </div>
    """)

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th>{("التاريخ" if is_ar else "Date")}</th>
          <th>{("الزبون / المشتري" if is_ar else "Client")}</th>
          <th>{("الوحدة" if is_ar else "Unité")}</th>
          <th>{("طريقة الدفع" if is_ar else "Mode")}</th>
          <th>{("ملاحظات / مرجع" if is_ar else "Observations")}</th>
          <th>{("المبلغ TTC" if is_ar else "Montant TTC")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for r in items:
        h.append(f"""
        <tr>
          <td class="center"><b>{r['date_display']}</b></td>
          <td><b>{escape(r.get('Client') or '—')}</b></td>
          <td class="center">{escape(r.get('UniteNumero') or '—')}</td>
          <td class="center">{escape(r.get('ModeReg') or '—')}</td>
          <td>{escape(r.get('obs') or '')}</td>
          <td class="num" style="font-weight: 700; color: #047857;">{money(r.get('MontantTTC'))}</td>
        </tr>
        """)

    h.append(f"""
      </tbody>
      <tfoot>
        <tr class="total-row">
          <td colspan="5" class="center">{'المجموع الإجمالي للمقبوضات' if is_ar else 'TOTAL ENCAISSÉ'}</td>
          <td class="num" style="color: #047857;">{money(data['grand_total_ttc'])} DA</td>
        </tr>
      </tfoot>
    </table>
    """)

    h.append(_doc_footer(is_ar))
    return "".join(h), title


# ------------------------------------------------------------------ 5. كشف الديون والمستحقات (Créances)
def render_creances_html(code: str, params: dict) -> tuple[str, str]:
    pid = int(params.get("id") or 1)
    q = str(params.get("q") or "")
    is_ar = params.get("lang") == "ar"

    with connect(code) as c:
        proj_row = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        proj_nom = proj_row[0] if proj_row else "Projet Immobilier"

    cre = promotion.creances_projet(code, pid, q=q)
    tot_reste = sum(_num(x["Reste"]) for x in cre)
    tot_prix = sum(_num(x["PrixTTC"]) for x in cre)
    tot_vers = sum(_num(x["TVersem"]) for x in cre)

    title = "كشف ديون ومستحقات الزبائن قيد التحصيل" if is_ar else "État des Créances Clients & Restes à Recouvrer"
    sub = f"{proj_nom} · متابعة الأقساط المتبقية" if is_ar else f"{proj_nom} · Suivi des Créances"

    h = [_doc_head(title, "portrait", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append(f"""
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;">
      <div class="kpi-card">
        <span>{("سعر البيع الإجمالي TTC" if is_ar else "Valeur Totale TTC")}</span>
        <b style="font-size: 15px;">{money(tot_prix)} DA</b>
      </div>
      <div class="kpi-card">
        <span>{("المقبوضات المسددة" if is_ar else "Versements Perçus")}</span>
        <b style="font-size: 15px; color: #0284c7;">{money(tot_vers)} DA</b>
      </div>
      <div class="kpi-card">
        <span>{("إجمالي الديون المتبقية" if is_ar else "Total Créances Restantes")}</span>
        <b style="font-size: 15px; color: #b91c1c;">{money(tot_reste)} DA</b>
      </div>
    </div>
    """)

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th>{("الوحدة" if is_ar else "Unité")}</th>
          <th>{("العمارة" if is_ar else "Bloc")}</th>
          <th>{("المشتري المدين" if is_ar else "Client / Débiteur")}</th>
          <th>{("الهاتف" if is_ar else "Téléphone")}</th>
          <th>{("سعر الشقة TTC" if is_ar else "Prix TTC")}</th>
          <th>{("المدفوعات" if is_ar else "Versé")}</th>
          <th>{("المتبقي في الذمة" if is_ar else "Reste à Régler")}</th>
          <th>{("نسبة التحصيل" if is_ar else "% Recouv.")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for r in cre:
        h.append(f"""
        <tr>
          <td class="center"><b>{escape(r['Numero'])}</b></td>
          <td class="center">{escape(r.get('NomBloc') or '—')}</td>
          <td><b>{escape(r.get('Acquereur') or '—')}</b></td>
          <td class="center">{escape(r.get('Telephone') or '—')}</td>
          <td class="num">{money(r['PrixTTC'])}</td>
          <td class="num" style="color: #0284c7;">{money(r['TVersem'])}</td>
          <td class="num" style="color: #b91c1c; font-weight: 800;">{money(r['Reste'])}</td>
          <td class="center"><b>{r.get('taux_recouvrement', 0)} %</b></td>
        </tr>
        """)

    h.append(f"""
      </tbody>
      <tfoot>
        <tr class="total-row">
          <td colspan="4" class="center">{'المجموع الإجمالي للديون' if is_ar else 'TOTAL CRÉANCES'} ({len(cre)} {'وحدة' if is_ar else 'unités'})</td>
          <td class="num">{money(tot_prix)} DA</td>
          <td class="num" style="color: #0284c7;">{money(tot_vers)} DA</td>
          <td class="num" style="color: #b91c1c;">{money(tot_reste)} DA</td>
          <td></td>
        </tr>
      </tfoot>
    </table>
    """)

    h.append(_doc_footer(is_ar))
    return "".join(h), title


# ------------------------------------------------------------------ 6. الوضعية السنوية والجبائية TCR
def render_tcr_html(code: str, params: dict) -> tuple[str, str]:
    pid = int(params.get("id") or 1)
    is_ar = params.get("lang") == "ar"

    with connect(code) as c:
        proj_row = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        proj_nom = proj_row[0] if proj_row else "Projet Immobilier"

    tcr_rows = promotion.tcr_projet(code, pid)

    title = "الوضعية السنوية الجبائية وحساب النتيجة (TCR)" if is_ar else "Compte de Résultat Annuel Fiscal (TCR)"
    sub = f"{proj_nom} · الضريبة على أرباح الشركات IBS ورسم TVA" if is_ar else f"{proj_nom} · Fiscalité IBS & TVA"

    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th>{("السنة" if is_ar else "Exercice")}</th>
          <th>{("عدد الوحدات" if is_ar else "Unités")}</th>
          <th>{("المساحة المباعة" if is_ar else "Superficie")}</th>
          <th>{("المبيعات TTC" if is_ar else "Cession TTC")}</th>
          <th>{("رقم الأعمال HT" if is_ar else "CA HT")}</th>
          <th>{("حقوق TVA" if is_ar else "Droits TVA")}</th>
          <th>{("التكاليف والأعباء" if is_ar else "Charges / Coût")}</th>
          <th>{("النتيجة الصافية" if is_ar else "Résultat")}</th>
          <th>{("الضريبة IBS (26%)" if is_ar else "IBS (26%)")}</th>
          <th>{("مجموع الحقوق" if is_ar else "Total Droits")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    tot_sup = tot_ttc = tot_ht = tot_tva = tot_chg = tot_res = tot_ibs = tot_droits = 0.0

    for r in tcr_rows:
        tot_sup += _num(r.get("Tsuperficie"))
        tot_ttc += _num(r.get("PCessionTTC"))
        tot_ht += _num(r.get("CA"))
        tot_tva += _num(r.get("TDroitsTVA"))
        tot_chg += _num(r.get("Tcharges"))
        tot_res += _num(r.get("resultat"))
        tot_ibs += _num(r.get("Dirg"))
        tot_droits += _num(r.get("Tdroits"))

        h.append(f"""
        <tr>
          <td class="center"><b>{r['Annee']}</b></td>
          <td class="center">{r['NbreUnites']}</td>
          <td class="num">{money(r['Tsuperficie'])} m²</td>
          <td class="num" style="color: #047857; font-weight: 700;">{money(r['PCessionTTC'])}</td>
          <td class="num" style="color: #0284c7;">{money(r['CA'])}</td>
          <td class="num">{money(r['TDroitsTVA'])}</td>
          <td class="num" style="color: #d97706;">{money(r['Tcharges'])}</td>
          <td class="num" style="color: #047857; font-weight: 800;">{money(r['resultat'])}</td>
          <td class="num" style="color: #b91c1c;">{money(r['Dirg'])}</td>
          <td class="num" style="font-weight: 900; color: #047857;">{money(r['Tdroits'])}</td>
        </tr>
        """)

    h.append(f"""
      </tbody>
      <tfoot>
        <tr class="total-row">
          <td class="center" colspan="2">{'المجموع الإجمالي' if is_ar else 'TOTAL'}</td>
          <td class="num">{money(tot_sup)} m²</td>
          <td class="num">{money(tot_ttc)} DA</td>
          <td class="num">{money(tot_ht)} DA</td>
          <td class="num">{money(tot_tva)} DA</td>
          <td class="num">{money(tot_chg)} DA</td>
          <td class="num">{money(tot_res)} DA</td>
          <td class="num">{money(tot_ibs)} DA</td>
          <td class="num">{money(tot_droits)} DA</td>
        </tr>
      </tfoot>
    </table>
    """)

    h.append(_doc_footer(is_ar))
    return "".join(h), title


# ------------------------------------------------------------------ Unified Dispatcher & Excel Export
def render_report_html(key: str, code: str, params: dict) -> tuple[str, str]:
    if key == "promotion_plan":
        return render_plan_html(code, params)
    elif key == "promotion_unites":
        return render_unites_html(code, params)
    elif key == "promotion_facturation":
        return render_facturation_html(code, params)
    elif key == "promotion_versements":
        return render_versements_html(code, params)
    elif key == "promotion_creances":
        return render_creances_html(code, params)
    elif key == "promotion_tcr":
        return render_tcr_html(code, params)
    else:
        return render_plan_html(code, params)


def export_promotion_excel(key: str, code: str, params: dict, out_path: Path | str) -> None:
    out_path = Path(out_path)
    pid = int(params.get("id") or 1)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Promotion"

    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid")
    border = Border(
        left=Side(style="thin", color="D1D5DB"),
        right=Side(style="thin", color="D1D5DB"),
        top=Side(style="thin", color="D1D5DB"),
        bottom=Side(style="thin", color="D1D5DB")
    )

    if key == "promotion_facturation":
        ws.title = "CA Facturé"
        data = promotion.ca_facture(code, pid, annee=str(params.get("annee") or ""), mois=str(params.get("mois") or ""), q=str(params.get("q") or ""))
        headers = ["Date Acte", "N° Acte", "Notaire", "Unité", "Bloc", "Type", "Acquéreur", "Superficie", "Montant HT", "Droits TVA", "Montant TTC"]
        ws.append(headers)
        for c_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=1, column=c_idx)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for u in data["items"]:
            ws.append([
                u.get("date_display"), u.get("NumActe"), u.get("Notaire"), u.get("Numero"),
                u.get("NomBloc"), u.get("TypeLogement") or u.get("TypeUnite"), u.get("Acquereur"),
                u.get("Superficie"), u.get("PrixHT"), u.get("DroitsTVA"), u.get("PrixTTC")
            ])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci in (8, 9, 10, 11):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                else:
                    cell.alignment = Alignment(horizontal="center")

    elif key == "promotion_versements":
        ws.title = "Encaissements"
        data = promotion.encaissements_projet(code, pid, annee=str(params.get("annee") or ""), mois=str(params.get("mois") or ""), mode=str(params.get("mode") or ""), q=str(params.get("q") or ""))
        headers = ["Date", "Client", "Unité", "Mode", "Observations", "Montant HT", "TVA", "Montant TTC"]
        ws.append(headers)
        for c_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=1, column=c_idx)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for r in data["items"]:
            ws.append([
                r.get("date_display"), r.get("Client"), r.get("UniteNumero"), r.get("ModeReg"),
                r.get("obs"), r.get("HT"), r.get("TVA"), r.get("MontantTTC")
            ])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci in (6, 7, 8):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                else:
                    cell.alignment = Alignment(horizontal="center")

    elif key == "promotion_creances":
        ws.title = "Créances"
        cre = promotion.creances_projet(code, pid, q=str(params.get("q") or ""))
        headers = ["Unité", "Bloc", "Acquéreur", "Téléphone", "Prix TTC", "Versements", "Reste à Recouvrer", "% Recouvrement"]
        ws.append(headers)
        for c_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=1, column=c_idx)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for r in cre:
            ws.append([
                r.get("Numero"), r.get("NomBloc"), r.get("Acquereur"), r.get("Telephone"),
                r.get("PrixTTC"), r.get("TVersem"), r.get("Reste"), r.get("taux_recouvrement")
            ])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci in (5, 6, 7):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                elif ci == 8:
                    cell.number_format = '0.0"%"'
                    cell.alignment = Alignment(horizontal="center")
                else:
                    cell.alignment = Alignment(horizontal="center")

    else:
        # Default: TCR / Unites
        ws.title = "TCR Promotion"
        tcr_rows = promotion.tcr_projet(code, pid)
        headers = ["Exercice", "Unités", "Superficie", "Cession TTC", "CA HT", "Droits TVA", "Charges", "Résultat", "IBS (26%)", "Total Droits"]
        ws.append(headers)
        for c_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=1, column=c_idx)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")

        for r in tcr_rows:
            ws.append([
                r.get("Annee"), r.get("NbreUnites"), r.get("Tsuperficie"), r.get("PCessionTTC"),
                r.get("CA"), r.get("TDroitsTVA"), r.get("Tcharges"), r.get("resultat"),
                r.get("Dirg"), r.get("Tdroits")
            ])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci in (3, 4, 5, 6, 7, 8, 9, 10):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                else:
                    cell.alignment = Alignment(horizontal="center")

    for col in ws.columns:
        longest = max(len(str(cell.value or "")) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max(11, min(42, longest + 3))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(out_path))
