"""Passeport Financier Numérique & Sceau Cryptographique Anti-Fraude.
Garantit l'authenticité, la non-falsification et la traçabilité des reçus de versement,
contrats de vente sur plans et situations financières du cabinet comptable / promoteur.
Algorithme : HMAC-SHA256 avec empreinte d'intégrité numérique et QR Code haute résolution (Segno).
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import urllib.parse
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import segno

from ..core.db import connect
from . import dates, dossiers, honoraires

# Clé secrète d'intégrité pour le hachage cryptographique
HMAC_SECRET = b"DEC2026_FISCAL_PASSPORT_SECURE_KEY_ALGERIE_DGI_2026_PROMOTION"


def calculate_doc_hash(
    dossier: str,
    doc_type: str,
    doc_id: str | int,
    ref_num: str,
    montant: float,
    client: str,
    date_doc: str,
) -> str:
    """Calcule l'empreinte cryptographique SHA-256 scellée par HMAC."""
    mt_clean = f"{abs(float(montant)):.2f}"
    payload = f"{dossier.strip().upper()}|{doc_type.strip().lower()}|{str(doc_id).strip()}|{ref_num.strip()}|{mt_clean}|{client.strip()}|{date_doc.strip()}"
    signature = hmac.new(HMAC_SECRET, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return signature


def generate_passport_qr_data_uri(verify_url: str, dark_color: str = "#047857", light_color: str = "#ffffff") -> str:
    """Génère un QR Code SVG vectoriel haute fidélité via Segno."""
    qr = segno.make(verify_url, error="M")
    return qr.svg_data_uri(scale=4, dark=dark_color, light=light_color, border=1)


def generate_doc_passport(
    dossier: str,
    doc_type: str,  # "recu_lot", "recu_promo", "contrat", "facture"
    doc_id: str | int,
    ref_num: str,
    montant: float,
    client: str,
    date_doc: str,
    base_url: str = "http://localhost:8000",
) -> Dict[str, Any]:
    """Génère le passeport financier numérique complet pour un document."""
    sig = calculate_doc_hash(dossier, doc_type, doc_id, ref_num, montant, client, date_doc)
    short_hash = f"{sig[:8].upper()}-{sig[8:16].upper()}-{sig[16:24].upper()}"

    # Construction de l'URL de vérification scellée
    params = {
        "d": dossier,
        "t": doc_type,
        "id": str(doc_id),
        "ref": ref_num,
        "m": f"{abs(float(montant)):.2f}",
        "h": sig,
    }
    query_str = urllib.parse.urlencode(params)
    verify_url = f"{base_url.rstrip('/')}/verify?{query_str}"

    qr_svg_data_uri = generate_passport_qr_data_uri(verify_url)

    return {
        "dossier": dossier,
        "doc_type": doc_type,
        "doc_id": doc_id,
        "ref_num": ref_num,
        "montant": float(montant),
        "client": client,
        "date_doc": date_doc,
        "signature": sig,
        "short_hash": short_hash,
        "verify_url": verify_url,
        "qr_data_uri": qr_svg_data_uri,
        "timestamp": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
    }


def render_passport_stamp_html(
    passport: Dict[str, Any],
    is_ar: bool = True,
    width_px: int = 240,
) -> str:
    """Génère le bloc visuel du Sceau Numérique pour l'impression du document."""
    short_hash = passport.get("short_hash", "")
    qr_uri = passport.get("qr_data_uri", "")
    verify_url = passport.get("verify_url", "#")

    if is_ar:
        title = "جواز السفر المالي الرقمي"
        subtitle = "ختم التحقق والأصالة غير قابل للتزوير"
        scan_txt = "امسح بالكاميرا للتحقق الفوري"
        cert_txt = "وثيقة مؤكدة ومسجلة محاسبياً"
    else:
        title = "Passeport Financier Numérique"
        subtitle = "Sceau de sécurité & Non-falsification"
        scan_txt = "Scanner pour vérifier l'authenticité"
        cert_txt = "Document certifié & Scellé"

    return f"""
    <div class="fiscal-passport-stamp" style="display:inline-flex;align-items:center;gap:10px;border:1.5px solid #047857;background:#f0fdf4;border-radius:8px;padding:8px 12px;font-family:'Cairo','Segoe UI',sans-serif;max-width:{width_px}px;box-shadow:0 1px 3px rgba(4,120,87,0.08);">
      <div style="flex-shrink:0;width:58px;height:58px;background:#fff;border:1px solid #10b981;border-radius:6px;padding:2px;display:flex;align-items:center;justify-content:center;">
        <a href="{escape(verify_url)}" target="_blank" title="{scan_txt}">
          <img src="{qr_uri}" style="width:100%;height:100%;display:block;border-radius:4px;" alt="QR Verification" />
        </a>
      </div>
      <div style="flex:1;min-width:0;line-height:1.25;">
        <div style="display:flex;align-items:center;gap:4px;color:#047857;font-weight:900;font-size:11px;">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
          <span>{title}</span>
        </div>
        <div style="font-size:9.5px;color:#0f766e;font-weight:700;margin-top:2px;">{subtitle}</div>
        <div style="font-size:8.5px;color:#64748b;margin-top:2px;font-family:monospace;direction:ltr;font-weight:700;">SHA: {short_hash}</div>
        <div style="font-size:8.5px;color:#047857;font-weight:800;margin-top:2px;background:#dcfce7;border-radius:3px;padding:1px 4px;display:inline-block;">✓ {cert_txt}</div>
      </div>
    </div>
    """


def verify_and_fetch_passport_details(
    dossier: str,
    doc_type: str,
    doc_id: str | int,
    ref_num: str = "",
    montant_param: float = 0.0,
    hash_param: str = "",
) -> Dict[str, Any]:
    """Vérifie l'authenticité d'un document contre la base SQLite et le sceau HMAC."""
    doc_id_int = int(doc_id) if str(doc_id).isdigit() else 0
    soc = dossiers.societe(dossier)
    soc_rs = str(soc.get("rs") or f"Entreprise {dossier}")
    soc_nif = str(soc.get("NIF") or "—")
    soc_rc = str(soc.get("RC") or "—")
    soc_adr = str(soc.get("adresse") or "—")

    found = False
    tampered = False
    real_montant = 0.0
    real_client = ""
    real_date = ""
    real_ref = ""
    mode_reg = ""
    designation = ""

    with connect(dossier) as conn:
        if doc_type in ("recu_lot", "lot"):
            row = conn.execute('SELECT * FROM VersClients WHERE "IDvers" = ?', (doc_id_int,)).fetchone()
            if row:
                v = dict(row)
                found = True
                real_montant = float(v.get("Mtvers") or 0.0)
                real_date = dates.to_display(v.get("DateVer")) or ""
                real_ref = str(v.get("NumVer") or doc_id_int)
                mode_reg = str(v.get("ModeVers") or "Espèces")
                lot_row = conn.execute('SELECT * FROM Lots WHERE "ID" = ?', (v.get("IDclient"),)).fetchone()
                if lot_row:
                    lot = dict(lot_row)
                    real_client = str(lot.get("Acquereur") or "—")
                    designation = f"Lotissement N° {lot.get('Idetude', '')} — Lot N° {lot.get('Nlot', '')}"
                else:
                    real_client = "—"
                    designation = "Versement Lotissement"
        elif doc_type in ("recu_promo", "versement_promo"):
            row = conn.execute('SELECT * FROM VersClients WHERE "IDvers" = ?', (doc_id_int,)).fetchone()
            if row:
                v = dict(row)
                found = True
                real_montant = float(v.get("Mtvers") or 0.0)
                real_date = dates.to_display(v.get("DateVer")) or ""
                real_ref = str(v.get("NumVer") or doc_id_int)
                mode_reg = str(v.get("ModeVers") or "Virement")
                # Chercher l'unité promo
                u_row = conn.execute('SELECT * FROM PromotionUnites WHERE "ID" = ?', (v.get("IDclient"),)).fetchone()
                if u_row:
                    u = dict(u_row)
                    real_client = str(u.get("Acquereur") or "—")
                    designation = f"Promotion Immobilière — Unité N° {u.get('Numero', '')} ({u.get('TypeLogement', '')})"
                else:
                    real_client = "—"
                    designation = "Versement Promotion Immobilière"
        elif doc_type in ("contrat", "contrat_lot"):
            row = conn.execute('SELECT * FROM Lots WHERE "ID" = ?', (doc_id_int,)).fetchone()
            if row:
                lot = dict(row)
                found = True
                real_montant = float(lot.get("PcessionLot") or 0.0)
                real_date = dates.to_display(lot.get("DateActe")) or ""
                real_ref = str(lot.get("NumActe") or f"ACTE-{doc_id_int}")
                real_client = str(lot.get("Acquereur") or "—")
                mode_reg = "Contrat Notarié"
                designation = f"Contrat de cession Lot N° {lot.get('Nlot', '')}"

    if found:
        # Vérification du hash
        computed_sig = calculate_doc_hash(dossier, doc_type, doc_id_int, real_ref, real_montant, real_client, real_date)
        if hash_param and computed_sig.lower() != hash_param.lower().strip():
            tampered = True
        elif montant_param and abs(montant_param - real_montant) > 0.009:
            tampered = True
    else:
        computed_sig = hash_param or ""

    ar_words = honoraires.nombre_en_lettres_ar(real_montant).replace("فقط", "").replace("لا غير", "").strip() if found else ""
    fr_words = honoraires.nombre_en_lettres_fr(real_montant) if found else ""

    return {
        "valid": found and not tampered,
        "found": found,
        "tampered": tampered,
        "dossier": dossier,
        "doc_type": doc_type,
        "doc_id": doc_id,
        "ref_num": real_ref or ref_num,
        "montant": real_montant,
        "montant_words_ar": f"{ar_words} دينار جزائري" if ar_words else "",
        "montant_words_fr": f"{fr_words} Dinars Algériens" if fr_words else "",
        "client": real_client,
        "date_doc": real_date,
        "mode_reglement": mode_reg,
        "designation": designation,
        "signature": computed_sig,
        "short_hash": f"{computed_sig[:8].upper()}-{computed_sig[8:16].upper()}" if computed_sig else "",
        "societe": {
            "rs": soc_rs,
            "nif": soc_nif,
            "rc": soc_rc,
            "adresse": soc_adr,
        },
        "verified_at": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
    }
