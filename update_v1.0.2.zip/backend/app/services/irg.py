"""IRG (personnes physiques) — acomptes and solde de liquidation.

Delphi: uMain page 7, Unit8 (acomptes, table IRGAcomptes), Unit9 (solde, table IRGsolde),
report RIrg (dataset RecapIrg).

Rules (Unit9):
  * IRG = Irg2022(résultat taxable): progressive scale 0 / 23 / 27 / 30 / 33 / 35 %.
  * Deductions = 1er acompte + 2ème acompte (from IRGAcomptes) + acomptes versés + crédit d'impôt.
  * IRG > deductions → solde de liquidation, otherwise excédent de versement.
Logical additions: the computed IRG is stored in `droits` (printed by RIrg), and a solde can
be created (Delphi's « Ajouter » only edited an existing record).
"""
from __future__ import annotations

import sqlite3

from fastapi import HTTPException

from ..core.db import connect
from . import dates
from . import g50
from .g50 import Conflict, G50Error, _client, _next_id, _num, _r2

ACOMPTES = [("E3L20", "1er acompte"), ("E3L30", "2éme acompte")]
ALIASES = {"E3L20": ("1er acompte",), "E3L30": ("2éme acompte", "2eme acompte")}

# Unit9.Irg2022: (lower bound, rate %, cumulated tax at the lower bound)
SCALE = [(240000, 23, 0), (480000, 27, 55200), (960000, 30, 184800), (1920000, 33, 472800), (3840000, 35, 1106400)]


def irg2022(base: float) -> float:
    tax = 0.0
    for low, rate, cum in SCALE:
        if base >= low:
            tax = (base - low) * rate / 100 + cum
    return tax


def _code_of(row: dict) -> str | None:
    imp, code = str(row.get("impots") or "").strip().lower(), str(row.get("code") or "").strip().upper()
    for c, names in ALIASES.items():
        if code == c or imp in names:
            return c
    return None


def acomptes(c: sqlite3.Connection, exercice: str) -> list[dict]:
    rows = [dict(r) for r in c.execute('SELECT * FROM IRGAcomptes WHERE CAST("Exercice" AS TEXT) = ? ORDER BY code, "ID"', (str(exercice),))]
    for r in rows:
        r["_id"], r["_code"] = r["ID"], _code_of(r)
        r["date_display"] = dates.to_display(r.get("dare"))
    return rows


def _find_g50_id(c: sqlite3.Connection, dare_storage: str | None, exercice: str) -> int:
    """Find the G50 declaration matching the payment date (dare), or 0."""
    if not dare_storage:
        return 0
    d = dates.parse(dare_storage)
    if not d:
        return 0
    m, y = d.month, d.year
    row = c.execute('SELECT idg50 FROM G50 WHERE CAST(Mois AS INTEGER) = ? AND CAST("Année" AS INTEGER) = ? LIMIT 1', (m, y)).fetchone()
    return int(row[0]) if row else 0


def save_acompte(code: str, exercice: str, data: dict, acompte_id: int | None = None) -> dict:
    acode = str(data.get("code") or "").strip().upper()
    label = dict(ACOMPTES).get(acode)
    if not label:
        raise G50Error("Sélectionnez l’acompte (1er ou 2ème)")
    base, taux = _num(data.get("Revenusimposables")), _num(data.get("taux"))
    droits = _num(data.get("droits")) if data.get("droits") not in (None, "") else base * taux / 100
    dare_storage = dates.to_storage(data.get("dare")) if data.get("dare") else None
    old_idg50 = 0
    with connect(code) as c:
        for r in acomptes(c, exercice):
            if r["_code"] == acode and r["ID"] != acompte_id:
                raise Conflict(f"Le {label} existe déjà pour l’exercice {exercice}")
        idc = str(_client(c).get("IDclients") or "")
        idg50 = _find_g50_id(c, dare_storage, exercice)
        values = {"code": acode, "impots": label, "Revenusimposables": _r2(base), "taux": taux, "droits": _r2(droits),
                  "Exercice": str(exercice), "IDclients": idc, "ClientExercice": f"{idc} {exercice}",
                  "codeacompte": f"{idc} {acode} {exercice}", "refacompte": label.split()[0],
                  "dare": dare_storage, "Idg50": idg50}
        if acompte_id is None:
            values["ID"] = _next_id(c, "IRGAcomptes", "ID")
            c.execute(f'INSERT INTO IRGAcomptes ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        else:
            old = c.execute('SELECT "Idg50" FROM IRGAcomptes WHERE "ID" = ?', (acompte_id,)).fetchone()
            if not old:
                raise HTTPException(404, "Acompte introuvable")
            old_idg50 = int(old[0] or 0)
            c.execute(f'UPDATE IRGAcomptes SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} WHERE "ID" = ?',
                      (*values.values(), acompte_id))
        _sync(c, exercice)
        if idg50:
            g50._recalc(c, idg50)
        if old_idg50 and old_idg50 != idg50:
            g50._recalc(c, old_idg50)
    return state(code, exercice)


def delete_acompte(code: str, exercice: str, acompte_id: int) -> dict:
    with connect(code) as c:
        row = c.execute('SELECT "Idg50" FROM IRGAcomptes WHERE "ID" = ?', (acompte_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Acompte introuvable")
        old_idg50 = int(row[0] or 0)
        c.execute('DELETE FROM IRGAcomptes WHERE "ID" = ?', (acompte_id,))
        _sync(c, exercice)
        if old_idg50:
            g50._recalc(c, old_idg50)
    return state(code, exercice)


def _ensure_solde_columns(c: sqlite3.Connection) -> set[str]:
    cols = {r[1] for r in c.execute('PRAGMA table_info(IRGsolde)')}
    if "idg50" not in cols:
        try:
            c.execute('ALTER TABLE IRGsolde ADD COLUMN idg50 INTEGER DEFAULT 0')
            cols.add("idg50")
        except Exception:
            pass
    if "dated" not in cols:
        try:
            c.execute('ALTER TABLE IRGsolde ADD COLUMN dated TEXT')
            cols.add("dated")
        except Exception:
            pass
    return cols


def _row(c: sqlite3.Connection, exercice: str) -> dict | None:
    _ensure_solde_columns(c)
    r = c.execute('SELECT * FROM IRGsolde WHERE CAST("Exercice" AS TEXT) = ? ORDER BY "IDIRGsolde" LIMIT 1', (str(exercice),)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["date_display"] = dates.to_display(d.get("dated"))
    return d


def _defaults(c: sqlite3.Connection, exercice: str) -> dict:
    acs = {r["_code"]: _num(r["droits"]) for r in acomptes(c, exercice)}
    return {"Acompte1": acs.get("E3L20", 0.0), "Acompte2": acs.get("E3L30", 0.0)}


INPUTS = ("Résultat_taxable", "Acompte1", "Acompte2", "Acomptes_versés", "Credit_impôt", "ilm")


def _write(c: sqlite3.Connection, exercice: str, v: dict, row_id: int | None) -> None:
    cols = _ensure_solde_columns(c)
    out = {k: (round(_num(v[k])) if v.get(k) not in (None, "") else None) for k in INPUTS}
    droits = irg2022(_num(v.get("Résultat_taxable")))
    ded = sum(_num(out.get(k)) for k in ("Acompte1", "Acompte2", "Acomptes_versés", "Credit_impôt"))
    idc = str(_client(c).get("IDclients") or "")
    out.update({"droits": round(droits), "Montantglobaldéduire": round(ded), "Exercice": int(exercice),
                "Soldedeliquidation": round(droits - ded) if droits > ded else None,
                "Excédentversement": None if droits > ded else round(ded - droits),
                "Codeacompte1": f"{idc} E3L20 {exercice}", "Codeacompte2": f"{idc} E3L30 {exercice}"})
    if "dated" in v:
        out["dated"] = v["dated"]
    if "idg50" in v:
        out["idg50"] = v["idg50"]
    out = {k: val for k, val in out.items() if k in cols}
    if row_id is None:
        out["IDIRGsolde"] = _next_id(c, "IRGsolde", "IDIRGsolde")
        c.execute(f'INSERT INTO IRGsolde ({", ".join(chr(34) + k + chr(34) for k in out)}) VALUES ({", ".join("?" for _ in out)})', tuple(out.values()))
    else:
        c.execute(f'UPDATE IRGsolde SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in out)} WHERE "IDIRGsolde" = ?', (*out.values(), row_id))


def _sync(c: sqlite3.Connection, exercice: str) -> None:
    row = _row(c, exercice)
    if row is not None:
        row.update(_defaults(c, exercice))
        _write(c, exercice, row, row["IDIRGsolde"])


def save_solde(code: str, exercice: str, data: dict) -> dict:
    with connect(code) as c:
        _ensure_solde_columns(c)
        row = _row(c, exercice)
        old_idg50 = int(row.get("idg50") or 0) if row else 0
        values = dict(row or _defaults(c, exercice))
        values.update({k: data[k] for k in INPUTS if k in data})

        if "dated" in data:
            values["dated"] = dates.to_storage(data.get("dated")) if data.get("dated") else None

        if values.get("dated"):
            new_idg50 = _find_g50_id(c, values.get("dated"), exercice)
        else:
            new_idg50 = 0
        values["idg50"] = new_idg50

        _write(c, exercice, values, row["IDIRGsolde"] if row else None)

        if new_idg50:
            g50._recalc(c, new_idg50)
        if old_idg50 and old_idg50 != new_idg50:
            g50._recalc(c, old_idg50)
    return state(code, exercice)


def refresh_solde(code: str, exercice: str) -> dict:
    """Unit9.Button1Click: acomptes of the exercice."""
    with connect(code) as c:
        row = _row(c, exercice)
        values = dict(row or {})
        values.update(_defaults(c, exercice))
        _write(c, exercice, values, row["IDIRGsolde"] if row else None)
    return state(code, exercice)


def delete_solde(code: str, exercice: str) -> dict:
    with connect(code) as c:
        row = _row(c, exercice)
        if not row:
            raise HTTPException(404, "Aucun solde IRG à supprimer")
        old_idg50 = int(row.get("idg50") or 0)
        c.execute('DELETE FROM IRGsolde WHERE CAST("Exercice" AS TEXT) = ?', (str(exercice),))
        if old_idg50:
            g50._recalc(c, old_idg50)
    return state(code, exercice)


def state(code: str, exercice: str) -> dict:
    with connect(code) as c:
        _ensure_solde_columns(c)
        return {"exercice": str(exercice), "acomptes": acomptes(c, exercice), "solde": _row(c, exercice),
                "defaults": _defaults(c, exercice), "acompte_types": [{"code": c, "label": l} for c, l in ACOMPTES],
                "scale": [{"from": low, "rate": rate} for low, rate, _ in SCALE]}
