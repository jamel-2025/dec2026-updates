"""Service de gestion et d'archivage des messages WhatsApp."""
from __future__ import annotations

import sqlite3
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from ..core import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS whatsapp_archives (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    timestamp REAL NOT NULL,
    dossier TEXT,
    client_name TEXT NOT NULL,
    telephone TEXT NOT NULL,
    category TEXT NOT NULL,
    sujet TEXT NOT NULL,
    message TEXT NOT NULL,
    lang TEXT NOT NULL DEFAULT 'ar',
    statut TEXT NOT NULL DEFAULT 'envoye'
);
CREATE INDEX IF NOT EXISTS idx_wa_time ON whatsapp_archives (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_wa_dossier ON whatsapp_archives (dossier);
"""


def _get_conn() -> sqlite3.Connection:
    config.AUDIT_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(config.AUDIT_DB), timeout=10.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db() -> None:
    with _get_conn() as conn:
        conn.executescript(_SCHEMA)


try:
    init_db()
except Exception:
    pass


def archiver_message(
    dossier: Optional[str],
    client_name: str,
    telephone: str,
    category: str,
    sujet: str,
    message: str,
    lang: str = "ar",
    statut: str = "envoye",
) -> Dict[str, Any]:
    """Enregistre un message WhatsApp envoyé dans l'archive."""
    now = datetime.now(timezone.utc)
    ts = now.timestamp()
    iso = now.strftime("%Y-%m-%d %H:%M:%S")

    with _get_conn() as conn:
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO whatsapp_archives (
                created_at, timestamp, dossier, client_name,
                telephone, category, sujet, message, lang, statut
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (iso, ts, dossier or "", client_name, telephone, category, sujet, message, lang, statut),
        )
        conn.commit()
        last_id = cur.lastrowid

    return {
        "id": last_id,
        "created_at": iso,
        "dossier": dossier,
        "client_name": client_name,
        "telephone": telephone,
        "category": category,
        "sujet": sujet,
        "message": message,
        "lang": lang,
        "statut": statut,
    }


def lister_archives(dossier: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
    """Récupère l'historique des messages envoyés."""
    with _get_conn() as conn:
        cur = conn.cursor()
        if dossier:
            cur.execute(
                """
                SELECT * FROM whatsapp_archives
                WHERE dossier = ?
                ORDER BY timestamp DESC
                LIMIT ?
                """,
                (dossier, limit),
            )
        else:
            cur.execute(
                """
                SELECT * FROM whatsapp_archives
                ORDER BY timestamp DESC
                LIMIT ?
                """,
                (limit,),
            )
        rows = cur.fetchall()

    return [dict(r) for r in rows]


def supprimer_archive(archive_id: int) -> bool:
    """Supprime un message de l'archive."""
    with _get_conn() as conn:
        cur = conn.cursor()
        cur.execute("DELETE FROM whatsapp_archives WHERE id = ?", (archive_id,))
        conn.commit()
        return cur.rowcount > 0
