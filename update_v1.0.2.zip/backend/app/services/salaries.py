"""Salariés et contrats de travail — Delphi uEmployes (répertoire), uContrats (contrats, impression
Rapports/Contrat_*.fr3). Tables Employes, Contrats.

Rules:
  * salarié: nom et prénom en arabe obligatoires; new record: السيد, بطاقة تعريف وطنية, أعزب, date d'entrée = today;
    deleting a salarié deletes his contracts;
  * contrat: poste (arabe) obligatoire; 7 types (SNAPO, CDD, avenant CDD, CDI, partiel CDD, avenant partiel, partiel CDI)
    with the defaults of cmbTypeContratChange; number CTR-<salarié>-<nn>; CDI types have no end date / motif;
  * impression: template per type, placeholders [SocRS]…[Observations] filled as in BuildContractReport
    (FormatMontantDZ amounts, yyyy/mm/dd dates, FixMojibake on texts).
"""
from __future__ import annotations

from datetime import date

from fastapi import HTTPException

from ..core.db import connect
from . import dates, dossiers
from .g50 import G50Error, _next_id, _num

TYPES = {
    1: ("صيدليات (SNAPO)", "Contrat_SNAPO.fr3", "عقد عمل غير محدد المدة"),
    2: ("محدد المدة (CDD)", "Contrat_CDD.fr3", "عقد عمل محدد المدة"),
    3: ("تمديد محدد المدة", "Contrat_CDD_Avenant.fr3", "تمديد عقد عمل محدد المدة"),
    4: ("غير محدد المدة (CDI)", "Contrat_CDI.fr3", "عقد عمل غير محدد المدة"),
    5: ("توقيت جزئي (CDD)", "Contrat_Partiel.fr3", "عقد عمل محدد المدة بالتوقيت الجزئي"),
    6: ("تمديد توقيت جزئي", "Contrat_Partiel_Avenant.fr3", "تمديد عقد عمل محدد المدة بالتوقيت الجزئي"),
    7: ("توقيت جزئي (CDI)", "Contrat_Partiel_CDI.fr3", "عقد عمل غير محدد المدة بالتوقيت الجزئي"),
}
CDI_TYPES = {1, 4, 7}
PART_TIME = {5, 6, 7}
HORAIRE = "من الأحد إلى الخميس من الساعة 08:00 إلى 12:00"
MOTIF_CDD = "تزايد حجم النشاط والعمل وتغطية العجز المسجل (المادة 12 من القانون 90-11)"

# cmbTypeContratChange
TYPE_DEFAULTS = {
    1: {"Poste_AR": "مساعد صيدلي", "DureeTexte_AR": "غير محددة", "OptionClauseLoyeaute": 1, "OptionReglementDiscipline": 1},
    2: {"DureeTexte_AR": "سنة واحدة", "MotifCDD_AR": MOTIF_CDD},
    3: {"DureeTexte_AR": "سنة واحدة (تمديد)", "MotifCDD_AR": "تمديد سريان العقد السابق نظراً لاستمرار تزايد النشاط"},
    4: {"DureeTexte_AR": "غير محددة"},
    5: {"DureeTexte_AR": "سنة واحدة (توقيت جزئي)", "HeuresHebdo": 20, "HoraireDetails_AR": HORAIRE},
    6: {"DureeTexte_AR": "سنة واحدة (تمديد توقيت جزئي)", "HeuresHebdo": 20, "HoraireDetails_AR": HORAIRE},
    7: {"DureeTexte_AR": "غير محددة (توقيت جزئي)", "HeuresHebdo": 20, "HoraireDetails_AR": HORAIRE},
}

EMP_FIELDS = ("Civilite", "NomPrenom_AR", "NomPrenom_FR", "DateNaissance", "LieuNaissance_AR", "TypePiece", "NumPiece",
              "DatePiece", "DairaPiece_AR", "Adresse_AR", "Telephone", "NumSecu", "SituationFam", "DateEntree", "Actif")
EMP_DATES = ("DateNaissance", "DatePiece", "DateEntree")
CTR_FIELDS = ("TypeContrat", "NumContrat", "DateContrat", "Poste_AR", "LieuTravail_AR", "DureeTexte_AR", "DateDebut", "DateFin",
              "PeriodeEssai", "DateDebutEssai", "DateFinEssai", "Preavis", "MotifCDD_AR", "SalaireBase", "PrimeNuisance",
              "PrimePanier", "PrimeTransport", "AutresPrimes", "HeuresHebdo", "HoraireDetails_AR", "IDContratPrecedent",
              "DateContratPrecedent", "OptionClauseLoyeaute", "OptionReglementDiscipline", "Observations")
CTR_DATES = ("DateContrat", "DateDebut", "DateFin", "DateDebutEssai", "DateFinEssai", "DateContratPrecedent")
CTR_NUMS = ("SalaireBase", "PrimeNuisance", "PrimePanier", "PrimeTransport", "AutresPrimes", "HeuresHebdo")


def fix_mojibake(s) -> str:
    """uContrats.FixMojibake — UTF-8 Arabic read as cp1252."""
    s = "" if s is None else str(s)
    if any(ch in s for ch in "ØÙÂÃ"):
        try:
            return s.encode("cp1252").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            return s
    return s


def montant_dz(v) -> str:
    """uContrats.FormatMontantDZ — 30.000.00 with left-to-right marks."""
    n = abs(_num(v))
    i, frac = int(n), round((n - int(n)) * 100)
    if frac >= 100:
        i, frac = i + 1, 0
    s = f"{i:,}".replace(",", ".")
    return f"\u200E{'-' if _num(v) < 0 else ''}{s}.{frac:02d}\u200E"


def _disp(v) -> str:
    return dates.to_display(v) if v else ""


def _add_months(d: date, months: int) -> date:
    y, m = divmod(d.month - 1 + months, 12)
    import calendar
    last = calendar.monthrange(d.year + y, m + 1)[1]
    return date(d.year + y, m + 1, min(d.day, last))


# ------------------------------------------------------------------ salariés
def employees(code: str, q: str = "") -> list[dict]:
    sql, args = "SELECT e.*, (SELECT COUNT(*) FROM Contrats c WHERE c.IDEmploye = e.IDEmploye) AS nb_contrats FROM Employes e", []
    if q:
        sql += " WHERE e.NomPrenom_AR LIKE ? OR e.NomPrenom_FR LIKE ? OR e.NumPiece LIKE ? OR e.Telephone LIKE ?"
        args = [f"%{q}%"] * 4
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(sql + " ORDER BY e.IDEmploye DESC", args)]
    for r in rows:
        r["_id"] = r["IDEmploye"]
        for k in ("NomPrenom_AR", "LieuNaissance_AR", "DairaPiece_AR", "Adresse_AR", "Civilite", "TypePiece", "SituationFam"):
            r[k] = fix_mojibake(r.get(k))
        for k in EMP_DATES:
            r[f"{k}_display"] = _disp(r.get(k))
    return rows


def employee_defaults() -> dict:
    return {"Civilite": "السيد", "TypePiece": "بطاقة تعريف وطنية", "SituationFam": "أعزب",
            "DateEntree": date.today().strftime("%d/%m/%Y"), "Actif": 1}


def save_employee(code: str, data: dict, eid: int | None = None) -> dict:
    if not str(data.get("NomPrenom_AR") or "").strip():
        raise G50Error("يرجى إدخال اسم ولقب العامل باللغة العربية أولاً.")
    values = {k: data.get(k) for k in EMP_FIELDS if k in data}
    for k in EMP_DATES:
        if k in values:
            values[k] = dates.to_storage(values[k]) if values[k] else None
    if "Actif" in values:
        values["Actif"] = 1 if values["Actif"] in (True, 1, "1", "true", "True") else 0
    values = {k: (v.strip() if isinstance(v, str) else v) for k, v in values.items()}
    with connect(code) as c:
        if eid is None:
            values["IDEmploye"] = eid = _next_id(c, "Employes", "IDEmploye")
            c.execute(f'INSERT INTO Employes ({", ".join(values)}) VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE Employes SET {", ".join(k + " = ?" for k in values)} WHERE IDEmploye = ?',
                           (*values.values(), eid)).rowcount:
            raise HTTPException(404, "Salarié introuvable")
    return next(e for e in employees(code) if e["IDEmploye"] == eid)


def delete_employee(code: str, eid: int) -> None:
    with connect(code) as c:
        c.execute("DELETE FROM Contrats WHERE IDEmploye = ?", (eid,))
        if not c.execute("DELETE FROM Employes WHERE IDEmploye = ?", (eid,)).rowcount:
            raise HTTPException(404, "Salarié introuvable")


# ------------------------------------------------------------------ contrats
def ensure_contrats_custom_table(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ContratsCustom (
            IDContrat INTEGER PRIMARY KEY,
            CustomHTML TEXT,
            CustomClauses TEXT,
            UpdatedAt TEXT
        )
    """)


def get_contrat_custom(code: str, cid: int) -> dict | None:
    with connect(code) as c:
        ensure_contrats_custom_table(c)
        r = c.execute("SELECT * FROM ContratsCustom WHERE IDContrat = ?", (cid,)).fetchone()
        return dict(r) if r else None


def save_contrat_custom(code: str, cid: int, custom_html: str = "", custom_clauses: str = "") -> dict:
    from datetime import datetime
    now = datetime.now().isoformat()
    with connect(code) as c:
        ensure_contrats_custom_table(c)
        c.execute("""
            INSERT INTO ContratsCustom (IDContrat, CustomHTML, CustomClauses, UpdatedAt)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(IDContrat) DO UPDATE SET
                CustomHTML = excluded.CustomHTML,
                CustomClauses = excluded.CustomClauses,
                UpdatedAt = excluded.UpdatedAt
        """, (cid, custom_html, custom_clauses, now))
    return {"status": "ok", "IDContrat": cid, "updated_at": now}


def delete_contrat_custom(code: str, cid: int) -> dict:
    with connect(code) as c:
        ensure_contrats_custom_table(c)
        c.execute("DELETE FROM ContratsCustom WHERE IDContrat = ?", (cid,))
    return {"status": "ok", "IDContrat": cid}


def contracts(code: str, eid: int | None = None) -> list[dict]:
    sql = ("SELECT c.*, e.NomPrenom_AR, e.NomPrenom_FR, e.Telephone, e.DateNaissance, e.NumPiece, e.DateEntree "
           "FROM Contrats c LEFT JOIN Employes e ON c.IDEmploye = e.IDEmploye")
    args: list = []
    if eid:
        sql += " WHERE c.IDEmploye = ?"
        args = [eid]
    with connect(code) as c:
        ensure_contrats_custom_table(c)
        rows = [dict(r) for r in c.execute(sql + " ORDER BY c.IDContrat DESC", args)]
        custom_ids = {r[0] for r in c.execute("SELECT IDContrat FROM ContratsCustom WHERE CustomHTML IS NOT NULL AND length(CustomHTML) > 0").fetchall()}

    today = date.today()
    for r in rows:
        cid = r["IDContrat"]
        r["_id"] = cid
        r["has_custom"] = cid in custom_ids
        t = int(_num(r.get("TypeContrat")))
        r["type_label"] = f"{t} - {TYPES[t][0]}" if t in TYPES else f"صنف: {t}"
        r["type_name"] = TYPES[t][0] if t in TYPES else f"صنف {t}"
        for k in ("NomPrenom_AR", "NomPrenom_FR", "Poste_AR", "LieuTravail_AR", "DureeTexte_AR", "MotifCDD_AR", "HoraireDetails_AR", "Observations",
                  "PeriodeEssai", "Preavis", "Telephone"):
            r[k] = fix_mojibake(r.get(k))
        for k in CTR_DATES:
            r[f"{k}_display"] = _disp(r.get(k))

        # Status & Expiration Calculations
        is_cdi = (t in (1, 4, 7)) or not r.get("DateFin")
        d_debut = dates.parse(r.get("DateDebut"))
        d_fin = dates.parse(r.get("DateFin"))

        if is_cdi or not d_fin:
            r["status"] = "cdi"
            r["is_cdi"] = True
            r["days_remaining"] = None
            r["status_label_ar"] = "غير محدد المدة (CDI)"
            r["status_label_fr"] = "Indéterminée (CDI)"
            r["progress_percent"] = 100
        else:
            r["is_cdi"] = False
            d_fin_date = d_fin.date() if hasattr(d_fin, "date") else d_fin
            diff = (d_fin_date - today).days
            r["days_remaining"] = diff
            if diff < 0:
                r["status"] = "expired"
                r["status_label_ar"] = f"منتهي (منذ {-diff} يوم)"
                r["status_label_fr"] = f"Expiré ({-diff} j)"
                r["progress_percent"] = 100
            elif diff <= 30:
                r["status"] = "expiring_soon"
                r["status_label_ar"] = f"ينتهي خلال {diff} يوم" if diff > 0 else "ينتهي اليوم"
                r["status_label_fr"] = f"Expire dans {diff} j" if diff > 0 else "Expire aujourd'hui"
            else:
                r["status"] = "active"
                r["status_label_ar"] = f"ساري ({diff} يوم متبقي)"
                r["status_label_fr"] = f"Actif ({diff} j)"

            if d_debut and d_fin:
                d_debut_date = d_debut.date() if hasattr(d_debut, "date") else d_debut
                total_days = max(1, (d_fin_date - d_debut_date).days)
                passed_days = max(0, min(total_days, (today - d_debut_date).days))
                r["progress_percent"] = min(100, max(0, int((passed_days / total_days) * 100)))
            else:
                r["progress_percent"] = 50

        # Période d'essai
        d_fin_essai = dates.parse(r.get("DateFinEssai"))
        if d_fin_essai:
            d_fin_essai_date = d_fin_essai.date() if hasattr(d_fin_essai, "date") else d_fin_essai
            diff_essai = (d_fin_essai_date - today).days
            r["essai_days_remaining"] = diff_essai
            if diff_essai < 0:
                r["essai_status"] = "expired"
                r["essai_label_ar"] = "انتهت التجربة"
                r["essai_label_fr"] = "Essai terminé"
            elif diff_essai <= 15:
                r["essai_status"] = "ending_soon"
                r["essai_label_ar"] = f"تجربة تنتهي خلال {diff_essai} يوم"
                r["essai_label_fr"] = f"Essai finit dans {diff_essai} j"
            else:
                r["essai_status"] = "active"
                r["essai_label_ar"] = f"تجربة جارية ({diff_essai} يوم)"
                r["essai_label_fr"] = f"Essai en cours ({diff_essai} j)"
        else:
            r["essai_days_remaining"] = None
            r["essai_status"] = None
            r["essai_label_ar"] = ""
            r["essai_label_fr"] = ""

    return rows


def contracts_dashboard(code: str) -> dict:
    items = contracts(code, None)
    total = len(items)
    cdi = sum(1 for x in items if x.get("status") == "cdi")
    cdd = total - cdi
    expired = sum(1 for x in items if x.get("status") == "expired")
    expiring_soon = sum(1 for x in items if x.get("status") == "expiring_soon")
    active = sum(1 for x in items if x.get("status") in ("active", "cdi"))
    essai_active = sum(1 for x in items if x.get("essai_status") in ("active", "ending_soon"))
    alerts_count = expired + expiring_soon

    return {
        "total": total,
        "cdi": cdi,
        "cdd": cdd,
        "expired": expired,
        "expiring_soon": expiring_soon,
        "active": active,
        "essai_active": essai_active,
        "alerts_count": alerts_count,
        "items": items,
    }


def contract_defaults(code: str, eid: int, ctype: int = 2) -> dict:
    """uContrats.btnNewClick (+ cmbTypeContratChange for another type)."""
    today = date.today()
    with connect(code) as c:
        if c.execute("SELECT 1 FROM Employes WHERE IDEmploye = ?", (eid,)).fetchone() is None:
            raise HTTPException(404, "Salarié introuvable")
        n = c.execute("SELECT COUNT(*) FROM Contrats WHERE IDEmploye = ?", (eid,)).fetchone()[0]
    d = {"IDEmploye": eid, "TypeContrat": 2, "NumContrat": f"CTR-{eid}-{n + 1:02d}", "DateContrat": today, "DateDebut": today,
         "DateFin": _add_months(today, 12), "DureeTexte_AR": "سنة واحدة", "PeriodeEssai": "03 أشهر", "DateDebutEssai": today,
         "DateFinEssai": _add_months(today, 3), "Preavis": "01 شهر", "MotifCDD_AR": MOTIF_CDD, "SalaireBase": 25000,
         "PrimeNuisance": 10, "PrimePanier": 250, "PrimeTransport": 100, "OptionClauseLoyeaute": 1, "OptionReglementDiscipline": 1}
    d = {k: (v.strftime("%d/%m/%Y") if isinstance(v, date) else v) for k, v in d.items()}
    return apply_type(d, ctype)


def apply_type(d: dict, ctype: int) -> dict:
    ctype = int(ctype)
    if ctype not in TYPES:
        raise G50Error("Type de contrat inconnu")
    out = {**d, "TypeContrat": ctype}
    for k, v in TYPE_DEFAULTS[ctype].items():
        if k == "Poste_AR" and str(out.get(k) or "").strip():
            continue
        out[k] = v
    return out


def save_contract(code: str, eid: int, data: dict, cid: int | None = None) -> dict:
    t = int(_num(data.get("TypeContrat")) or 2)
    if t not in TYPES:
        raise G50Error("Type de contrat inconnu")
    if not str(data.get("Poste_AR") or "").strip():
        raise G50Error("يرجى تحديد منصب العمل بالعربية.")
    values = {k: data.get(k) for k in CTR_FIELDS if k in data}
    values["TypeContrat"] = t
    for k in CTR_DATES:
        if k in values:
            values[k] = dates.to_storage(values[k]) if values[k] else None
    for k in CTR_NUMS:
        if k in values:
            values[k] = _num(values[k])
    for k in ("OptionClauseLoyeaute", "OptionReglementDiscipline"):
        if k in values:
            values[k] = 1 if values[k] in (True, 1, "1", "true") else 0
    if t in CDI_TYPES and t != 1:          # UpdateUIForType: no end date / motif for a CDI
        values["DateFin"] = None
        values["MotifCDD_AR"] = ""
    values["IDEmploye"] = eid
    with connect(code) as c:
        if c.execute("SELECT 1 FROM Employes WHERE IDEmploye = ?", (eid,)).fetchone() is None:
            raise HTTPException(404, "Salarié introuvable")
        if cid is None:
            values["IDContrat"] = cid = _next_id(c, "Contrats", "IDContrat")
            c.execute(f'INSERT INTO Contrats ({", ".join(values)}) VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE Contrats SET {", ".join(k + " = ?" for k in values)} WHERE IDContrat = ?',
                           (*values.values(), cid)).rowcount:
            raise HTTPException(404, "Contrat introuvable")
    return next(x for x in contracts(code, eid) if x["IDContrat"] == cid)


def delete_contract(code: str, cid: int) -> None:
    with connect(code) as c:
        if not c.execute("DELETE FROM Contrats WHERE IDContrat = ?", (cid,)).rowcount:
            raise HTTPException(404, "Contrat introuvable")


# ------------------------------------------------------------------ impression (BuildContractReport)
def print_data(code: str, cid: int) -> dict:
    with connect(code) as c:
        r = c.execute("SELECT * FROM Contrats WHERE IDContrat = ?", (cid,)).fetchone()
        if r is None:
            raise HTTPException(404, "Contrat introuvable")
        ct = dict(r)
        e = c.execute("SELECT * FROM Employes WHERE IDEmploye = ?", (ct["IDEmploye"],)).fetchone()
        emp = dict(e) if e else {}
    s = dossiers.societe(code)
    t = int(_num(ct.get("TypeContrat")))
    _, template, titre = TYPES.get(t, ("", "Contrat_Travail.fr3", "عقد عمل رسمي"))
    ymd = lambda v: dates.parse(v).strftime("%Y/%m/%d") if dates.parse(v) else ""

    def _field(*keys: str) -> str:
        for k in keys:
            for variant in (k, k.lower(), k.upper()):
                val = str(s.get(variant) or "").strip()
                if val:
                    return fix_mojibake(val)
        return ""

    # Priority strictly to Arabic official fields for contracts
    soc_rs = _field("RS_AR", "rs")
    soc_adr = _field("Adresse_AR", "adresse")
    soc_ger = _field("Gerant_AR", "gerant")
    soc_qual = _field("QualiteGerant_AR", "qualite_gerant") or "المسير"
    piece = fix_mojibake(str(emp.get("NumPiece") or "").strip())
    tp = fix_mojibake(emp.get("TypePiece"))
    if tp and "بطاقة" not in tp:
        piece = f"{tp} رقم: {piece}"
    dcontrat = ymd(ct.get("DateContrat")) or date.today().strftime("%Y/%m/%d")
    emp_nom = fix_mojibake(emp.get("NomPrenom_AR"))
    obs = fix_mojibake(ct.get("Observations"))
    heures = _num(ct.get("HeuresHebdo"))
    v = {
        "TitreContrat": titre, "NumContrat": str(ct.get("NumContrat") or ""), "DateContrat": dcontrat,
        "SocRS": soc_rs, "SocAdr": soc_adr, "SocGer": soc_ger,
        "SocQual": soc_qual, "SocNIF": str(s.get("NIF") or ""), "SocRC": str(s.get("RC") or ""),
        "EmpNom": emp_nom, "EmpNomFR": str(emp.get("NomPrenom_FR") or "").strip(), "EmpNais": ymd(emp.get("DateNaissance")),
        "EmpLieu": fix_mojibake(emp.get("LieuNaissance_AR")), "EmpPiece": piece, "EmpDateP": ymd(emp.get("DatePiece")),
        "EmpDaira": fix_mojibake(emp.get("DairaPiece_AR")), "EmpAdr": fix_mojibake(emp.get("Adresse_AR")),
        "EmpCNAS": str(emp.get("NumSecu") or "").strip(), "EmpSituation": fix_mojibake(emp.get("SituationFam")),
        "Poste": fix_mojibake(ct.get("Poste_AR")), "LieuTravail": fix_mojibake(ct.get("LieuTravail_AR")) or soc_rs,
        "DureeTexte": fix_mojibake(ct.get("DureeTexte_AR")), "DateDebut": ymd(ct.get("DateDebut")) or "...",
        "DateFin": ymd(ct.get("DateFin")) or "...", "PeriodeEssai": fix_mojibake(ct.get("PeriodeEssai")),
        "Preavis": fix_mojibake(ct.get("Preavis")), "MotifCDD": fix_mojibake(ct.get("MotifCDD_AR")),
        "SalaireBase": montant_dz(ct.get("SalaireBase")), "PrimeNuisance": f"{_num(ct.get('PrimeNuisance')):g}",
        "PrimePanier": montant_dz(ct.get("PrimePanier")), "PrimeTransport": montant_dz(ct.get("PrimeTransport")),
        "HeuresHebdo": f"{round(heures, 1):g}", "HoraireDetails": fix_mojibake(ct.get("HoraireDetails_AR")), "Observations": obs,
    }
    if t == 1:
        texts = {"MemoTitle": titre,
                 "MemoP2_SubRef": f"تابع لعقد عمل الصيدليات رقم: {v['NumContrat']}  |  العامل الأجير: {emp_nom}",
                 "MemoDateLieu": f"حرر هذا العقد في نسختين أصليتين، وقرئ وصودق عليه من الطرفين بـ: {soc_adr} في: {dcontrat}",
                 "MemoP2_DateLieu": f"حرر هذا الملحق التأديبي بـ: {soc_adr} بتاريخ: {dcontrat}",
                 "MemoObsBody": obs.strip() or "لا توجد شروط خاصة إضافية."}
    else:
        texts = {"MemoTitle": titre, "MemoDateLieu": f"حرر هذا العقد بـ: {soc_adr} بتاريخ: {dcontrat} - قرئ وصودق عليه",
                 "MemoObs": f"ملاحظات: {obs}" if obs.strip() else ""}
    # values for the redesigned HTML contract: long Arabic dates, whole dinars with thousands separators
    long_date = lambda x: dates_ar(dates.parse(x))
    whole = lambda x: f"{round(_num(x)):,}".replace(",", " ")
    pretty = {**v, "EmpNais": long_date(emp.get("DateNaissance")), "EmpDateP": long_date(emp.get("DatePiece")),
              "DateDebut": long_date(ct.get("DateDebut")) or "...", "DateFin": long_date(ct.get("DateFin")) or "...",
              "DateContrat": long_date(ct.get("DateContrat")) or dates_ar(date.today()),
              "SalaireBase": whole(ct.get("SalaireBase")), "PrimePanier": whole(ct.get("PrimePanier")),
              "PrimeTransport": whole(ct.get("PrimeTransport"))}
    return {"template": template, "variables": v, "texts": texts, "title": f"{titre} — {emp_nom}", "pretty": pretty}


MOIS_AR = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def dates_ar(d: date | None) -> str:
    """15 أكتوبر 2026 (Algerian month names)."""
    return f"{d.day:02d} {MOIS_AR[d.month - 1]} {d.year}" if d else ""
