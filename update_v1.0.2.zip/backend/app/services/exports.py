"""Exportation des états — Delphi « Exp PDF » / « Exp Excel » of every preview form (Unit33, Unit6, Unit38,
Unit37, Unit28, Unit44, Unit32, Unit21, Unit19…).

As in Delphi the file is written to <dossier>/Rapports/<année>/<catégorie>/<nom>.pdf|.xlsx with the
same names (« G50 32024 », « EtatTva Année 2024 », « Recap G50 32024 »…), then its folder can be opened.
PDF: the report HTML (images embedded) printed by Microsoft Edge / Chrome headless.
Excel: fr3.xlsx (cell grid of the page objects, like TfrxXLSXExport).
Logical corrections: file names without the Delphi typos; reports that Delphi could only print
(pharmacie, IBS, IRG, TAPP, lotissement, contrats, bénéficiaire) can be exported too.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from fastapi import HTTPException

from ..core import config
from ..core.db import connect, dossier_path
from ..fr3 import html, rtf, xlsx
from . import reports
from .g50 import G50Error

BROWSERS = [r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"]


def _one(code: str, sql: str, args: tuple) -> dict:
    with connect(code) as c:
        r = c.execute(sql, args).fetchone()
    return dict(r) if r else {}


def _g50(code: str, p: dict) -> tuple[str, str]:
    g = _one(code, 'SELECT ma, "Année" AS an FROM G50 WHERE idg50 = ?', (int(p.get("idg50") or 0),))
    return str(g.get("an") or p.get("exercice") or ""), str(g.get("ma") or "")


def target(key: str, code: str, p: dict) -> tuple[str, str, str]:
    """(année, sous-dossier, nom de fichier sans extension)."""
    an = str(p.get("exercice") or "")
    if key in ("g50", "etat_tva", "recap_g50"):
        an, ma = _g50(code, p)
        return an, {"g50": "G50", "etat_tva": "Etat TVA", "recap_g50": "Recap G50"}[key], \
            {"g50": f"G50 {ma}", "etat_tva": f"EtatTva {ma}", "recap_g50": f"Recap G50 {ma}"}[key]
    if key == "etat_tva_annee":
        return an, "Etat TVA", f"EtatTva Année {an}"
    if key == "etat_tva_trim":
        return an, "Etat TVA", f"EtatTva T{p.get('trimestre') or ''} {an}"
    if key == "recap_annee":
        return an, "", f"Recap Annee {an}"
    if key == "ventes":
        mois = str(p.get("mois") or "")
        return an, "Etat Ventes", f"EtatVentes_{mois}_{an}" if mois else f"EtatVentes_Annee_{an}"
    if key == "station_mois":
        s = _one(code, 'SELECT ma, "Annee" AS an FROM Station WHERE "IDStation" = ?', (int(p.get("id") or 0),))
        return str(s.get("an") or an), "", f"CA Station Mois {s.get('ma') or ''}"
    if key == "station_annee":
        return an, "", f"Etat CA Station de Service {an}"
    if key == "encaissements":
        return an, "", f"Etat Suivi de Versement {an}"
    if key == "projet":
        return an, "", f"Etat Projet {p.get('projet') or ''} {an}"
    if key == "pharma":
        return an, "", f"Declaration Pharma {an}"
    if key in ("ibs", "irg"):
        return an, "", f"Solde {key.upper()} {an}"
    if key == "tapp":
        t = _one(code, 'SELECT Exercice AS an, ClientExercice AS s FROM DeclarationTAPP WHERE IDDeclarationTAPP = ?', (int(p.get("id") or 0),))
        return str(t.get("an") or an), "", f"TAPP {t.get('s') or ''} {t.get('an') or ''}"
    if key == "lotissement":
        lo = _one(code, 'SELECT "Adresse" AS a FROM Lotissement WHERE "ID" = ?', (int(p.get("id") or 0),))
        return "Lotissement", "", f"Lotissement {lo.get('a') or p.get('id')}"
    if key.startswith("lotissement_"):
        lo = _one(code, 'SELECT "Adresse" AS a FROM Lotissement WHERE "ID" = ?', (int(p.get("id") or 0),))
        adr = (lo.get("a") or f"Lotissement_{p.get('id')}").replace(" ", "_")
        names = {
            "lotissement_plan": f"Plan_Cadastral_A4_{adr}",
            "lotissement_lots": f"Lots_Matrice_{adr}",
            "lotissement_versements": f"Versements_Encaissements_{adr}",
            "lotissement_creances": f"Creances_Restes_{adr}",
            "lotissement_annuelle": f"Situation_Annuelle_TCR_{adr}",
        }
        return "Lotissement", "Etats", names.get(key, f"{key}_{adr}")
    if key == "contrat":
        c = _one(code, "SELECT c.NumContrat AS n, e.NomPrenom_FR AS nf, e.NomPrenom_AR AS na, c.DateContrat AS d FROM Contrats c "
                       "LEFT JOIN Employes e ON e.IDEmploye = c.IDEmploye WHERE c.IDContrat = ?", (int(p.get("id") or 0),))
        return "Contrats", "", f"Contrat {c.get('n') or ''} {c.get('nf') or c.get('na') or ''}"
    if key == "beneficiaire":
        b = _one(code, "SELECT Annee AS an, NomComplet_AR AS n FROM BeneficiairesEffectifs WHERE IDBeneficiaire = ?", (int(p.get("id") or 0),))
        return str(b.get("an") or an), "", f"Beneficiaire_Effectif_{b.get('an') or ''}_{(b.get('n') or '').replace(' ', '_')}"
    if key == "recu_honoraires":
        from . import honoraires
        r = honoraires.get_recu_paiement(code, int(p.get("id") or 0))
        ex = str(r["echeance"]["exercice"] or "")
        return ex, "Honoraires", f"Recu_{r['recu_num']}"
    if key == "recu_lot":
        vid = int(p.get("vid") or 0)
        lot_id = int(p.get("lot_id") or 0)
        return "Lotissement", "Reçus", f"Recu_Versement_Lot_{lot_id}_V{vid}"
    return an, "", reports.REPORTS[key].title


def _safe(name: str) -> str:
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]', "-", name).strip(" .") or "Etat"


def rapports_dir(code: str) -> Path:
    return dossier_path(code).parent / "Rapports"


def _browsers() -> list[str]:
    found = [b for b in BROWSERS if Path(b).is_file()]
    found += [w for n in ("chrome", "msedge", "chromium") if (w := shutil.which(n)) and w not in found]
    if not found:
        raise G50Error("Exportation PDF impossible : Google Chrome ou Microsoft Edge est introuvable sur ce poste")
    return found


def html_to_pdf(doc: str, out: Path) -> None:
    tmp = tempfile.mkdtemp()
    try:
        src = Path(tmp) / "etat.html"
        src.write_text(doc, encoding="utf-8")
        tmp_pdf = Path(tmp) / "etat.pdf"
        # the page is generated locally by the application; --no-sandbox only as a fallback for
        # restricted sessions where the sandboxed headless browser cannot start
        attempts = [(b, x) for b in _browsers() for x in (["--headless"], ["--headless", "--no-sandbox"])]
        for i, (browser, extra) in enumerate(attempts):
            cmd = [browser, *extra, "--disable-gpu", "--no-pdf-header-footer", "--no-first-run",
                   f"--user-data-dir={Path(tmp) / f'profile{i}'}", f"--print-to-pdf={tmp_pdf}", src.as_uri()]
            try:
                subprocess.run(cmd, capture_output=True, timeout=120, check=False,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except subprocess.TimeoutExpired as e:
                raise G50Error("Exportation PDF : délai dépassé") from e
            if tmp_pdf.is_file() and tmp_pdf.stat().st_size > 0:
                break
        if not tmp_pdf.is_file() or tmp_pdf.stat().st_size == 0:
            raise G50Error("Erreur lors de la préparation du rapport (PDF non généré).")
        shutil.copyfile(tmp_pdf, out)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def export(key: str, code: str, params: dict, fmt: str) -> dict:
    if fmt not in ("pdf", "xlsx", "doc"):
        raise HTTPException(400, "Format inconnu")
    if fmt == "doc" and key != "contrat":
        raise HTTPException(400, "L’export Word est disponible pour les contrats de travail")
    if key not in reports.REPORTS:
        raise HTTPException(404, f"Rapport inconnu : {key}")
    if key in ("recu_honoraires", "recu_lot"):
        if fmt != "pdf":
            raise HTTPException(400, "Seul l’export PDF est disponible pour les reçus")
        an, sub, name = target(key, code, params)
        folder = rapports_dir(code) / _safe(an or "Divers")
        if sub:
            folder = folder / _safe(sub)
        folder.mkdir(parents=True, exist_ok=True)
        out = folder / f"{_safe(name)}.pdf"
        if key == "recu_honoraires":
            from . import honoraires_html
            rendered_html = honoraires_html.render(code, params)[0]
        else:
            from . import recu_lot_html
            rendered_html = recu_lot_html.render(code, params)[0]
        html_to_pdf(rendered_html, out)
        rel = out.relative_to(rapports_dir(code)).as_posix()
        return {"name": out.name, "path": str(out), "folder": str(folder), "rel": rel, "size": out.stat().st_size}
    pages, title = reports.render_pages(key, code, params)
    an, sub, name = target(key, code, params)
    if fmt == "doc":       # uContrats.btnExportWordClick: Contrats_Word\عقد_عمل_<nom>_<n°>.doc
        c = _one(code, "SELECT c.NumContrat AS n, e.NomPrenom_AR AS na, e.NomPrenom_FR AS nf FROM Contrats c "
                       "LEFT JOIN Employes e ON e.IDEmploye = c.IDEmploye WHERE c.IDContrat = ?", (int(params.get("id") or 0),))
        an, sub = "Contrats_Word", ""
        name = "عقد_عمل_" + (c.get("na") or c.get("nf") or "Employe") + (f"_{c['n']}" if c.get("n") else "")
    folder = rapports_dir(code) / _safe(an or "Divers")
    if sub:
        folder = folder / _safe(sub)
    try:
        folder.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise G50Error("Erreur : impossible de créer le répertoire cible.") from e
    out = folder / f"{_safe(name)}.{fmt}"
    if key == "contrat" and fmt in ("pdf", "doc"):     # redesigned contract (services/contrat_html)
        from . import contrat_html
        if fmt == "pdf":
            html_to_pdf(contrat_html.render(code, params)[0], out)
        else:                                          # Word opens an HTML document saved as .doc
            out.write_text(contrat_html.render(code, params, for_word=True)[0], encoding="utf-8-sig")
    elif key == "ventes" and fmt in ("pdf", "xlsx"):
        from . import ventes_html
        if fmt == "pdf":
            html_to_pdf(ventes_html.render(code, params)[0], out)
        else:
            ventes_html.export_excel(code, params, out)
    elif (key.startswith("lotissement_") or key == "lotissement") and fmt in ("pdf", "xlsx"):
        from . import lotissement_reports
        if fmt == "pdf":
            html_to_pdf(lotissement_reports.render_report_html(key, code, params)[0], out)
        else:
            lotissement_reports.export_lotissement_excel(key, code, params, out)
    elif key.startswith("promotion_") and fmt in ("pdf", "xlsx"):
        from . import promotion_reports
        if fmt == "pdf":
            html_to_pdf(promotion_reports.render_report_html(key, code, params)[0], out)
        else:
            promotion_reports.export_promotion_excel(key, code, params, out)
    elif fmt == "pdf":
        html_to_pdf(html.render(pages, title, inline_images=True), out)
    elif fmt == "doc":
        out.write_bytes(rtf.pages_to_rtf(pages))
    else:
        out.write_bytes(xlsx.pages_to_xlsx(pages, name))
    rel = out.relative_to(rapports_dir(code)).as_posix()
    return {"name": out.name, "path": str(out), "folder": str(folder), "rel": rel, "size": out.stat().st_size}


def file(code: str, rel: str) -> Path:
    base = rapports_dir(code).resolve()
    p = (base / rel).resolve()
    if base not in p.parents or not p.is_file():
        raise HTTPException(404, "Fichier introuvable")
    return p


def open_folder(code: str, rel: str = "") -> str:
    base = rapports_dir(code)
    p = file(code, rel).parent if rel else base
    p.mkdir(parents=True, exist_ok=True)
    if hasattr(os, "startfile"):
        os.startfile(p)  # noqa: S606 — local-first: shows the folder like Delphi's ShellExecute
    return str(p)


# ------------------------------------------------------------------ listes (grilles) → Excel (Unit5 Export_Naftal / Export_Lubrifiants…)
def export_list(code: str | None, annee: str, title: str, columns: list[dict], rows: list[dict], totals: dict | None = None) -> dict:
    from datetime import datetime

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    if not rows:
        raise G50Error("Aucune donnée à exporter !")
    wb = Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\/*?:\[\]]", " ", title)[:31] or "Liste"
    thin = Side(style="thin", color="FFB0B7C3")
    ws.append([title])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([])
    ws.append([c.get("title", c["key"]) for c in columns])
    for i, c in enumerate(columns, 1):
        cell = ws.cell(row=3, column=i)
        cell.font = Font(bold=True, color="FFFFFFFF")
        cell.fill = PatternFill("solid", fgColor="FF334155")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = max(10, min(45, len(str(c.get("title", ""))) + 4))
    for r in rows:
        line = []
        for c in columns:
            v = r.get(c["key"])
            if c.get("money") and v not in (None, ""):
                try:
                    v = float(v)
                except (TypeError, ValueError):
                    pass
            line.append(v)
        ws.append(line)
    if totals:
        ws.append([totals.get(c["key"], "Total" if i == 0 else None) for i, c in enumerate(columns)])
        for i in range(1, len(columns) + 1):
            ws.cell(row=ws.max_row, column=i).font = Font(bold=True)
    for row in ws.iter_rows(min_row=3, max_row=ws.max_row, max_col=len(columns)):
        for i, cell in enumerate(row):
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
            if columns[i].get("money") and isinstance(cell.value, (int, float)):
                cell.number_format = "#,##0"
            longest = len(str(cell.value or ""))
            col = ws.column_dimensions[get_column_letter(i + 1)]
            col.width = max(col.width or 10, min(45, longest + 2))
    ws.freeze_panes = "A4"
    name = f"{_safe(title)} {datetime.now():%Y%m%d_%H%M%S}.xlsx"
    if code:
        folder = rapports_dir(code) / _safe(annee or "Divers") / "Listes"
    else:
        folder = config.PROJECT_ROOT / "data" / "exports"
    folder.mkdir(parents=True, exist_ok=True)
    out = folder / name
    wb.save(out)
    if code:
        rel = out.relative_to(rapports_dir(code)).as_posix()
        return {"name": name, "rel": rel, "url": f"/api/dossiers/{code}/rapports/fichier?rel={rel}", "folder": str(folder)}
    return {"name": name, "rel": None, "url": f"/api/listes/fichier?name={name}", "folder": str(folder)}


def list_file(name: str) -> Path:
    base = (config.PROJECT_ROOT / "data" / "exports").resolve()
    p = (base / Path(name).name).resolve()
    if not p.is_file():
        raise HTTPException(404, "Fichier introuvable")
    return p
