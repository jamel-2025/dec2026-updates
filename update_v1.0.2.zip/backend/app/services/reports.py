"""Report registry: each official report = an .fr3 template from Rapports/ + a data
provider that builds the same datasets the Delphi code binds before ShowReport."""
from __future__ import annotations

import sys
from pathlib import Path
from decimal import ROUND_HALF_UP, Decimal
from html import escape as _escape

from dataclasses import dataclass
from functools import lru_cache
from typing import Callable

from fastapi import HTTPException

from ..core import config
from ..core.db import connect
from ..fr3 import fmt, html
from ..fr3.engine import Report
from . import beneficiaires, dossiers, g50, lotissement, pharma, promotion, salaries, ref, station, ventes


class EmptyReport(Exception):
    """Raised by a provider when Delphi would show 'Aucune ... à imprimer'."""


@dataclass(frozen=True)
class ReportDef:
    key: str
    file: str
    title: str
    provider: Callable[[str, dict], dict[str, list[dict]]]


def _pharma(code: str, params: dict) -> dict[str, list[dict]]:
    # uMain.SpeedButton35Click: DBPharma = TPharma (current exercice), DBSociete = DM.tclient
    rec = pharma.get(code, params.get("exercice", ""))
    if rec is None:
        raise EmptyReport("Aucune déclaration à imprimer pour cet exercice")
    return {"DBPharma": [rec], "DBSociete": [dossiers.societe(code)]}


def _left_join(refs: list[dict], rows: list[dict], ref_key: str, row_key: str, pick: dict[str, str]) -> list[dict]:
    """VirtualQuery 'ref LEFT JOIN detail' of Unit33: every reference line, with the amounts when entered."""
    norm = lambda v: str(v or "").strip().upper()
    out = []
    for r in refs:
        matches = [x for x in rows if norm(x.get(row_key)) == norm(r.get(ref_key))] or [None]
        for m in matches:
            line = {alias: r.get(src) for alias, src in pick.items()}
            line.update(m or {})
            for alias, src in pick.items():      # reference columns win over detail columns of the same name
                line[alias] = r.get(src)
            out.append(line)
    return out


def _g50_vars(g: dict, tva_rows: list[dict], sal: list[dict], tap: list[dict]) -> dict[str, str]:
    """Report variables of TForm33.LoadG50Report (dots when empty, amounts in whole dinars)."""
    dots = "." * 30
    v: dict[str, str] = {}
    num = lambda x: float(x or 0)
    money = lambda x: fmt.format_float("#,##0", x)       # whole dinars (official form), not Delphi's '#,##0.00'
    put = lambda name, x: v.__setitem__(name, money(x) if num(x) > 0 else dots)

    remap = {"E3B11": "E3B1", "E3B12": "E3B2", "E3B13": "E3B3", "E3B14": "E3B4", "E3B15": "E3B5", "E3B16": "E3B6",
             "E3B21": "E3B8", "E3B32": "E3B8", "E3B22": "E3B9", "E3B33": "E3B9", "E3B23": "E3B10", "E3B24": "E3B11",
             "E3B26": "E3B12", "E3B34": "E3B13", "E3B35": "E3B14", "E3B25": "E3B19",
             "E3B27": "E3B99", "E3B36": "E3B99", "E3B31": "E3B99", "E3B37": "E3B99"}
    for i in list(range(1, 46)) + [99]:
        for f in ("CAG", "CAI", "CAE", "DROITS"):
            v[f"TVA_E3B{i}_{f}"] = dots
    st = {1: dict.fromkeys(("CAG", "CAI", "CAE", "DROITS"), 0.0), 2: dict.fromkeys(("CAG", "CAI", "CAE", "DROITS"), 0.0)}
    for t in tva_rows:
        new = remap.get(str(t.get("CODE") or "").strip().upper())
        if not new:
            continue
        for f in ("CAG", "CAI", "CAE", "DROITS"):
            if num(t.get(f)) > 0:
                v[f"TVA_{new}_{f}"] = money(t.get(f))
            st[1 if new in ("E3B1", "E3B2", "E3B3", "E3B4", "E3B5", "E3B6", "E3B7") else 2][f] += num(t.get(f))
    for k in (1, 2):
        for f, x in st[k].items():
            put(f"TVA_ST11_{k}_{f}", x)

    sal_base = sum(num(x.get("Revenusimposables")) for x in sal)
    sal_droits = sum(num(x.get("droits")) for x in sal)
    tap_base = sum(num(x.get("Caimposable")) for x in tap)
    tap_droits = sum(num(x.get("Droits")) for x in tap)
    tap_taux = next((num(x.get("tauxtap")) for x in reversed(tap) if num(x.get("tauxtap")) > 0), 0.0)
    put("SALAIRE_BASE", sal_base); put("SALAIRE_DROITS", sal_droits); put("P2_ST4", sal_droits); put("RECAP_SALAIRES", sal_droits)
    put("TAP_BASE", tap_base); put("TAP_DROITS", tap_droits); put("P6_ST10", tap_droits); put("RECAP_TAP", tap_droits)
    v["TAP_TAUX"] = f"{fmt.format_float('0.##', tap_taux)}%" if tap_taux > 0 else "..%"

    ded = {"DED_PRECOMPTE_ANT": "Précompte_antérieur", "DED_ACHATS": "TTVAachatMatieres", "DED_BIENS": "TVAbiensamortissables",
           "DED_PRORATA_COMPL": "déductioncomplémentaire", "DED_FACTURES_ANNUL": "TVAfacturesannulées",
           "DED_AUTRES": "Autres_déductions", "DED_TOTAL_ST": "Total_des_déductions", "TVA_DROITS_DUS": "Totaldroits_dus",
           "TVA_REGUL_PRORATA_EXC": "déduction_excédentaire", "TVA_REVERSEMENT": "Reversement_de_la_déduction",
           "TVA_TOTAL_RAPPELER": "TOTALaRAPPELER", "TVA_TOTAL_DED": "Total_des_déductions", "TVA_A_PAYER": "TVA_à_payer",
           "TVA_PRECOMPTE_REPORTER": "Précompte_à_reporter", "TVA_AUTOLIQUIDEE": "E3B96"}
    for name, col in ded.items():
        put(name, g.get(col))
    total_final = num(g.get("TVA_à_payer")) + num(g.get("E3B96"))
    put("TVA_TOTAL_FINAL", total_final); put("RECAP_TVA", total_final)
    put("TOTAL_GENERAL", sal_droits + tap_droits + total_final)
    for name in ("P1_ST1", "P1_ST2", "P1_ST3", "P2_ST5", "IBS_BASE_19", "IBS_DROITS_19", "IBS_BASE_23", "IBS_DROITS_23",
                 "IBS_BASE_26", "IBS_DROITS_26", "P3_ST6", "TLS_BASE", "TLS_DROITS", "P4_ST7", "INDIRECTS_ST9",
                 "TIMBRE_BASE", "TIMBRE_DROITS", "AUTRES_BASE", "AUTRES_DROITS", "TVA_REGUL_ACOMPTES", "RECAP_IRG_RET",
                 "RECAP_RCM", "RECAP_LOCATIF", "RECAP_PROF", "RECAP_IBS", "RECAP_TLS", "RECAP_INDIRECTS",
                 "RECAP_TIMBRE", "RECAP_AUTRES"):
        v.setdefault(name, dots)
    v.setdefault("TLS_TAUX", "..%")
    return v


def _g50(code: str, params: dict) -> dict[str, list[dict]]:
    """uMain.PrepareG50Data + TForm33.LoadG50Report (classic model)."""
    idg50 = int(params.get("idg50") or 0)
    try:
        g50.recalc(code, idg50)          # the printed form always reflects the current lines
    except HTTPException:
        raise EmptyReport("Déclaration G50 introuvable") from None
    with connect(code) as c:
        g = c.execute("SELECT * FROM G50 WHERE idg50 = ?", (idg50,)).fetchone()
        if g is None:
            raise EmptyReport("Déclaration G50 introuvable")
        g = dict(g)
        q = lambda sql: [dict(r) for r in c.execute(sql, (idg50,))]
        tva = q('SELECT * FROM TVA WHERE "Idg50" = ? ORDER BY "ID"')
        tap = q('SELECT * FROM TAP WHERE "Idg50" = ? ORDER BY "idtap"')
        tls = q('SELECT * FROM TLS WHERE "Idg50" = ? ORDER BY "IDTLS"')
        sal = q('SELECT * FROM IRGSalaires WHERE "Idg50" = ? ORDER BY "ID"')
        timbre = q('SELECT G50.idg50 AS ISG, Timbre.Caimposable, Timbre.droits FROM G50 LEFT JOIN Timbre '
                   'ON G50.idg50 = Timbre.Idg50 WHERE G50.idg50 = ?')
        autres = q('SELECT G50.idg50 AS ISG, A.Revenusimposables, A.impots, A.droits, A.code AS Code, A.taux '
                   'FROM G50 LEFT JOIN AutresTaxes A ON G50.idg50 = A.Idg50 WHERE G50.idg50 = ?')
    tap_cols = {"CODE": "CODE", "n": "N", "IMPOTS": "IMPOTS"}
    data = {
        "DBG50": [g],
        "DBSociete": [dossiers.societe(code)],
        "DBtva": _left_join(ref.table("TVAref"), tva, "CODE", "CODE", {"CODE": "CODE", "nature": "NATURE", "OP_TEXT": "OPÉRATIONS"}),
        "DBtap": _left_join(ref.table("TAPRef"), tap, "IMPOTS", "impots", tap_cols),
        "DBtls": _left_join(ref.table("TlsRef"), tls, "IMPOTS", "impots", tap_cols),
        "DBsalaires": _left_join(ref.table("IRGIBSRef"), sal, "CODE", "code", {"CODE": "CODE", "n": "N", "IMPOTS": "IMPOTS"}),
        "DBtimbre": timbre,
        "DBautres": autres,
        "DBibs": tva,
    }
    year = int(float(g.get("Année") or 0))
    out = {"__vars__": _g50_vars(g, tva, sal, tap), "__template__": "G50_TAP.fr3" if year < 2024 else "G50_2024.fr3", **data}
    out["__texts__"], out["__colors__"] = _g50_header(g, data["DBSociete"][0])
    if year >= 2024:
        totals, colors = _g50_2024_totals(g, code=code, idg50=idg50)
        out["__texts__"].update(totals)
        out["__colors__"].update(colors)
    return out


MOIS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]
MOIS_AR = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def _g50_header(g: dict, s: dict) -> tuple[dict[str, str], dict]:
    """Identification block of the G50 form (both templates). Delphi left it as printed dots; it is filled from the
    company file and the period. The form's blue labels are kept; the values are printed in black, at the size of
    the « Profession/Activité » and « Adresse » lines. Empty fields keep their dots. « Trimestre / الفصل » stays
    blank: the application files monthly declarations only."""
    val = lambda k: str(s.get(k) or "").strip()
    try:
        m = int(float(g.get("Mois") or 0))
    except ValueError:
        m = 0
    mois_fr = MOIS_FR[m - 1] if 1 <= m <= 12 else str(g.get("leMois") or "").strip()
    mois_ar = MOIS_AR[m - 1] if 1 <= m <= 12 else ""
    annee = str(g.get("Année") or "").strip()

    def v(x: str, dots: int, size: float = 11.0) -> str:
        if not x:
            return "." * dots
        return f'<span style="display:inline;color:#000000;font-size:{size:g}px">{_escape(x)}</span>'

    texts = {
        "TableCell139": f"{v(mois_ar, 25, 9)} : الشهر",
        "TableCell161": f"{v(annee, 25, 9)} : السنة",
        "TableCell158": f"{v(val('direction'), 34)} :. مديرية ",
        "TableCell169": f"DIRECTION : {v(val('direction'), 32)}",
        "TableCell172": f"Mois de {v(mois_fr, 15, 9)}",
        "TableCell180": f"{v(val('inspection'), 26)} : مصلحة الضرائب لـ",
        "TableCell191": f"STRUCTURE : {v(val('inspection'), 46)}",
        "TableCell194": f"Année : {v(annee, 23, 9)}",
        "TableCell202": f"قباضة الضرائب : {v(val('recette'), 45)}",
        "TableCell213": f"RECETTE DES IMPOTS DE : {v(val('recette'), 20)}",
        "TableCell89": f"COMMUNE DE : {v(val('commune'), 31)}",
        "TableCell100": f"NIN : {v(val('NIN'), 0)}",
        "TableCell111": f"NIF : {v(val('NIF'), 0)}",
        "TableCell115": v(val("fj").upper(), 0),   # « F. J. » cell is 20 px wide: the value goes in the free cell beside it
        "TableCell122": f"Article d’imposition : {v(val('article'), 0)}",
    }
    styles = {k: {"html": True, "overflow": True, "wrap": False} for k in texts}
    styles["TableCell115"]["halign"] = "left"
    return texts, styles


# Totals the official G50 2024 form leaves blank (Delphi printed dots): recap column, « MONTANT TOTAL A PAYER »,
# TOTAL rows of the IBS / IRG sections and of the « régime des acomptes provisionnels » (TLS hydrocarbures / mines,
# no data in the application → 0). Black static labels of page 3 are printed in the form's blue like the others.
G50_2024_BLACK_LABELS = [
    "P2R2B1Cell103", "P2R2B1Cell106", "P2R2B2Cell109", "P2R2B3Cell115", "P2R2B4Cell121", "P2R2B5Cell127", "P2R2B6Cell133",
    "P2R2B6Cell136", "P2R2B7Cell139", "P2R2B8Cell145", "P2R2B9Cell151", "P2R2B10Cell157", "P2RTotalCell163",
    "P2RFoot1Cell167", "P2RFoot2Cell168", "TableCell362", "TableCell289", "TableCell290", "TableCell219",
]
FORM_BLUE = "#0000ff"


def _g50_2024_totals(g: dict, code: str = "", idg50: int = 0) -> tuple[dict[str, str], dict]:
    n = lambda k: float(g.get(k) or 0)
    w = _whole
    ibs_acomptes, ibs_retenues = n("st2"), n("st33")
    irg_retenues = n("st31") + n("st32")
    irg_acompte_val = 0.0

    # Retrieve IBS and IRG acompte rows linked to this declaration
    ibs_row = None
    irg_row = None
    ibs_solde_row = None
    irg_solde_row = None
    if code and idg50:
        with connect(code) as c:
            ibs_row = c.execute('SELECT code, impots, droits FROM IBSAcomptes WHERE "Idg50" = ? LIMIT 1', (idg50,)).fetchone()
            irg_row = c.execute('SELECT code, impots, droits FROM IRGAcomptes WHERE "Idg50" = ? LIMIT 1', (idg50,)).fetchone()
            cols_ibs_solde = {r[1] for r in c.execute('PRAGMA table_info(IBSsolde)')}
            if "idg50" in cols_ibs_solde:
                ibs_solde_row = c.execute('SELECT Soldedeliquidation, Excédentversement FROM IBSsolde WHERE "idg50" = ? LIMIT 1', (idg50,)).fetchone()
            cols_irg_solde = {r[1] for r in c.execute('PRAGMA table_info(IRGsolde)')}
            if "idg50" in cols_irg_solde:
                irg_solde_row = c.execute('SELECT Soldedeliquidation, Excédentversement FROM IRGsolde WHERE "idg50" = ? LIMIT 1', (idg50,)).fetchone()

    ibs_solde_val = float(ibs_solde_row["Soldedeliquidation"] or 0) if ibs_solde_row else 0.0
    irg_solde_val = float(irg_solde_row["Soldedeliquidation"] or 0) if irg_solde_row else 0.0
    if irg_row:
        irg_acompte_val = float(irg_row["droits"] or 0)
    irg_total_table3 = irg_acompte_val + irg_solde_val

    recap = [ibs_acomptes, ibs_retenues, irg_total_table3, irg_retenues, n("st1"), n("st4"), n("st5"), n("st6")]
    # whole dinars, half up; the total is the sum of the printed lines (no centime gap on the official form)
    recap = [float(int(Decimal(str(v)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))) for v in recap]
    texts = {f"TableCell{9300 + i}": w(v) for i, v in enumerate(recap)}
    sal_base = 0.0
    if code and idg50:
        with connect(code) as c:
            sal_rows = c.execute('SELECT Revenusimposables FROM IRGSalaires WHERE "Idg50" = ?', (idg50,)).fetchall()
            sal_base = sum(float(r[0] or 0) for r in sal_rows)

    texts.update({
        "TableCell9703": w(sum(recap)),                 # MONTANT TOTAL A PAYER
        "TableCell9828": w(ibs_acomptes),               # 1 — IBS : acompte / solde de liquidation
        "TableCell9853": w(ibs_retenues),               # 2 — IBS : retenues à la source
        "TableCell9873": w(irg_total_table3),           # 3 — IRG (BIC/BNC/RA) : acompte / solde
        "TableCell9909": w(irg_retenues),               # 4 — IRG : retenues à la source (was the last row only)
        "TableCellFix_20": w(0),                        # II — régime des acomptes provisionnels
    })
    if sal_base > 0:
        texts["TableCell9884_base"] = w(sal_base)

    # Detailed rows for Table 1 (IBS) and Table 3 (IRG) if an acompte or solde is linked
    if ibs_row:
        texts["TableCell9809"] = str(ibs_row["code"] or "E1M10")
        texts["TableCell9810"] = f"  {ibs_row['impots']} provisionnel IBS"
        texts["TableCell9812"] = w(float(ibs_row["droits"] or 0))

    if ibs_solde_row:
        texts["TableCell9813"] = "E1M20"
        texts["TableCell9814"] = "  Solde de liquidation IBS"
        texts["TableCell9816"] = w(ibs_solde_val)

    if irg_row:
        texts["TableCell9862"] = str(irg_row["code"] or "E3L20")
        texts["TableCell9863"] = f"  {irg_row['impots']} provisionnel IRG"
        texts["TableCell9865"] = w(irg_acompte_val)

    if irg_solde_row:
        texts["TableCell9866"] = "E3L40"
        texts["TableCell9867"] = "  Solde de liquidation IRG"
        texts["TableCell9869"] = w(irg_solde_val)

    styles: dict = dict.fromkeys(G50_2024_BLACK_LABELS, FORM_BLUE)
    # amounts printed like the TVA rights of the form (Arial 13 px, black), in bold
    amount = {"color": "#000000", "font_size": 13.0, "bold": True, "halign": "right", "valign": "center"}
    for name in [f"TableCell{9300 + i}" for i in range(8)] + ["TableCell9703", "TableCell9828", "TableCell9853", "TableCell9873",
                                                              "TableCell9909", "TableCellFix_20", "TableCell9812", "TableCell9816",
                                                              "TableCell9865", "TableCell9869", "TableCell9884_base"]:
        styles[name] = amount
    if ibs_row:
        styles["TableCell9809"] = {"color": "#000000", "font_size": 11.0, "bold": True, "halign": "center", "valign": "center"}
        styles["TableCell9810"] = {"color": "#000000", "font_size": 11.0, "bold": False, "halign": "left", "valign": "center"}
    if ibs_solde_row:
        styles["TableCell9813"] = {"color": "#000000", "font_size": 11.0, "bold": True, "halign": "center", "valign": "center"}
        styles["TableCell9814"] = {"color": "#000000", "font_size": 11.0, "bold": False, "halign": "left", "valign": "center"}
    if irg_row:
        styles["TableCell9862"] = {"color": "#000000", "font_size": 11.0, "bold": True, "halign": "center", "valign": "center"}
        styles["TableCell9863"] = {"color": "#000000", "font_size": 11.0, "bold": False, "halign": "left", "valign": "center"}
    if irg_solde_row:
        styles["TableCell9866"] = {"color": "#000000", "font_size": 11.0, "bold": True, "halign": "center", "valign": "center"}
        styles["TableCell9867"] = {"color": "#000000", "font_size": 11.0, "bold": False, "halign": "left", "valign": "center"}

    # the two spare rows under « 8- TVA » have no frame in the template: close the left border of the column
    for name in ("TableCell9108", "TableCell9109"):
        styles[name] = {"frame": {"left": True}}
    return texts, styles


def _whole(v) -> str:
    return fmt.format_float("#,##0", v)


_ETAT_SQL = '''SELECT D."IDg50", F."NIN", F."NIF", COALESCE(F.rs, D.fournisseur) AS rs, F.adresse, F.rcom,
       D.datrfqcture, D.nfacture, COALESCE(D.ht, 0) + COALESCE(D.tvadroits, 0) AS TTC, D.ht, D.tvadroits,
       D."IDDetailEtatTVA", D."Année", D."leMois", G."Mois"
  FROM DetailEtatTVA D
  LEFT JOIN fournisseurTva F ON D."IDfournisseurTva" = F."IDfournisseurTva"
  JOIN G50 G ON D."IDg50" = G.idg50'''


def _money2(v) -> str:
    return fmt.format_float("#,##0.00", v)


def _etat_tva(code: str, params: dict) -> dict:
    """Unit6 / RetatTVA — QEtatTVA (invoices of the declaration). Suppliers are LEFT-joined so
    that every deducted invoice appears on the statement attached to the G50."""
    idg50 = int(params.get("idg50") or 0)
    with connect(code) as c:
        g = c.execute("SELECT * FROM G50 WHERE idg50 = ?", (idg50,)).fetchone()
        if g is None:
            raise EmptyReport("Déclaration G50 introuvable")
        rows = [dict(r) for r in c.execute(_ETAT_SQL + ' WHERE D."IDg50" = ? ORDER BY D.datrfqcture, D."IDDetailEtatTVA"', (idg50,))]
    if not rows:
        raise EmptyReport("Aucune déduction effectuée ce mois-ci")
    total = sum(float(r["tvadroits"] or 0) for r in rows)
    return {"DBEtatTVA": rows, "DBg50": [dict(g)], "DBSociete": [dossiers.societe(code)],
            "__whole_amounts__": False,
            "__texts__": {"TableCell269": _money2(total), **_arrete(total)}}        # script ReportSummary1OnBeforePrint


def _arrete(total: float) -> dict[str, str]:
    """« Arrêté le présent état contenant … page(s) … à la somme totale de … » — the official form leaves the
    number of pages and the total blank (dots); they are filled (page count resolved after pagination)."""
    pages, amount = "\x00TOTALPAGES\x00", _money2(total)
    return {
        "TableCell207": f"Arrêté le présent état contenant {pages} page (s) numérotée(s) de 1 à {pages} à la somme totale "
                        f"de la taxe sur la valeur ajoutée déduite de : {amount} DA",
        "TableCell216": f"يوقف حساب هذا الكشف وهو يحتوي على عدد {pages} صفحة مرقمة من 1 إلى {pages} "
                        f"المبلغ الإجمالي للرسم على القيمة المضافة المخصوم {amount} دج",
    }


def _etat_tva_annee(code: str, params: dict) -> dict:
    """Unit38 / RetatTVAannee — QEtatTVAannee (all invoices of the exercice, by month)."""
    annee = str(params.get("exercice") or params.get("annee") or "")
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(_ETAT_SQL + ' WHERE D."Année" = ? ORDER BY G."Mois", D.datrfqcture', (annee,))]
    if not rows:
        raise EmptyReport("Aucune déduction effectuée cette année-ci")
    total = sum(float(r["tvadroits"] or 0) for r in rows)
    return {"DBEtatTVAanne": rows, "DBg50": [], "DBSociete": [dossiers.societe(code)],
            "__whole_amounts__": False,
            "__texts__": {"TableCell269": _money2(total), **_arrete(total)}}


TRIMESTRES = {1: "1er trimestre", 2: "2ème trimestre", 3: "3ème trimestre", 4: "4ème trimestre"}


def _etat_tva_trim(code: str, params: dict) -> dict:
    """État de récupération de TVA trimestriel (addition): the annual statement (RetatTVAannee) restricted to the
    three months of the quarter, period printed as « 1er trimestre 2024 »."""
    annee = str(params.get("exercice") or params.get("annee") or "")
    t = int(params.get("trimestre") or 0)
    if t not in TRIMESTRES:
        raise EmptyReport("Veuillez sélectionner un trimestre valide (1 à 4)")
    with connect(code) as c:
        rows = [dict(r) for r in c.execute(_ETAT_SQL + ' WHERE D."Année" = ? AND CAST(G."Mois" AS INTEGER) BETWEEN ? AND ? '
                                           'ORDER BY G."Mois", D.datrfqcture', (annee, 3 * t - 2, 3 * t))]
    if not rows:
        raise EmptyReport(f"Aucune déduction effectuée au {TRIMESTRES[t]} {annee}")
    total = sum(float(r["tvadroits"] or 0) for r in rows)
    return {"DBEtatTVAanne": rows, "DBg50": [], "DBSociete": [dossiers.societe(code)],
            "__whole_amounts__": False,
            "__texts__": {"TableCell269": _money2(total), "TableCell117": f"Période :   {TRIMESTRES[t]} {annee}", **_arrete(total)},
            "__template__": "RetatTVAannee.fr3"}


def _recap_annee(code: str, params: dict) -> dict:
    """Unit28 / RecapAnnee — Qtap, QRTva, Qsalaires, Qtimbre, Qautres (Unit20); empty pages hidden."""
    annee = str(params.get("exercice") or params.get("annee") or "")
    with connect(code) as c:
        q = lambda sql: [dict(r) for r in c.execute(sql, (annee,))]
        tap = q('''SELECT G.Mois, G.leMois, G."Année" AS Exercice, T."Idg50" AS IDG50, SUM(T.CAbrut) AS CAbruts,
                   SUM(T.CAexo) AS CAexos, SUM(T.CArefaction) AS CArefactions, SUM(T.CASrefaction) AS CASrefactions,
                   SUM(T.CAtaxable) AS CAtaxables, SUM(T.Droits) AS Droitss
                   FROM TAP T JOIN G50 G ON T."Idg50" = G.idg50 WHERE G."Année" = ?
                   GROUP BY G.Mois, G.leMois, G."Année", T."Idg50" ORDER BY G.Mois''')
        tva = q('''SELECT G."Année" AS Exercice, G.Mois, G.leMois, T."Idg50" AS IDG50, SUM(T.caN) AS TN, SUM(T.car) AS TR,
                   SUM(T.Caexo) AS TEXO, SUM(T.CAG) AS TotalCA, SUM(T.DROITS) AS SumOfDROITS, G.TTVAachatMatieres,
                   G.TVAbiensamortissables, G."Autres_déductions", G."Reversement_de_la_déduction",
                   G."Précompte_antérieur", G."TVA_à_payer", G."Précompte_à_reporter"
                   FROM TVA T JOIN G50 G ON T."Idg50" = G.idg50 WHERE G."Année" = ?
                   GROUP BY G."Année", G.Mois, G.leMois, T."Idg50" ORDER BY G.Mois''')
        sal = q('''SELECT G.leMois, G."Année", G.Mois, S.Revenusimposables AS REVENUSIMPOSABLES, S.taux AS TAUX,
                   S.droits AS DROITS, S.impots AS IMPOTS FROM IRGSalaires S JOIN G50 G ON S."Idg50" = G.idg50
                   WHERE G."Année" = ? ORDER BY G.Mois, S."ID"''')
        timbre = q('''SELECT G.leMois, G."Année", G.Mois, T.Caimposable AS CAIMPOSABLE, T.taux AS TAUX, T.droits AS DROITS,
                      T.impots AS IMPOTS FROM Timbre T JOIN G50 G ON T."Idg50" = G.idg50 WHERE G."Année" = ? ORDER BY G.Mois''')
        autres = q('''SELECT G.leMois, G."Année", G.Mois, A.impots, A.Revenusimposables AS REVENUSIMPOSABLES, A.taux AS TAUX,
                      A.droits AS DROITS FROM G50 G JOIN AutresTaxes A ON G.idg50 = A."Idg50" WHERE G."Année" = ? ORDER BY G.Mois''')
    sets = {"RecapTAP": tap, "RecapTVA": tva, "RecapIRGsalaire": sal, "RecapTimbre": timbre, "RecapAutres": autres}
    pages = {"TAP": tap, "TVA": tva, "Salaires": sal, "Timbre": timbre, "Autres": autres}
    hidden = {name for name, rows in pages.items() if not rows}          # TForm28.FormActivate
    if len(hidden) == len(pages):
        raise EmptyReport(f"Aucune déclaration G50 pour l’exercice {annee}")
    return {**sets, "DBSociete": [dossiers.societe(code)], "__hidden_pages__": hidden}


def _recap_g50(code: str, params: dict) -> dict:
    """Unit37 / Recap (embedded report) — QUnionG50 lines of the declaration + its TVA block.
    TLS lines are included (Delphi's union predates TLS replacing TAP in 2024)."""
    idg50 = int(params.get("idg50") or 0)
    try:
        g50.recalc(code, idg50)
    except HTTPException:
        raise EmptyReport("Déclaration G50 introuvable") from None
    with connect(code) as c:
        g = dict(c.execute("SELECT * FROM G50 WHERE idg50 = ?", (idg50,)).fetchone())
        union = [dict(r) for r in c.execute('''
            SELECT "Idg50" AS IDg50, code AS CODE, impots, Caimposable, tauxtap AS TAUXTAP, Droits, NT AS Nat FROM TAP WHERE "Idg50" = :i
            UNION ALL SELECT "Idg50", code, impots, Caimposable, tauxtap, Droits, NT FROM TLS WHERE "Idg50" = :i
            UNION ALL SELECT "Idg50", code, impots, Revenusimposables, taux, droits, NT FROM IRGSalaires WHERE "Idg50" = :i
            UNION ALL SELECT "Idg50", code, impots, Caimposable, taux, droits, NT FROM Timbre WHERE "Idg50" = :i
            UNION ALL SELECT "Idg50", CODE, "OPérations", CAI, TAUX, DROITS, NT FROM TVA WHERE "Idg50" = :i
            UNION ALL SELECT "Idg50", code, impots, Revenusimposables, taux, droits, NT FROM AutresTaxes WHERE "Idg50" = :i''',
            {"i": idg50})]
    return {"Dbnature": union, "DBG50": [g], "DBg50": [g], "DBopTVA": [g], "DBSociete": [dossiers.societe(code)],
            "__template__": "Unit37.Recap.fr3"}


def _ibs(code: str, params: dict) -> dict:
    """uMain.SpeedButton29Click — RIbs with RecapIBS = solde of the exercice."""
    exercice = str(params.get("exercice") or "")
    with connect(code) as c:
        row = c.execute('SELECT * FROM IBSsolde WHERE CAST("Exercice" AS TEXT) = ? ORDER BY "ID" LIMIT 1', (exercice,)).fetchone()
    if row is None:
        raise EmptyReport("Aucun solde IBS à imprimer")
    return {"RecapIBS": [dict(row)], "DBSociete": [dossiers.societe(code)]}


def _irg(code: str, params: dict) -> dict:
    """uMain.SpeedButton30Click — RIrg with RecapIrg = solde IRG of the exercice."""
    exercice = str(params.get("exercice") or "")
    with connect(code) as c:
        row = c.execute('SELECT * FROM IRGsolde WHERE CAST("Exercice" AS TEXT) = ? ORDER BY "IDIRGsolde" LIMIT 1', (exercice,)).fetchone()
    if row is None:
        raise EmptyReport("Aucun solde IRG à imprimer")
    return {"RecapIrg": [dict(row)], "DBSociete": [dossiers.societe(code)]}


def _tapp(code: str, params: dict) -> dict:
    """uMain.SpeedButton34Click — RTAPP.fr3 (from Rapports) for the selected declaration."""
    decl = int(params.get("id") or 0)
    with connect(code) as c:
        row = c.execute('SELECT * FROM DeclarationTAPP WHERE "IDDeclarationTAPP" = ?', (decl,)).fetchone()
    if row is None:
        raise EmptyReport("Aucune déclaration TAPP-TF à imprimer")
    return {"DBTAPP": [dict(row)], "DBSociete": [dossiers.societe(code)]}


def _ventes(code: str, params: dict) -> dict:
    """Unit44.PrepareAndBuildReport — ReportSales (embedded) for the year or one month."""
    annee, mois = str(params.get("exercice") or ""), str(params.get("mois") or "")
    rows = ventes.list_(code, annee, mois)["items"]
    if not rows:
        raise EmptyReport("Aucune facture de vente à imprimer")
    title = f"ETAT DES VENTES - MOIS DE : {mois.upper()} {annee}" if mois else f"ETAT DES VENTES ANNUELLES - ANNEE : {annee}"
    return {"DBSales": rows, "__texts__": {"MemoTitle": title}, "__template__": "Unit44.ReportSales.fr3"}


def _encaissements(code: str, params: dict) -> dict:
    """Unit19 / Unit20.Rencaissem (embedded) — payments of the exercice, as filtered in the grid."""
    rows = promotion.rows(code, str(params.get("exercice") or ""), str(params.get("projet") or ""), str(params.get("q") or ""))
    if not rows:
        raise EmptyReport("Aucun état à imprimer")
    # correction of the embedded report: the « Mode Ver » column printed the project
    return {"BDEncaissements": rows, "DBSociete": [dossiers.societe(code)],
            "__bind__": {"TableCell57": '[BDEncaissements."ModeReg"]'}, "__template__": "Unit20.Rencaissem.fr3"}


def _projet(code: str, params: dict) -> dict:
    """Unit17.Rproj (embedded) — payments of one project (« Imprimer » of the projects list)."""
    projet = str(params.get("projet") or "").strip()
    rows = [r for r in promotion.rows(code, str(params.get("exercice") or ""), projet) if str(r.get("Projet") or "").strip() == projet]
    if not rows:
        raise EmptyReport("Aucun versement pour ce projet")
    return {"BDEncaissements": rows, "Dbproj": [{"Projet": projet}], "DBSociete": [dossiers.societe(code)],
            "__bind__": {"TableCell57": '[BDEncaissements."ModeReg"]'}, "__template__": "Unit17.Rproj.fr3"}


def _lotissement(code: str, params: dict) -> dict:
    """uMain.SpeedButton53 — Unit36.frxReport2: étude, lots, TCR, versements, créances (TAP removed)."""
    lid = int(params.get("id") or 0)
    lst = lotissement.lots(code, lid)
    return {"DBlotissement": [lst["study"]], "DBlots": lst["items"], "DBTCR": lotissement.tcr(code, lid),
            "DBvers": lotissement.versements(code, lid), "DBcreances": lotissement.creances(code, lid),
            # correction: « Total superficie à vendre » printed the total area
            "__bind__": {"TableCell294": '[DBlotissement."SupTotaleVendre"]'},
            "__hide_token__": "TAP", "__template__": "Unit36.frxReport2.fr3"}


def _contrat(code: str, params: dict) -> dict:
    """uContrats.BuildContractReport — Rapports/Contrat_<type>.fr3 with the [Var] placeholders."""
    try:
        d = salaries.print_data(code, int(params.get("id") or 0))
        return {"__vars__": d["variables"], "__texts__": d["texts"], "__template__": d["template"]}
    except HTTPException as e:
        raise EmptyReport(str(e.detail)) from e


def _beneficiaire(code: str, params: dict) -> dict:
    """uBeneficiaireEffectif.PrepareFastReport — Rapports/Beneficiaire_Effectif.fr3 (4 pages)."""
    try:
        return {"__vars__": beneficiaires.print_variables(code, int(params.get("id") or 0)), "__template__": "Beneficiaire_Effectif.fr3"}
    except HTTPException as e:
        raise EmptyReport(str(e.detail)) from e


def _station_mois(code: str, params: dict) -> dict:
    """Unit32 / Unit5.RsatationM — monthly station statement."""
    try:
        d = station.detail(code, int(params.get("id") or 0))
    except HTTPException as e:
        raise EmptyReport(str(e.detail)) from e
    lines = d.pop("lines")
    d.pop("prices", None)
    # Corrections of the embedded report: the supplier column printed TVAachat and the
    # « Achats TTC » column printed Marge.
    bind = {"TableCell99": '[DBlurifiants."Fournisseur"]', "TableCell160": '[DBlurifiants."AchatTTC"]'}
    return {"DBNaftal": lines["carburants"], "DBlurifiants": lines["lubrifiants"], "DBprestation": lines["prestations"],
            "DBstation": [d], "DBSociete": [dossiers.societe(code)], "__bind__": bind, "__template__": "Unit5.RsatationM.fr3"}


def _station_annee(code: str, params: dict) -> dict:
    """Unit21.Rstation — annual statement; totals written in the footer cells (CalculerTotauxStation)."""
    y = station.year(code, str(params.get("exercice") or ""))
    if not y["items"]:
        raise EmptyReport("Aucun état à imprimer")
    t = y["totals"]
    cells = {"TableCell221": "SecteurpetrolierCA", "TableCell222": "ReventeCA", "TableCell223": "PrestationCA",
             "TableCell224": "ReventeTVA", "TableCell225": "PrestationTVA", "TableCell226": "TotalCA", "TableCell227": "TotalTVA"}
    variables = {"TotSecteurCA": t["SecteurpetrolierCA"], "TotReventeCA": t["ReventeCA"], "TotPrestationCA": t["PrestationCA"],
                 "TotReventeTVA": t["ReventeTVA"], "TotPrestationTVA": t["PrestationTVA"], "TotCA": t["TotalCA"], "TotTVA": t["TotalTVA"]}
    return {"DBstation": y["items"], "DBSociete": [dossiers.societe(code)], "__vars__": variables,
            "__texts__": {cell: _whole(t[k]) for cell, k in cells.items()}, "__template__": "Unit21.Rstation.fr3"}


REPORTS: dict[str, ReportDef] = {
    r.key: r for r in (
        ReportDef("pharma", "RPharma.fr3", "Etat détaillant le chiffre d'affaires — Pharmacie", _pharma),
        ReportDef("g50", "G50_2024.fr3", "Déclaration G50", _g50),
        ReportDef("etat_tva", "RetatTVA.fr3", "État de récupération de TVA", _etat_tva),
        ReportDef("etat_tva_annee", "RetatTVAannee.fr3", "État de récupération de TVA — année", _etat_tva_annee),
        ReportDef("etat_tva_trim", "RetatTVAannee.fr3", "État de récupération de TVA — trimestre", _etat_tva_trim),
        ReportDef("recap_annee", "RecapAnnee.fr3", "Récapitulatif annuel", _recap_annee),
        ReportDef("recap_g50", "Unit37.Recap.fr3", "Récapitulatif G50", _recap_g50),
        ReportDef("ibs", "RIbs.fr3", "Solde de liquidation IBS", _ibs),
        ReportDef("irg", "RIrg.fr3", "Solde de liquidation IRG", _irg),
        ReportDef("tapp", "RTAPP.fr3", "Déclaration TAPP-TFP", _tapp),
        ReportDef("ventes", "Unit44.ReportSales.fr3", "Etat des ventes", _ventes),
        ReportDef("encaissements", "Unit20.Rencaissem.fr3", "Etat des versements", _encaissements),
        ReportDef("projet", "Unit17.Rproj.fr3", "Versements du projet", _projet),
        ReportDef("lotissement", "Unit36.frxReport2.fr3", "Situation du lotissement", _lotissement),
        ReportDef("contrat", "Contrat_CDD.fr3", "Contrat de travail", _contrat),
        ReportDef("beneficiaire", "Beneficiaire_Effectif.fr3", "Déclaration du bénéficiaire effectif", _beneficiaire),
        ReportDef("station_mois", "Unit5.RsatationM.fr3", "Etat mensuel — station-service", _station_mois),
        ReportDef("station_annee", "Unit21.Rstation.fr3", "Etat annuel — station-service", _station_annee),
        ReportDef("recu_honoraires", "Recu_Honoraires.fr3", "وصل استلام أتعاب", lambda c, p: {}),
        ReportDef("convention", "Convention_Honoraires.fr3", "اتفاقية أتعاب ومسك المحاسبة", lambda c, p: {}),
        ReportDef("recu_lot", "Recu_Lot.fr3", "وصل استلام دفعة قطعة أرضية", lambda c, p: {}),
        ReportDef("lotissement_plan", "Unit36.frxReport2.fr3", "مخطط التجزئة العقارية A4", lambda c, p: {}),
        ReportDef("lotissement_lots", "Unit36.frxReport2.fr3", "قائمة القطع الأرضية", lambda c, p: {}),
        ReportDef("lotissement_facturation", "Unit36.frxReport2.fr3", "Chiffre d’affaires facturé", lambda c, p: {}),
        ReportDef("lotissement_versements", "Unit36.frxReport2.fr3", "كشف المقبوضات والتسبيقات", lambda c, p: {}),
        ReportDef("lotissement_creances", "Unit36.frxReport2.fr3", "كشف الديون والمستحقات", lambda c, p: {}),
        ReportDef("lotissement_annuelle", "Unit36.frxReport2.fr3", "الوضعية السنوية TCR", lambda c, p: {}),
        ReportDef("lotissement_situation", "Unit36.frxReport2.fr3", "Situation du lotissement", lambda c, p: {}),
        ReportDef("promotion_plan", "Unit17.Rproj.fr3", "مخطط الترقية العقارية A4", lambda c, p: {}),
        ReportDef("promotion_unites", "Unit17.Rproj.fr3", "قائمة الوحدات العقارية", lambda c, p: {}),
        ReportDef("promotion_facturation", "Unit17.Rproj.fr3", "رقم الأعمال المفوتر", lambda c, p: {}),
        ReportDef("promotion_versements", "Unit17.Rproj.fr3", "كشف مقبوضات الترقية", lambda c, p: {}),
        ReportDef("promotion_creances", "Unit17.Rproj.fr3", "كشف ديون الترقية", lambda c, p: {}),
        ReportDef("promotion_annuelle", "Unit17.Rproj.fr3", "الوضعية السنوية للترقية", lambda c, p: {}),
    )
}


@lru_cache(maxsize=32)
def _template(path: str, mtime: float) -> Report:
    return Report(path)


def template(name: str) -> Report:
    candidates = [
        config.RAPPORTS_DIR / name,
        config.PROJECT_ROOT / "Rapports" / name,
        config.PROJECT_ROOT / name,
        config.DELPHI_ROOT / "Rapports" / name,
        config.DELPHI_ROOT / name,
        config.SPEC_DIR / "reports" / name,
    ]
    if getattr(sys, "frozen", False):
        exe_dir = Path(sys.executable).resolve().parent
        candidates.extend([
            exe_dir / "Rapports" / name,
            exe_dir / "_internal" / "Rapports" / name,
            Path(getattr(sys, "_MEIPASS", "")) / "Rapports" / name,
        ])
    for p in candidates:
        if p and p.is_file():
            return _template(str(p), p.stat().st_mtime)
    raise HTTPException(500, f"Modèle introuvable : {name}")


def status(key: str, code: str, params: dict) -> dict:
    """Whether the report has data (Delphi: IsEmpty check before ShowReport)."""
    if key.startswith("lotissement_") or key == "lotissement":
        return {"available": True, "message": None}
    if key.startswith("promotion_") or key == "promotion":
        return {"available": True, "message": None}
    if key == "convention":
        return {"available": True, "message": None}
    if key == "recu_lot":
        from . import recu_lot_html
        try:
            recu_lot_html.render(code, params)
            return {"available": True, "message": None}
        except Exception as e:
            return {"available": False, "message": str(e)}
    if key == "recu_honoraires":
        from . import honoraires
        try:
            honoraires.get_recu_paiement(code, int(params.get("id") or 0))
            return {"available": True, "message": None}
        except Exception as e:
            return {"available": False, "message": str(e)}

    d = REPORTS.get(key)
    if d is None:
        raise HTTPException(404, f"Rapport inconnu : {key}")
    try:
        d.provider(code, params)
    except EmptyReport as e:
        return {"available": False, "message": str(e)}
    return {"available": True, "message": None}


def render_html(key: str, code: str, params: dict, inline_images: bool = False) -> str:
    if key == "contrat":                       # redesigned layout, content read from the Delphi template
        from . import contrat_html
        return contrat_html.render(code, params)[0]
    if key == "recu_honoraires":
        from . import honoraires_html
        return honoraires_html.render(code, params)[0]
    if key == "recu_lot":
        from . import recu_lot_html
        return recu_lot_html.render(code, params)[0]
    if key.startswith("lotissement_") or key == "lotissement":
        from . import lotissement_reports
        return lotissement_reports.render_report_html(key, code, params)[0]
    if key.startswith("promotion_"):
        from . import promotion_reports
        return promotion_reports.render_report_html(key, code, params)[0]
    if key == "ventes":
        from . import ventes_html
        return ventes_html.render(code, params)[0]
    if key == "convention":
        import sys
        from pathlib import Path
        candidates = [
            Path(__file__).resolve().parent.parent.parent.parent / "Honor",
            Path(__file__).resolve().parent.parent.parent.parent.parent / "Honor",
            Path("G:/Honor"),
            Path("C:/Honor"),
        ]
        honor_dir = next((p for p in candidates if (p / "reports_html.py").is_file()), None)
        if honor_dir:
            if str(honor_dir) not in sys.path:
                sys.path.insert(0, str(honor_dir))
            try:
                import reports_html
                client_id = int(params.get("client_id") or 1)
                exercice = int(params.get("exercice") or 2026)
                lang = params.get("lang") or "ar"
                return reports_html.render_convention_html(client_id, exercice, lang=lang)[0]
            except Exception:
                pass
        # Fallback to standard template rendering
        try:
            pages, title = render_pages(key, code, params)
            return html.render(pages, title, inline_images)
        except Exception:
            raise HTTPException(404, "Modèle de convention d'honoraires introuvable")
    pages, title = render_pages(key, code, params)
    return html.render(pages, title, inline_images)


def render_pages(key: str, code: str, params: dict):
    d = REPORTS.get(key)
    if d is None:
        raise HTTPException(404, f"Rapport inconnu : {key}")
    try:
        data = d.provider(code, params)
    except EmptyReport as e:
        raise HTTPException(404, str(e)) from e
    variables = data.pop("__vars__", {})
    tpl = data.pop("__template__", d.file)
    texts = data.pop("__texts__", {})
    hidden = data.pop("__hidden_pages__", set())
    bindings = data.pop("__bind__", {})
    hide = data.pop("__hide_token__", "")
    colors = data.pop("__colors__", {})
    whole = data.pop("__whole_amounts__", True)
    pages = template(tpl).render(data, variables, whole_amounts=whole, texts=texts, hidden_pages=hidden, bindings=bindings, hide_token=hide, colors=colors)
    return pages, d.title
