"""Service d'exportation des factures d'achat selon le modèle standardisé achats.xlsx.

Ce module permet d'exporter la liste des factures d'achat (DetailEtatTVA) d'un dossier
pour un mois, un trimestre ou une année entière, dans le format exact des 26 colonnes
de 'achats.xlsx' :
  Col 1: Code (ex: F-0030)
  Col 2: Nom du fournisseur
  Col 3: N° Factures
  Col 4: Date (Format Date)
  Col 5: Jrn Achats (4)
  Col 6: Compte 401 (401000)
  Col 7: TTC (Formule =I... + K... + M... - O...)
  Col 8: cpte38 (380000)
  Col 9: HT
  Col 10: cptetva (445000)
  Col 11: TVA (Formule ou montant TVA déductible)
  Col 12: Cpte timbre (445000)
  Col 13: Timbre (0 ou valeur)
  Col 14: Cpte remise (445000)
  Col 15: Remise (0)
  Col 16: Cpte autres taxess
  Col 17: autres taxes
  Col 18: Cpte stock (300000)
  Col 19: Jrn Stock (5)
  Col 20: Cpte cons (600000)
  Col 21: Jrn Cons (6)
  Col 22: Cpte règlement (512000)
  Col 23: Jrn Règlement (7)
  Col 24: Ref. Règlement
  Col 25: Date Règlement (Formule =D...)
  Col 26: Centre d'analyse
"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..core.db import connect, dossier_path
from .g50 import G50Error


HEADERS = [
    "Code", "Nom du fournisseur", "N° Factures", "Date", "Jrn Achats",
    "Compte 401", "TTC", "cpte38", "HT", "cptetva", "TVA", "Cpte timbre",
    "Timbre", "Cpte remise", "Remise", "Cpte autres taxess", "autres taxes",
    "Cpte stock", "Jrn Stock", "Cpte cons", "Jrn Cons", "Cpte règlement",
    "Jrn Règlement", "Ref. Règlement", "Date Règlement", "Centre d'analyse"
]

COL_WIDTHS = {
    "A": 10.0, "B": 28.0, "C": 15.0, "D": 13.0, "E": 11.0,
    "F": 13.0, "G": 16.0, "H": 12.0, "I": 16.0, "J": 12.0,
    "K": 16.0, "L": 12.0, "M": 12.0, "N": 12.0, "O": 12.0,
    "P": 14.0, "Q": 14.0, "R": 12.0, "S": 12.0, "T": 12.0,
    "U": 12.0, "V": 14.0, "W": 14.0, "X": 15.0, "Y": 15.0,
    "Z": 18.0
}


def _parse_date(dt_val) -> datetime | None:
    if not dt_val:
        return None
    if isinstance(dt_val, datetime):
        return dt_val
    s = str(dt_val).strip()
    # Normalize ISO with T or space
    s = s.replace("T", " ")
    for fmt_str in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y"):
        try:
            return datetime.strptime(s.split(".")[0], fmt_str)
        except Exception:
            pass
    return None


def fetch_achats_data(
    code: str,
    exercice: str | None = None,
    idg50: int | None = None,
    trimestre: int | None = None,
    mois: str | None = None
) -> list[dict]:
    """Extrait les factures d'achat du dossier filtrées selon la période spécifiée."""
    sql = """
        SELECT D.IDDetailEtatTVA, D.fournisseur, D.nfacture, D.datrfqcture, D.ht,
               D.TauxTva, D.tvadroits, D.NATURE, D.IDfournisseurTva, D.leMois, D.Année,
               D.Timbre, D.DT,
               F.rs AS f_rs, F.NIF AS f_nif, F.rcom AS f_rcom, F.adresse AS f_adresse,
               G.Mois AS g_mois_num, G.ma AS g_periode
        FROM DetailEtatTVA D
        LEFT JOIN FournisseurTVA F ON D.IDfournisseurTva = F.IDfournisseurTva
        LEFT JOIN G50 G ON D.IDg50 = G.idg50
        WHERE 1=1
    """
    params: list = []
    if idg50:
        sql += " AND D.IDg50 = ?"
        params.append(idg50)
    elif exercice:
        sql += " AND (D.Année = ? OR G.Année = ?)"
        params.extend([str(exercice), str(exercice)])
        if trimestre:
            sql += " AND CAST(G.Mois AS INTEGER) BETWEEN ? AND ?"
            params.extend([3 * int(trimestre) - 2, 3 * int(trimestre)])
        elif mois:
            sql += " AND (D.leMois = ? OR G.Mois = ? OR G.leMois = ?)"
            params.extend([str(mois), str(mois), str(mois)])

    sql += " ORDER BY D.datrfqcture ASC, D.IDDetailEtatTVA ASC"

    with connect(code) as c:
        rows = [dict(r) for r in c.execute(sql, tuple(params)).fetchall()]
    return rows


def generate_achats_excel(
    code: str,
    rows: list[dict],
    out_path: Path,
    title_suffix: str = ""
) -> Path:
    """Génère le classeur Excel 'achats.xlsx' selon le modèle exact."""
    if not rows:
        raise G50Error("Aucune facture d'achat à exporter pour la période sélectionnée.")

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Feuil1"

    # Style Header (Violet / Pourpre exact FF7030A0, Texte Blanc Gras)
    fill_header = PatternFill(start_color="FF7030A0", end_color="FF7030A0", fill_type="solid")
    font_header = Font(name="Calibri", size=10, bold=True, color="FFFFFFFF")
    align_header = Alignment(horizontal="center", vertical="center", wrap_text=True)

    border_thin_dotted = Border(
        left=Side(style="dotted", color="FFB0B7C3"),
        right=Side(style="dotted", color="FFB0B7C3"),
        top=Side(style="dotted", color="FFB0B7C3"),
        bottom=Side(style="dotted", color="FFB0B7C3"),
    )
    border_total = Border(
        top=Side(style="thin", color="FF7030A0"),
        bottom=Side(style="double", color="FF7030A0"),
        left=Side(style="dotted", color="FFB0B7C3"),
        right=Side(style="dotted", color="FFB0B7C3"),
    )

    f_data = Font(name="Calibri", size=10)
    f_total = Font(name="Calibri", size=10, bold=True, color="FF7030A0")
    fill_total = PatternFill(start_color="FFF3E8FF", end_color="FFF3E8FF", fill_type="solid")

    # 1. Écriture de la ligne d'en-tête (Ligne 1)
    ws.row_dimensions[1].height = 25.5
    for col_idx, col_name in enumerate(HEADERS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.font = font_header
        cell.fill = fill_header
        cell.alignment = align_header

    # 2. Remplissage des lignes de données (à partir de la ligne 2)
    current_row = 2
    for r in rows:
        # Code fournisseur
        f_id = r.get("IDfournisseurTva") or 0
        fourn_code = f"F-{int(f_id):04d}" if f_id else f"F-9999"

        # Nom fournisseur
        fourn_nom = (r.get("f_rs") or r.get("fournisseur") or "").strip()

        # N° Facture
        n_fact = str(r.get("nfacture") or "").strip()

        # Date
        parsed_dt = _parse_date(r.get("datrfqcture"))

        # Montants
        ht_val = float(r.get("ht") or 0.0)
        tva_val = float(r.get("tvadroits") or 0.0)
        timbre_val = float(r.get("Timbre") or 0.0)
        taux_tva = float(r.get("TauxTva") or 19.0)

        # Formule TVA: Si HT > 0, on met la formule du modèle =I{row}*{taux}/100, ou montant si spécifique
        formule_tva = f"=I{current_row}*{int(taux_tva)}/100" if taux_tva in (19, 9) else tva_val
        formule_ttc = f"=I{current_row}+K{current_row}+M{current_row}-O{current_row}"
        formule_date_reglement = f"=D{current_row}"

        row_values = [
            fourn_code,                        # 1: Code
            fourn_nom,                         # 2: Nom du fournisseur
            n_fact,                            # 3: N° Factures
            parsed_dt,                         # 4: Date
            4,                                 # 5: Jrn Achats (Journal 4 par défaut)
            401000,                            # 6: Compte 401
            formule_ttc,                       # 7: TTC
            380000,                            # 8: cpte38
            ht_val,                            # 9: HT
            445000,                            # 10: cptetva
            formule_tva,                       # 11: TVA
            445000,                            # 12: Cpte timbre
            timbre_val,                        # 13: Timbre
            445000,                            # 14: Cpte remise
            0.0,                               # 15: Remise
            None,                              # 16: Cpte autres taxess
            None,                              # 17: autres taxes
            300000,                            # 18: Cpte stock
            5,                                 # 19: Jrn Stock
            600000,                            # 20: Cpte cons
            6,                                 # 21: Jrn Cons
            512000,                            # 22: Cpte règlement
            7,                                 # 23: Jrn Règlement
            f"{current_row-1:05d}",             # 24: Ref. Règlement
            formule_date_reglement,            # 25: Date Règlement
            None                               # 26: Centre d'analyse
        ]

        for col_idx, val in enumerate(row_values, start=1):
            cell = ws.cell(row=current_row, column=col_idx, value=val)
            cell.font = f_data
            cell.border = border_thin_dotted

            # Formats par colonne conformes au modèle achats.xlsx
            if col_idx in (1, 3, 24):  # Code, Facture, Ref Règlement -> Texte centré
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = '@'
            elif col_idx in (4, 25):   # Dates
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = 'yyyy-mm-dd'
            elif col_idx in (5, 6, 8, 10, 12, 14, 18, 19, 20, 21, 22, 23):  # Journaux et Comptes
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.number_format = '0'
            elif col_idx in (7, 9, 11, 13, 15, 17):  # Montants décimaux HT, TVA, TTC, Timbre, Remise
                cell.alignment = Alignment(horizontal="right", vertical="center")
                cell.number_format = '#,##0.00'
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")

        current_row += 1

    # 3. Ligne Total Général
    last_data_row = current_row - 1
    ws.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=6)
    c_tot_lbl = ws.cell(row=current_row, column=1, value=f"TOTAL GÉNÉRAL ({len(rows)} factures) :")
    c_tot_lbl.font = f_total
    c_tot_lbl.fill = fill_total
    c_tot_lbl.alignment = Alignment(horizontal="right", vertical="center")

    for col in range(1, 27):
        cell = ws.cell(row=current_row, column=col)
        cell.border = border_total
        cell.fill = fill_total

    # Formules Somme Excel
    # Col 7: TTC
    c_ttc = ws.cell(row=current_row, column=7, value=f"=SUM(G2:G{last_data_row})")
    c_ttc.font = f_total
    c_ttc.number_format = '#,##0.00'
    c_ttc.alignment = Alignment(horizontal="right", vertical="center")

    # Col 9: HT
    c_ht = ws.cell(row=current_row, column=9, value=f"=SUM(I2:I{last_data_row})")
    c_ht.font = f_total
    c_ht.number_format = '#,##0.00'
    c_ht.alignment = Alignment(horizontal="right", vertical="center")

    # Col 11: TVA
    c_tva = ws.cell(row=current_row, column=11, value=f"=SUM(K2:K{last_data_row})")
    c_tva.font = f_total
    c_tva.number_format = '#,##0.00'
    c_tva.alignment = Alignment(horizontal="right", vertical="center")

    # Col 13: Timbre
    c_tmb = ws.cell(row=current_row, column=13, value=f"=SUM(M2:M{last_data_row})")
    c_tmb.font = f_total
    c_tmb.number_format = '#,##0.00'
    c_tmb.alignment = Alignment(horizontal="right", vertical="center")

    ws.row_dimensions[current_row].height = 22.0

    # 4. Ajustement des largeurs de colonnes
    for col_letter, width in COL_WIDTHS.items():
        ws.column_dimensions[col_letter].width = width

    # Feuilles Feuil2 et Feuil3 pour correspondre 100% au template
    wb.create_sheet("Feuil2")
    wb.create_sheet("Feuil3")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(out_path))
    return out_path
