"""Génération massive des dossiers — Delphi uBatchGen (« Génération Automatique des Dossiers Multi-Sociétés »).

Étape 1 — WinDev → base centrale: the 19 WinDev files (clients.fic, G50.fic, Salaires.fic…) are read through
the HFSQL ODBC driver (tools/hfsql_export.ps1, 32-bit PowerShell, Windows-1252 decoding like
DecodeFieldToStr) into data/central/G50central.sqlite (Delphi: DB\\G50.mdb), with Delphi's post-processing:
IRGSalaires.idclients / Timbre.idclients / DetailEtatTVA.idcp from G50, the Exercices table, month names.
Alternative source: an existing DB\\G50.mdb (« Vérifier DB\\G50.mdb »).

Étape 2 — distribution: one dossier per company of the central base (ProcessOneClient): clients row, the
EXPORT_TABLES rows of the company (and of its principal company), link field set to the company id,
TAP / DetailEtatTVA through its G50, Exercices from its G50, fournisseurTva copied entirely.
Logical safeguard: Delphi restarted at S1 and overwrote the existing dossiers; here a company already
present (same NIF and raison sociale) is skipped unless « remplacer » is asked, and then a backup of all
dossiers is taken first.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import string
import subprocess
import sys
import tempfile
from pathlib import Path

from ..core import config
from . import dossiers, sauvegarde, societes
from .g50 import G50Error

# Mappings[] of btnDirectImportClick: WinDev file -> table of the central base
MAPPINGS = [("clients", "clients"), ("G50", "G50"), ("TVA", "TVA"), ("TAP", "TAP"), ("Salaires", "IRGSalaires"),
            ("Timbre", "Timbre"), ("fournisseurTva", "fournisseurTva"), ("DetailEtatTVA", "DetailEtatTVA"),
            ("IBSAcomptes", "IBSAcomptes"), ("IBSsolde", "IBSsolde"), ("AutresTaxes", "AutresTaxes"), ("DecCAPharm", "DecCAPharm"),
            ("DeclarationTAPP", "DeclarationTAPP"), ("Indirect", "Indirect"), ("IRGLocatif", "IRGLocatif1"),
            ("IRGPrestation", "IRGPrestation"), ("IRGRcm", "IRGRcm"), ("IBSRetenus", "IBSRetenus"), ("DSecondaire", "DSecondaire")]
EXPORT_TABLES = ["G50", "TAP", "TVA", "IRGSalaires", "DecCAPharm", "DeclarationTAPP", "IBSAcomptes", "IBSsolde", "Timbre",
                 "DetailEtatTVA", "AutresTaxes", "Indirect", "IRGLocatif1", "IRGPrestation", "IRGRcm", "IBSRetenus", "DSecondaire"]


def _find_hfsql_script() -> Path:
    candidates = []
    # 1. sys._MEIPASS (PyInstaller bundle directory)
    if getattr(sys, "frozen", False):
        meipass = Path(getattr(sys, "_MEIPASS", sys.executable)).resolve()
        if meipass.is_file():
            meipass = meipass.parent
        candidates.extend([
            meipass / "app" / "tools" / "hfsql_export.ps1",
            meipass / "tools" / "hfsql_export.ps1",
            meipass / "backend" / "app" / "tools" / "hfsql_export.ps1",
            meipass / "hfsql_export.ps1",
        ])
    # 2. Executable parent directory
    exe_dir = Path(sys.executable).resolve().parent
    candidates.extend([
        exe_dir / "backend" / "app" / "tools" / "hfsql_export.ps1",
        exe_dir / "app" / "tools" / "hfsql_export.ps1",
        exe_dir / "tools" / "hfsql_export.ps1",
        exe_dir / "_internal" / "app" / "tools" / "hfsql_export.ps1",
        exe_dir / "_internal" / "tools" / "hfsql_export.ps1",
        exe_dir / "hfsql_export.ps1",
    ])
    # 3. Path(__file__)
    cur = Path(__file__).resolve().parent
    candidates.extend([
        cur / "hfsql_export.ps1",
        cur.parent / "tools" / "hfsql_export.ps1",
        cur.parent.parent / "tools" / "hfsql_export.ps1",
        cur.parent.parent / "app" / "tools" / "hfsql_export.ps1",
        cur.parent.parent / "backend" / "app" / "tools" / "hfsql_export.ps1",
    ])
    for c in candidates:
        if c.is_file():
            return c
    return cur.parent / "tools" / "hfsql_export.ps1"


SCRIPT = _find_hfsql_script()
WINDEV_KEYS = ("clients", "G50", "TVA", "TAP", "Salaires", "Timbre")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _ps32() -> Path | None:
    """32-bit PowerShell (the HFSQL ODBC driver wd240hfo.dll is 32-bit): SysWOW64 on 64-bit Windows,
    System32 on 32-bit Windows; Windows may be installed on another drive than C:."""
    root = Path(os.environ.get("SystemRoot") or os.environ.get("windir") or r"C:\Windows")
    for sub in ("SysWOW64", "System32"):
        p = root / sub / "WindowsPowerShell" / "v1.0" / "powershell.exe"
        if p.is_file():
            return p
    return None


PS32 = _ps32()


def _ps() -> str:
    root = Path(os.environ.get("SystemRoot") or r"C:\Windows")
    p = root / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return str(p) if p.is_file() else "powershell"


# ------------------------------------------------------------------ dossier WinDev
def _n_fic(p: Path) -> int:
    """Number of the main WinDev files present in p (Windows paths are case-insensitive)."""
    try:
        return sum(1 for n in WINDEV_KEYS if (p / f"{n}.fic").is_file())
    except OSError:
        return 0


def _subdirs(p: Path) -> list[Path]:
    try:
        return [x for x in p.iterdir() if x.is_dir() and not x.name.startswith(("$", "."))]
    except OSError:
        return []


def resolve_folder(src: Path, depth: int = 2) -> Path | None:
    """src itself if it holds the .fic files, else the first sub-folder (≤ depth levels) that does —
    the user often selects the application folder while the files sit in a data sub-folder."""
    if _n_fic(src):
        return src
    level = [src]
    for _ in range(depth):
        nxt: list[Path] = []
        for d in level:
            for s in _subdirs(d):
                if _n_fic(s):
                    return s
                nxt.append(s)
        level = nxt[:400]
    return None


def _last_file() -> Path:
    return config.PROJECT_ROOT / "data" / "central" / "windev_dossier.txt"


def _drives() -> list[Path]:
    """Fixed local drives (skips CD/DVD, empty card readers and slow network drives)."""
    out: list[Path] = []
    try:
        import ctypes
        mask = ctypes.windll.kernel32.GetLogicalDrives()
        for i, letter in enumerate(string.ascii_uppercase):
            if mask & (1 << i):
                root = f"{letter}:\\"
                if ctypes.windll.kernel32.GetDriveTypeW(root) == 3:  # DRIVE_FIXED
                    out.append(Path(root))
    except Exception:
        out = [Path(f"{x}:\\") for x in "CDEFG" if Path(f"{x}:\\").exists()]
    return out


def detect_windev() -> dict:
    """Looks for the WinDev data folders on this PC (Delphi FormCreate only tried C:\\G50 2022)."""
    found: dict[str, int] = {}

    def add(p: Path | None) -> None:
        if p is None:
            return
        r = resolve_folder(p, depth=1)
        if r is not None:
            key = str(r)
            if key.lower() not in {k.lower() for k in found}:
                found[key] = _n_fic(r)

    last = ""
    try:
        last = _last_file().read_text(encoding="utf-8").strip()
    except OSError:
        pass
    if last and Path(last).is_dir():
        add(Path(last))
    hints = ("g50", "windev", "pcsoft", "pc soft", "declar", "fisc", "jibaya", "impot")
    for base in [config.PROJECT_ROOT, config.PROJECT_ROOT.parent]:
        add(base / "G50 2022")
    for drv in _drives():
        add(drv / "G50 2022")
        tops = _subdirs(drv)
        for prog in ("Program Files (x86)", "Program Files"):
            if (drv / prog).is_dir():
                tops += [d for d in _subdirs(drv / prog) if any(h in d.name.lower() for h in hints)]
        for d in tops:
            if any(h in d.name.lower() for h in hints):
                add(d)
    items = sorted(found.items(), key=lambda kv: (kv[0] != last, -kv[1]))
    return {"last": last if last in found else "", "candidates": [{"path": k, "fic": v} for k, v in items]}


def pick_folder(initial: str = "") -> str:
    """Native Windows « Rechercher un dossier » dialog (desktop only)."""
    ps = (
        "[Console]::OutputEncoding = [Text.Encoding]::UTF8;"
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$o = New-Object System.Windows.Forms.Form; $o.TopMost = $true;"
        "$d = New-Object System.Windows.Forms.FolderBrowserDialog;"
        "$d.Description = 'Choisissez le dossier des fichiers WinDev (clients.fic, G50.fic, TVA.fic...)';"
        "$d.ShowNewFolderButton = $false;"
        "if ($env:DEC_INITIAL -and (Test-Path $env:DEC_INITIAL)) { $d.SelectedPath = $env:DEC_INITIAL };"
        "if ($d.ShowDialog($o) -eq 'OK') { Write-Output $d.SelectedPath }"
    )
    env = dict(os.environ, DEC_INITIAL=initial or "")
    r = subprocess.run([_ps(), "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", ps],
                       capture_output=True, timeout=600, env=env, creationflags=NO_WINDOW)
    return r.stdout.decode("utf-8", "replace").strip().splitlines()[-1].strip() if r.stdout.strip() else ""


def central_path() -> Path:
    return config.PROJECT_ROOT / "data" / "central" / "G50central.sqlite"


def _q(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _write_table(c: sqlite3.Connection, table: str, cols: list[str], rows: list[list]) -> None:
    c.execute(f"DROP TABLE IF EXISTS {_q(table)}")
    c.execute(f"CREATE TABLE {_q(table)} ({', '.join(_q(x) for x in cols)})")
    if rows:
        c.executemany(f"INSERT INTO {_q(table)} VALUES ({', '.join('?' for _ in cols)})", rows)


def _cols(c: sqlite3.Connection, table: str) -> list[str]:
    return [r[1] for r in c.execute(f"PRAGMA table_info({_q(table)})")]


def _find(cols: list[str], *names: str) -> str | None:
    low = {x.lower(): x for x in cols}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def _postprocess(c: sqlite3.Connection, log: list[str]) -> None:
    """End of btnDirectImportClick: link columns, Exercices, French month names."""
    tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "G50" not in tables:
        return
    gcols = _cols(c, "G50")
    gid, gcl, gan = _find(gcols, "idg50"), _find(gcols, "IDclients"), _find(gcols, "Année", "Annee")
    for t, col in (("IRGSalaires", "idclients"), ("Timbre", "idclients"), ("DetailEtatTVA", "idcp")):
        if t not in tables or not gid or not gcl:
            continue
        cols = _cols(c, t)
        link = _find(cols, "Idg50")
        if not link:
            continue
        if not _find(cols, col):
            c.execute(f"ALTER TABLE {_q(t)} ADD COLUMN {_q(col)}")
        c.execute(f"UPDATE {_q(t)} SET {_q(_find(_cols(c, t), col))} = (SELECT {_q(gcl)} FROM G50 WHERE G50.{_q(gid)} = {_q(t)}.{_q(link)})")
    if gan:
        c.execute("DROP TABLE IF EXISTS Exercices")
        c.execute('CREATE TABLE Exercices (IDclients, "Année")')
        c.execute(f'INSERT INTO Exercices SELECT DISTINCT {_q(gcl)}, {_q(gan)} FROM G50 WHERE {_q(gcl)} > 0 AND LENGTH({_q(gan)}) = 4')
    lm = _find(gcols, "leMois")
    if lm:
        c.execute(f"UPDATE G50 SET {_q(lm)} = 'Février' WHERE {_q(lm)} LIKE 'F_vrier' OR {_q(lm)} LIKE 'F__vrier'")
        c.execute(f"UPDATE G50 SET {_q(lm)} = 'Décembre' WHERE {_q(lm)} LIKE 'D_cembre' OR {_q(lm)} LIKE 'D__cembre'")
    log.append("✓ Post-traitement : liens idclients / idcp, table Exercices, noms des mois")


# ------------------------------------------------------------------ étape 1
def import_windev(folder: str) -> dict:
    src = Path(str(folder or "").strip().strip('"'))
    if not str(folder or "").strip() or not src.is_dir():
        raise G50Error(f"Dossier introuvable : {src}")
    log: list[str] = []
    found = resolve_folder(src)
    if found is None:
        raise G50Error(f"Aucun fichier WinDev (.fic) trouvé dans : {src}")
    if found != src:
        log.append(f"✓ Fichiers WinDev trouvés dans le sous-dossier : {found}")
        src = found
    ps32 = _ps32()
    if ps32 is None:
        raise G50Error("PowerShell 32 bits introuvable (nécessaire au pilote ODBC HFSQL)")
    script_path = _find_hfsql_script()
    if not script_path.is_file():
        raise G50Error(f"Script d'export WinDev (hfsql_export.ps1) introuvable dans : {script_path}")
    with tempfile.TemporaryDirectory() as tmp:
        r = subprocess.run([str(ps32), "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path), "-RepFic", str(src),
                            "-OutDir", tmp, "-Tables", ",".join(f for f, _ in MAPPINGS)],
                           capture_output=True, timeout=900, creationflags=NO_WINDOW)
        lines = r.stdout.decode("utf-8", "replace").splitlines() + r.stderr.decode("utf-8", "replace").splitlines()
        status = {}
        for line in lines:
            parts = line.strip().split("|")
            if parts[0] == "PILOTE":
                log.append(f"✓ Pilote ODBC HFSQL : {parts[1]}")
            elif parts[0] == "ERREUR" and len(parts) == 2:
                raise G50Error(parts[1])
            elif parts[0] in ("OK", "ABSENT", "ERREUR") and len(parts) >= 2:
                status[parts[1]] = parts
        if not status:
            raise G50Error("Impossible de se connecter aux fichiers WinDev : " + " ".join(lines)[-400:])
        out = central_path()
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp_db = out.with_suffix(".tmp")
        tmp_db.unlink(missing_ok=True)
        c = sqlite3.connect(tmp_db)
        total = 0
        try:
            for fic, table in MAPPINGS:
                st = status.get(fic)
                if not st or st[0] == "ABSENT":
                    log.append(f"  - [{fic}.fic] non présent, ignoré.")
                    continue
                if st[0] == "ERREUR":
                    log.append(f"  ! [{fic}.fic] {st[2] if len(st) > 2 else ''}")
                    continue
                with open(Path(tmp) / f"{fic}.jsonl", encoding="utf-8") as fh:
                    cols = json.loads(fh.readline())
                    rows = [json.loads(line) for line in fh if line.strip()]
                _write_table(c, table, cols, rows)
                total += len(rows)
                log.append(f"✓ {fic}.fic → {table} : {len(rows)} enregistrement(s)")
            _postprocess(c, log)
            c.commit()
        finally:
            c.close()
        tmp_db.replace(out)
    try:
        _last_file().write_text(str(src), encoding="utf-8")
    except OSError:
        pass
    return {"log": log, "total": total, "folder": str(src), **central_info()}


def import_mdb(path: str = "") -> dict:
    """« Vérifier DB\\G50.mdb »: use the Delphi central base as source of step 2."""
    p = Path(path) if path else config.DELPHI_ROOT / "DB" / "G50.mdb"
    if not p.is_file():
        raise G50Error(f"Base centrale introuvable : {p}")
    import pyodbc
    src = pyodbc.connect(rf"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={p};ReadOnly=1")
    out = central_path()
    out.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(out.with_suffix(".tmp"))
    log, total = [], 0
    try:
        for t in [r.table_name for r in src.cursor().tables(tableType="TABLE")]:
            if t.startswith(("~", "MSys")):
                continue
            cur = src.cursor().execute(f"SELECT * FROM [{t}]")
            cols = [d[0] for d in cur.description]
            rows = [[societes._plain(v) for v in r] for r in cur.fetchall()]
            rows = [[None if isinstance(v, bytes) else v for v in r] for r in rows]
            _write_table(c, t, cols, rows)
            total += len(rows)
            log.append(f"✓ {t} : {len(rows)} enregistrement(s)")
        c.commit()
    finally:
        c.close()
        src.close()
    out.with_suffix(".tmp").replace(out)
    return {"log": log, "total": total, **central_info()}


def central_info() -> dict:
    p = central_path()
    if not p.is_file():
        return {"central": None, "societes": []}
    c = sqlite3.connect(p)
    try:
        cols = _cols(c, "clients")
        idc, rs, nif = _find(cols, "IDclients"), _find(cols, "rs"), _find(cols, "NIF")
        rows = [{"id": r[0], "rs": (r[1] or "").strip(), "nif": (r[2] or "").strip()}
                for r in c.execute(f"SELECT {_q(idc)}, {_q(rs)}, {_q(nif)} FROM clients ORDER BY {_q(idc)}")]
    finally:
        c.close()
    existing = {((d.get("nif") or "").strip(), (d.get("rs") or "").strip().upper()): d["code"] for d in dossiers.list_dossiers()}
    for r in rows:
        r["dossier"] = existing.get((r["nif"], r["rs"].upper()))
    return {"central": str(p), "societes": rows}


# ------------------------------------------------------------------ étape 2
def _copy(src: sqlite3.Connection, dst: sqlite3.Connection, table: str, where: str, args: tuple, set_link: tuple[str, object] | None) -> int:
    scols = _cols(src, table)
    dcols = {x.lower(): x for x in _cols(dst, table)}
    pairs = [(s, dcols[s.lower()]) for s in scols if s.lower() in dcols]
    if not pairs:
        return 0
    rows = src.execute(f"SELECT {', '.join(_q(s) for s, _ in pairs)} FROM {_q(table)} WHERE {where}", args).fetchall()
    if not rows:
        return 0
    dst.execute(f"DELETE FROM {_q(table)}")
    dst.executemany(f"INSERT INTO {_q(table)} ({', '.join(_q(d) for _, d in pairs)}) VALUES ({', '.join('?' for _ in pairs)})", rows)
    if set_link:
        col = dcols.get(set_link[0].lower())
        if col:
            dst.execute(f"UPDATE {_q(table)} SET {_q(col)} = ?", (set_link[1],))
    return len(rows)


def _dates(dst: sqlite3.Connection) -> None:
    """WinDev dates stored as AAAAMMJJ strings → ISO (storage format of the dossiers)."""
    for (t,) in dst.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
        for col in [x for x in _cols(dst, t) if "date" in x.lower()]:
            dst.execute(f"UPDATE {_q(t)} SET {_q(col)} = substr({_q(col)},1,4)||'-'||substr({_q(col)},5,2)||'-'||substr({_q(col)},7,2)||'T00:00:00' "
                        f"WHERE typeof({_q(col)}) = 'text' AND length({_q(col)}) = 8 AND {_q(col)} GLOB '[12][0-9][0-9][0-9][01][0-9][0-3][0-9]'")
            dst.execute(f"UPDATE {_q(t)} SET {_q(col)} = NULL WHERE {_q(col)} IN ('', '00000000')")


G50_CHILDREN = ["TVA", "TAP", "TLS", "IRGSalaires", "Timbre", "AutresTaxes", "DetailEtatTVA"]


def _keep(previous: Path, src: sqlite3.Connection, dst: sqlite3.Connection, log: list[str]) -> None:
    """Logical safeguard when a dossier is regenerated: WinDev holds only part of the data. Everything entered
    in the application and absent from WinDev is carried over from the replaced dossier: company fields that
    WinDev does not have (activities, Arabic data...), the tables WinDev does not provide (contracts, beneficial
    owners, sales, station, real estate...), the G50 created after the WinDev export (with their lines) and the
    exercices."""
    old = sqlite3.connect(previous)
    try:
        src_tables = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        dst_tables = {r[0] for r in dst.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        old_tables = {r[0] for r in old.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        # 1. company columns not provided by WinDev
        wcols = {x.lower() for x in _cols(src, "clients")}
        orow = old.execute("SELECT * FROM clients LIMIT 1").fetchone()
        if orow:
            ocols = _cols(old, "clients")
            dcols = {x.lower(): x for x in _cols(dst, "clients")}
            keep = {dcols[c.lower()]: v for c, v in zip(ocols, orow)
                    if c.lower() not in wcols and c.lower() in dcols and v not in (None, "")}
            if keep:
                dst.execute(f"UPDATE clients SET {', '.join(_q(k) + ' = ?' for k in keep)}", tuple(keep.values()))
                log.append(f"    ↺ fiche société : {len(keep)} champ(s) conservé(s) (activités, données arabes…)")
        # 2. tables not provided by WinDev
        refreshed = set(EXPORT_TABLES) | {"clients", "Exercices", "fournisseurTva", "Mois", "PPu"}
        for t in sorted((old_tables & dst_tables) - refreshed - src_tables):
            n = old.execute(f"SELECT COUNT(*) FROM {_q(t)}").fetchone()[0]
            if not n:
                continue
            dl = {x.lower() for x in _cols(dst, t)}
            cols = [c for c in _cols(old, t) if c.lower() in dl]
            rows = old.execute(f"SELECT {', '.join(_q(c) for c in cols)} FROM {_q(t)}").fetchall()
            dst.execute(f"DELETE FROM {_q(t)}")
            dst.executemany(f"INSERT INTO {_q(t)} ({', '.join(_q(c) for c in cols)}) VALUES ({', '.join('?' for _ in cols)})", rows)
            log.append(f"    ↺ {t} : {n} enreg. conservé(s)")
        # 3. G50 created in the application (not in WinDev) with their lines
        new_ids = {r[0] for r in dst.execute("SELECT idg50 FROM G50")}
        extra = [r[0] for r in old.execute("SELECT idg50 FROM G50") if r[0] not in new_ids]
        for t in ["G50", *G50_CHILDREN]:
            if t not in old_tables or t not in dst_tables or not extra:
                continue
            link = "idg50" if t == "G50" else _find(_cols(old, t), "Idg50", "IDg50")
            if not link:
                continue
            dl = {x.lower() for x in _cols(dst, t)}
            cols = [c for c in _cols(old, t) if c.lower() in dl]
            rows = old.execute(f"SELECT {', '.join(_q(c) for c in cols)} FROM {_q(t)} WHERE {_q(link)} IN ({', '.join('?' for _ in extra)})", extra).fetchall()
            if rows:
                dst.executemany(f"INSERT INTO {_q(t)} ({', '.join(_q(c) for c in cols)}) VALUES ({', '.join('?' for _ in cols)})", rows)
        if extra:
            log.append(f"    ↺ {len(extra)} G50 saisie(s) dans l’application conservée(s)")
        # 4. exercices
        years = [r[0] for r in old.execute('SELECT DISTINCT "Année" FROM Exercices').fetchall()]
        years += [r[0] for r in dst.execute('SELECT DISTINCT TRIM("Année") FROM G50 WHERE LENGTH(TRIM("Année")) = 4').fetchall()]
        for an in years:
            if an and not dst.execute('SELECT 1 FROM Exercices WHERE "Année" = ?', (an,)).fetchone():
                dst.execute('INSERT INTO Exercices (IDclients, "Année") SELECT IDclients, ? FROM clients LIMIT 1', (an,))
    finally:
        old.close()
        previous.unlink(missing_ok=True)


def _process(src: sqlite3.Connection, client: dict, code: str, log: list[str]) -> None:
    """ProcessOneClient."""
    folder = config.SOCIETES_DIR / code
    folder.mkdir(parents=True, exist_ok=True)
    db = folder / config.DB_FILENAME
    previous = None
    if db.is_file():                      # replacement: keep a copy to carry over what WinDev does not hold
        previous = Path(tempfile.mkdtemp()) / "avant.sqlite"
        s_old, d_old = sqlite3.connect(f"file:{db}?mode=ro", uri=True), sqlite3.connect(previous)
        try:
            s_old.backup(d_old)
        finally:
            d_old.close()
            s_old.close()
    db.unlink(missing_ok=True)
    for suffix in ("-wal", "-shm"):
        (folder / (config.DB_FILENAME + suffix)).unlink(missing_ok=True)
    dst = societes._create_db(db)
    try:
        cid, pid = client["id"], client.get("principal")
        ids = [cid] + ([pid] if pid and pid != cid else [])
        mark = ", ".join("?" for _ in ids)
        dst.execute("DELETE FROM clients")
        idc = _find(_cols(src, "clients"), "IDclients")
        _copy(src, dst, "clients", f"{_q(idc)} = ?", (cid,), None)
        tables = {r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        g = _cols(src, "G50") if "G50" in tables else []
        gid, gcl = _find(g, "idg50"), _find(g, "IDclients")
        for t in EXPORT_TABLES:
            if t not in tables:
                continue
            cols = _cols(src, t)
            link = _find(cols, "IDCP") or _find(cols, "IDclients", "ID_CLIENTS", "IDCLIENT", "ID_CLIENT")
            if t in ("DetailEtatTVA", "TAP") and _find(cols, "Idg50") and gid:
                where, args = f"{_q(_find(cols, 'Idg50'))} IN (SELECT {_q(gid)} FROM G50 WHERE {_q(gcl)} IN ({mark}))", tuple(ids)
            elif link:
                where, args = f"{_q(link)} IN ({mark})", tuple(ids)
            else:
                log.append(f"    - {t} : pas de champ idclients")
                continue
            n = _copy(src, dst, t, where, args, (link, cid) if link else None)
            if n:
                log.append(f"    OK {t} : {n} enreg.")
        if "fournisseurTva" in tables:
            n = _copy(src, dst, "fournisseurTva", "1 = 1", (), None)
            log.append(f"    OK fournisseurTva : {n} (copié intégralement)")
        dst.execute("DELETE FROM Exercices")
        dst.execute('INSERT INTO Exercices (IDclients, "Année") SELECT DISTINCT ?, TRIM("Année") FROM G50 WHERE LENGTH(TRIM("Année")) = 4', (cid,))
        if not dst.execute("SELECT COUNT(*) FROM Exercices").fetchone()[0]:
            from datetime import date
            dst.execute('INSERT INTO Exercices (IDclients, "Année") VALUES (?, ?)', (cid, str(date.today().year)))
        dst.execute("UPDATE G50 SET leMois = 'Février' WHERE leMois LIKE 'F_vrier'")
        dst.execute("UPDATE G50 SET leMois = 'Décembre' WHERE leMois LIKE 'D_cembre'")
        _dates(dst)
        if previous:
            _keep(previous, src, dst, log)
        dst.commit()
    finally:
        dst.close()


def generate(replace: bool = False, only: list | None = None) -> dict:
    """btnBatchImportClick."""
    p = central_path()
    if not p.is_file():
        raise G50Error("Aucune base centrale : exécutez d’abord l’étape 1 (ou Vérifier DB\\G50.mdb)")
    info = central_info()
    log: list[str] = []
    if replace and any(s["dossier"] for s in info["societes"]):
        b = sauvegarde.backup("AvantGeneration")
        log.append(f"✓ Sauvegarde de sécurité : {b['name']}")
    src = sqlite3.connect(p)
    created, replaced, skipped = [], [], []
    try:
        ccols = _cols(src, "clients")
        idc, pcol = _find(ccols, "IDclients"), _find(ccols, "idclientPrincipal")
        principal = {r[0]: r[1] for r in src.execute(f"SELECT {_q(idc)}, {_q(pcol)} FROM clients")} if pcol else {}
        for s in info["societes"]:
            if only and s["id"] not in only:
                continue
            client = {"id": s["id"], "principal": principal.get(s["id"]) or None}
            if client["principal"] in (0, "0", ""):
                client["principal"] = None
            if s["dossier"] and not replace:
                skipped.append(s["dossier"])
                log.append(f">> {s['dossier']} | {s['rs']} : déjà présent, conservé")
                continue
            code = s["dossier"] or societes._next_code()
            log.append(f">> {code} | {s['rs']} (id={s['id']}{', principal=' + str(client['principal']) if client['principal'] else ''})")
            try:
                _process(src, client, code, log)
                (replaced if s["dossier"] else created).append(code)
            except Exception as e:  # noqa: BLE001 — one failing company must not stop the batch (Delphi behaviour)
                log.append(f"    ! {type(e).__name__} : {e}")
    finally:
        src.close()
    return {"log": log, "created": created, "replaced": replaced, "skipped": skipped,
            "message": f"Génération terminée : {len(created)} dossier(s) créé(s), {len(replaced)} remplacé(s), {len(skipped)} conservé(s)."}
