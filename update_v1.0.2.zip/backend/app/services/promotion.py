"""Promotion immobilière — Suivi des projets, blocs, logements, locaux, garages, élévation 2D et encaissements VEFA.
Intègre la loi 11-04 relative à l'activité de promotion immobilière en Algérie :
- Gestion hiérarchique : Projet → Blocs / Bâtiments → Unités (Logements, Locaux commerciaux, Garages / Parkings).
- Échéancier légal des ventes sur plan (VEFA : 20% signature, 15% fondations, 35% gros-œuvres, 20% finitions, 10% livraison).
- Matrice visuelle d'élévation 2D par étage et statut contractuel / fiscal.
- Suivi rigoureux des encaissements, TVA, CA facturé (actes notariés) et créances réelles.
"""
from __future__ import annotations

import math
from fastapi import HTTPException

from ..core.db import connect
from . import dates, ref
from .g50 import Conflict, G50Error, _next_id, _num

MODES = ["Espece", "Cheque Bancaire", "Virement Bancaire"]
TYPES_LOGEMENTS = ["F1", "F2", "F3", "F4", "F5", "Duplex"]
VEFA_TRANCHES = [
    {"num": 1, "libelle": "Signature du contrat VEFA", "pct": 20.0},
    {"num": 2, "libelle": "Achèvement des fondations", "pct": 15.0},
    {"num": 3, "libelle": "Achèvement des gros œuvres", "pct": 35.0},
    {"num": 4, "libelle": "Achèvement des finitions", "pct": 20.0},
    {"num": 5, "libelle": "Livraison et remise des clés", "pct": 10.0},
]


def _ensure_promo_tables(c) -> None:
    c.execute("""
        CREATE TABLE IF NOT EXISTS PromotionBlocs (
            ID INTEGER PRIMARY KEY,
            IdProjet INTEGER NOT NULL,
            NomBloc TEXT NOT NULL,
            NbrEtages INTEGER DEFAULT 5,
            NbrLogements INTEGER DEFAULT 0,
            NbrLocaux INTEGER DEFAULT 0,
            NbrGarages INTEGER DEFAULT 0,
            Observations TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS PromotionUnites (
            ID INTEGER PRIMARY KEY,
            IdProjet INTEGER NOT NULL,
            IdBloc INTEGER,
            TypeUnite TEXT NOT NULL, -- 'logement', 'local', 'garage'
            Numero TEXT NOT NULL,
            Etage INTEGER DEFAULT 0, -- -2, -1 (sous-sol), 0 (RDC), 1..N (étages)
            TypeLogement TEXT, -- 'F1', 'F2', 'F3', 'F4', 'F5', 'Duplex', 'Commercial', 'Parking'
            Superficie REAL DEFAULT 0,
            PrixM2 REAL DEFAULT 0,
            PrixTTC REAL DEFAULT 0,
            PrixHT REAL DEFAULT 0,
            TauxTVA REAL DEFAULT 19,
            DroitsTVA REAL DEFAULT 0,
            Acquereur TEXT,
            Telephone TEXT,
            DateActe TEXT,
            NumActe TEXT,
            Notaire TEXT,
            Statut TEXT DEFAULT 'disponible', -- 'disponible', 'reserve', 'vendu_dette', 'vendu_solde'
            TVersem REAL DEFAULT 0,
            Reste REAL DEFAULT 0,
            AvancementPct REAL DEFAULT 0,
            FOREIGN KEY (IdBloc) REFERENCES PromotionBlocs(ID) ON DELETE SET NULL
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS PromotionEcheances (
            ID INTEGER PRIMARY KEY,
            IdUnite INTEGER NOT NULL,
            NumTranche INTEGER NOT NULL,
            Libelle TEXT NOT NULL,
            Pourcentage REAL NOT NULL,
            Montant REAL NOT NULL,
            DatePrevue TEXT,
            DateReglement TEXT,
            EstRegle INTEGER DEFAULT 0,
            FOREIGN KEY (IdUnite) REFERENCES PromotionUnites(ID) ON DELETE CASCADE
        )
    """)
    cols = [col[1] for col in c.execute("PRAGMA table_info(Encaissements)").fetchall()]
    if "IdUnite" not in cols:
        try:
            c.execute("ALTER TABLE Encaissements ADD COLUMN IdUnite INTEGER")
        except Exception:
            pass


def _calc_unite_status(r: dict) -> str:
    reste = _num(r.get("Reste"))
    verse = _num(r.get("TVersem"))
    acte = bool(str(r.get("DateActe") or "").strip())
    acq = bool(str(r.get("Acquereur") or "").strip())

    if acte:
        return "vendu_solde" if reste <= 0 else "vendu_dette"
    if acq or verse > 0:
        return "reserve"
    return "disponible"


# ------------------------------------------------------------------ projets (Unit17)
def projets(code: str) -> list[dict]:
    with connect(code) as c:
        _ensure_promo_tables(c)
        rows = [dict(r) for r in c.execute(
            'SELECT p."ID" AS _id, p."Projet" AS projet, '
            '(SELECT COUNT(*) FROM Encaissements e WHERE TRIM(e."Projet") = TRIM(p."Projet")) AS usage, '
            '(SELECT COUNT(*) FROM PromotionBlocs b WHERE b."IdProjet" = p."ID") AS nbr_blocs, '
            '(SELECT COUNT(*) FROM PromotionUnites u WHERE u."IdProjet" = p."ID") AS nbr_unites, '
            '(SELECT COUNT(*) FROM PromotionUnites u WHERE u."IdProjet" = p."ID" AND (u."DateActe" IS NOT NULL AND TRIM(u."DateActe") != "")) AS nbr_vendus, '
            '(SELECT COALESCE(SUM(u."PrixTTC"), 0) FROM PromotionUnites u WHERE u."IdProjet" = p."ID" AND (u."DateActe" IS NOT NULL AND TRIM(u."DateActe") != "")) AS ca_facture_ttc, '
            '(SELECT COALESCE(SUM(u."TVersem"), 0) FROM PromotionUnites u WHERE u."IdProjet" = p."ID") AS total_versements '
            'FROM ProjEncaissement p ORDER BY p."Projet"')]
    return rows


def save_projet(code: str, name: str, pid: int | None = None) -> dict:
    name = str(name or "").strip()
    if not name:
        raise G50Error("Veuillez saisir le nom du projet")
    with connect(code) as c:
        _ensure_promo_tables(c)
        dup = c.execute('SELECT "ID" FROM ProjEncaissement WHERE UPPER(TRIM("Projet")) = UPPER(?)', (name,)).fetchone()
        if dup and dup[0] != pid:
            raise Conflict(f"Le projet « {name} » existe déjà")
        if pid is None:
            pid = _next_id(c, "ProjEncaissement", "ID")
            c.execute('INSERT INTO ProjEncaissement ("ID", "Projet") VALUES (?, ?)', (pid, name))
        else:
            old = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
            if old is None:
                raise HTTPException(404, "Projet introuvable")
            c.execute('UPDATE ProjEncaissement SET "Projet" = ? WHERE "ID" = ?', (name, pid))
            c.execute('UPDATE Encaissements SET "Projet" = ? WHERE TRIM("Projet") = TRIM(?)', (name, old[0]))
    return {"_id": pid, "projet": name}


def delete_projet(code: str, pid: int) -> None:
    with connect(code) as c:
        _ensure_promo_tables(c)
        r = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        if r is None:
            raise HTTPException(404, "Projet introuvable")
        n = c.execute('SELECT COUNT(*) FROM Encaissements WHERE TRIM("Projet") = TRIM(?)', (r[0],)).fetchone()[0]
        nu = c.execute('SELECT COUNT(*) FROM PromotionUnites WHERE "IdProjet" = ?', (pid,)).fetchone()[0]
        if n or nu:
            raise Conflict(f"Le projet « {r[0]} » contient {nu} unité(s) et {n} versement(s) : suppression impossible")
        c.execute('DELETE FROM PromotionBlocs WHERE "IdProjet" = ?', (pid,))
        c.execute('DELETE FROM ProjEncaissement WHERE "ID" = ?', (pid,))


# ------------------------------------------------------------------ blocs
def blocs(code: str, pid: int) -> list[dict]:
    with connect(code) as c:
        _ensure_promo_tables(c)
        rows = [dict(r) for r in c.execute(
            'SELECT b.*, '
            '(SELECT COUNT(*) FROM PromotionUnites u WHERE u."IdBloc" = b."ID" AND u."TypeUnite" = "logement") AS nbr_logements, '
            '(SELECT COUNT(*) FROM PromotionUnites u WHERE u."IdBloc" = b."ID" AND u."TypeUnite" = "local") AS nbr_locaux, '
            '(SELECT COUNT(*) FROM PromotionUnites u WHERE u."IdBloc" = b."ID" AND u."TypeUnite" = "garage") AS nbr_garages, '
            '(SELECT COUNT(*) FROM PromotionUnites u WHERE u."IdBloc" = b."ID" AND (u."DateActe" IS NOT NULL AND TRIM(u."DateActe") != "")) AS nbr_vendus, '
            '(SELECT COUNT(*) FROM PromotionUnites u WHERE u."IdBloc" = b."ID" AND (u."DateActe" IS NULL OR TRIM(u."DateActe") = "") AND (u."Acquereur" IS NOT NULL AND TRIM(u."Acquereur") != "")) AS nbr_reserves, '
            '(SELECT COALESCE(SUM(u."Superficie"), 0) FROM PromotionUnites u WHERE u."IdBloc" = b."ID") AS superficie_totale, '
            '(SELECT COALESCE(SUM(u."PrixTTC"), 0) FROM PromotionUnites u WHERE u."IdBloc" = b."ID") AS valeur_totale '
            'FROM PromotionBlocs b WHERE b."IdProjet" = ? ORDER BY b."NomBloc"', (pid,))]
    return rows


def save_bloc(code: str, pid: int, data: dict, bid: int | None = None) -> dict:
    nom = str(data.get("NomBloc") or "").strip()
    if not nom:
        raise G50Error("Veuillez saisir le nom ou numéro de la bâtisse / bloc")
    etages = max(1, int(_num(data.get("NbrEtages")) or 5))
    obs = str(data.get("Observations") or "")

    with connect(code) as c:
        _ensure_promo_tables(c)
        dup = c.execute('SELECT "ID" FROM PromotionBlocs WHERE "IdProjet" = ? AND UPPER(TRIM("NomBloc")) = UPPER(?)', (pid, nom)).fetchone()
        if dup and dup[0] != bid:
            raise Conflict(f"Le bloc « {nom} » existe déjà dans ce projet")
        if bid is None:
            bid = _next_id(c, "PromotionBlocs", "ID")
            c.execute('INSERT INTO PromotionBlocs ("ID", "IdProjet", "NomBloc", "NbrEtages", "Observations") VALUES (?, ?, ?, ?, ?)',
                      (bid, pid, nom, etages, obs))
        else:
            c.execute('UPDATE PromotionBlocs SET "NomBloc" = ?, "NbrEtages" = ?, "Observations" = ? WHERE "ID" = ?',
                      (nom, etages, obs, bid))
    return {"_id": bid, "NomBloc": nom, "NbrEtages": etages}


def delete_bloc(code: str, bid: int) -> None:
    with connect(code) as c:
        _ensure_promo_tables(c)
        c.execute('DELETE FROM PromotionEcheances WHERE "IdUnite" IN (SELECT "ID" FROM PromotionUnites WHERE "IdBloc" = ?)', (bid,))
        c.execute('DELETE FROM PromotionUnites WHERE "IdBloc" = ?', (bid,))
        c.execute('DELETE FROM PromotionBlocs WHERE "ID" = ?', (bid,))


# ------------------------------------------------------------------ unités
def unites(code: str, pid: int, bid: int | None = None, type_unite: str = "", statut: str = "", q: str = "") -> dict:
    with connect(code) as c:
        _ensure_promo_tables(c)
        sql = """
            SELECT u.*, b."NomBloc" 
            FROM PromotionUnites u 
            LEFT JOIN PromotionBlocs b ON u."IdBloc" = b."ID" 
            WHERE u."IdProjet" = ?
        """
        args: list[object] = [pid]
        if bid is not None:
            sql += ' AND u."IdBloc" = ?'
            args.append(bid)
        if type_unite:
            sql += ' AND u."TypeUnite" = ?'
            args.append(type_unite)
        if q:
            sql += ' AND (u."Numero" LIKE ? OR u."Acquereur" LIKE ? OR u."TypeLogement" LIKE ? OR b."NomBloc" LIKE ?)'
            args.extend([f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%"])

        sql += ' ORDER BY u."Etage" DESC, u."Numero" ASC'
        rows = [dict(r) for r in c.execute(sql, args)]

    for r in rows:
        r["_id"] = r["ID"]
        r["date_display"] = dates.to_display(r.get("DateActe"))
        r["statut"] = _calc_unite_status(r)
        ttc = _num(r.get("PrixTTC"))
        versem = _num(r.get("TVersem"))
        if r["statut"] == "disponible":
            r["Reste"] = 0.0
            r["taux_paiement"] = 0.0
        else:
            r["Reste"] = max(0.0, ttc - versem)
            r["taux_paiement"] = round((versem / ttc * 100) if ttc > 0 else 0.0, 1)

    if statut:
        rows = [r for r in rows if r["statut"] == statut]

    # Synthèse des totaux
    unites_vendues = [r for r in rows if r.get("DateActe")]
    ca_facture_ttc = sum(_num(r.get("PrixTTC")) for r in unites_vendues)
    ca_facture_ht = sum(_num(r.get("PrixHT")) for r in unites_vendues)
    tva_facturee = sum(_num(r.get("DroitsTVA")) for r in unites_vendues)
    total_versements = sum(_num(r.get("TVersem")) for r in rows)
    creances_reelles = sum(_num(r.get("Reste")) for r in rows if r["statut"] in ("vendu_dette", "reserve"))

    totals = {
        "count_total": len(rows),
        "count_vendus": len(unites_vendues),
        "count_reserves": sum(1 for r in rows if r["statut"] == "reserve"),
        "count_disponibles": sum(1 for r in rows if r["statut"] == "disponible"),
        "superficie_totale": sum(_num(r.get("Superficie")) for r in rows),
        "superficie_vendue": sum(_num(r.get("Superficie")) for r in unites_vendues),
        "ca_facture_ttc": round(ca_facture_ttc, 2),
        "ca_facture_ht": round(ca_facture_ht, 2),
        "droits_tva_ventes": round(tva_facturee, 2),
        "total_versements": round(total_versements, 2),
        "creances_reelles": round(creances_reelles, 2),
    }

    # Groupement par étage pour la vue élévation 2D
    etages_map: dict[int, list[dict]] = {}
    for r in rows:
        et = int(r.get("Etage") or 0)
        etages_map.setdefault(et, []).append(r)

    elevation = []
    for etage_num in sorted(etages_map.keys(), reverse=True):
        if etage_num < 0:
            label = f"Sous-sol {abs(etage_num)}" if abs(etage_num) > 1 else "Sous-sol (Garages)"
            label_ar = f"الطابق تحت الأرض {abs(etage_num)}"
        elif etage_num == 0:
            label = "RDC (Rez-de-chaussée / Locaux)"
            label_ar = "الطابق الأرضي (محلات تجارية)"
        else:
            label = f"Étage {etage_num}"
            label_ar = f"الطابق {etage_num}"
        elevation.append({
            "etage": etage_num,
            "label": label,
            "label_ar": label_ar,
            "unites": etages_map[etage_num]
        })

    return {
        "items": rows,
        "elevation": elevation,
        "totals": totals
    }


def unite_detail(code: str, uid: int) -> dict:
    with connect(code) as c:
        _ensure_promo_tables(c)
        r = c.execute("""
            SELECT u.*, b."NomBloc", p."Projet" 
            FROM PromotionUnites u
            LEFT JOIN PromotionBlocs b ON u."IdBloc" = b."ID"
            LEFT JOIN ProjEncaissement p ON u."IdProjet" = p."ID"
            WHERE u."ID" = ?
        """, (uid,)).fetchone()
        if not r:
            raise HTTPException(404, "Unité introuvable")
        unite = dict(r)
        unite["_id"] = unite["ID"]
        unite["date_display"] = dates.to_display(unite.get("DateActe"))
        unite["statut"] = _calc_unite_status(unite)

        # Versements effectués
        versements = [dict(v) for v in c.execute(
            'SELECT * FROM Encaissements WHERE "IdUnite" = ? ORDER BY "DateOP" DESC', (uid,))]
        for v in versements:
            v["_id"] = v["IDOP"]
            v["date_display"] = dates.to_display(v.get("DateOP"))

        # Échéancier VEFA
        echeances = [dict(e) for e in c.execute(
            'SELECT * FROM PromotionEcheances WHERE "IdUnite" = ? ORDER BY "NumTranche" ASC', (uid,))]
        if not echeances and _num(unite.get("PrixTTC")) > 0:
            ttc = _num(unite["PrixTTC"])
            echeances = [
                {
                    "NumTranche": t["num"],
                    "Libelle": t["libelle"],
                    "Pourcentage": t["pct"],
                    "Montant": round(ttc * t["pct"] / 100, 2),
                    "EstRegle": 1 if _num(unite.get("TVersem")) >= (ttc * sum(x["pct"] for x in VEFA_TRANCHES[:t["num"]]) / 100) else 0
                }
                for t in VEFA_TRANCHES
            ]

    return {"unite": unite, "versements": versements, "echeances": echeances}


def save_unite(code: str, pid: int, data: dict, uid: int | None = None) -> dict:
    numero = str(data.get("Numero") or "").strip()
    if not numero:
        raise G50Error("Veuillez saisir le numéro ou repère de l'unité (ex: A-101)")
    type_u = str(data.get("TypeUnite") or "logement").lower()
    etage = int(_num(data.get("Etage")) or 0)
    type_log = str(data.get("TypeLogement") or ("Commercial" if type_u == "local" else ("Parking" if type_u == "garage" else "F3")))
    sup = _num(data.get("Superficie"))
    p_m2 = _num(data.get("PrixM2"))
    taux_tva = _num(data.get("TauxTVA") or 19.0)
    bid = int(_num(data.get("IdBloc"))) if data.get("IdBloc") else None

    # Calculs automatiques
    prix_ttc = _num(data.get("PrixTTC")) or (sup * p_m2)
    if p_m2 <= 0 and sup > 0 and prix_ttc > 0:
        p_m2 = round(prix_ttc / sup, 2)
    prix_ht = round(prix_ttc / (1 + taux_tva / 100), 2) if taux_tva > 0 else prix_ttc
    droits_tva = round(prix_ttc - prix_ht, 2)

    date_acte_iso = dates.to_storage(data.get("DateActe")) if data.get("DateActe") else None
    acq = str(data.get("Acquereur") or "").strip() or None
    tel = str(data.get("Telephone") or "").strip() or None
    num_acte = str(data.get("NumActe") or "").strip() or None
    notaire = str(data.get("Notaire") or "").strip() or None

    with connect(code) as c:
        _ensure_promo_tables(c)
        if uid is None:
            uid = _next_id(c, "PromotionUnites", "ID")
            t_vers = 0.0
            reste = max(0.0, prix_ttc) if acq or date_acte_iso else 0.0
            statut = "reserve" if acq and not date_acte_iso else ("vendu_dette" if date_acte_iso else "disponible")
            c.execute("""
                INSERT INTO PromotionUnites (
                    "ID", "IdProjet", "IdBloc", "TypeUnite", "Numero", "Etage", "TypeLogement",
                    "Superficie", "PrixM2", "PrixTTC", "PrixHT", "TauxTVA", "DroitsTVA",
                    "Acquereur", "Telephone", "DateActe", "NumActe", "Notaire",
                    "Statut", "TVersem", "Reste", "AvancementPct"
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                uid, pid, bid, type_u, numero, etage, type_log,
                sup, p_m2, prix_ttc, prix_ht, taux_tva, droits_tva,
                acq, tel, date_acte_iso, num_acte, notaire,
                statut, t_vers, reste, _num(data.get("AvancementPct"))
            ))
            # Générer l'échéancier VEFA par défaut
            for t in VEFA_TRANCHES:
                eid = _next_id(c, "PromotionEcheances", "ID")
                c.execute("""
                    INSERT INTO PromotionEcheances ("ID", "IdUnite", "NumTranche", "Libelle", "Pourcentage", "Montant", "EstRegle")
                    VALUES (?, ?, ?, ?, ?, ?, 0)
                """, (eid, uid, t["num"], t["libelle"], t["pct"], round(prix_ttc * t["pct"] / 100, 2)))
        else:
            old = c.execute('SELECT "TVersem" FROM PromotionUnites WHERE "ID" = ?', (uid,)).fetchone()
            t_vers = _num(old[0]) if old else 0.0
            reste = max(0.0, prix_ttc - t_vers) if (acq or date_acte_iso or t_vers > 0) else 0.0
            statut = _calc_unite_status({"DateActe": date_acte_iso, "Reste": reste, "TVersem": t_vers, "Acquereur": acq})

            c.execute("""
                UPDATE PromotionUnites SET
                    "IdBloc" = ?, "TypeUnite" = ?, "Numero" = ?, "Etage" = ?, "TypeLogement" = ?,
                    "Superficie" = ?, "PrixM2" = ?, "PrixTTC" = ?, "PrixHT" = ?, "TauxTVA" = ?, "DroitsTVA" = ?,
                    "Acquereur" = ?, "Telephone" = ?, "DateActe" = ?, "NumActe" = ?, "Notaire" = ?,
                    "Statut" = ?, "Reste" = ?, "AvancementPct" = ?
                WHERE "ID" = ?
            """, (
                bid, type_u, numero, etage, type_log,
                sup, p_m2, prix_ttc, prix_ht, taux_tva, droits_tva,
                acq, tel, date_acte_iso, num_acte, notaire,
                statut, reste, _num(data.get("AvancementPct")), uid
            ))
            # Mettre à jour les montants des tranches VEFA
            c.execute('DELETE FROM PromotionEcheances WHERE "IdUnite" = ?', (uid,))
            for t in VEFA_TRANCHES:
                eid = _next_id(c, "PromotionEcheances", "ID")
                c.execute("""
                    INSERT INTO PromotionEcheances ("ID", "IdUnite", "NumTranche", "Libelle", "Pourcentage", "Montant", "EstRegle")
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (eid, uid, t["num"], t["libelle"], t["pct"], round(prix_ttc * t["pct"] / 100, 2),
                      1 if t_vers >= (prix_ttc * sum(x["pct"] for x in VEFA_TRANCHES[:t["num"]]) / 100) else 0))

    return unite_detail(code, uid)["unite"]


def delete_unite(code: str, uid: int) -> None:
    with connect(code) as c:
        _ensure_promo_tables(c)
        c.execute('DELETE FROM PromotionEcheances WHERE "IdUnite" = ?', (uid,))
        c.execute('DELETE FROM Encaissements WHERE "IdUnite" = ?', (uid,))
        c.execute('DELETE FROM PromotionUnites WHERE "ID" = ?', (uid,))


# ------------------------------------------------------------------ générateur automatique de bloc
def generate_bloc(code: str, pid: int, data: dict) -> dict:
    """Génère automatiquement une bâtisse complète avec logements, locaux et garages."""
    nom_bloc = str(data.get("NomBloc") or "").strip()
    if not nom_bloc:
        raise G50Error("Veuillez indiquer le nom de la bâtisse / bloc (ex: Bloc A)")
    nbr_etages = max(1, int(_num(data.get("NbrEtages")) or 5))
    prix_m2_base = _num(data.get("PrixM2Base")) or 95000.0
    taux_tva = _num(data.get("TauxTVA") or 19.0)

    # Configuration par défaut des logements par étage
    logements_config = data.get("LogementsParEtage") or [
        {"type": "F3", "sup": 85.0, "count": 2, "prix_m2": prix_m2_base},
        {"type": "F4", "sup": 115.0, "count": 2, "prix_m2": prix_m2_base},
    ]
    nbr_locaux_rdc = int(_num(data.get("NbrLocauxRDC")) or 4)
    sup_local = _num(data.get("SuperficieLocal")) or 45.0
    prix_m2_local = _num(data.get("PrixM2Local")) or (prix_m2_base * 1.5)

    nbr_garages_ss = int(_num(data.get("NbrGaragesSS")) or 6)
    sup_garage = _num(data.get("SuperficieGarage")) or 18.0
    prix_forfait_garage = _num(data.get("PrixForfaitGarage")) or 1200000.0

    created_unites = 0
    with connect(code) as c:
        _ensure_promo_tables(c)
        # Créer le bloc
        bid = _next_id(c, "PromotionBlocs", "ID")
        c.execute("""
            INSERT INTO PromotionBlocs ("ID", "IdProjet", "NomBloc", "NbrEtages", "Observations")
            VALUES (?, ?, ?, ?, ?)
        """, (bid, pid, nom_bloc, nbr_etages, f"Génération automatique : R+{nbr_etages}"))

        # 1. Garages en sous-sol (Étage -1)
        if nbr_garages_ss > 0:
            for g_idx in range(1, nbr_garages_ss + 1):
                uid = _next_id(c, "PromotionUnites", "ID")
                num = f"{nom_bloc}-PKG-{str(g_idx).padStart(2, '0') if hasattr(str(g_idx), 'padStart') else f'{g_idx:02d}'}"
                ht = round(prix_forfait_garage / (1 + taux_tva / 100), 2)
                tva = round(prix_forfait_garage - ht, 2)
                c.execute("""
                    INSERT INTO PromotionUnites (
                        "ID", "IdProjet", "IdBloc", "TypeUnite", "Numero", "Etage", "TypeLogement",
                        "Superficie", "PrixM2", "PrixTTC", "PrixHT", "TauxTVA", "DroitsTVA", "Statut", "TVersem", "Reste"
                    ) VALUES (?, ?, ?, 'garage', ?, -1, 'Parking', ?, ?, ?, ?, ?, ?, 'disponible', 0, 0)
                """, (uid, pid, bid, num, sup_garage, round(prix_forfait_garage / sup_garage, 2), prix_forfait_garage, ht, taux_tva, tva))
                created_unites += 1

        # 2. Locaux commerciaux au RDC (Étage 0)
        if nbr_locaux_rdc > 0:
            for l_idx in range(1, nbr_locaux_rdc + 1):
                uid = _next_id(c, "PromotionUnites", "ID")
                num = f"{nom_bloc}-LOC-{l_idx:02d}"
                ttc = round(sup_local * prix_m2_local, 2)
                ht = round(ttc / (1 + taux_tva / 100), 2)
                tva = round(ttc - ht, 2)
                c.execute("""
                    INSERT INTO PromotionUnites (
                        "ID", "IdProjet", "IdBloc", "TypeUnite", "Numero", "Etage", "TypeLogement",
                        "Superficie", "PrixM2", "PrixTTC", "PrixHT", "TauxTVA", "DroitsTVA", "Statut", "TVersem", "Reste"
                    ) VALUES (?, ?, ?, 'local', ?, 0, 'Commercial', ?, ?, ?, ?, ?, ?, 'disponible', 0, 0)
                """, (uid, pid, bid, num, sup_local, prix_m2_local, ttc, ht, taux_tva, tva))
                created_unites += 1

        # 3. Logements aux étages supérieurs (Étages 1..N)
        for etage in range(1, nbr_etages + 1):
            porte = 1
            for cfg in logements_config:
                t_log = str(cfg.get("type") or "F3")
                sup = _num(cfg.get("sup")) or 85.0
                p_m2 = _num(cfg.get("prix_m2")) or prix_m2_base
                cnt = int(_num(cfg.get("count")) or 1)
                for _ in range(cnt):
                    uid = _next_id(c, "PromotionUnites", "ID")
                    num = f"{nom_bloc}-{etage}{porte:02d}"
                    porte += 1
                    ttc = round(sup * p_m2, 2)
                    ht = round(ttc / (1 + taux_tva / 100), 2)
                    tva = round(ttc - ht, 2)
                    c.execute("""
                        INSERT INTO PromotionUnites (
                            "ID", "IdProjet", "IdBloc", "TypeUnite", "Numero", "Etage", "TypeLogement",
                            "Superficie", "PrixM2", "PrixTTC", "PrixHT", "TauxTVA", "DroitsTVA", "Statut", "TVersem", "Reste"
                        ) VALUES (?, ?, ?, 'logement', ?, ?, ?, ?, ?, ?, ?, ?, ?, 'disponible', 0, 0)
                    """, (uid, pid, bid, num, etage, t_log, sup, p_m2, ttc, ht, taux_tva, tva))
                    # Générer tranches VEFA
                    for t in VEFA_TRANCHES:
                        eid = _next_id(c, "PromotionEcheances", "ID")
                        c.execute("""
                            INSERT INTO PromotionEcheances ("ID", "IdUnite", "NumTranche", "Libelle", "Pourcentage", "Montant", "EstRegle")
                            VALUES (?, ?, ?, ?, ?, ?, 0)
                        """, (eid, uid, t["num"], t["libelle"], t["pct"], round(ttc * t["pct"] / 100, 2)))
                    created_unites += 1

    return {"bloc_id": bid, "nom_bloc": nom_bloc, "unites_creees": created_unites}


# ------------------------------------------------------------------ versements liés à l'unité
def save_unite_versement(code: str, uid: int, data: dict) -> dict:
    for k, msg in (("DateOP", "Date requise"), ("MontantTTC", "Montant requis"), ("ModeReg", "Mode requis")):
        if data.get(k) in (None, "") or (k == "MontantTTC" and not _num(data[k])):
            raise G50Error(msg)
    if data["ModeReg"] not in MODES:
        raise G50Error("Mode de règlement inconnu")

    date_iso = dates.to_storage(data["DateOP"])
    d = dates.parse(date_iso)
    ttc = _num(data["MontantTTC"])

    with connect(code) as c:
        _ensure_promo_tables(c)
        u = c.execute("""
            SELECT u.*, p."Projet" 
            FROM PromotionUnites u 
            LEFT JOIN ProjEncaissement p ON u."IdProjet" = p."ID" 
            WHERE u."ID" = ?
        """, (uid,)).fetchone()
        if not u:
            raise HTTPException(404, "Unité introuvable")
        unite = dict(u)

        taux_tva = _num(unite.get("TauxTVA") or 19.0)
        ht = round(ttc / (1 + taux_tva / 100), 2) if taux_tva > 0 else ttc
        tva = round(ttc - ht, 2)
        client = str(data.get("Client") or unite.get("Acquereur") or "").strip() or f"Client {unite['Numero']}"
        projet = str(unite.get("Projet") or "Projet").strip()

        # Enregistrer dans Encaissements pour conformité fiscale globale
        v_id = _next_id(c, "Encaissements", "IDOP")
        values = {
            "IDOP": v_id,
            "DateOP": date_iso,
            "Client": client,
            "CodeTier": str(data.get("CodeTier") or ""),
            "MontantTTC": ttc,
            "TauxTva": taux_tva,
            "HT": ht,
            "TVA": tva,
            "Projet": projet,
            "ModeReg": data["ModeReg"],
            "obs": str(data.get("obs") or f"Versement {unite['Numero']}"),
            "Annee": d.year,
            "NMois": d.month,
            "Peride": d.month,
            "LaPeriode": ref.mois_label(d.month),
            "IdUnite": uid
        }
        c.execute(f'INSERT INTO Encaissements ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                  f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))

        # Recalculer le total des versements de l'unité
        tot_v = c.execute('SELECT COALESCE(SUM("MontantTTC"), 0) FROM Encaissements WHERE "IdUnite" = ?', (uid,)).fetchone()[0]
        prix_ttc = _num(unite["PrixTTC"])
        reste = max(0.0, prix_ttc - tot_v)
        statut = _calc_unite_status({"DateActe": unite.get("DateActe"), "Reste": reste, "TVersem": tot_v, "Acquereur": client})

        c.execute("""
            UPDATE PromotionUnites 
            SET "TVersem" = ?, "Reste" = ?, "Statut" = ?, "Acquereur" = COALESCE("Acquereur", ?) 
            WHERE "ID" = ?
        """, (tot_v, reste, statut, client, uid))

        # Mettre à jour l'échéancier VEFA
        for t in VEFA_TRANCHES:
            tranche_cumul = prix_ttc * sum(x["pct"] for x in VEFA_TRANCHES[:t["num"]]) / 100
            regle = 1 if tot_v >= tranche_cumul else 0
            c.execute('UPDATE PromotionEcheances SET "EstRegle" = ? WHERE "IdUnite" = ? AND "NumTranche" = ?', (regle, uid, t["num"]))

    return unite_detail(code, uid)


# ------------------------------------------------------------------ listing existant pour rétrocompatibilité
def rows(code: str, annee: str, projet: str = "", mois: str = "", mode: str = "", q: str = "") -> list[dict]:
    sql = 'SELECT * FROM Encaissements WHERE 1=1'
    args: list[object] = []
    if annee:
        sql += ' AND CAST("Annee" AS INTEGER) = ?'
        args.append(int(_num(annee)))
    if projet:
        sql += ' AND "Projet" LIKE ?'
        args.append(f"%{projet}%")
    if mois:
        sql += ' AND CAST("NMois" AS INTEGER) = ?'
        args.append(int(_num(mois)))
    if mode:
        sql += ' AND "ModeReg" = ?'
        args.append(mode)
    if q:
        sql += ' AND ("Client" LIKE ? OR "Projet" LIKE ? OR "obs" LIKE ?)'
        args.extend([f"%{q}%", f"%{q}%", f"%{q}%"])

    with connect(code) as c:
        _ensure_promo_tables(c)
        out = [dict(r) for r in c.execute(sql + ' ORDER BY "DateOP" DESC, "IDOP" DESC', args)]
    for r in out:
        r["_id"] = r["IDOP"]
        r["date_display"] = dates.to_display(r.get("DateOP"))
    return out


def list_(code: str, annee: str, projet: str = "", mois: str = "", mode: str = "", q: str = "") -> dict:
    items = rows(code, annee, projet, mois=mois, mode=mode, q=q)
    tot = lambda k: sum(_num(r.get(k)) for r in items)

    MOIS_AR = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]
    MOIS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]

    monthly_map = {}
    for r in items:
        m = int(r.get("NMois") or 1)
        m = max(1, min(12, m))
        an = str(r.get("Annee") or annee)
        k = f"{an}-{m}"
        ttc = _num(r.get("MontantTTC"))
        ht = _num(r.get("HT"))
        tva = _num(r.get("TVA"))

        if k not in monthly_map:
            monthly_map[k] = {
                "Annee": an,
                "Mois": m,
                "MoisLib": MOIS_AR[m - 1],
                "MoisLibFR": MOIS_FR[m - 1],
                "count": 0,
                "ttc": 0.0,
                "ht": 0.0,
                "tva": 0.0,
            }
        monthly_map[k]["count"] += 1
        monthly_map[k]["ttc"] += ttc
        monthly_map[k]["ht"] += ht
        monthly_map[k]["tva"] += tva

    monthly_list = sorted(monthly_map.values(), key=lambda x: (x["Annee"], x["Mois"]), reverse=True)

    return {
        "items": items,
        "monthly": monthly_list,
        "totals": {"ttc": tot("MontantTTC"), "ht": tot("HT"), "tva": tot("TVA")},
        "projets": projets(code),
        "modes": MODES,
        "taux": [_num(t["TAUX"]) for t in ref.table("TauxTVA")]
    }


def save(code: str, annee: str, data: dict, item_id: int | None = None) -> dict:
    for k, msg in (("DateOP", "Veuillez saisir la date de l’opération."), ("Client", "Veuillez saisir le nom du client."),
                   ("MontantTTC", "Veuillez saisir le montant TTC."), ("TauxTva", "Veuillez sélectionner le taux TVA."),
                   ("Projet", "Veuillez sélectionner le projet."), ("ModeReg", "Veuillez sélectionner le mode de règlement.")):
        if data.get(k) in (None, "") or (k == "MontantTTC" and not _num(data[k])):
            raise G50Error(msg)
    if data["ModeReg"] not in MODES:
        raise G50Error("Mode de règlement inconnu")
    date_iso = dates.to_storage(data["DateOP"])
    d = dates.parse(date_iso)
    ttc, taux = _num(data["MontantTTC"]), _num(data["TauxTva"])
    ht = ttc / (1 + taux / 100) if taux > 0 else ttc
    values = {"DateOP": date_iso, "Client": str(data["Client"]).strip(), "CodeTier": str(data.get("CodeTier") or ""),
              "MontantTTC": round(ttc, 2), "TauxTva": taux, "HT": round(ht, 2), "TVA": round(ttc - ht, 2),
              "Projet": str(data["Projet"]).strip(), "ModeReg": data["ModeReg"], "obs": str(data.get("obs") or ""),
              "Annee": int(_num(annee)), "NMois": d.month, "Peride": d.month, "LaPeriode": ref.mois_label(d.month)}
    with connect(code) as c:
        _ensure_promo_tables(c)
        if not c.execute('SELECT 1 FROM ProjEncaissement WHERE TRIM("Projet") = ?', (values["Projet"],)).fetchone():
            raise G50Error("Projet inconnu : ajoutez-le d’abord à la liste des projets")
        if item_id is None:
            values["IDOP"] = item_id = _next_id(c, "Encaissements", "IDOP")
            c.execute(f'INSERT INTO Encaissements ({", ".join(chr(34) + k + chr(34) for k in values)}) '
                      f'VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
        elif not c.execute(f'UPDATE Encaissements SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in values)} '
                           'WHERE "IDOP" = ?', (*values.values(), item_id)).rowcount:
            raise HTTPException(404, "Versement introuvable")
    return {"id": item_id}


def delete(code: str, item_id: int) -> None:
    with connect(code) as c:
        _ensure_promo_tables(c)
        if not c.execute('DELETE FROM Encaissements WHERE "IDOP" = ?', (item_id,)).rowcount:
            raise HTTPException(404, "Versement introuvable")


# ------------------------------------------------------------------ Situation, Facturation, Encaissements & TCR
def ca_facture(code: str, pid: int, annee: str = "", mois: str = "", q: str = "") -> dict:
    year_sql = """
        CASE 
            WHEN u."DateActe" IS NOT NULL AND u."DateActe" <> '' THEN substr(u."DateActe", 1, 4)
            ELSE strftime('%Y', 'now')
        END
    """
    month_sql = """
        CASE 
            WHEN u."DateActe" IS NOT NULL AND u."DateActe" <> '' AND length(u."DateActe") >= 7 THEN CAST(substr(u."DateActe", 6, 2) AS INTEGER)
            ELSE 1
        END
    """
    sql = f"""
        SELECT u.*, b."NomBloc", ({year_sql}) AS Annee, ({month_sql}) AS Mois
        FROM PromotionUnites u
        LEFT JOIN PromotionBlocs b ON u."IdBloc" = b."ID"
        WHERE u."IdProjet" = ? AND u."DateActe" IS NOT NULL AND TRIM(u."DateActe") <> ''
    """
    args: list[object] = [pid]
    if annee:
        sql += f" AND ({year_sql}) = ?"
        args.append(str(annee))
    if mois:
        sql += f" AND ({month_sql}) = ?"
        args.append(int(mois))
    if q:
        sql += ' AND (u."Numero" LIKE ? OR u."Acquereur" LIKE ? OR u."NumActe" LIKE ? OR u."Notaire" LIKE ?)'
        args.extend([f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%"])

    sql += f" ORDER BY ({year_sql}) DESC, ({month_sql}) DESC, u.\"Numero\" ASC"

    with connect(code) as c:
        _ensure_promo_tables(c)
        unites_facturees = [dict(r) for r in c.execute(sql, args)]

    MOIS_AR = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]
    MOIS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]

    monthly_map: dict[tuple[str, int], dict] = {}
    yearly_map: dict[str, dict] = {}
    total_ht = 0.0
    total_ttc = 0.0
    total_tva = 0.0
    total_sup = 0.0

    for u in unites_facturees:
        u["_id"] = u["ID"]
        u["date_display"] = dates.to_display(u.get("DateActe"))
        an = str(u.get("Annee") or "")
        m = int(u.get("Mois") or 1)
        m = max(1, min(12, m))
        key = (an, m)
        ttc = _num(u.get("PrixTTC"))
        ht = _num(u.get("PrixHT"))
        tva = _num(u.get("DroitsTVA"))
        sup = _num(u.get("Superficie"))

        total_ht += ht
        total_ttc += ttc
        total_tva += tva
        total_sup += sup

        if key not in monthly_map:
            monthly_map[key] = {
                "Annee": an,
                "Mois": m,
                "MoisLib": MOIS_AR[m - 1],
                "MoisLibFR": MOIS_FR[m - 1],
                "count": 0,
                "sup": 0.0,
                "total_ht": 0.0,
                "total_tva": 0.0,
                "total_ttc": 0.0,
            }
        monthly_map[key]["count"] += 1
        monthly_map[key]["sup"] += sup
        monthly_map[key]["total_ht"] += ht
        monthly_map[key]["total_tva"] += tva
        monthly_map[key]["total_ttc"] += ttc

        if an not in yearly_map:
            yearly_map[an] = {
                "Annee": an,
                "count": 0,
                "sup": 0.0,
                "total_ht": 0.0,
                "total_tva": 0.0,
                "total_ttc": 0.0,
            }
        yearly_map[an]["count"] += 1
        yearly_map[an]["sup"] += sup
        yearly_map[an]["total_ht"] += ht
        yearly_map[an]["total_tva"] += tva
        yearly_map[an]["total_ttc"] += ttc

    monthly_list = sorted(monthly_map.values(), key=lambda x: (x["Annee"], x["Mois"]), reverse=True)
    yearly_list = sorted(yearly_map.values(), key=lambda x: x["Annee"], reverse=True)

    return {
        "items": unites_facturees,
        "monthly": monthly_list,
        "yearly": yearly_list,
        "total_ht": round(total_ht, 2),
        "total_tva": round(total_tva, 2),
        "total_ttc": round(total_ttc, 2),
        "total_sup": round(total_sup, 2),
        "total_unites": len(unites_facturees),
    }


def encaissements_projet(code: str, pid: int, annee: str = "", mois: str = "", mode: str = "", q: str = "") -> dict:
    with connect(code) as c:
        _ensure_promo_tables(c)
        proj_row = c.execute('SELECT "Projet" FROM ProjEncaissement WHERE "ID" = ?', (pid,)).fetchone()
        proj_name = proj_row[0] if proj_row else ""

        sql = """
            SELECT e.*, e."IDOP" AS _id, u."Numero" AS UniteNumero, u."TypeUnite"
            FROM Encaissements e
            LEFT JOIN PromotionUnites u ON e."IdUnite" = u."ID"
            WHERE (e."IdUnite" IN (SELECT "ID" FROM PromotionUnites WHERE "IdProjet" = ?)
                   OR (e."IdUnite" IS NULL AND e."Projet" = ?))
        """
        args: list[object] = [pid, proj_name]
        if annee:
            sql += ' AND CAST(e."Annee" AS TEXT) = ?'
            args.append(str(annee))
        if mois:
            sql += ' AND CAST(e."NMois" AS TEXT) = ?'
            args.append(str(int(mois)))
        if mode:
            sql += ' AND e."ModeReg" = ?'
            args.append(mode)
        if q:
            sql += ' AND (e."Client" LIKE ? OR e."obs" LIKE ? OR u."Numero" LIKE ?)'
            args.extend([f"%{q}%", f"%{q}%", f"%{q}%"])

        sql += ' ORDER BY e."DateOP" DESC, e."IDOP" DESC'
        items = [dict(r) for r in c.execute(sql, args)]

    MOIS_AR = ["جانفي", "فيفري", "مارس", "أفريل", "ماي", "جوان", "جويلية", "أوت", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]
    MOIS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]

    monthly_map: dict[tuple[str, int], dict] = {}
    yearly_map: dict[str, dict] = {}
    mode_map: dict[str, float] = {}
    grand_ttc = 0.0
    grand_ht = 0.0
    grand_tva = 0.0

    for r in items:
        r["date_display"] = dates.to_display(r.get("DateOP"))
        an = str(r.get("Annee") or "")
        m = int(r.get("NMois") or 1)
        m = max(1, min(12, m))
        key = (an, m)
        ttc = _num(r.get("MontantTTC"))
        ht = _num(r.get("HT"))
        tva = _num(r.get("TVA"))
        m_reg = str(r.get("ModeReg") or "Autre")

        grand_ttc += ttc
        grand_ht += ht
        grand_tva += tva

        mode_map[m_reg] = mode_map.get(m_reg, 0.0) + ttc

        if key not in monthly_map:
            monthly_map[key] = {
                "Annee": an,
                "Mois": m,
                "MoisLib": MOIS_AR[m - 1],
                "MoisLibFR": MOIS_FR[m - 1],
                "count": 0,
                "total_ht": 0.0,
                "total_tva": 0.0,
                "total_ttc": 0.0,
            }
        monthly_map[key]["count"] += 1
        monthly_map[key]["total_ht"] += ht
        monthly_map[key]["total_tva"] += tva
        monthly_map[key]["total_ttc"] += ttc

        if an not in yearly_map:
            yearly_map[an] = {
                "Annee": an,
                "count": 0,
                "total_ht": 0.0,
                "total_tva": 0.0,
                "total_ttc": 0.0,
            }
        yearly_map[an]["count"] += 1
        yearly_map[an]["total_ht"] += ht
        yearly_map[an]["total_tva"] += tva
        yearly_map[an]["total_ttc"] += ttc

    monthly_list = sorted(monthly_map.values(), key=lambda x: (x["Annee"], x["Mois"]), reverse=True)
    yearly_list = sorted(yearly_map.values(), key=lambda x: x["Annee"], reverse=True)

    return {
        "items": items,
        "monthly": monthly_list,
        "yearly": yearly_list,
        "modes": [{"mode": k, "total": v} for k, v in mode_map.items()],
        "grand_total_ttc": round(grand_ttc, 2),
        "grand_total_ht": round(grand_ht, 2),
        "grand_total_tva": round(grand_tva, 2),
        "count": len(items),
    }


def creances_projet(code: str, pid: int, q: str = "") -> list[dict]:
    sql = """
        SELECT u.*, b."NomBloc", u."ID" AS _id
        FROM PromotionUnites u
        LEFT JOIN PromotionBlocs b ON u."IdBloc" = b."ID"
        WHERE u."IdProjet" = ? AND u."Reste" > 0 
          AND ((u."DateActe" IS NOT NULL AND TRIM(u."DateActe") <> '')
               OR u."TVersem" > 0 
               OR (u."Acquereur" IS NOT NULL AND TRIM(u."Acquereur") <> ''))
    """
    args: list[object] = [pid]
    if q:
        sql += ' AND (u."Numero" LIKE ? OR u."Acquereur" LIKE ? OR u."Telephone" LIKE ?)'
        args.extend([f"%{q}%", f"%{q}%", f"%{q}%"])

    sql += ' ORDER BY u."Reste" DESC, u."Numero" ASC'

    with connect(code) as c:
        _ensure_promo_tables(c)
        rows = [dict(r) for r in c.execute(sql, args)]

    for r in rows:
        r["date_display"] = dates.to_display(r.get("DateActe"))
        prix = _num(r.get("PrixTTC"))
        versem = _num(r.get("TVersem"))
        r["taux_recouvrement"] = round((versem / prix * 100), 1) if prix > 0 else 0.0

    return rows


def tcr_projet(code: str, pid: int) -> list[dict]:
    """Compte de résultat annuel fiscal pour la promotion immobilière (loi 11-04 & code des impôts)."""
    with connect(code) as c:
        _ensure_promo_tables(c)
        year_sql = """
            CASE 
                WHEN u."DateActe" IS NOT NULL AND u."DateActe" <> '' THEN substr(u."DateActe", 1, 4)
                ELSE strftime('%Y', 'now')
            END
        """
        rows = [dict(r) for r in c.execute(f"""
            SELECT ({year_sql}) AS "Annee",
                   COUNT(*) AS NbreUnites,
                   SUM(u."Superficie") AS Tsuperficie,
                   SUM(u."PrixTTC") AS PCessionTTC,
                   SUM(u."PrixHT") AS CA,
                   SUM(u."DroitsTVA") AS TDroitsTVA
            FROM PromotionUnites u
            WHERE u."IdProjet" = ? AND u."DateActe" IS NOT NULL AND TRIM(u."DateActe") <> ''
            GROUP BY ({year_sql})
            ORDER BY ({year_sql}) DESC
        """, (pid,))]

    for r in rows:
        an = str(r["Annee"])
        ca_ht = _num(r["CA"])
        tva = _num(r["TDroitsTVA"])
        # Coût de revient estimé à 60% du CA HT
        cout_revient = round(ca_ht * 0.60, 2)
        r["CoutRevnent"] = cout_revient
        r["Tcharges"] = cout_revient
        resultat = max(0.0, ca_ht - cout_revient)
        r["resultat"] = round(resultat, 2)
        d_ibs = round(resultat * 0.26)
        r["Dirg"] = d_ibs
        r["IRG"] = d_ibs
        r["IBS"] = d_ibs
        r["Tdroits"] = round(tva + d_ibs)
        r["_id"] = an
        r["impot"] = "IBS"

    return rows


def situation(code: str, pid: int) -> dict:
    fac = ca_facture(code, pid)
    enc = encaissements_projet(code, pid)
    cre = creances_projet(code, pid)
    tcr_list = tcr_projet(code, pid)

    with connect(code) as c:
        _ensure_promo_tables(c)
        tot_unites = c.execute('SELECT COUNT(*), COALESCE(SUM("Superficie"), 0) FROM PromotionUnites WHERE "IdProjet" = ?', (pid,)).fetchone()
        breakdown = c.execute('''
            SELECT "TypeUnite", 
                   COUNT(*) as total, 
                   SUM(CASE WHEN "DateActe" IS NOT NULL AND "DateActe" != '' THEN 1 ELSE 0 END) as vendus
            FROM PromotionUnites 
            WHERE "IdProjet" = ?
            GROUP BY "TypeUnite"
        ''', (pid,)).fetchall()

    by_type = {dict(row)["TypeUnite"]: {"total": row["total"], "vendus": row["vendus"]} for row in breakdown}
    total_count = tot_unites[0] if tot_unites else 0
    total_sup = tot_unites[1] if tot_unites else 0.0

    return {
        "facturation": fac,
        "versements": enc,
        "creances": cre,
        "tcr": tcr_list,
        "summary": {
            "total_unites": total_count,
            "total_sup": total_sup,
            "unites_vendues": fac["total_unites"],
            "sup_vendue": fac["total_sup"],
            "logements_total": by_type.get("logement", {}).get("total", 0),
            "logements_vendus": by_type.get("logement", {}).get("vendus", 0),
            "locaux_total": by_type.get("local", {}).get("total", 0),
            "locaux_vendus": by_type.get("local", {}).get("vendus", 0),
            "garages_total": by_type.get("garage", {}).get("total", 0),
            "garages_vendus": by_type.get("garage", {}).get("vendus", 0),
            "ca_facture_ttc": fac["total_ttc"],
            "ca_facture_ht": fac["total_ht"],
            "droits_tva_ventes": fac["total_tva"],
            "total_versements": enc["grand_total_ttc"],
            "creances_reelles": sum(_num(x["Reste"]) for x in cre),
        }
    }
