"""Lotissement Reports & Situations — Mises en page HTML haute fidélité (A4 portrait & paysage)
et exports Excel/PDF conformes pour :
  - lotissement_plan : المخطط العقاري والمسحي A4 مع شبكة القطع والألوان والمفتاح الإحصائي
  - lotissement_lots : قائمة القطع الأرضية والتفاصيل التعاقدية والمالية مع رقم العقد والموثق
  - lotissement_versements : كشف المقبوضات الشهرية والسنوية والتسبيقات
  - lotissement_creances : كشف الديون والمستحقات المتبقية
  - lotissement_annuelle : الوضعية السنوية وحساب النتائج (TCR / IBS / IRG)
  - lotissement_globale : الوضعية الشاملة للمشروع والتكاليف الإجمالية للهيئة
"""
from __future__ import annotations

import base64
from datetime import datetime
from html import escape
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from ..core import config
from ..core.db import connect
from . import dates, dossiers, honoraires, lotissement
from .g50 import G50Error, _num

FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"


def _font_face() -> str:
    faces = []
    for f, rng in (
        ("cairo-arabic-wght-normal.woff2", "U+0600-06FF,U+0750-077F,U+0870-08FF,U+FB50-FDFF,U+FE70-FEFF"),
        ("cairo-latin-wght-normal.woff2", "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+2000-206F,U+20AC"),
    ):
        p = FONTS / f
        if p.is_file():
            b64 = base64.b64encode(p.read_bytes()).decode()
            faces.append(
                f"@font-face{{font-family:'Cairo';font-weight:200 1000;src:url(data:font/woff2;base64,{b64}) format('woff2');unicode-range:{rng};}}"
            )
    return "".join(faces)


def money(v: float | int | None) -> str:
    val = round(float(v or 0), 2)
    return f"{val:,.2f}".replace(",", " ").replace(".", ",")


def money_int(v: float | int | None) -> str:
    val = round(float(v or 0))
    return f"{val:,}".replace(",", " ")


def _resolve_lid(code: str, params: dict) -> int:
    try:
        lid = int(params.get("id") or params.get("lotissement_id") or 0)
    except Exception:
        lid = 0
    if lid <= 0:
        try:
            with connect(code) as c:
                row = c.execute('SELECT "ID" FROM Lotissement ORDER BY "ID" LIMIT 1').fetchone()
                if row:
                    lid = int(row[0])
        except Exception:
            pass
    return lid


CSS_BASE = """
* { box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
body { margin: 0; font-family: 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif; color: #0f172a; font-size: 11px; line-height: 1.4; background: #fff; }
.doc { width: 100%; max-width: 1120px; margin: 0 auto; padding: 4px; }
.top-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #047857; padding-bottom: 8px; margin-bottom: 12px; gap: 12px; }
.header-company { flex: 1; }
.header-company h2 { margin: 0 0 4px; font-size: 16px; font-weight: 900; color: #047857; }
.header-company p { margin: 1px 0; font-size: 10.5px; color: #475569; }
.header-company b { color: #0f172a; }
.header-title-box { text-align: center; background: #f8fafc; border: 1.5px solid #cbd5e1; border-radius: 6px; padding: 8px 16px; min-width: 320px; }
.header-title-box h1 { margin: 0 0 3px; font-size: 15px; font-weight: 900; color: #0f172a; letter-spacing: -0.01em; }
.header-title-box p { margin: 0; font-size: 10.5px; font-weight: 700; color: #047857; }
.header-meta { text-align: end; font-size: 10px; color: #64748b; line-height: 1.5; min-width: 140px; }
.kpis-banner { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-bottom: 12px; }
.kpi-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 10px; text-align: center; }
.kpi-card span { display: block; font-size: 10px; color: #64748b; margin-bottom: 2px; }
.kpi-card b { font-size: 13px; font-weight: 800; color: #0f172a; font-family: 'Cairo', monospace; }
.report-table { width: 100%; border-collapse: collapse; margin-top: 6px; font-size: 10.5px; }
.report-table th { background: #047857; color: #fff; font-weight: 700; padding: 6px 6px; border: 1px solid #047857; text-align: center; }
.report-table td { padding: 5px 6px; border: 1px solid #cbd5e1; vertical-align: middle; }
.report-table tr:nth-child(even) td { background: #f8fafc; }
.report-table tr.total-row td { background: #e2e8f0; font-weight: 800; border-top: 2px solid #0f172a; }
.num { font-family: 'Cairo', 'Consolas', monospace; text-align: right; white-space: nowrap; }
.center { text-align: center; }
.pill { display: inline-block; padding: 1px 6px; border-radius: 4px; font-size: 9.5px; font-weight: 800; color: #fff; }
.footer { margin-top: 14px; padding-top: 6px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 9.5px; color: #94a3b8; }
"""


def _doc_head(title: str, orientation: str = "portrait", is_ar: bool = True) -> str:
    page_css = f"@page {{ size: A4 {orientation}; margin: 8mm 10mm; }}"
    dir_attr = 'dir="rtl"' if is_ar else 'dir="ltr"'
    lang_attr = 'lang="ar"' if is_ar else 'lang="fr"'
    return f"""<!DOCTYPE html>
<html {dir_attr} {lang_attr}>
<head>
<meta charset="utf-8">
<title>{escape(title)}</title>
<style>
{_font_face()}
{page_css}
{CSS_BASE}
</style>
</head>
<body>
<div class="doc">
"""


def _doc_header(code: str, title: str, subtitle: str, is_ar: bool = True) -> str:
    soc = dossiers.societe(code)
    rs = escape(str(soc.get("rs") or f"Entreprise {code}"))
    nif = escape(str(soc.get("NIF") or "—"))
    ai = escape(str(soc.get("article") or "—"))
    rc = escape(str(soc.get("RC") or "—"))
    adr = escape(str(soc.get("adresse") or "—"))
    now = datetime.now().strftime("%d/%m/%Y %H:%M")

    if is_ar:
        lbl_nif = f"ر.ت.ج (NIF) : <b>{nif}</b>"
        lbl_ai = f"ر.الضريبة : <b>{ai}</b>"
        lbl_rc = f"السجل التجاري : <b>{rc}</b>"
        lbl_date = f"تاريخ الطباعة : {now}"
    else:
        lbl_nif = f"NIF : <b>{nif}</b>"
        lbl_ai = f"Art. Imp : <b>{ai}</b>"
        lbl_rc = f"RC : <b>{rc}</b>"
        lbl_date = f"Édité le : {now}"

    return f"""
<div class="top-header">
  <div class="header-company">
    <h2>{rs}</h2>
    <p>{lbl_nif} · {lbl_ai} · {lbl_rc}</p>
    <p>{adr}</p>
  </div>
  <div class="header-title-box">
    <h1>{escape(title)}</h1>
    <p>{escape(subtitle)}</p>
  </div>
  <div class="header-meta">
    <div>{lbl_date}</div>
    <div>Dec G50 ERP</div>
  </div>
</div>
"""


# ------------------------------------------------------------------ 1. المخطط العقاري A4 (Cadastre Plan A4)
def render_plan_html(code: str, params: dict) -> tuple[str, str]:
    lid = _resolve_lid(code, params)
    lang = str(params.get("lang") or "ar").lower()
    is_ar = lang != "fr"
    data = lotissement.lots(code, lid)
    st = data["study"]
    lots = data["items"]
    totals = data["totals"]

    title = f"المخطط العقاري والمسحي للمشروع (A4)" if is_ar else f"Plan Cadastral du Lotissement (A4)"
    sub = f"{st.get('Adresse')} · {st.get('Lotisseur')}"
    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    # KPIs
    h.append("""<div class="kpis-banner">""")
    kpis = [
        ("إجمالي القطع" if is_ar else "Total Lots", f"{len(lots)}"),
        ("المساحة المباعة" if is_ar else "Surface Vendue", f"{money_int(totals.get('SupLot'))} / {money_int(st.get('SupUtile'))} m²"),
        ("رقم الأعمال الإجمالي" if is_ar else "CA Cession", f"{money_int(totals.get('PcessionLot'))} DA"),
        ("المقبوضات المستلمة" if is_ar else "Versements Reçus", f"{money_int(totals.get('TVersemU'))} DA"),
        ("الديون المتبقية" if is_ar else "Créances / Reste", f"{money_int(totals.get('ResteU'))} DA"),
    ]
    for lbl, val in kpis:
        h.append(f"""<div class="kpi-card"><span>{lbl}</span><b>{val}</b></div>""")
    h.append("""</div>""")

    # Legend
    leg = [
        ("#059669", "مسدد بالكامل 100%" if is_ar else "Soldé (100% payé)"),
        ("#d97706", "مبيوع مع ديون" if is_ar else "Vendu avec créance"),
        ("#2563eb", "محجوز / تسبيق" if is_ar else "Réservé / Acompte"),
        ("#64748b", "متاح للبيع" if is_ar else "Disponible à la vente"),
    ]
    h.append("""<div style="display:flex;gap:16px;justify-content:center;margin-bottom:12px;font-size:11px;font-weight:700;">""")
    for color, text in leg:
        h.append(f"""<span style="display:inline-flex;align-items:center;gap:5px;">
            <span style="width:12px;height:12px;background:{color};border-radius:3px;display:inline-block;"></span>
            {text}
        </span>""")
    h.append("""</div>""")

    # Grid Matrix for A4
    cols = 6 if len(lots) > 24 else 5
    h.append(f"""<div style="display:grid;grid-template-columns:repeat({cols}, 1fr);gap:8px;">""")
    for plot in lots:
        statut = plot.get("statut", "disponible")
        bg_col = {
            "vendu_solde": "#ecfdf5",
            "vendu_dette": "#fffbeb",
            "reserve": "#eff6ff",
            "disponible": "#f8fafc"
        }.get(statut, "#f8fafc")
        border_col = {
            "vendu_solde": "#10b981",
            "vendu_dette": "#f59e0b",
            "reserve": "#3b82f6",
            "disponible": "#cbd5e1"
        }.get(statut, "#cbd5e1")
        acq = escape(str(plot.get("Acquereur") or ("متاح للبيع" if is_ar else "Disponible")))
        reste = _num(plot.get("ResteU"))
        verse = _num(plot.get("TVersemU"))
        prix = _num(plot.get("PcessionLot"))
        sup = plot.get("SupLot")

        h.append(f"""
        <div style="background:{bg_col};border:1.5px solid {border_col};border-radius:6px;padding:6px 8px;font-size:10px;line-height:1.3;">
          <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(0,0,0,0.06);padding-bottom:3px;margin-bottom:3px;">
            <b style="font-size:13px;color:#0f172a;">N° {plot.get('Nlot')}</b>
            <span style="background:{border_col};color:#fff;padding:1px 5px;border-radius:3px;font-size:9px;font-weight:800;">{sup} m²</span>
          </div>
          <div style="font-weight:700;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="{acq}">{acq}</div>
          <div style="color:#64748b;font-size:9.5px;margin-top:2px;">{money_int(prix)} DA</div>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-top:4px;font-size:9.5px;font-weight:800;">
            <span style="color:{border_col};">{statut.replace('_', ' ').title()}</span>
            <span style="color:{'#b91c1c' if reste > 0 else '#059669'};">{f'-{money_int(reste)}' if reste > 0 else ('✓ مسدد' if is_ar else '✓ Soldé')}</span>
          </div>
        </div>
        """)
    h.append("""</div>""")

    h.append(f"""
    <div class="footer">
      <span>{escape(st.get('Adresse', ''))} · {escape(st.get('Lotisseur', ''))}</span>
      <span>{len(lots)} {'قطعة أرضية' if is_ar else 'lots'}</span>
    </div>
    </div></body></html>
    """)
    return "".join(h), title


# ------------------------------------------------------------------ 2. قائمة القطع الأرضية (Lots Table A4)
def render_lots_html(code: str, params: dict) -> tuple[str, str]:
    lid = _resolve_lid(code, params)
    lang = str(params.get("lang") or "ar").lower()
    is_ar = lang != "fr"
    data = lotissement.lots(code, lid)
    st = data["study"]
    lots = data["items"]
    t = data["totals"]

    title = "كشف القطع الأرضية والتفاصيل التعاقدية" if is_ar else "Liste des Lots & Détails Contractuels"
    sub = f"{st.get('Adresse')} · {st.get('Lotisseur')}"
    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append("""
    <table class="report-table">
      <thead>
        <tr>
          <th style="width:40px;">N°</th>
          <th style="width:170px;">""" + ("المشتري / الحائز" if is_ar else "Acquéreur") + """</th>
          <th style="width:70px;">""" + ("المساحة (م²)" if is_ar else "Superficie") + """</th>
          <th style="width:90px;">""" + ("سعر الوحدة /م²" if is_ar else "Prix /m²") + """</th>
          <th style="width:110px;">""" + ("سعر القطعة" if is_ar else "Prix du lot") + """</th>
          <th style="width:100px;">""" + ("تكلفة الإنجاز" if is_ar else "Coût revient") + """</th>
          <th style="width:95px;">""" + ("وعاء الرسم TVA" if is_ar else "Base TVA") + """</th>
          <th style="width:85px;">""" + ("حقوق TVA" if is_ar else "Droits TVA") + """</th>
          <th style="width:85px;">""" + ("تاريخ العقد" if is_ar else "Date d’acte") + """</th>
          <th style="width:80px;">""" + ("رقم العقد" if is_ar else "N° d’acte") + """</th>
          <th style="width:120px;">""" + ("مكتب الموثق" if is_ar else "Notaire") + """</th>
          <th style="width:105px;">""" + ("المقبوضات" if is_ar else "Versements") + """</th>
          <th style="width:105px;">""" + ("المتبقي / الديون" if is_ar else "Reste à payer") + """</th>
        </tr>
      </thead>
      <tbody>
    """)

    for r in lots:
        h.append(f"""
        <tr>
          <td class="center"><b>{r.get('Nlot')}</b></td>
          <td><b>{escape(str(r.get('Acquereur') or '—'))}</b></td>
          <td class="num">{money(r.get('SupLot'))}</td>
          <td class="num">{money(r.get('PCessionU'))}</td>
          <td class="num">{money(r.get('PcessionLot'))}</td>
          <td class="num">{money(r.get('CoutrevnentLot'))}</td>
          <td class="num">{money(r.get('BaseTvaLot'))}</td>
          <td class="num">{money(r.get('DroitsTvaLot'))}</td>
          <td class="center">{r.get('date_display') or '—'}</td>
          <td class="center">{escape(str(r.get('NumActe') or '—'))}</td>
          <td>{escape(str(r.get('Notaire') or '—'))}</td>
          <td class="num" style="color:#047857;font-weight:700;">{money(r.get('TVersemU'))}</td>
          <td class="num" style="color:{'#b91c1c' if _num(r.get('ResteU')) > 0 else '#047857'};font-weight:700;">{money(r.get('ResteU'))}</td>
        </tr>
        """)

    # Totals Row
    h.append(f"""
      <tr class="total-row">
        <td colspan="2" class="center"><b>{("المجموع العام" if is_ar else "TOTAL GÉNÉRAL")} ({len(lots)} {('قطعة' if is_ar else 'lots')})</b></td>
        <td class="num">{money(t.get('SupLot'))}</td>
        <td></td>
        <td class="num">{money(t.get('PcessionLot'))}</td>
        <td class="num">{money(t.get('CoutrevnentLot'))}</td>
        <td class="num">{money(t.get('BaseTvaLot'))}</td>
        <td class="num">{money(t.get('DroitsTvaLot'))}</td>
        <td colspan="3"></td>
        <td class="num" style="color:#047857;">{money(t.get('TVersemU'))}</td>
        <td class="num" style="color:#b91c1c;">{money(t.get('ResteU'))}</td>
      </tr>
      </tbody>
    </table>
    <div class="footer">
      <span>{escape(st.get('Adresse', ''))} · {escape(st.get('Lotisseur', ''))}</span>
      <span>{len(lots)} {'قطعة مسجلة' if is_ar else 'lots enregistrés'}</span>
    </div>
    </div></body></html>
    """)
    return "".join(h), title


# ------------------------------------------------------------------ 3. المقبوضات الشهرية والسنوية والتسبيقات (Versements A4)
def render_versements_html(code: str, params: dict) -> tuple[str, str]:
    lid = _resolve_lid(code, params)
    lang = str(params.get("lang") or "ar").lower()
    is_ar = lang != "fr"
    st = lotissement.study(code, lid)
    annee_filter = str(params.get("annee") or "")
    mois_filter = str(params.get("mois") or "")
    mode_filter = str(params.get("mode") or "")
    q_filter = str(params.get("q") or "")

    vers = lotissement.versements(code, lid, annee=annee_filter, mois=mois_filter, mode=mode_filter, q=q_filter)
    enc_m = lotissement.encaissements_mensuels(code, lid, annee=annee_filter, mode=mode_filter, q=q_filter)

    title = "كشف المقبوضات الشهرية والسنوية والتسبيقات" if is_ar else "Relevé des Encaissements Mensuels & Annuels"
    filter_desc = []
    if annee_filter: filter_desc.append(f"السنة: {annee_filter}" if is_ar else f"Année: {annee_filter}")
    if mois_filter: filter_desc.append(f"الشهر: {mois_filter}" if is_ar else f"Mois: {mois_filter}")
    if mode_filter: filter_desc.append(f"طريقة الدفع: {mode_filter}" if is_ar else f"Mode: {mode_filter}")
    if q_filter: filter_desc.append(f"بحث: {q_filter}" if is_ar else f"Recherche: {q_filter}")

    sub = f"{st.get('Adresse')} · {st.get('Lotisseur')}"
    if filter_desc:
        sub += f" · ({' | '.join(filter_desc)})"

    h = [_doc_head(title, "portrait", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    # Summary table: Encaissements Mensuels & Annuels
    h.append(f"""
    <h3 style="margin:12px 0 6px;color:#047857;font-size:13px;border-bottom:1.5px solid #047857;padding-bottom:3px;">
      {("1 – ملخص رقم الأعمال المقبوض شهرياً وسنوياً (Chiffre d’Affaires Encaissé)" if is_ar else "1 – Récapitulatif du Chiffre d'Affaires Encaissé")}
    </h3>
    <table class="report-table" style="margin-bottom:16px;">
      <thead>
        <tr>
          <th>{("السنة" if is_ar else "Année")}</th>
          <th>{("الشهر / الفترة" if is_ar else "Mois / Période")}</th>
          <th>{("عدد الدفعات" if is_ar else "Nombre")}</th>
          <th>{("رقم الأعمال المقبوض (DA)" if is_ar else "Montant Encaissé (DA)")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for row in enc_m.get("monthly", []):
        m_val = str(row.get('Mois') or '').zfill(2)
        h.append(f"""
        <tr>
          <td class="center"><b>{row.get('Annee')}</b></td>
          <td class="center"><b>{row.get('MoisLib')}</b> ({m_val}/{row.get('Annee')})</td>
          <td class="center">{row.get('count')}</td>
          <td class="num" style="font-weight:800;color:#047857;">{money(row.get('total'))}</td>
        </tr>
        """)

    h.append(f"""
      <tr class="total-row">
        <td colspan="3" class="center"><b>{("إجمالي كل المقبوضات" if is_ar else "TOTAL GÉNÉRAL ENCAISSÉ")}</b></td>
        <td class="num" style="color:#047857;font-size:12px;">{money(enc_m.get('grand_total'))}</td>
      </tr>
      </tbody>
    </table>
    """)

    # Detail Table: All payments
    h.append(f"""
    <h3 style="margin:14px 0 6px;color:#047857;font-size:13px;border-bottom:1.5px solid #047857;padding-bottom:3px;">
      {("2 – التفاصيل الفردية لكافة الدفعات والتسبيقات" if is_ar else "2 – Détail chronologique de tous les versements")}
    </h3>
    <table class="report-table">
      <thead>
        <tr>
          <th style="width:90px;">{("التاريخ" if is_ar else "Date")}</th>
          <th style="width:70px;">{("رقم القطعة" if is_ar else "N° Lot")}</th>
          <th>{("المشتري / الحائز" if is_ar else "Acquéreur")}</th>
          <th style="width:130px;">{("طريقة الدفع" if is_ar else "Mode de versement")}</th>
          <th style="width:120px;">{("المبلغ المدفوع (DA)" if is_ar else "Montant (DA)")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    tot_v = 0.0
    for v in vers:
        mt = _num(v.get("Mtvers"))
        tot_v += mt
        h.append(f"""
        <tr>
          <td class="center">{v.get('date_display') or '—'}</td>
          <td class="center"><b>{v.get('Nlot')}</b></td>
          <td><b>{escape(str(v.get('Acquereur') or '—'))}</b></td>
          <td class="center">{escape(str(v.get('ModeVers') or '—'))}</td>
          <td class="num" style="font-weight:700;color:#047857;">{money(mt)}</td>
        </tr>
        """)

    h.append(f"""
      <tr class="total-row">
        <td colspan="4" class="center"><b>{("مجموع الدفعات" if is_ar else "TOTAL DES VERSEMENTS")} ({len(vers)})</b></td>
        <td class="num" style="color:#047857;">{money(tot_v)}</td>
      </tr>
      </tbody>
    </table>
    <div class="footer">
      <span>{escape(st.get('Adresse', ''))}</span>
      <span>{len(vers)} {'دفعة مسجلة' if is_ar else 'versements'}</span>
    </div>
    </div></body></html>
    """)
    return "".join(h), title


# ------------------------------------------------------------------ 4. كشف الديون والمستحقات (Créances A4)
def render_creances_html(code: str, params: dict) -> tuple[str, str]:
    lid = _resolve_lid(code, params)
    lang = str(params.get("lang") or "ar").lower()
    is_ar = lang != "fr"
    st = lotissement.study(code, lid)
    cre = lotissement.creances(code, lid)

    title = "كشف الديون والمستحقات المتبقية على المشترين" if is_ar else "État des Créances & Restes à Recouvrer"
    sub = f"{st.get('Adresse')} · {st.get('Lotisseur')}"
    h = [_doc_head(title, "portrait", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th style="width:70px;">{("رقم القطعة" if is_ar else "N° Lot")}</th>
          <th style="width:90px;">{("المساحة (م²)" if is_ar else "Superficie")}</th>
          <th>{("اسم ولقب المشتري" if is_ar else "Acquéreur")}</th>
          <th style="width:130px;">{("سعر التنازل (DA)" if is_ar else "Prix de cession")}</th>
          <th style="width:130px;">{("المدفوعات السابقة (DA)" if is_ar else "Versements reçus")}</th>
          <th style="width:140px;">{("الدين المتبقي (DA)" if is_ar else "Reste à payer")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    tot_p, tot_v, tot_r = 0.0, 0.0, 0.0
    for r in cre:
        p = _num(r.get("PcessionLot"))
        v = _num(r.get("TVersemU"))
        rem = _num(r.get("ResteU"))
        tot_p += p; tot_v += v; tot_r += rem
        h.append(f"""
        <tr>
          <td class="center"><b>{r.get('Nlot')}</b></td>
          <td class="num">{money(r.get('SupLot'))}</td>
          <td><b>{escape(str(r.get('Acquereur') or '—'))}</b></td>
          <td class="num">{money(p)}</td>
          <td class="num" style="color:#047857;">{money(v)}</td>
          <td class="num" style="color:#b91c1c;font-weight:800;font-size:12px;">{money(rem)}</td>
        </tr>
        """)

    h.append(f"""
      <tr class="total-row">
        <td colspan="3" class="center"><b>{("المجموع العام للديون" if is_ar else "TOTAL DES CRÉANCES")} ({len(cre)} {('قطعة مدينة' if is_ar else 'créances')})</b></td>
        <td class="num">{money(tot_p)}</td>
        <td class="num" style="color:#047857;">{money(tot_v)}</td>
        <td class="num" style="color:#b91c1c;font-size:13px;">{money(tot_r)}</td>
      </tr>
      </tbody>
    </table>
    <div class="footer">
      <span>{escape(st.get('Adresse', ''))}</span>
      <span>{len(cre)} {'مشتري مدين' if is_ar else 'acquéreurs débiteurs'}</span>
    </div>
    </div></body></html>
    """)
    return "".join(h), title


# ------------------------------------------------------------------ 5. الوضعية السنوية وحساب النتائج (TCR A4)
def render_annuelle_html(code: str, params: dict) -> tuple[str, str]:
    lid = _resolve_lid(code, params)
    lang = str(params.get("lang") or "ar").lower()
    is_ar = lang != "fr"
    st = lotissement.study(code, lid)
    tcr_rows = lotissement.tcr(code, lid)

    title = "الوضعية السنوية وحساب النتائج الجبائية (TCR / IBS / IRG)" if is_ar else "Situation Annuelle & Compte de Résultat Fiscal"
    sub = f"{st.get('Adresse')} · {st.get('Lotisseur')}"
    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th>{("السنة" if is_ar else "Année")}</th>
          <th>{("القطع" if is_ar else "Lots")}</th>
          <th>{("المساحة (م²)" if is_ar else "Superficie")}</th>
          <th>{("سعر التنازل TTC" if is_ar else "Prix Cession TTC")}</th>
          <th>{("تكلفة الإنجاز" if is_ar else "Coût Revient")}</th>
          <th>{("وعاء TVA" if is_ar else "Base TVA")}</th>
          <th>{("حقوق TVA" if is_ar else "Droits TVA")}</th>
          <th>{("رقم الأعمال المحاسبي" if is_ar else "CA Imposable")}</th>
          <th>{("إجمالي الأعباء" if is_ar else "Charges Totales")}</th>
          <th>{("النتيجة الصافية" if is_ar else "Résultat")}</th>
          <th>{("الضريبة المستحقة" if is_ar else "Impôt Dû")}</th>
          <th>{("الضريبة الإجمالية" if is_ar else "Total Droits")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for r in tcr_rows:
        res = _num(r.get("resultat"))
        impot_val = _num(r.get("IRG"))
        impot_lbl = r.get("impot", "IRG")
        h.append(f"""
        <tr>
          <td class="center"><b>{r.get('CAannee')}</b></td>
          <td class="center">{r.get('NbreLots')}</td>
          <td class="num">{money(r.get('Tsuperficie'))}</td>
          <td class="num">{money(r.get('PCessionTTC'))}</td>
          <td class="num">{money(r.get('CoutRevnent'))}</td>
          <td class="num">{money(r.get('BaseTva'))}</td>
          <td class="num" style="color:#047857;font-weight:700;">{money(r.get('TDroitsTVA'))}</td>
          <td class="num">{money(r.get('CA'))}</td>
          <td class="num">{money(r.get('Tcharges'))}</td>
          <td class="num" style="font-weight:800;color:{'#059669' if res >= 0 else '#b91c1c'};">{money(res)}</td>
          <td class="num"><b>{money(impot_val)}</b> <small>({impot_lbl})</small></td>
          <td class="num" style="font-weight:900;color:#0f172a;">{money(r.get('Tdroits'))}</td>
        </tr>
        """)

    h.append(f"""
      </tbody>
    </table>
    <div class="footer">
      <span>{escape(st.get('Adresse', ''))}</span>
      <span>{len(tcr_rows)} {'سنوات مالية' if is_ar else 'exercices fiscaux'}</span>
    </div>
    </div></body></html>
    """)
    return "".join(h), title


# ------------------------------------------------------------------ 5b. Situation du Chiffre d'affaires Facturé
def render_facturation_html(code: str, params: dict) -> tuple[str, str]:
    lid = _resolve_lid(code, params)
    annee = str(params.get("annee") or "")
    mois = str(params.get("mois") or "")
    q = str(params.get("q") or "")
    is_ar = params.get("lang") == "ar"

    st = lotissement.study(code, lid)
    data = lotissement.ca_facture(code, lid, annee=annee, mois=mois, q=q)
    lots = data["items"]

    title = "وضعية رقم الأعمال المفوتر والمبيعات الموثقة" if is_ar else "Chiffre d’affaires Facturé (Actes Notariés)"
    sub = f"{st.get('Adresse')} · {st.get('Lotisseur')}"
    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    # Badges
    badges = []
    if annee:
        badges.append(f"<b>{'السنة' if is_ar else 'Année'}:</b> {annee}")
    if mois:
        badges.append(f"<b>{'الشهر' if is_ar else 'Mois'}:</b> {mois.zfill(2)}")
    if q:
        badges.append(f"<b>{'بحث' if is_ar else 'Recherche'}:</b> {escape(q)}")

    if badges:
        h.append(f'<div style="margin: 0 0 10px; display: flex; gap: 8px; flex-wrap: wrap;">')
        for b in badges:
            h.append(f'<span style="display:inline-block; padding: 2px 8px; background: #e0f2fe; color: #0369a1; border-radius: 4px; font-size: 11px;">{b}</span>')
        h.append('</div>')

    # Summary KPIs
    h.append(f"""
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px;">
      <div style="border: 1px solid #cbd5e1; padding: 8px 12px; border-radius: 6px; background: #f8fafc;">
        <span style="font-size: 11px; color: #64748b; font-weight: 700;">{("القطع الموثقة" if is_ar else "Lots Actés")}</span>
        <div style="font-size: 16px; font-weight: 900; color: #0f172a;">{data['total_lots']}</div>
      </div>
      <div style="border: 1px solid #cbd5e1; padding: 8px 12px; border-radius: 6px; background: #f8fafc;">
        <span style="font-size: 11px; color: #64748b; font-weight: 700;">{("المساحة الإجمالية" if is_ar else "Superficie Totale")}</span>
        <div style="font-size: 16px; font-weight: 900; color: #0f172a;">{money(data['total_sup'])} m²</div>
      </div>
      <div style="border: 1px solid #cbd5e1; padding: 8px 12px; border-radius: 6px; background: #f8fafc;">
        <span style="font-size: 11px; color: #64748b; font-weight: 700;">{("سعر البيع الإجمالي TTC" if is_ar else "Total Cession TTC")}</span>
        <div style="font-size: 16px; font-weight: 900; color: #047857;">{money(data['total_ttc'])} DA</div>
      </div>
      <div style="border: 1px solid #cbd5e1; padding: 8px 12px; border-radius: 6px; background: #f8fafc;">
        <span style="font-size: 11px; color: #64748b; font-weight: 700;">{("رقم الأعمال خارج الرسم HT" if is_ar else "Total CA HT")}</span>
        <div style="font-size: 16px; font-weight: 900; color: #0284c7;">{money(data['total_ht'])} DA</div>
      </div>
    </div>
    """)

    h.append(f"""
    <table class="report-table">
      <thead>
        <tr>
          <th>{("التاريخ" if is_ar else "Date Acte")}</th>
          <th>{("رقم العقد" if is_ar else "N° Acte")}</th>
          <th>{("الموثق" if is_ar else "Notaire")}</th>
          <th>{("القطعة" if is_ar else "Lot")}</th>
          <th>{("المشتري" if is_ar else "Acquéreur")}</th>
          <th>{("المساحة" if is_ar else "Superficie")}</th>
          <th>{("سعر /م²" if is_ar else "Prix /m²")}</th>
          <th>{("سعر البيع TTC" if is_ar else "Prix Cession TTC")}</th>
          <th>{("وعاء TVA" if is_ar else "Base TVA")}</th>
          <th>{("حقوق TVA" if is_ar else "Droits TVA")}</th>
          <th>{("رقم الأعمال HT" if is_ar else "CA Facturé HT")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for r in lots:
        h.append(f"""
        <tr>
          <td class="center">{r.get('date_display') or '—'}</td>
          <td class="center"><b>{r.get('NumActe') or '—'}</b></td>
          <td>{escape(r.get('Notaire') or '—')}</td>
          <td class="center"><b>{r.get('Nlot')}</b></td>
          <td><b>{escape(r.get('Acquereur') or '')}</b></td>
          <td class="num">{money(r.get('SupLot'))} m²</td>
          <td class="num">{money(r.get('PCessionU'))}</td>
          <td class="num" style="font-weight:700;">{money(r.get('PcessionLot'))}</td>
          <td class="num">{money(r.get('BaseTvaLot'))}</td>
          <td class="num" style="color:#047857;">{money(r.get('DroitsTvaLot'))}</td>
          <td class="num" style="font-weight:900;color:#0284c7;">{money(r.get('BaseTapLot'))}</td>
        </tr>
        """)

    h.append(f"""
      </tbody>
      <tfoot>
        <tr style="background: #e2e8f0; font-weight: 900;">
          <td colspan="5">{("المجموع الإجمالي" if is_ar else "TOTAL GÉNÉRAL")}</td>
          <td class="num">{money(data['total_sup'])} m²</td>
          <td class="center">—</td>
          <td class="num" style="color:#047857;">{money(data['total_ttc'])}</td>
          <td class="num">{money(sum(_num(x.get('BaseTvaLot')) for x in lots))}</td>
          <td class="num" style="color:#047857;">{money(sum(_num(x.get('DroitsTvaLot')) for x in lots))}</td>
          <td class="num" style="color:#0284c7;">{money(data['total_ht'])}</td>
        </tr>
      </tfoot>
    </table>
    <div class="footer">
      <span>{escape(st.get('Adresse', ''))}</span>
      <span>{len(lots)} {'قطع موثقة' if is_ar else 'lots facturés'}</span>
    </div>
    </div></body></html>
    """)
    return "".join(h), title


# ------------------------------------------------------------------ 0. وضعية القطع والدراسة المالية والجبائية الشاملة (Situation Complète du Lotissement)
def render_situation_html(code: str, params: dict) -> tuple[str, str]:
    lid = _resolve_lid(code, params)
    lang = str(params.get("lang") or "fr").lower()
    is_ar = lang == "ar"
    data = lotissement.lots(code, lid)
    st = data["study"]
    lots = data["items"]
    t = data["totals"]

    title = "وضعية القطع والدراسة المالية والجبائية للتجزئة" if is_ar else "Situation des Lots & Calcul des Bases et Droits"
    sub = f"{st.get('Adresse')} · {st.get('Lotisseur')}"
    h = [_doc_head(title, "landscape", is_ar)]
    h.append(_doc_header(code, title, sub, is_ar))

    # Top KPI Banner
    h.append(f"""
    <div class="kpis-banner">
      <div class="kpi-card">
        <span>{("إجمالي القطع" if is_ar else "Nombre de Lots")}</span>
        <b>{len(lots)}</b>
      </div>
      <div class="kpi-card">
        <span>{("المساحة الصالحة للبيع" if is_ar else "Superficie Utile")}</span>
        <b>{money(st.get('SupUtile'))} m²</b>
      </div>
      <div class="kpi-card">
        <span>{("قيمة التنازل الإجمالية TTC" if is_ar else "Valeur Cession TTC")}</span>
        <b style="color:#047857;">{money(t.get('PcessionLot'))} DA</b>
      </div>
      <div class="kpi-card">
        <span>{("إجمالي المقبوضات" if is_ar else "Total Versements")}</span>
        <b style="color:#0284c7;">{money(t.get('TVersemU'))} DA</b>
      </div>
      <div class="kpi-card">
        <span>{("الديون المتبقية للتحصيل" if is_ar else "Reste à Recouvrer")}</span>
        <b style="color:{'#b91c1c' if _num(t.get('ResteU')) > 0 else '#047857'};">{money(t.get('ResteU'))} DA</b>
      </div>
    </div>
    """)

    # Part 1: Table Situation des Lots
    h.append(f"""
    <h3 style="margin:10px 0 6px;color:#047857;font-size:12px;font-weight:800;display:flex;justify-content:space-between;align-items:center;">
      <span>{("1 – جدول وضعية القطع الأرضية والتفاصيل المالية (Situation des Lots)" if is_ar else "1 – Situation des Lots & Détails Financiers")}</span>
      <span style="font-size:10px;font-weight:600;color:#64748b;">{len(lots)} {("قطعة مسجلة" if is_ar else "lots enregistrés")}</span>
    </h3>
    <table class="report-table">
      <thead>
        <tr>
          <th rowspan="2" style="width:34px;">{("الرقم" if is_ar else "N° Lot")}</th>
          <th rowspan="2" style="width:36px;">{("واجهات" if is_ar else "Faç.")}</th>
          <th rowspan="2" style="width:60px;">{("المساحة (م²)" if is_ar else "Superficie (m²)")}</th>
          <th rowspan="2" style="width:130px;">{("المشتري / الحائز" if is_ar else "Acquéreur")}</th>
          <th colspan="2">{("سعر التنازل (DA)" if is_ar else "Prix de Cession (DA)")}</th>
          <th colspan="2">{("تكلفة الإنجاز (DA)" if is_ar else "Coût de Revient (DA)")}</th>
          <th colspan="2">{("الرسم على القيمة المضافة TVA" if is_ar else "TVA (19 %)")}</th>
          <th rowspan="2" style="width:75px;">{("مجموع الحقوق" if is_ar else "Total Droits")}</th>
          <th rowspan="2" style="width:75px;">{("تاريخ العقد" if is_ar else "Date d'acte")}</th>
          <th rowspan="2" style="width:55px;">G50</th>
          <th rowspan="2" style="width:85px;">{("المقبوضات" if is_ar else "Versements")}</th>
          <th rowspan="2" style="width:85px;">{("المتبقي للدفع" if is_ar else "Reste à Régler")}</th>
        </tr>
        <tr>
          <th style="width:60px;">{("للمتر²" if is_ar else "/ m²")}</th>
          <th style="width:80px;">{("للقطعة" if is_ar else "Total Lot")}</th>
          <th style="width:60px;">{("للمتر²" if is_ar else "/ m²")}</th>
          <th style="width:80px;">{("للقطعة" if is_ar else "Total Lot")}</th>
          <th style="width:75px;">{("الوعاء" if is_ar else "Base")}</th>
          <th style="width:70px;">{("الحقوق" if is_ar else "Droits")}</th>
        </tr>
      </thead>
      <tbody>
    """)

    for r in lots:
        acq = escape(str(r.get("Acquereur") or ""))
        p_u = _num(r.get("PCessionU"))
        p_lot = _num(r.get("PcessionLot"))
        c_u = _num(r.get("CoutrevnentU"))
        c_lot = _num(r.get("CoutrevnentLot"))
        b_tva = _num(r.get("BaseTvaLot"))
        d_tva = _num(r.get("DroitsTvaLot"))
        tot_d = _num(r.get("TotalDroits"))
        vers = _num(r.get("TVersemU"))
        reste = _num(r.get("ResteU"))
        date_act = r.get("date_display") or ""
        g50_per = str(r.get("G50") or "")

        h.append(f"""
        <tr>
          <td class="center"><b>{r.get('Nlot')}</b></td>
          <td class="center">{r.get('Nfacade') or 1}</td>
          <td class="num">{money(r.get('SupLot'))}</td>
          <td><b>{acq if acq else '<span style="color:#94a3b8;font-weight:400;">—</span>'}</b></td>
          <td class="num">{money(p_u)}</td>
          <td class="num" style="font-weight:700;">{money(p_lot)}</td>
          <td class="num">{money(c_u)}</td>
          <td class="num">{money(c_lot)}</td>
          <td class="num">{money(b_tva)}</td>
          <td class="num">{money(d_tva)}</td>
          <td class="num" style="font-weight:700;">{money(tot_d)}</td>
          <td class="center">{date_act if date_act else '—'}</td>
          <td class="center">{g50_per if g50_per else '—'}</td>
          <td class="num" style="color:#047857;font-weight:700;">{money(vers)}</td>
          <td class="num" style="color:{'#b91c1c' if reste > 0 else '#047857'};font-weight:700;">{money(reste)}</td>
        </tr>
        """)

    # Totals row
    h.append(f"""
      <tr class="total-row">
        <td colspan="2" class="center"><b>{("المجموع العام" if is_ar else "TOTAL GÉNÉRAL")}</b></td>
        <td class="num">{money(t.get('SupLot'))}</td>
        <td class="center"><b>{len(lots)} {("قطعة" if is_ar else "lots")}</b></td>
        <td class="center">—</td>
        <td class="num">{money(t.get('PcessionLot'))}</td>
        <td class="center">—</td>
        <td class="num">{money(t.get('CoutrevnentLot'))}</td>
        <td class="num">{money(t.get('BaseTvaLot'))}</td>
        <td class="num">{money(t.get('DroitsTvaLot'))}</td>
        <td class="num">{money(t.get('TotalDroits'))}</td>
        <td colspan="2"></td>
        <td class="num" style="color:#047857;">{money(t.get('TVersemU'))}</td>
        <td class="num" style="color:#b91c1c;">{money(t.get('ResteU'))}</td>
      </tr>
      </tbody>
    </table>
    """)

    # Section 2: Étude & Calcul des Bases et Droits (Page break for print)
    p_cession_tot = _num(st.get("SupUtile")) * _num(st.get("PCessionUniTTC"))
    cout_rev_tot = _num(st.get("SupUtile")) * _num(st.get("CoutrevnentUni"))

    h.append(f"""
    <div class="page-break" style="margin-top:20px;padding-top:14px;border-top:2px solid #047857;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <h2 style="margin:0;font-size:14px;font-weight:900;color:#047857;">
          {("2 – الدراسة المالية للمشروع وحساب القواعد والحقوق الجبائية" if is_ar else "2 – Étude Financière & Calcul des Bases et Droits Fiscaux")}
        </h2>
        <span style="font-size:10.5px;color:#64748b;">
          {("المرجع الجبائي: قانون الضرائب المباشرة والرسوم المماثلة / قانون الرسوم على رقم الأعمال" if is_ar else "Conforme CIDTA & CTCA — Algérie")}
        </span>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start;">
        <!-- Card 1: Viabilisation & Coût de Revient -->
        <div style="background:#fff;border:1px solid #cbd5e1;border-radius:6px;padding:10px 12px;box-shadow:0 1px 2px rgba(0,0,0,0.04);">
          <h4 style="margin:0 0 6px;color:#047857;font-size:12px;border-bottom:1.5px solid #047857;padding-bottom:3px;">
            {("تهيئة وتكاليف إنجاز العقار (Viabilisation & Coût de Revient)" if is_ar else "Calcul du Coût de Revient & Viabilisation du Terrain")}
          </h4>
          <table class="report-table" style="margin-top:4px;">
            <tbody>
              <tr>
                <td>{("المساحة المحجوزة" if is_ar else "Superficie Réservée")}</td>
                <td class="num"><b>{money(st.get('SupeReservee'))}</b> m²</td>
              </tr>
              <tr>
                <td>{("مساحة الأجزاء المشتركة" if is_ar else "Superficie des parties communes")}</td>
                <td class="num"><b>{money(st.get('SupPconununes'))}</b> m²</td>
              </tr>
              <tr>
                <td>{("المساحة الصالحة للبيع (المفيدة)" if is_ar else "Superficie Utile")}</td>
                <td class="num" style="color:#047857;"><b>{money(st.get('SupUtile'))}</b> m²</td>
              </tr>
              <tr style="background:#f1f5f9;font-weight:700;">
                <td>{("إجمالي مساحة التجزئة" if is_ar else "Total Superficie à vendre / lotissement")}</td>
                <td class="num"><b>{money(st.get('SupTotale'))}</b> m²</td>
              </tr>
              <tr>
                <td>{("قيمة شراء الأرض الخام" if is_ar else "Valeur du Terrain nu")}</td>
                <td class="num"><b>{money(st.get('PrixchatTerrain'))}</b> DA</td>
              </tr>
              <tr>
                <td>{("أشغال المناولة والمقاولة" if is_ar else "Sous-Traitance")}</td>
                <td class="num">{money(st.get('soustraitance'))} DA</td>
              </tr>
              <tr>
                <td>{("الدراسات ومكتب الدراسات BET" if is_ar else "Études et Services BET")}</td>
                <td class="num">{money(st.get('ServicesBET'))} DA</td>
              </tr>
              <tr>
                <td>{("أشغال شبكة الكهرباء" if is_ar else "Travaux d'électricité")}</td>
                <td class="num">{money(st.get('TrvxElec'))} DA</td>
              </tr>
              <tr>
                <td>{("أشغال شبكة الغاز" if is_ar else "Travaux de Gaz")}</td>
                <td class="num">{money(st.get('TrvxGaz'))} DA</td>
              </tr>
              <tr>
                <td>{("أعباء ومصاريف أخرى" if is_ar else "Autres Charges")}</td>
                <td class="num">{money(st.get('Autres'))} DA</td>
              </tr>
              <tr style="background:#ecfdf5;font-weight:800;border-top:1.5px solid #047857;">
                <td style="color:#047857;">{("إجمالي تكاليف أشغال التهيئة" if is_ar else "Total Viabilisation")}</td>
                <td class="num" style="color:#047857;"><b>{money(st.get('CoutsTravaux'))}</b> DA</td>
              </tr>
              <tr style="background:#f8fafc;font-weight:800;">
                <td>{("القيمة الإجمالية بعد التهيئة" if is_ar else "Valeur après Viabilisation")}</td>
                <td class="num"><b>{money(st.get('Tvaleurapresviabilisation'))}</b> DA</td>
              </tr>
              <tr style="background:#047857;color:#fff;font-weight:900;">
                <td style="color:#fff;">{("تكلفة الإنجاز للمتر المربع (/ م²)" if is_ar else "Coût de Revient Unitaire / m²")}</td>
                <td class="num" style="color:#fff;font-size:12px;"><b>{money(st.get('CoutrevnentUni'))}</b> DA / m²</td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Right Side: Card 2 & Card 3 -->
        <div style="display:flex;flex-direction:column;gap:12px;">
          <!-- Card 2: Calcul des Bases -->
          <div style="background:#fff;border:1px solid #cbd5e1;border-radius:6px;padding:10px 12px;box-shadow:0 1px 2px rgba(0,0,0,0.04);">
            <h4 style="margin:0 0 6px;color:#047857;font-size:12px;border-bottom:1.5px solid #047857;padding-bottom:3px;">
              {("حساب القواعد والأسس الجبائية (Calcul des Bases Fiscales)" if is_ar else "Calcul des Bases Fiscales")}
            </h4>
            <table class="report-table" style="margin-top:4px;">
              <thead>
                <tr>
                  <th>{("البيان / التعيين" if is_ar else "Désignation")}</th>
                  <th style="width:100px;">{("للمتر² (/ m²)" if is_ar else "/ M²")}</th>
                  <th style="width:130px;">{("كامل التجزئة (DA)" if is_ar else "Lotissement (DA)")}</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><b>{("سعر التنازل المتضمن للرسم TTC" if is_ar else "Prix de Cession TTC")}</b></td>
                  <td class="num">{money(st.get('PCessionUniTTC'))}</td>
                  <td class="num" style="font-weight:700;">{money(p_cession_tot)}</td>
                </tr>
                <tr>
                  <td>{("تكلفة الإنجاز" if is_ar else "Coût de Revient")}</td>
                  <td class="num">{money(st.get('CoutrevnentUni'))}</td>
                  <td class="num">{money(cout_rev_tot)}</td>
                </tr>
                <tr>
                  <td>{("الفرق المتضمن للرسم TTC" if is_ar else "Différence TTC")}</td>
                  <td class="num">{money(st.get('DifferenceTTC'))}</td>
                  <td class="num">{money(st.get('DifferenceTTCL'))}</td>
                </tr>
                <tr>
                  <td>{("الفرق خارج الرسم HT" if is_ar else "Différence HT")}</td>
                  <td class="num">{money(st.get('DifferenceHT'))}</td>
                  <td class="num">{money(st.get('DifferenceHTL'))}</td>
                </tr>
                <tr style="background:#f8fafc;font-weight:700;">
                  <td style="color:#047857;">{("وعاء الرسم على القيمة المضافة TVA" if is_ar else "Base TVA")}</td>
                  <td class="num" style="color:#047857;">{money(st.get('BaseimposableTVA'))}</td>
                  <td class="num" style="color:#047857;">{money(st.get('BaseTVAL'))}</td>
                </tr>
                <tr style="background:#eff6ff;font-weight:800;">
                  <td style="color:#1d4ed8;">{f"وعاء {st.get('CBaseBIC', 'IBS')}" if is_ar else str(st.get('CBaseBIC', 'Base IBS'))}</td>
                  <td class="num" style="color:#1d4ed8;">{money(st.get('BaseBIC'))}</td>
                  <td class="num" style="color:#1d4ed8;">{money(st.get('BaseBICL'))}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Card 3: Calcul des Droits -->
          <div style="background:#fff;border:1px solid #cbd5e1;border-radius:6px;padding:10px 12px;box-shadow:0 1px 2px rgba(0,0,0,0.04);">
            <h4 style="margin:0 0 6px;color:#047857;font-size:12px;border-bottom:1.5px solid #047857;padding-bottom:3px;">
              {("حساب الحقوق والواجبات الجبائية (Calcul des Droits Fiscaux)" if is_ar else "Calcul des Droits Fiscaux")}
            </h4>
            <table class="report-table" style="margin-top:4px;">
              <thead>
                <tr>
                  <th>{("طبيعة الضريبة / الرسم" if is_ar else "Nature de l'Impôt")}</th>
                  <th style="width:100px;">{("للمتر² (/ m²)" if is_ar else "/ M²")}</th>
                  <th style="width:130px;">{("كامل التجزئة (DA)" if is_ar else "Lotissement (DA)")}</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><b>{("حقوق الرسم على القيمة المضافة TVA (19 %)" if is_ar else "Droits TVA (19 %)")}</b></td>
                  <td class="num" style="color:#047857;">{money(st.get('DroitTVA'))}</td>
                  <td class="num" style="color:#047857;font-weight:700;">{money(st.get('DroitTVAL'))}</td>
                </tr>
                <tr>
                  <td><b>{f"حقوق {st.get('CDroitsBIC', 'IBS')} ({st.get('TauxBic', '26')} %)" if is_ar else f"{st.get('CDroitsBIC', 'Droits IBS')} ({st.get('TauxBic', '26')} %)"}</b></td>
                  <td class="num" style="color:#1d4ed8;">{money(st.get('DroitsBIC'))}</td>
                  <td class="num" style="color:#1d4ed8;font-weight:700;">{money(st.get('DroitsBICL'))}</td>
                </tr>
                <tr class="total-row" style="background:#0f172a;color:#fff;border-top:2px solid #047857;">
                  <td style="color:#fff;font-weight:900;">{("مجموع الحقوق والضرائب الجبائية" if is_ar else "Total Droits Fiscaux")}</td>
                  <td class="num" style="color:#34d399;font-weight:900;font-size:12px;">{money(st.get('TotalDroitsM'))}</td>
                  <td class="num" style="color:#34d399;font-weight:900;font-size:12px;">{money(st.get('TotalDroitL'))}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Signatures Box -->
      <div style="display:flex;justify-content:space-between;margin-top:20px;padding-top:12px;border-top:1px dashed #cbd5e1;">
        <div style="width:40%;text-align:center;font-size:10.5px;color:#475569;">
          <b>{("المرقي العقاري / صاحب التجزئة" if is_ar else "Le Promoteur / Lotisseur")}</b>
          <div style="height:48px;"></div>
          <span>{escape(st.get('Lotisseur', ''))}</span>
        </div>
        <div style="width:40%;text-align:center;font-size:10.5px;color:#475569;">
          <b>{("التأشيرة المحاسبية والجبائية" if is_ar else "Visa Comptable & Fiscal")}</b>
          <div style="height:48px;"></div>
          <span>{("المحاسب المعتمد / خبير الحسابات" if is_ar else "Le Comptable Agréé / Commissaire aux Comptes")}</span>
        </div>
      </div>
    </div>
    """)

    h.append(f"""
    <div class="footer" style="margin-top:16px;">
      <span>{escape(st.get('Adresse', ''))} · {escape(st.get('Lotisseur', ''))}</span>
      <span>{len(lots)} {'قطعة أرضية مسجلة' if is_ar else 'lots enregistrés'} · Dec G50 ERP</span>
    </div>
    </div></body></html>
    """)
    return "".join(h), title


# ------------------------------------------------------------------ 6. Export Excel dédié (openpyxl)
def export_lotissement_excel(key: str, code: str, params: dict, out_path: Path) -> None:
    lid = _resolve_lid(code, params)
    st = lotissement.study(code, lid)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.views.sheetView[0].showGridLines = True

    soc = dossiers.societe(code)
    rs = str(soc.get("rs") or f"Entreprise {code}")

    # Styles
    f_title = Font(name="Calibri", size=14, bold=True, color="006233")
    f_header = Font(name="Calibri", size=10, bold=True, color="FFFFFF")
    f_total = Font(name="Calibri", size=10, bold=True, color="0F172A")
    f_data = Font(name="Calibri", size=10)
    fill_header = PatternFill("solid", fgColor="047857")
    fill_total = PatternFill("solid", fgColor="E2E8F0")
    thin = Side(style="thin", color="CBD5E1")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    if key in ("lotissement_lots", "lotissement"):
        if key == "lotissement":
            ws.title = "Situation des Lots"
        else:
            ws.title = "Lots du Lotissement"
        data = lotissement.lots(code, lid)
        lots = data["items"]

        ws["A1"] = f"{rs} — {st.get('Adresse')}"
        ws["A1"].font = f_title
        ws["A2"] = f"Situation des lots et données fiscales · Édité le {datetime.now():%d/%m/%Y %H:%M}"

        headers = ["N° Lot", "Façades", "Acquéreur", "Superficie (m²)", "Prix /m² (DA)", "Prix Lot TTC",
                   "Coût Revient /m²", "Coût Revient Lot", "Base TVA", "Droits TVA", "Total Droits",
                   "Date d'acte", "G50", "Versements", "Reste dû"]
        ws.append([])
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=4, column=col_idx)
            c.font = f_header
            c.fill = fill_header
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        for r in lots:
            ws.append([
                r.get("Nlot"), r.get("Nfacade") or 1, r.get("Acquereur"), r.get("SupLot"), r.get("PCessionU"),
                r.get("PcessionLot"), r.get("CoutrevnentU"), r.get("CoutrevnentLot"), r.get("BaseTvaLot"),
                r.get("DroitsTvaLot"), r.get("TotalDroits"), r.get("date_display"), r.get("G50"),
                r.get("TVersemU"), r.get("ResteU")
            ])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                cell.font = f_data
                if ci in (4, 5, 6, 7, 8, 9, 10, 11, 14, 15):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                elif ci in (1, 2, 12, 13):
                    cell.alignment = Alignment(horizontal="center")

        # Sheet 2: Étude & Fiscalité if key == "lotissement"
        if key == "lotissement":
            ws2 = wb.create_sheet(title="Étude & Fiscalité")
            ws2.views.sheetView[0].showGridLines = True
            ws2["A1"] = f"{rs} — {st.get('Adresse')} (Étude & Bases Fiscales)"
            ws2["A1"].font = f_title
            ws2.append([])

            ws2.append(["1. VIABILISATION & COÛT DE REVIENT", "MONTANT / SURFACE"])
            r_h = ws2.max_row
            ws2.cell(row=r_h, column=1).font = f_header; ws2.cell(row=r_h, column=1).fill = fill_header
            ws2.cell(row=r_h, column=2).font = f_header; ws2.cell(row=r_h, column=2).fill = fill_header

            rows_v = [
                ("Superficie Réservée", f"{money(st.get('SupeReservee'))} m²"),
                ("Superficie des parties communes", f"{money(st.get('SupPconununes'))} m²"),
                ("Superficie Utile", f"{money(st.get('SupUtile'))} m²"),
                ("Total Superficie lotissement", f"{money(st.get('SupTotale'))} m²"),
                ("Valeur du Terrain nu", st.get('PrixchatTerrain')),
                ("Sous-Traitance", st.get('soustraitance')),
                ("Études et Services BET", st.get('ServicesBET')),
                ("Travaux d'électricité", st.get('TrvxElec')),
                ("Travaux de Gaz", st.get('TrvxGaz')),
                ("Autres Charges", st.get('Autres')),
                ("Total Viabilisation", st.get('CoutsTravaux')),
                ("Valeur après Viabilisation", st.get('Tvaleurapresviabilisation')),
                ("Coût de Revient Unitaire / m²", st.get('CoutrevnentUni')),
            ]
            for lbl, val in rows_v:
                ws2.append([lbl, val])
                r_idx = ws2.max_row
                ws2.cell(row=r_idx, column=1).border = border
                c2 = ws2.cell(row=r_idx, column=2)
                c2.border = border
                if isinstance(val, (int, float)):
                    c2.number_format = '#,##0.00'
                    c2.alignment = Alignment(horizontal="right")

            ws2.append([])
            ws2.append(["2. BASES FISCALES", "Par M² (/ m²)", "Lotissement Total (DA)"])
            r_head = ws2.max_row
            for ci in (1, 2, 3):
                c = ws2.cell(row=r_head, column=ci)
                c.font = f_header; c.fill = fill_header

            p_cession_tot = _num(st.get("SupUtile")) * _num(st.get("PCessionUniTTC"))
            cout_rev_tot = _num(st.get("SupUtile")) * _num(st.get("CoutrevnentUni"))
            rows_b = [
                ("Prix de Cession TTC", st.get("PCessionUniTTC"), p_cession_tot),
                ("Coût de Revient", st.get("CoutrevnentUni"), cout_rev_tot),
                ("Différence TTC", st.get("DifferenceTTC"), st.get("DifferenceTTCL")),
                ("Différence HT", st.get("DifferenceHT"), st.get("DifferenceHTL")),
                ("Base TVA", st.get("BaseimposableTVA"), st.get("BaseTVAL")),
                (str(st.get("CBaseBIC", "Base IBS")), st.get("BaseBIC"), st.get("BaseBICL")),
            ]
            for lbl, v1, v2 in rows_b:
                ws2.append([lbl, v1, v2])
                r_idx = ws2.max_row
                ws2.cell(row=r_idx, column=1).border = border
                for ci, v in ((2, v1), (3, v2)):
                    c = ws2.cell(row=r_idx, column=ci)
                    c.border = border
                    c.number_format = '#,##0.00'
                    c.alignment = Alignment(horizontal="right")

            ws2.append([])
            ws2.append(["3. DROITS FISCAUX", "Droits / M²", "Lotissement Total (DA)"])
            r_head = ws2.max_row
            for ci in (1, 2, 3):
                c = ws2.cell(row=r_head, column=ci)
                c.font = f_header; c.fill = fill_header
            rows_d = [
                ("Droits TVA (19 %)", st.get("DroitTVA"), st.get("DroitTVAL")),
                (f"{st.get('CDroitsBIC', 'Droits IBS')} ({st.get('TauxBic', '26')} %)", st.get("DroitsBIC"), st.get("DroitsBICL")),
                ("Total Droits Fiscaux", st.get("TotalDroitsM"), st.get("TotalDroitL")),
            ]
            for lbl, v1, v2 in rows_d:
                ws2.append([lbl, v1, v2])
                r_idx = ws2.max_row
                ws2.cell(row=r_idx, column=1).border = border
                for ci, v in ((2, v1), (3, v2)):
                    c = ws2.cell(row=r_idx, column=ci)
                    c.border = border
                    c.number_format = '#,##0.00'
                    c.alignment = Alignment(horizontal="right")
                    if lbl == "Total Droits Fiscaux":
                        c.font = f_total

    elif key == "lotissement_versements":
        ws.title = "Versements & Encaissements"
        annee_filter = str(params.get("annee") or "")
        mois_filter = str(params.get("mois") or "")
        mode_filter = str(params.get("mode") or "")
        q_filter = str(params.get("q") or "")

        vers = lotissement.versements(code, lid, annee=annee_filter, mois=mois_filter, mode=mode_filter, q=q_filter)
        enc_m = lotissement.encaissements_mensuels(code, lid, annee=annee_filter, mode=mode_filter, q=q_filter)

        ws["A1"] = f"{rs} — {st.get('Adresse')} (Versements)"
        ws["A1"].font = f_title
        ws.append([])

        # Table 1: Mensuel
        ws.append(["Année", "Mois", "Période", "Nombre", "Chiffre d'Affaires Encaissé (DA)"])
        m_head_row = 3
        for ci in range(1, 6):
            c = ws.cell(row=m_head_row, column=ci)
            c.font = f_header; c.fill = fill_header; c.alignment = Alignment(horizontal="center")
        for m_row in enc_m.get("monthly", []):
            ws.append([m_row["Annee"], m_row["Mois"], m_row["MoisLib"], m_row["count"], m_row["total"]])
            cur = ws.max_row
            for ci in range(1, 6):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci == 5:
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                else:
                    cell.alignment = Alignment(horizontal="center")

        ws.append([])
        ws.append([])
        ws.append(["Date Versement", "N° Lot", "Acquéreur", "Mode de Règlement", "Montant Versé (DA)"])
        v_head_row = ws.max_row
        for ci in range(1, 6):
            c = ws.cell(row=v_head_row, column=ci)
            c.font = f_header; c.fill = fill_header; c.alignment = Alignment(horizontal="center")

        for v in vers:
            ws.append([v.get("date_display"), v.get("Nlot"), v.get("Acquereur"), v.get("ModeVers"), v.get("Mtvers")])
            cur = ws.max_row
            for ci in range(1, 6):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci == 5:
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                elif ci in (1, 2, 4):
                    cell.alignment = Alignment(horizontal="center")

    elif key == "lotissement_creances":
        ws.title = "Créances & Restes"
        cre = lotissement.creances(code, lid)
        ws["A1"] = f"{rs} — {st.get('Adresse')} (Créances)"
        ws["A1"].font = f_title
        ws.append([])
        headers = ["N° Lot", "Superficie (m²)", "Acquéreur", "Prix de Cession (DA)", "Versements Reçus (DA)", "Reste à Recouvrer (DA)"]
        ws.append(headers)
        for ci in range(1, len(headers) + 1):
            c = ws.cell(row=3, column=ci)
            c.font = f_header; c.fill = fill_header; c.alignment = Alignment(horizontal="center")

        for r in cre:
            ws.append([r.get("Nlot"), r.get("SupLot"), r.get("Acquereur"), r.get("PcessionLot"), r.get("TVersemU"), r.get("ResteU")])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci in (2, 4, 5, 6):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                elif ci == 1:
                    cell.alignment = Alignment(horizontal="center")

    elif key == "lotissement_facturation":
        ws.title = "CA Facturé (Actes Notariés)"
        annee = str(params.get("annee") or "")
        mois = str(params.get("mois") or "")
        q = str(params.get("q") or "")
        fac_data = lotissement.ca_facture(code, lid, annee=annee, mois=mois, q=q)
        lots_fac = fac_data["items"]

        ws["A1"] = f"{rs} — {st.get('Adresse')} (Chiffre d’affaires Facturé)"
        ws["A1"].font = f_title
        ws.append([])
        headers = ["Date Acte", "N° Acte", "Notaire", "N° Lot", "Acquéreur", "Superficie (m²)", "Prix /m²",
                   "Prix Cession TTC", "Base TVA", "Droits TVA", "CA Facturé HT"]
        ws.append(headers)
        for ci in range(1, len(headers) + 1):
            c = ws.cell(row=3, column=ci)
            c.font = f_header; c.fill = fill_header; c.alignment = Alignment(horizontal="center")

        for r in lots_fac:
            ws.append([
                r.get("date_display"), r.get("NumActe"), r.get("Notaire"), r.get("Nlot"), r.get("Acquereur"),
                r.get("SupLot"), r.get("PCessionU"), r.get("PcessionLot"), r.get("BaseTvaLot"), r.get("DroitsTvaLot"), r.get("BaseTapLot")
            ])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci in (6, 7, 8, 9, 10, 11):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                else:
                    cell.alignment = Alignment(horizontal="center")

    elif key == "lotissement_annuelle":
        ws.title = "Situation Annuelle TCR"
        tcr_rows = lotissement.tcr(code, lid)
        ws["A1"] = f"{rs} — {st.get('Adresse')} (Situation Annuelle)"
        ws["A1"].font = f_title
        ws.append([])
        headers = ["Année", "Nombre Lots", "Superficie Vendue", "Prix Cession TTC", "Coût Revient",
                   "Base TVA", "Droits TVA", "CA Imposable", "Charges Totales", "Résultat", "Impôt Dû", "Total Droits"]
        ws.append(headers)
        for ci in range(1, len(headers) + 1):
            c = ws.cell(row=3, column=ci)
            c.font = f_header; c.fill = fill_header; c.alignment = Alignment(horizontal="center")

        for r in tcr_rows:
            ws.append([
                r.get("CAannee"), r.get("NbreLots"), r.get("Tsuperficie"), r.get("PCessionTTC"), r.get("CoutRevnent"),
                r.get("BaseTva"), r.get("TDroitsTVA"), r.get("CA"), r.get("Tcharges"), r.get("resultat"), r.get("IRG"), r.get("Tdroits")
            ])
            cur = ws.max_row
            for ci in range(1, len(headers) + 1):
                cell = ws.cell(row=cur, column=ci)
                cell.border = border
                if ci in (3, 4, 5, 6, 7, 8, 9, 10, 11, 12):
                    cell.number_format = '#,##0.00'
                    cell.alignment = Alignment(horizontal="right")
                else:
                    cell.alignment = Alignment(horizontal="center")

    # Auto-adjust column widths
    for col in ws.columns:
        longest = max(len(str(cell.value or "")) for cell in col)
        col_letter = get_column_letter(col[0].column)
        ws.column_dimensions[col_letter].width = max(11, min(42, longest + 3))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(out_path))


def render_report_html(key: str, code: str, params: dict) -> tuple[str, str]:
    """Unified dispatcher for all lotissement report keys."""
    if key in ("lotissement", "lotissement_situation"):
        return render_situation_html(code, params)
    elif key == "lotissement_plan":
        return render_plan_html(code, params)
    elif key == "lotissement_lots":
        return render_lots_html(code, params)
    elif key == "lotissement_versements":
        return render_versements_html(code, params)
    elif key == "lotissement_creances":
        return render_creances_html(code, params)
    elif key == "lotissement_annuelle":
        return render_annuelle_html(code, params)
    elif key == "lotissement_facturation":
        return render_facturation_html(code, params)
    else:
        return render_situation_html(code, params)

