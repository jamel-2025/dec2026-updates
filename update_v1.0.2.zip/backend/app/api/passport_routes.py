"""Routes pour le Passeport Financier Numérique et la vérification publique anti-fraude.
"""
from __future__ import annotations

from html import escape
from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse

from ..services import passport

router = APIRouter(tags=["passport"])


@router.get("/api/passport/inspect")
def inspect_passport(
    d: str = Query(..., description="Code dossier"),
    t: str = Query("recu_lot", description="Type de document"),
    id: str = Query(..., description="ID document"),
    ref: str = Query("", description="Référence"),
    m: float = Query(0.0, description="Montant"),
    h: str = Query("", description="Hash HMAC-SHA256"),
):
    """API JSON retournant le statut de conformité et l'intégrité du document."""
    res = passport.verify_and_fetch_passport_details(
        dossier=d,
        doc_type=t,
        doc_id=id,
        ref_num=ref,
        montant_param=m,
        hash_param=h,
    )
    return res


@router.get("/verify", response_class=HTMLResponse)
def public_verify_page(
    request: Request,
    d: str = Query(..., description="Code dossier"),
    t: str = Query("recu_lot", description="Type de document"),
    id: str = Query(..., description="ID document"),
    ref: str = Query("", description="Référence"),
    m: float = Query(0.0, description="Montant"),
    h: str = Query("", description="Hash signature"),
    lang: str = Query("ar", description="Langue d'affichage"),
):
    """Page web publique responsive vérifiant l'authenticité d'un document scellé."""
    info = passport.verify_and_fetch_passport_details(
        dossier=d,
        doc_type=t,
        doc_id=id,
        ref_num=ref,
        montant_param=m,
        hash_param=h,
    )

    is_valid = info["valid"]
    is_ar = lang == "ar"
    dir_attr = 'dir="rtl"' if is_ar else 'dir="ltr"'
    lang_attr = 'lang="ar"' if is_ar else 'lang="fr"'

    soc = info["societe"]
    soc_rs = escape(soc.get("rs") or "")
    soc_nif = escape(soc.get("NIF") or "—")
    soc_rc = escape(soc.get("RC") or "—")
    soc_adr = escape(soc.get("adresse") or "—")

    client = escape(info.get("client") or "—")
    ref_num = escape(str(info.get("ref_num") or id))
    date_doc = escape(str(info.get("date_doc") or "—"))
    mode_reg = escape(str(info.get("mode_reglement") or "—"))
    designation = escape(str(info.get("designation") or "—"))
    short_hash = escape(info.get("short_hash") or "—")
    verified_at = escape(info.get("verified_at") or "")

    # Formatage montant
    mt = info.get("montant") or 0.0
    mt_str = f"{mt:,.2f}".replace(",", " ").replace(".", ",") + " DA"

    if is_valid:
        status_bg = "#ecfdf5"
        status_border = "#059669"
        status_color = "#065f46"
        icon_svg = """<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>"""
        status_title = "وثيقة رسمية أصيلة ومؤكدة محاسبياً" if is_ar else "DOCUMENT AUTHENTIFIÉ ET SCELLÉ"
        status_sub = "تم التحقق من مطابقة هذا الإيصال مع القيود المحاسبية الأصلية بالسنتيم دون أي تعديل" if is_ar else "Conforme aux écritures comptables certifiées, intégrité mathématique vérifiée au centime près."
    else:
        status_bg = "#fef2f2"
        status_border = "#dc2626"
        status_color = "#991b1b"
        icon_svg = """<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>"""
        status_title = "تحذير : وثيقة غير مطابقة أو ملغاة" if is_ar else "ALERTE : DOCUMENT NON CONFORME OU MODIFIÉ"
        status_sub = "لم يتم العثور على هذا المستند أو أن البيانات المقدمة لا تتطابق مع السجل المالي الأصلي" if is_ar else "Ce document est introuvable ou ses données ont été altérées."

    words_text = info.get("montant_words_ar") if is_ar else info.get("montant_words_fr")

    html = f"""<!DOCTYPE html>
<html {dir_attr} {lang_attr}>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{"جواز السفر المالي الرقمي — التحقق من الأصالة" if is_ar else "Passeport Financier — Vérification d'authenticité"}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: 'Cairo', system-ui, -apple-system, sans-serif;
    background: #0f172a;
    color: #1e293b;
    min-height: 100vh;
    padding: 20px 16px;
    display: flex;
    justify-content: center;
    align-items: center;
  }}
  .card {{
    background: #ffffff;
    max-width: 620px;
    width: 100%;
    border-radius: 16px;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
    overflow: hidden;
    border: 1px solid #334155;
  }}
  .card-header {{
    background: linear-gradient(135deg, #064e3b 0%, #047857 50%, #0f766e 100%);
    color: #ffffff;
    padding: 24px;
    text-align: center;
    position: relative;
  }}
  .gold-ribbon {{
    display: inline-block;
    background: linear-gradient(90deg, #d97706, #fbbf24, #d97706);
    color: #78350f;
    font-size: 11px;
    font-weight: 900;
    padding: 3px 12px;
    border-radius: 20px;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    margin-bottom: 8px;
  }}
  .card-header h1 {{
    font-size: 22px;
    font-weight: 900;
    letter-spacing: -0.02em;
  }}
  .card-header p {{
    font-size: 13px;
    color: #a7f3d0;
    margin-top: 4px;
  }}
  .status-banner {{
    background: {status_bg};
    border-bottom: 2px solid {status_border};
    padding: 20px;
    text-align: center;
  }}
  .status-banner .icon {{ margin-bottom: 8px; }}
  .status-banner h2 {{
    color: {status_color};
    font-size: 18px;
    font-weight: 800;
  }}
  .status-banner p {{
    color: #475569;
    font-size: 12.5px;
    margin-top: 4px;
    max-width: 480px;
    margin-left: auto;
    margin-right: auto;
  }}
  .content {{
    padding: 24px;
  }}
  .company-info {{
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 14px 18px;
    margin-bottom: 18px;
  }}
  .company-name {{
    font-size: 16px;
    font-weight: 800;
    color: #0f172a;
  }}
  .company-sub {{
    font-size: 12px;
    color: #64748b;
    margin-top: 4px;
    line-height: 1.5;
  }}
  .details-grid {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 18px;
  }}
  .detail-box {{
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 10px 14px;
  }}
  .detail-lbl {{
    font-size: 11px;
    color: #64748b;
    font-weight: 700;
  }}
  .detail-val {{
    font-size: 14px;
    color: #0f172a;
    font-weight: 800;
    margin-top: 2px;
  }}
  .amount-card {{
    background: #f0fdf4;
    border: 2px dashed #047857;
    border-radius: 12px;
    padding: 18px;
    text-align: center;
    margin-bottom: 20px;
  }}
  .amount-lbl {{
    font-size: 12px;
    color: #065f46;
    font-weight: 800;
  }}
  .amount-digits {{
    font-size: 28px;
    font-weight: 900;
    color: #047857;
    margin: 6px 0;
    font-family: monospace;
    direction: ltr;
  }}
  .amount-words {{
    font-size: 13px;
    font-weight: 700;
    color: #1e293b;
    line-height: 1.4;
  }}
  .security-footer {{
    border-top: 1px solid #e2e8f0;
    padding-top: 16px;
    font-size: 11px;
    color: #64748b;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 8px;
  }}
  .hash-pill {{
    background: #e2e8f0;
    color: #334155;
    font-family: monospace;
    padding: 2px 8px;
    border-radius: 4px;
    font-weight: 700;
    font-size: 10.5px;
  }}
</style>
</head>
<body>
  <div class="card">
    <div class="card-header">
      <div class="gold-ribbon">{"الجمهورية الجزائرية الديمقراطية الشعبية" if is_ar else "RÉPUBLIQUE ALGÉRIENNE"}</div>
      <h1>{"جواز السفر المالي الرقمي — الختم الإلكتروني" if is_ar else "Passeport Fiscal & Sceau Numérique"}</h1>
      <p>{"نظام التوثيق والتحقق ضد التزوير للمحاسبة والترقية العقارية" if is_ar else "Système d'authentification et de traçabilité financière"}</p>
    </div>

    <div class="status-banner">
      <div class="icon">{icon_svg}</div>
      <h2>{status_title}</h2>
      <p>{status_sub}</p>
    </div>

    <div class="content">
      <div class="company-info">
        <div class="company-name">{soc_rs}</div>
        <div class="company-sub">
          <span>NIF : <b>{soc_nif}</b></span> &nbsp;·&nbsp;
          <span>RC : <b>{soc_rc}</b></span> &nbsp;·&nbsp;
          <span>{soc_adr}</span>
        </div>
      </div>

      <div class="details-grid">
        <div class="detail-box">
          <div class="detail-lbl">{"المستفيد / المشتري" if is_ar else "Acquéreur / Client"}</div>
          <div class="detail-val">{client}</div>
        </div>
        <div class="detail-box">
          <div class="detail-lbl">{"رقم الوصل / المرجع" if is_ar else "N° de Reçu / Réf"}</div>
          <div class="detail-val">{ref_num}</div>
        </div>
        <div class="detail-box">
          <div class="detail-lbl">{"تاريخ التسجيل" if is_ar else "Date d'encaissement"}</div>
          <div class="detail-val">{date_doc}</div>
        </div>
        <div class="detail-box">
          <div class="detail-lbl">{"طريقة الدفع" if is_ar else "Mode de règlement"}</div>
          <div class="detail-val">{mode_reg}</div>
        </div>
      </div>

      <div class="detail-box" style="margin-bottom: 18px;">
        <div class="detail-lbl">{"التعيين والبيان" if is_ar else "Désignation de l'opération"}</div>
        <div class="detail-val" style="font-size:13px;">{designation}</div>
      </div>

      <div class="amount-card">
        <div class="amount-lbl">{"المبلغ المسدد المقبوض والمطابق رسمياً" if is_ar else "MONTANT EXACT SCELLÉ AU CENTIME PRÈS"}</div>
        <div class="amount-digits">{mt_str}</div>
        <div class="amount-words">{words_text}</div>
      </div>

      <div class="security-footer">
        <div>
          <span>{"بصمة الأمان :" if is_ar else "Empreinte :"}</span>
          <span class="hash-pill">SHA256: {short_hash}</span>
        </div>
        <div>
          <span>{"وقت التحقق :" if is_ar else "Vérifié le :"}</span>
          <b>{verified_at}</b>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
"""
    return HTMLResponse(content=html, status_code=200 if is_valid else 400)
