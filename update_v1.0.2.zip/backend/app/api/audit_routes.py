"""API Routes for Audit Log & Security Monitor."""
from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Query, Request, Response
from fastapi.responses import Response

from ..core import audit, users

router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("/logs")
def get_audit_logs(
    limit: int = Query(150, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    source: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    dossier: Optional[str] = Query(None),
    q: Optional[str] = Query(None),
):
    """Retrieve filtered audit logs with pagination and stats."""
    res = audit.list_logs(
        limit=limit,
        offset=offset,
        source=source,
        category=category,
        dossier=dossier,
        q=q,
    )
    res["stats"] = audit.get_stats()
    return res


@router.get("/stats")
def get_audit_stats() -> dict:
    """Retrieve live statistics for real-time monitoring."""
    return audit.get_stats()


@router.post("/clear")
def clear_audit_logs(request: Request) -> dict:
    """Purge audit log records completely."""
    users.require_permission(request, "audit_clear")
    audit.clear_logs()
    return {"ok": True, "message": "Journal d'audit réinitialisé"}


@router.get("/export")
def export_audit_excel(limit: int = Query(1000, ge=1, le=5000)) -> Response:
    """Download audit log as a formatted Excel spreadsheet (.xlsx)."""
    try:
        content = audit.export_excel(limit=limit)
        return Response(
            content=content,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": 'attachment; filename="Journal_Audit_Dec2026.xlsx"'
            },
        )
    except Exception as e:
        raise HTTPException(500, f"Erreur lors de l'export Excel: {e}")

