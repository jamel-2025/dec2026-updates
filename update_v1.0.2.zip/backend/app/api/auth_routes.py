"""Dec2026 Authentication, Multi-User RBAC, Network Sessions & Concurrency Locks API."""
from __future__ import annotations

import shutil
import subprocess
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import Response as RawResponse
from pydantic import BaseModel, Field

from ..core import access, audit, config, tunnel, users
from ..core.locks import LOCK_MANAGER

router = APIRouter(tags=["Authentification, Utilisateurs & Réseau"])


class LoginPayload(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    pin: Optional[str] = None


class PinPayload(BaseModel):
    pin: str = Field(..., min_length=6)


class UserUpsertPayload(BaseModel):
    username: str = Field(..., min_length=2)
    display_name_fr: str = ""
    display_name_ar: str = ""
    role: str = "comptable"
    password: Optional[str] = None
    pin: Optional[str] = None
    active: bool = True
    permissions: Optional[List[str]] = None
    assigned_dossiers: Optional[List[str]] = None


class AssignDossierPayload(BaseModel):
    dossier_code: str
    username: str


class NetworkUpdatePayload(BaseModel):
    acces_mobile: Optional[bool] = None
    ecoute_lan: Optional[bool] = None
    lecture_seule: Optional[bool] = None
    session_heures: Optional[int] = None
    auth_requise_local: Optional[bool] = None


class LockPayload(BaseModel):
    resource_key: str
    dossier: Optional[str] = None
    exercice: Optional[str] = None
    mois: Optional[int] = None


# ─────────────────────────────────────────────────────────────
# 1. État d'accès & Profil courant
# ─────────────────────────────────────────────────────────────

@router.get("/api/auth/etat")
def get_auth_etat(request: Request):
    """Vérifie l'état d'authentification du client (local ou LAN) et son profil utilisateur."""
    is_local = access.is_desktop(request)
    cfg = access.load()
    token = request.cookies.get(access.COOKIE)

    user_info = None
    is_auth = False

    if token and access.SESSIONS.valid(token):
        s_item = access.SESSIONS.get(token)
        if s_item:
            all_u = users.load_users()
            u_db = all_u.get(s_item.username)
            if u_db:
                user_info = users.sanitize_user(u_db)
            else:
                user_info = {
                    "username": s_item.username,
                    "display_name_fr": s_item.display_name_fr,
                    "display_name_ar": s_item.display_name_ar,
                    "role": s_item.role,
                    "role_info": users.ROLES.get(s_item.role, users.ROLES["lecture"]),
                    "permissions": users.ROLES.get(s_item.role, users.ROLES["lecture"])["permissions"],
                    "active": True,
                }
            is_auth = True
    edition = config.get_edition()
    mode_reseau = edition == "reseau" or bool(cfg.get("mode_reseau", False))

    return {
        "local": is_local,
        "authentifie": is_auth,
        "acces_mobile": cfg.get("acces_mobile", True),
        "pin_defini": bool(cfg.get("pin_hash")),
        "lecture_seule": bool(cfg.get("lecture_seule", False)) or (user_info and user_info.get("role") == "lecture"),
        "auth_requise_local": True,
        "mode_reseau": mode_reseau,
        "edition": edition,
        "user": user_info,
    }


class ProfileUpdatePayload(BaseModel):
    username: str = Field(..., min_length=2)
    password: Optional[str] = None


@router.post("/api/auth/profile/update")
def update_profile(payload: ProfileUpdatePayload, request: Request):
    """Mise à jour simple du compte d'accès (Solo)."""
    target = payload.username.strip()
    if not target:
        raise HTTPException(400, "Le nom d'utilisateur est requis.")

    all_u = users.load_users()
    tok = request.cookies.get(access.COOKIE)
    curr = access.SESSIONS.get(tok) if tok else None
    old_username = curr.username if curr else "admin"
    if old_username not in all_u:
        old_username = list(all_u.keys())[0] if all_u else "admin"

    old_obj = all_u.get(old_username, {})

    saved = users.create_or_update_user(
        username=target,
        display_name_fr=target,
        display_name_ar=target,
        role=old_obj.get("role", "admin"),
        password=payload.password if payload.password else None,
        pin=payload.password if payload.password else None,
        active=True,
    )
    if old_username.lower() != target.lower() and old_username in all_u:
        users.delete_user(old_username)

    return {"ok": True, "user": saved}


@router.get("/api/auth/current")
def get_current_user(request: Request):
    """Renvoie le profil utilisateur actif et ses permissions."""
    token = request.cookies.get(access.COOKIE)
    if token and access.SESSIONS.valid(token):
        s_item = access.SESSIONS.get(token)
        if s_item:
            u_db = users.load_users().get(s_item.username)
            if u_db:
                return users.sanitize_user(u_db)
    cfg = access.load_config()
    mode_reseau = bool(cfg.get("mode_reseau", False))
    if not mode_reseau and access.is_desktop(request):
        admin_u = users.load_users().get("admin")
        if admin_u:
            return users.sanitize_user(admin_u)
    raise HTTPException(status_code=401, detail="Non authentifié")


# ─────────────────────────────────────────────────────────────
# 2. Connexion & Déconnexion
# ─────────────────────────────────────────────────────────────

@router.post("/api/auth/login")
def login(payload: LoginPayload, request: Request, response: Response):
    """Authentifie un utilisateur (Nom d'utilisateur + Mot de passe ou Code PIN)."""
    client_ip = request.client.host if request.client else "unknown"
    if access.THROTTLE.is_blocked(client_ip):
        audit.record(
            action="AUTH_THROTTLED",
            category="security",
            description=f"Tentative de connexion bloquée suite à des échecs répétés (IP: {client_ip})",
            request=request,
            status="blocked",
        )
        raise HTTPException(
            status_code=429,
            detail="Trop de tentatives, réessayez dans 5 minutes.",
        )

    cfg = access.load()
    is_local = access.is_desktop(request)
    if not is_local and not cfg.get("acces_mobile", True):
        audit.record(
            action="AUTH_DISABLED",
            category="security",
            description="Tentative de connexion distante alors que l'accès réseau est désactivé",
            request=request,
            status="blocked",
        )
        raise HTTPException(
            status_code=403,
            detail="Accès depuis le réseau désactivé sur le poste principal.",
        )

    # Resolve target username / credential
    target_ident = payload.username or payload.pin or ""
    pwd = payload.password if payload.username else None

    # Authenticate via users DB
    matched_user = users.authenticate(target_ident, pwd)

    # Fallback to legacy pin_hash in acces.json if no match in users.json
    if not matched_user and payload.pin and access.check_pin(payload.pin):
        matched_user = users.load_users().get("admin")
        if matched_user:
            matched_user = users.sanitize_user(matched_user)

    if not matched_user:
        access.THROTTLE.record_failure(client_ip)
        audit.record(
            action="AUTH_LOGIN_FAILED",
            category="security",
            description=f"Échec de connexion pour « {target_ident} » (Mot de passe ou PIN incorrect)",
            request=request,
            status="warning",
            username=target_ident,
        )
        raise HTTPException(status_code=401, detail="Identifiants incorrects.")

    access.THROTTLE.reset(client_ip)

    # Extract device
    ua = request.headers.get("user-agent", "")
    device = audit.parse_device(ua)
    source = "local" if is_local else "lan"

    token = access.SESSIONS.create(
        username=matched_user["username"],
        role=matched_user["role"],
        display_name_fr=matched_user.get("display_name_fr", matched_user["username"]),
        display_name_ar=matched_user.get("display_name_ar", matched_user["username"]),
        client_ip=client_ip,
        device=device,
        source=source,
    )

    session_hours = cfg.get("session_heures", 12)
    max_age = int(session_hours * 3600)
    is_https = request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https"

    response.set_cookie(
        key=access.COOKIE,
        value=token,
        max_age=max_age,
        httponly=True,
        samesite="lax",
        secure=is_https,
        path="/",
    )

    audit.record(
        action="AUTH_LOGIN_SUCCESS",
        category="security",
        description=f"Connexion réussie de « {matched_user['display_name_fr']} » ({matched_user['role']})",
        request=request,
        status="success",
        username=matched_user["username"],
        user_role=matched_user["role"],
    )

    return {
        "ok": True,
        "message": "Connexion réussie",
        "user": matched_user,
    }


@router.post("/api/auth/logout")
def logout(request: Request, response: Response):
    """Déconnecte la session active et libère ses verrous concurrents."""
    token = request.cookies.get(access.COOKIE)
    user_name = "inconnu"
    if token:
        s_item = access.SESSIONS.get(token)
        if s_item:
            user_name = s_item.username
            # Clean locks held by this user
            client_ip = request.client.host if request.client else None
            for lock in LOCK_MANAGER.list_active():
                if lock["username"] == user_name:
                    LOCK_MANAGER.release(lock["resource_key"], user_name, client_ip)
        access.SESSIONS.revoke(token)

    response.delete_cookie(key=access.COOKIE, path="/")
    audit.record(
        action="AUTH_LOGOUT",
        category="security",
        description=f"Déconnexion de l'utilisateur « {user_name} »",
        request=request,
        status="success",
        username=user_name,
    )
    return {"ok": True}


# ─────────────────────────────────────────────────────────────
# 3. Gestion des Utilisateurs (CRUD)
# ─────────────────────────────────────────────────────────────

@router.get("/api/auth/users")
def get_all_users():
    """Renvoie la liste des utilisateurs du système pour l'écran de connexion et l'administration."""
    return users.list_users()


@router.get("/api/auth/roles")
def get_roles():
    """Renvoie les définitions des 4 rôles (admin, comptable, saisie, lecture)."""
    return list(users.ROLES.values())


@router.get("/api/auth/permissions/catalog")
def get_permissions_catalog():
    """Renvoie le catalogue complet des permissions granulaires et les rôles."""
    return {
        "catalog": users.PERMISSIONS_CATALOG,
        "roles": list(users.ROLES.values()),
    }


@router.post("/api/auth/users")
def save_user(payload: UserUpsertPayload, request: Request):
    """Crée ou met à jour un compte utilisateur avec permissions et portefeuille de dossiers."""
    # Only admin can manage users
    tok = request.cookies.get(access.COOKIE)
    curr = access.SESSIONS.get(tok)
    if not access.is_desktop(request) and (not curr or curr.role != "admin"):
        raise HTTPException(403, "Action réservée aux administrateurs.")

    try:
        saved = users.create_or_update_user(
            username=payload.username,
            display_name_fr=payload.display_name_fr,
            display_name_ar=payload.display_name_ar,
            role=payload.role,
            password=payload.password,
            pin=payload.pin,
            active=payload.active,
            permissions=payload.permissions,
            assigned_dossiers=payload.assigned_dossiers,
        )
        audit.record(
            action="USER_UPDATE",
            category="security",
            description=f"Création/Mise à jour de l'utilisateur « {saved['username']} » ({saved['role']})",
            request=request,
            status="success",
        )
        return {"ok": True, "user": saved}
    except Exception as e:
        raise HTTPException(400, str(e))


@router.delete("/api/auth/users/{username}")
def remove_user(username: str, request: Request):
    """Supprime un utilisateur (compte admin protégé)."""
    tok = request.cookies.get(access.COOKIE)
    curr = access.SESSIONS.get(tok)
    if not access.is_desktop(request) and (not curr or curr.role != "admin"):
        raise HTTPException(403, "Action réservée aux administrateurs.")

    try:
        deleted = users.delete_user(username)
        if not deleted:
            raise HTTPException(404, "Utilisateur introuvable.")
        audit.record(
            action="USER_DELETE",
            category="security",
            description=f"Suppression de l'utilisateur « {username} »",
            request=request,
            status="warning",
        )
        return {"ok": True}
    except ValueError as ve:
        raise HTTPException(400, str(ve))


@router.post("/api/auth/dossiers/assign")
def assign_dossier(payload: AssignDossierPayload, request: Request):
    """Permet au manager d'affecter ou réaffecter un dossier à un collaborateur."""
    tok = request.cookies.get(access.COOKIE)
    curr = access.SESSIONS.get(tok)
    if not access.is_desktop(request) and (not curr or curr.role != "admin"):
        raise HTTPException(403, "Action réservée aux administrateurs.")

    from ..core import assignments
    modifier = curr.username if curr else "admin"
    res = assignments.set_dossier_assignee(payload.dossier_code, payload.username, modifier=modifier)
    audit.record(
        action="DOSSIER_ASSIGN",
        category="security",
        description=f"Réaffectation du dossier {payload.dossier_code} à « {payload.username or 'aucun'} »",
        request=request,
        dossier=payload.dossier_code,
        status="success",
        details={"dossier": payload.dossier_code, "assigned_to": payload.username},
    )
    return {"ok": True, "assignment": res}


@router.get("/api/collaborateurs/performance")
def get_collaborateurs_performance(request: Request):
    """Tableau de bord de pilotage du cabinet : performance, dossiers et avancement par collaborateur."""
    from ..services import dossiers, manquantes
    from ..core import assignments
    from datetime import date

    all_u = users.load_users()
    all_d = dossiers.list_dossiers()
    meta = assignments.load_meta()
    today = date.today()
    g50_m, g50_y = (12, today.year - 1) if today.month == 1 else (today.month - 1, today.year)

    # Global manquantes stats for current G50 month
    global_m = manquantes.search("g50", str(g50_y), str(g50_m))
    filed_codes = {r["code"].upper() for r in global_m.get("filed", [])}
    missing_codes = {r["code"].upper() for r in global_m.get("missing", [])}

    collaborateurs = []
    for u_key, u_obj in all_u.items():
        is_admin = u_obj.get("role") == "admin"
        if is_admin:
            u_dossiers = all_d
        else:
            u_dossiers = [d for d in all_d if (d.get("assigned_to") or "").lower() == u_key or d.get("assigned_to") == "*"]

        total_d = len(u_dossiers)
        done_count = sum(1 for d in u_dossiers if d["code"].upper() in filed_codes)
        late_count = sum(1 for d in u_dossiers if d["code"].upper() in missing_codes)
        taux = round((done_count / total_d * 100), 1) if total_d > 0 else 100.0

        collaborateurs.append({
            "username": u_key,
            "display_name_fr": u_obj.get("display_name_fr") or u_key,
            "display_name_ar": u_obj.get("display_name_ar") or u_key,
            "role": u_obj.get("role", "comptable"),
            "role_color": users.ROLES.get(u_obj.get("role", "comptable"), {}).get("color", "#64748b"),
            "active": u_obj.get("active", True),
            "dossiers_count": total_d,
            "assigned_dossiers": [d["code"] for d in u_dossiers],
            "g50_month": f"{g50_m:02d}/{g50_y}",
            "completed_g50_count": done_count,
            "late_g50_count": late_count,
            "taux_avancement": taux,
            "last_login": u_obj.get("last_login"),
        })

    total_cabinet_d = len(all_d)
    cabinet_done = len(filed_codes)
    cabinet_late = len(missing_codes)
    cabinet_taux = round((cabinet_done / total_cabinet_d * 100), 1) if total_cabinet_d > 0 else 100.0

    return {
        "collaborateurs": collaborateurs,
        "cabinet": {
            "total_dossiers": total_cabinet_d,
            "completed_count": cabinet_done,
            "late_count": cabinet_late,
            "taux_avancement": cabinet_taux,
            "g50_period": f"{g50_m:02d}/{g50_y}",
        }
    }


# ─────────────────────────────────────────────────────────────
# 4. Utilisateurs & Appareils connectés sur le Réseau LAN
# ─────────────────────────────────────────────────────────────

@router.get("/api/system/connected-users")
def get_connected_users(request: Request):
    """Liste tous les appareils et utilisateurs connectés en temps réel sur le réseau local."""
    tok = request.cookies.get(access.COOKIE)
    curr_token = tok or ""
    active_sessions = access.SESSIONS.list_active()

    # If desktop is local and not in sessions yet, add desktop host entry
    has_local = any(s["source"] == "local" for s in active_sessions)
    if access.is_desktop(request) and not has_local:
        active_sessions.insert(0, {
            "username": "admin",
            "role": "admin",
            "display_name_fr": "Poste Principal (Bureau)",
            "display_name_ar": "المحطة الرئيسية (الحاسوب)",
            "client_ip": "127.0.0.1",
            "device": "Windows PC",
            "source": "local",
            "last_seen_seconds": 0,
            "current_dossier": "",
            "current_page": "dashboard",
            "online": True,
        })

    active_locks = LOCK_MANAGER.list_active()

    return {
        "count": len(active_sessions),
        "users": active_sessions,
        "active_locks": active_locks,
    }


# ─────────────────────────────────────────────────────────────
# 5. Gestion des Verrous Concurrents (Anti-Conflit G50 / Dossier)
# ─────────────────────────────────────────────────────────────

@router.post("/api/locks/acquire")
def acquire_lock(payload: LockPayload, request: Request):
    """Tente d'acquérir ou de renouveler un verrou exclusif sur un dossier ou une déclaration G50."""
    tok = request.cookies.get(access.COOKIE)
    s_item = access.SESSIONS.get(tok)

    if s_item:
        uname = s_item.username
        dname = s_item.display_name_fr
        role = s_item.role
    elif access.is_desktop(request):
        uname = "admin"
        dname = "Administrateur (PC)"
        role = "admin"
    else:
        uname = "invite"
        dname = "Invité LAN"
        role = "lecture"

    client_ip = request.client.host if request.client else "127.0.0.1"
    ua = request.headers.get("user-agent", "")
    device = audit.parse_device(ua)

    res = LOCK_MANAGER.acquire(
        resource_key=payload.resource_key,
        username=uname,
        display_name=dname,
        role=role,
        client_ip=client_ip,
        device=device,
    )
    return res


@router.post("/api/locks/heartbeat")
def heartbeat_lock(payload: LockPayload, request: Request):
    """Maintient le bail du verrou actif."""
    tok = request.cookies.get(access.COOKIE)
    s_item = access.SESSIONS.get(tok)
    uname = s_item.username if s_item else "admin"
    client_ip = request.client.host if request.client else "127.0.0.1"

    ok = LOCK_MANAGER.heartbeat(payload.resource_key, uname, client_ip)
    return {"ok": ok}


@router.post("/api/locks/release")
def release_lock(payload: LockPayload, request: Request):
    """Libère un verrou détenu par l'utilisateur."""
    tok = request.cookies.get(access.COOKIE)
    s_item = access.SESSIONS.get(tok)
    uname = s_item.username if s_item else "admin"
    client_ip = request.client.host if request.client else "127.0.0.1"

    ok = LOCK_MANAGER.release(payload.resource_key, uname, client_ip)
    return {"ok": ok}


@router.get("/api/locks/active")
def get_active_locks():
    """Renvoie la liste des verrous actifs en temps réel."""
    return LOCK_MANAGER.list_active()


@router.post("/api/locks/force-release")
def force_release_lock(payload: LockPayload, request: Request):
    """Déverrouillage forcé réservé aux administrateurs."""
    tok = request.cookies.get(access.COOKIE)
    s_item = access.SESSIONS.get(tok)
    if not access.is_desktop(request) and (not s_item or s_item.role != "admin"):
        raise HTTPException(403, "Action réservée aux administrateurs.")

    ok = LOCK_MANAGER.force_release(payload.resource_key)
    audit.record(
        action="LOCK_FORCE_RELEASE",
        category="system",
        description=f"Déverrouillage forcé du verrou « {payload.resource_key} »",
        request=request,
        status="warning",
    )
    return {"ok": ok}


# ─────────────────────────────────────────────────────────────
# 6. Réseau LAN, QR Code & Tunnel Cloudflare
# ─────────────────────────────────────────────────────────────

def _check_local_only(request: Request):
    """Garantit que la route n'est accessible que depuis le poste desktop local."""
    if not access.is_desktop(request):
        raise HTTPException(
            status_code=403,
            detail="Action disponible uniquement sur le poste principal.",
        )


@router.get("/api/reseau")
def get_reseau_status(request: Request):
    """Informations de connectivité réseau pour le dialogue Accès Mobile."""
    _check_local_only(request)
    cfg = access.load()
    ips = access.get_local_ips()
    port = cfg.get("port", 8790)

    lan_ip = None
    for ip in ips:
        if not ip.startswith("192.168.56."):
            lan_ip = ip
            break
    if not lan_ip and ips:
        lan_ip = ips[0]
    lan_ip = lan_ip or "127.0.0.1"

    url_lan = f"http://{lan_ip}:{port}/"

    tailscale_info = {"installe": False, "connecte": False, "url": None}
    ts_exe = shutil.which("tailscale")
    if ts_exe:
        tailscale_info["installe"] = True
        try:
            res = subprocess.run([ts_exe, "status", "--json"], capture_output=True, text=True, timeout=2)
            if res.returncode == 0:
                import json
                ts_data = json.loads(res.stdout)
                tailscale_info["connecte"] = ts_data.get("BackendState") == "Running"
                self_node = ts_data.get("Self", {})
                dns_name = self_node.get("DNSName", "").rstrip(".")
                if dns_name:
                    tailscale_info["url"] = f"https://{dns_name}/"
        except Exception:
            pass

    qr_data_uri = access.generate_qr_data_uri(url_lan)

    return {
        "acces_mobile": cfg.get("acces_mobile", True),
        "ecoute_lan": cfg.get("ecoute_lan", True),
        "port": port,
        "pin_defini": bool(cfg.get("pin_hash")),
        "lecture_seule": cfg.get("lecture_seule", False),
        "auth_requise_local": cfg.get("auth_requise_local", False),
        "adresses": ips,
        "ip_principale": lan_ip,
        "url_lan": url_lan,
        "qr_data_uri": qr_data_uri,
        "qr_png_data_uri": qr_data_uri,
        "tailscale": tailscale_info,
        "tunnel": tunnel.get_status(),
    }


@router.put("/api/reseau")
def update_reseau_settings(payload: NetworkUpdatePayload, request: Request):
    """Met à jour les paramètres d'écoute réseau et d'accès mobile."""
    _check_local_only(request)
    cfg = access.load()

    if payload.acces_mobile is not None:
        cfg["acces_mobile"] = payload.acces_mobile
    if payload.ecoute_lan is not None:
        cfg["ecoute_lan"] = payload.ecoute_lan
    if payload.lecture_seule is not None:
        cfg["lecture_seule"] = payload.lecture_seule
    if payload.session_heures is not None:
        cfg["session_heures"] = payload.session_heures
    if payload.auth_requise_local is not None:
        cfg["auth_requise_local"] = payload.auth_requise_local

    access.save(cfg)
    return {"ok": True, "settings": cfg}


@router.put("/api/reseau/pin")
def update_pin(payload: PinPayload, request: Request):
    """Définit ou change le code PIN d'accès mobile."""
    _check_local_only(request)
    try:
        access.set_pin(payload.pin)
        return {"ok": True, "message": "Code PIN enregistré avec succès."}
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


@router.post("/api/reseau/deconnecter")
def disconnect_all(request: Request):
    """Déconnecte tous les téléphones distants simultanément."""
    _check_local_only(request)
    access.SESSIONS.revoke_all()
    audit.record(
        action="AUTH_REVOKE_ALL",
        category="security",
        description="Révocation de toutes les sessions distantes",
        request=request,
        status="warning",
    )
    return {"ok": True, "message": "Toutes les sessions distantes ont été révoquées."}


@router.get("/api/reseau/qr.svg")
def get_qr_svg(url: str, request: Request):
    """Génère le code QR officiel au format SVG."""
    _check_local_only(request)
    svg_code = access.generate_qr_svg(url)
    return RawResponse(content=svg_code, media_type="image/svg+xml")


@router.get("/api/reseau/qr.png")
def get_qr_png(url: str, request: Request):
    """Génère le code QR officiel au format PNG."""
    _check_local_only(request)
    png_bytes = access.generate_qr_png_bytes(url)
    return RawResponse(content=png_bytes, media_type="image/png")


@router.get("/api/reseau/tunnel")
def get_tunnel_status(request: Request):
    """Obtient le statut du tunnel public Cloudflare."""
    _check_local_only(request)
    return tunnel.get_status()


@router.post("/api/reseau/tunnel/start")
def start_tunnel_endpoint(request: Request):
    """Démarre le tunnel public Cloudflare vers le serveur local."""
    _check_local_only(request)
    cfg = access.load()
    port = cfg.get("port", 8790)
    res = tunnel.start_tunnel(port=port)
    audit.record(
        action="TUNNEL_START",
        category="system",
        description=f"Démarrage du tunnel Cloudflare (Port {port})",
        request=request,
        status="success",
        details=res,
    )
    return res


@router.post("/api/reseau/tunnel/stop")
def stop_tunnel_endpoint(request: Request):
    """Arrête le tunnel public Cloudflare."""
    _check_local_only(request)
    res = tunnel.stop_tunnel()
    audit.record(
        action="TUNNEL_STOP",
        category="system",
        description="Arrêt du tunnel Cloudflare",
        request=request,
        status="success",
    )
    return res
