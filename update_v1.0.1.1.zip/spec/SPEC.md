# Spécification extraite de G50multi2026 (générée — ne pas éditer)

Unités : **75** · lignes Pascal : **27758** · tables physiques : **39**

## Unités

| Unité | Fiche | Titre | Taille | Contrôles |
|---|---|---|---|---|
| uMain | frmMain | Multi-Sociétés 2026 | 1432x736 | 445 |
| uDataModule | DM |  | NonexNone | 170 |
| uNewSociete | frmNewSociete | Nouveau Dossier - Création Société | 498x616 | 34 |
| uSocieteEdit | frmSocieteEdit | Fiche Société | 500x620 | 46 |
| uEmployes | frmEmployes | إدارة العمال والأجراء - Répertoire des Salariés | 1150x700 | 55 |
| uContrats | frmContrats | منظومة عقود العمل (الأصناف السبعة المعتمدة) - Gestion des Contrats | 1128x720 | 95 |
| uBeneficiaireEffectif | frmBeneficiaireEffectif | إستمارتين المستفيد الحقيقي (Bénéficiaire Effectif CNRC) | 1180x720 | 85 |
| uImportHFSQL | frmImportHFSQL | Génération Dossiers - Import HFSQL | 600x520 | 18 |
| uBatchGen | frmBatchGen | Génération Automatique des Dossiers | 640x640 | 22 |
| Unit1 | Form1 | Sauv-Restore | 824x442 | 6 |
| Unit13 | FoExercice | F Exercices | 274x245 | 12 |
| Unit22 | Form22 | F Exercice | 288x77 | 9 |
| Unit10 | Form10 | F Société | 822x396 | 40 |
| Unit23 | Form23 | Nouveau G50 | 389x91 | 73 |
| Unit20 | Form20 | Form20 | 1116x749 | 2102 |
| Unit15 | FormG50 | FormG50 | 1117x698 | 99 |
| UnitaP | Ftap | F TAP | 652x221 | 46 |
| UnitTsl | Ftsl | F TSL | 652x221 | 46 |
| Unit24 | Form24 | F IRG/Salaires | 655x285 | 24 |
| Unit25 | Form25 | Form25 | 438x220 | 21 |
| Unit26 | Form26 | Form26 | 640x257 | 37 |
| Unit27 | Form27 | Autres Taxes | 739x224 | 22 |
| Unit45 | Form45 | Solde IBS | 531x560 | 88 |
| UnitThemes | Fthemes | Fthemes | 521x74 | 6 |
| Unit3 | Form3 | Form3 | 1050x552 | 21 |
| Unit4 | Form4 | Déduction TVA | 393x337 | 54 |
| Unit5 | Form5 | Detail Chiffres d'Affaires | 1372x620 | 474 |
| Unit2 | Form2 | Déclaration Fiscale Mensuelle G50 | 1160x720 | 149 |
| Unit6 | Form6 | Form6 | 1035x549 | 8 |
| Unit7 | Form7 | Acomptes IBS | 439x230 | 24 |
| Unit8 | Form8 | Acomptes IRG | 462x232 | 24 |
| Unit9 | Form9 | Form9 | 557x421 | 69 |
| Unit11 | Form11 | Form11 | 596x569 | 67 |
| Unit12 | Form12 | Form12 | 616x325 | 27 |
| Unit14 | Form14 | Station - Nouveau | 432x81 | 43 |
| Unit17 | Form17 | Fprojet | 464x445 | 140 |
| Unit18 | Form18 | FSuivi Encaissement | 517x487 | 22 |
| Unit19 | Form19 | Form19 | 974x441 | 8 |
| uMissingG50 | frmMissingG50 | Entreprises sans declarations G50 | 638x492 | 12 |
| UmmingTAPP | frmMissingTAPP | Entreprises manquantes - TAPP | 700x520 | 12 |
| UmissingIBS | frmMissingIBS | Sociétés sans IBS | 648x496 | 10 |
| UmissingIRG | frmMissingIRG | Suivi IRG - Personnes Physiques | 650x500 | 10 |
| Unit21 | Form21 | CA Station de Services | 1047x556 | 134 |
| Unit28 | Form28 | Form28 | 972x545 | 8 |
| uOpenSociete | frmOpenSociete | Ouvrir un Dossier de Société | 648x522 | 22 |
| Unit29 | Form29 | Fiche Modification Sociéte | 820x460 | 59 |
| Unit30 | Form30 | Form30 | 1372x551 | 11 |
| Unit31 | Form31 | Form31 | 834x238 | 20 |
| Unit32 | Form32 | Form32 | 1026x674 | 8 |
| Unit33 | Form33 | Form33 | 1092x685 | 123 |
| Unit35 | Form35 | Form35 | 1154x666 | 82 |
| Unit36 | Form36 | Form36 | 978x538 | 1234 |
| uForm3_Lotis | Form3_Lotis | Form3_Lotis | 1058x515 | 110 |
| uForm4_Lotis | Form4_Lotis | Calcul /Lot | 915x371 | 102 |
| uForm7_Lotis | Form7_Lotis | Versement | 447x130 | 8 |
| uForm8_Lotis | Form8_Lotis | Sitaution Annuelle | 974x540 | 47 |
| uForm9_Lotis | Form9_Lotis | Activation du logiciel | 301x242 | 10 |
| uForm11_Lotis | Form11_Lotis | Situation Globale  | 901x497 | 67 |
| uForm12_Lotis | Form12_Lotis | Versements | 780x555 | 16 |
| uForm13_Lotis | Form13_Lotis | Créances | 809x517 | 14 |
| uForm15_Lotis | RefPPetrolier | Prix Ref P Pétroliers | 759x482 | 0 |
| uImportLotis | frmImportLotis | Liste des Lots | 728x520 | 55 |
| uAdjustGrid_Lotis |  |  |  |  |
| uCustom_Lotis |  |  |  |  |
| Unit37 | Form37 | Recap G50  | 894x600 | 168 |
| Unit38 | Form38 | Form38 | 1061x666 | 8 |
| Unit40 | Form40 | Facture de Ventes - Taxe sur la Valeur Ajoutée | 393x289 | 24 |
| Unit41 | Form41 | Table des Clients | 1100x551 | 10 |
| Unit42 | Form42 | Fiche Client | 834x240 | 21 |
| Unit43 | Form43 | Etat des Ventes Annuelles | 1100x600 | 20 |
| Unit44 | Form44 | Impression Etat des Ventes Annuelles | 1063x670 | 37 |
| Unit39 | Form39 | Form39 | 445x310 | 5 |
| Unit46 | Form46 | Form46 | 803x234 | 20 |
| uni_RegCommon |  |  |  |  |
| Unit47 | Form47 | A propos | 351x203 | 8 |

## Tables physiques

- `AutresTaxes` (13 champs) — Unit20.Tautres
- `AutresTaxesRef` (8 champs) — Unit20.TAutresTaxesRef
- `ClientrVentes` (9 champs) — Unit20.TClientrVentes, Unit40.TclientVentes
- `DecCAPharm` (13 champs) — Unit20.TPharma
- `DeclarationTAPP` (31 champs) — Unit20.TTAPP
- `DetailEtatTVA` (21 champs) — Unit20.TEtatTVA, Unit4.TEtatTVA
- `Encaissements` (15 champs) — Unit17.TEncaissements, Unit20.TEncaissements
- `Exercices` (2 champs) — Unit13.TExercices, Unit20.Texercices, uDataModule.TExercices, uMain.TExercices
- `FacturesVentes` (22 champs) — Unit20.TFacturesVentes
- `G50` (51 champs) — Unit20.TG50, Unit23.TG50P, uMain.TG50
- `IBSAcomptes` (13 champs) — Unit20.TacompteIBS
- `IBSsolde` (38 champs) — Unit20.Tibs, Unit45.Tsolde, Unit9.Tsolde
- `IRGAcomptes` (13 champs) — Unit20.TacompteIRG
- `IRGIBSRef` (8 champs) — Unit20.TIRGSalairesRef
- `IRGSalaires` (21 champs) — Unit20.TSalaires
- `IRGsolde` (17 champs) — Unit20.TIRG
- `Lotissement` (64 champs) — Unit36.TLotissement, uDataModule.TLotissement
- `Lots` (29 champs) — Unit36.TLot2, Unit36.Tlots, uDataModule.TLots, uImportLotis.Tlots
- `Mois` (4 champs) — Unit14.TMois, Unit20.Tmois, Unit36.Tmois
- `Naftal` (21 champs) — Unit5.Tnaftal
- `Naftal2` (16 champs) — Unit5.Tlurifiants
- `Naftal3` (14 champs) — Unit5.Tprestation
- `Nature` (3 champs) — Unit20.Tnature
- `PPu` (3 champs) — Unit20.TPPu, Unit5.Tpp
- `ProjEncaissement` (0 champs) — Unit20.Tproj
- `Station` (15 champs) — Unit14.TStation
- `TAP` (47 champs) — Unit20.TTap, uDataModule.TTAP
- `TAPRef` (16 champs) — Unit20.TtapRef
- `TLS` (47 champs) — Unit20.TTLS
- `TVA` (18 champs) — Unit20.TTva
- `TVARef` (7 champs) — Unit20.TTvaRef
- `TauxTVA` (3 champs) — Unit20.TtauxTva
- `Timbre` (14 champs) — Unit20.Ttimbre
- `TlsRef` (0 champs) — Unit20.TTlsRef
- `VersClients` (6 champs) — Unit36.TVersClients, uDataModule.TVersClients
- `bilanF` (0 champs) — uDataModule.Tsecteur
- `clients` (41 champs) — uDataModule.Tsoc, uDataModule.UniTable1, uDataModule.tclient
- `fournisseurTva` (8 champs) — Unit20.TfournisseurTva, Unit4.TfournisseurTva
- `naturededction` (2 champs) — Unit20.TNatDeduction
