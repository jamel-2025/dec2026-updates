from __future__ import annotations

from pathlib import Path
from typing import Any, Optional, Union

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

from ..fr3 import picture
from ..core import access, audit, users
from ..services import achats_export, batch, beneficiaires, bilan_fiscal, dossiers, etat104, excel_service, exports, g50, ibs, irg, lotissement, manquantes, obligations, pharma, promotion, ref, reports, salaries, sauvegarde, societes, station, tapp, tiers, ventes, ventes_recurrentes
from fastapi import UploadFile, File, Form
from fastapi.responses import Response

router = APIRouter(prefix="/api")


@router.get("/health")
def health():
    return {"status": "ok"}


# ------------------------------------------------------------------ licence
class LicenceActivateIn(BaseModel):
    client: str
    serial: str
    activation_key: str
    expiry: str = "LIFETIME"


@router.get("/licence/status")
def licence_status():
    from ..core import licence
    return licence.get_license_status()


@router.post("/licence/activate")
def licence_activate(body: LicenceActivateIn):
    from ..core import licence
    try:
        return licence.activate(body.client, body.serial, body.activation_key, body.expiry)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/licence/deactivate")
def licence_deactivate():
    from ..core import licence
    return licence.deactivate()



# ------------------------------------------------------------------ dossiers
@router.get("/dossiers")
def list_dossiers(user: Optional[str] = None):
    return dossiers.list_dossiers(filter_user=user)


@router.get("/dossiers/{code}")
def open_dossier(code: str, request: Request):
    s = dossiers.societe(code)
    audit.record(
        action="DOSSIER_OPEN",
        category="system",
        description=f"Ouverture du dossier {code} : « {s.get('rs', '')} »",
        request=request,
        dossier=code,
        status="success",
        details={"code": code, "rs": s.get("rs", "")},
    )
    return {"code": code, "societe": s, "menu": dossiers.menu_visibility(s), "exercices": dossiers.exercices(code)}


# ------------------------------------------------------------------ pharmacie (uMain page 5 + Form12)
class PharmaIn(BaseModel):
    DAtedEC: Optional[str] = None
    CA1: Optional[Union[float, int, str]] = None
    CA2: Optional[Union[float, int, str]] = None
    CA3: Optional[Union[float, int, str]] = None
    CA4: Optional[Union[float, int, str]] = None
    CA5: Optional[Union[float, int, str]] = None


@router.get("/dossiers/{code}/pharma/{exercice}")
def get_pharma(code: str, exercice: str):
    return {"record": pharma.get(code, exercice)}


@router.put("/dossiers/{code}/pharma/{exercice}")
def put_pharma(code: str, exercice: str, body: PharmaIn):
    try:
        dump = body.model_dump() if hasattr(body, "model_dump") else body.dict()
        return {"record": pharma.save(code, exercice, dump)}
    except ValueError as e:
        raise HTTPException(422, str(e)) from e


@router.delete("/dossiers/{code}/pharma/{exercice}")
def delete_pharma(code: str, exercice: str):
    if not pharma.delete(code, exercice):
        raise HTTPException(404, "Aucune déclaration à supprimer")
    return {"message": "Déclaration supprimée"}


# ------------------------------------------------------------------ reports
@router.get("/reports")
def list_reports():
    return [{"key": r.key, "file": r.file, "title": r.title} for r in reports.REPORTS.values()]


@router.get("/reports/img/{name}")
def report_image(name: str):
    p = picture.cache_path(name)
    if p is None:
        raise HTTPException(404)
    return FileResponse(p, media_type="image/png", headers={"Cache-Control": "public, max-age=31536000, immutable"})


@router.get("/reports/{key}/status")
def report_status(key: str, dossier: str, request: Request):
    return reports.status(key, dossier, dict(request.query_params))


@router.get("/reports/{key}", response_class=HTMLResponse)
def report(key: str, dossier: str, request: Request):
    return HTMLResponse(reports.render_html(key, dossier, dict(request.query_params)))


@router.post("/reports/{key}/export")
def report_export(key: str, dossier: str, fmt: str, request: Request):
    """« Exp PDF » / « Exp Excel »: file saved in <dossier>/Rapports/<année>/<catégorie>/."""
    params = {k: v for k, v in request.query_params.items() if k not in ("fmt",)}
    res = _g50_call(exports.export, key, dossier, params, fmt)
    audit.record(
        action=f"EXPORT_RAPPORT_{fmt.upper()}",
        category="system",
        description=f"Export rapport {key} ({fmt.upper()}) dossier {dossier}",
        request=request,
        dossier=dossier,
        status="success",
        details={"key": key, "fmt": fmt},
    )
    return res


@router.post("/listes/export")
def list_export(body: dict, request: Request):
    """Any table of the application → Excel (Delphi: Export_Naftal_…, Export_Lubrifiants_…, grid exports)."""
    res = _g50_call(exports.export_list, body.get("dossier") or None, str(body.get("annee") or ""), str(body.get("title") or "Liste"),
                     list(body.get("columns") or []), list(body.get("rows") or []), body.get("totals"))
    title = body.get("title", "Liste")
    audit.record(
        action="EXPORT_EXCEL_LIST",
        category="system",
        description=f"Export tableau Excel : « {title} »",
        request=request,
        dossier=body.get("dossier") or None,
        status="success",
        details={"title": title, "annee": body.get("annee")},
    )
    return res


@router.get("/listes/fichier")
def list_file(name: str):
    from fastapi.responses import FileResponse
    p = exports.list_file(name)
    return FileResponse(p, filename=p.name)


@router.get("/dossiers/{code}/rapports/fichier")
def report_file(code: str, rel: str):
    from fastapi.responses import FileResponse
    p = exports.file(code, rel)
    return FileResponse(p, filename=p.name)


@router.post("/dossiers/{code}/achats/export")
def achats_export_endpoint(
    code: str,
    request: Request,
    exercice: Optional[str] = None,
    idg50: Optional[int] = None,
    trimestre: Optional[int] = None,
    mois: Optional[str] = None,
):
    """Exporte la liste des factures d'achat selon le modèle standardisé achats.xlsx (26 colonnes)."""
    rows = achats_export.fetch_achats_data(code, exercice=exercice, idg50=idg50, trimestre=trimestre, mois=mois)
    if not rows:
        raise HTTPException(400, "Aucune facture d'achat trouvée pour cette période.")

    an = str(exercice or "")
    if not an and rows:
        an = str(rows[0].get("Année") or "")

    folder = exports.rapports_dir(code) / (an or "Divers") / "Etat TVA"
    folder.mkdir(parents=True, exist_ok=True)

    # Nom du fichier selon la période
    if idg50:
        ma = rows[0].get("g_periode") or f"G50_{idg50}"
        filename = f"Achats_{ma}.xlsx"
    elif trimestre:
        filename = f"Achats_T{trimestre}_{an}.xlsx"
    elif mois:
        filename = f"Achats_{mois}_{an}.xlsx"
    else:
        filename = f"Achats_Annee_{an}.xlsx"

    out_path = folder / filename
    achats_export.generate_achats_excel(code, rows, out_path)
    rel = out_path.relative_to(exports.rapports_dir(code)).as_posix()

    audit.record(
        action="EXPORT_ACHATS_EXCEL",
        category="system",
        description=f"Export factures d'achat modèle achats.xlsx ({filename})",
        request=request,
        dossier=code,
        status="success",
        details={"name": filename, "rows": len(rows)},
    )
    return {
        "name": out_path.name,
        "path": str(out_path),
        "folder": str(folder),
        "rel": rel,
        "size": out_path.stat().st_size,
        "count": len(rows),
    }


# ------------------------------------------------------------------ référentiel (Ref.mdb)
REF_TABLES = {"TVAref", "TAPRef", "TlsRef", "IRGIBSRef", "AutresTaxesRef", "TauxTVA", "naturededction", "Mois"}


@router.get("/ref/{table}")
def ref_table(table: str):
    if table not in REF_TABLES:
        raise HTTPException(404, "Table de référence inconnue")
    return ref.table(table)


# ------------------------------------------------------------------ G50 mensuel
def _g50_call(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except g50.Conflict as e:
        raise HTTPException(409, str(e)) from e
    except g50.G50Error as e:
        raise HTTPException(422, str(e)) from e
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"Erreur opération : {e}") from e


class G50New(BaseModel):
    annee: str
    mois: int


class G50Header(BaseModel):
    precompte_anterieur: Optional[Union[float, str]] = None
    deduction_complementaire: Optional[Union[float, str]] = None
    factures_annulees: Optional[Union[float, str]] = None
    regul_prorata: Optional[Union[float, str]] = None
    reversement: Optional[Union[float, str]] = None
    tap_option: Optional[bool] = None
    date_depot: Optional[str] = None


@router.get("/dossiers/{code}/g50")
def g50_list(code: str, annee: str):
    return g50.list_g50(code, annee)


@router.post("/dossiers/{code}/g50", status_code=201)
def g50_create(code: str, body: G50New, request: Request):
    users.require_permission(request, "g50_edit")
    res = _g50_call(g50.create, code, body.annee, body.mois)
    audit.record(
        action="G50_CREATE",
        category="declarations",
        description=f"Création déclaration G50 {body.mois}/{body.annee}",
        request=request,
        dossier=code,
        status="success",
        details={"annee": body.annee, "mois": body.mois, "idg50": res.get("idg50")},
    )
    return res


@router.get("/dossiers/{code}/g50/{idg50}")
def g50_detail(code: str, idg50: int):
    return g50.detail(code, idg50)


@router.patch("/dossiers/{code}/g50/{idg50}")
def g50_update(code: str, idg50: int, body: G50Header, request: Request):
    users.require_permission(request, "g50_edit")
    data = body.model_dump(exclude_unset=True) if hasattr(body, "model_dump") else body.dict(exclude_unset=True)
    res = _g50_call(g50.update, code, idg50, data)
    audit.record(
        action="G50_UPDATE",
        category="declarations",
        description=f"Modification déclaration G50 (#{idg50})",
        request=request,
        dossier=code,
        status="success",
        details={"idg50": idg50, "updated_fields": list(data.keys())},
    )
    return res


@router.delete("/dossiers/{code}/g50/{idg50}")
def g50_delete(code: str, idg50: int, request: Request):
    users.require_permission(request, "g50_edit")
    g50.delete(code, idg50)
    audit.record(
        action="G50_DELETE",
        category="declarations",
        description=f"Suppression de la déclaration G50 (#{idg50})",
        request=request,
        dossier=code,
        status="warning",
        details={"idg50": idg50},
    )
    return {"message": "Déclaration supprimée"}


@router.post("/dossiers/{code}/g50/{idg50}/lines/{kind}", status_code=201)
def g50_line_add(code: str, idg50: int, kind: str, body: dict, request: Request):
    users.require_permission(request, "g50_edit")
    res = _g50_call(g50.save_line, code, idg50, kind, body)
    audit.record(
        action=f"G50_LINE_ADD_{kind.upper()}",
        category="declarations",
        description=f"Ajout d'une ligne dans G50 (#{idg50}) : {kind}",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.put("/dossiers/{code}/g50/{idg50}/lines/{kind}/{line_id}")
def g50_line_update(code: str, idg50: int, kind: str, line_id: int, body: dict, request: Request):
    users.require_permission(request, "g50_edit")
    res = _g50_call(g50.save_line, code, idg50, kind, body, line_id)
    audit.record(
        action=f"G50_LINE_MOD_{kind.upper()}",
        category="declarations",
        description=f"Modification ligne G50 (#{idg50}) : {kind} (ID #{line_id})",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.delete("/dossiers/{code}/g50/{idg50}/lines/{kind}/{line_id}")
def g50_line_delete(code: str, idg50: int, kind: str, line_id: int, request: Request):
    users.require_permission(request, "g50_edit")
    res = _g50_call(g50.delete_line, code, idg50, kind, line_id)
    audit.record(
        action=f"G50_LINE_DEL_{kind.upper()}",
        category="declarations",
        description=f"Suppression ligne G50 (#{idg50}) : {kind} (ID #{line_id})",
        request=request,
        dossier=code,
        status="warning",
    )
    return res


@router.get("/dossiers/{code}/fournisseurs")
def fournisseurs(code: str, q: str = ""):
    return g50.fournisseurs(code, q)


@router.post("/dossiers/{code}/fournisseurs", status_code=201)
def fournisseur_create(code: str, body: dict, request: Request):
    res = _g50_call(g50.create_fournisseur, code, body)
    rs = body.get("rs", "")
    audit.record(
        action="FOURNISSEUR_ADD",
        category="tiers",
        description=f"Ajout fournisseur TVA : « {rs} »",
        request=request,
        dossier=code,
        status="success",
        details={"rs": rs, "id": res.get("id")},
    )
    return res


# ------------------------------------------------------------------ IBS (uMain page 2, Unit7, Unit45)
@router.get("/dossiers/{code}/ibs/{exercice}")
def ibs_state(code: str, exercice: str):
    return ibs.state(code, exercice)


@router.post("/dossiers/{code}/ibs/{exercice}/acomptes", status_code=201)
def ibs_acompte_add(code: str, exercice: str, body: dict):
    return _g50_call(ibs.save_acompte, code, exercice, body)


@router.put("/dossiers/{code}/ibs/{exercice}/acomptes/{acompte_id}")
def ibs_acompte_update(code: str, exercice: str, acompte_id: int, body: dict):
    return _g50_call(ibs.save_acompte, code, exercice, body, acompte_id)


@router.delete("/dossiers/{code}/ibs/{exercice}/acomptes/{acompte_id}")
def ibs_acompte_delete(code: str, exercice: str, acompte_id: int):
    return ibs.delete_acompte(code, exercice, acompte_id)


@router.put("/dossiers/{code}/ibs/{exercice}/solde")
def ibs_solde_save(code: str, exercice: str, body: dict):
    return _g50_call(ibs.save_solde, code, exercice, body)


@router.post("/dossiers/{code}/ibs/{exercice}/solde/refresh")
def ibs_solde_refresh(code: str, exercice: str):
    return ibs.refresh_solde(code, exercice)


@router.delete("/dossiers/{code}/ibs/{exercice}/solde")
def ibs_solde_delete(code: str, exercice: str):
    return ibs.delete_solde(code, exercice)


# ------------------------------------------------------------------ IRG (uMain page 7, Unit8, Unit9)
@router.get("/dossiers/{code}/irg/{exercice}")
def irg_state(code: str, exercice: str):
    return irg.state(code, exercice)


@router.post("/dossiers/{code}/irg/{exercice}/acomptes", status_code=201)
def irg_acompte_add(code: str, exercice: str, body: dict):
    return _g50_call(irg.save_acompte, code, exercice, body)


@router.put("/dossiers/{code}/irg/{exercice}/acomptes/{acompte_id}")
def irg_acompte_update(code: str, exercice: str, acompte_id: int, body: dict):
    return _g50_call(irg.save_acompte, code, exercice, body, acompte_id)


@router.delete("/dossiers/{code}/irg/{exercice}/acomptes/{acompte_id}")
def irg_acompte_delete(code: str, exercice: str, acompte_id: int):
    return irg.delete_acompte(code, exercice, acompte_id)


@router.put("/dossiers/{code}/irg/{exercice}/solde")
def irg_solde_save(code: str, exercice: str, body: dict):
    return _g50_call(irg.save_solde, code, exercice, body)


@router.post("/dossiers/{code}/irg/{exercice}/solde/refresh")
def irg_solde_refresh(code: str, exercice: str):
    return irg.refresh_solde(code, exercice)


@router.delete("/dossiers/{code}/irg/{exercice}/solde")
def irg_solde_delete(code: str, exercice: str):
    return irg.delete_solde(code, exercice)


# ------------------------------------------------------------------ TAPP-TFP (uMain page 3, Unit11)
@router.get("/dossiers/{code}/tapp/{exercice}")
def tapp_state(code: str, exercice: str):
    return tapp.state(code, exercice)


@router.post("/dossiers/{code}/tapp/{exercice}", status_code=201)
def tapp_add(code: str, exercice: str, body: dict):
    return _g50_call(tapp.save, code, exercice, body)


@router.put("/dossiers/{code}/tapp/{exercice}/{decl_id}")
def tapp_update(code: str, exercice: str, decl_id: int, body: dict):
    return _g50_call(tapp.save, code, exercice, body, decl_id)


@router.delete("/dossiers/{code}/tapp/{exercice}/{decl_id}")
def tapp_delete(code: str, exercice: str, decl_id: int):
    return tapp.delete(code, exercice, decl_id)


# ------------------------------------------------------------------ tiers (Unit30/31, Unit41/42)
@router.get("/dossiers/{code}/tiers/{kind}")
def tiers_list(code: str, kind: str, q: str = ""):
    return tiers.list_(code, kind, q)


@router.post("/dossiers/{code}/tiers/{kind}", status_code=201)
def tiers_add(code: str, kind: str, body: dict, request: Request):
    res = _g50_call(tiers.save, code, kind, body)
    rs = body.get("rs", "")
    audit.record(
        action=f"TIER_ADD_{kind.upper()}",
        category="tiers",
        description=f"Ajout d'une fiche {kind} : « {rs} »",
        request=request,
        dossier=code,
        status="success",
        details={"rs": rs, "id": res.get("_id")},
    )
    return res


@router.put("/dossiers/{code}/tiers/{kind}/{item_id}")
def tiers_update(code: str, kind: str, item_id: int, body: dict, request: Request):
    res = _g50_call(tiers.save, code, kind, body, item_id)
    rs = body.get("rs", "")
    audit.record(
        action=f"TIER_MOD_{kind.upper()}",
        category="tiers",
        description=f"Modification fiche {kind} : « {rs} » (ID #{item_id})",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.delete("/dossiers/{code}/tiers/{kind}/{item_id}")
def tiers_delete(code: str, kind: str, item_id: int, request: Request):
    if str(kind).lower() == "client":
        users.require_permission(request, "ventes_delete")
    else:
        users.require_permission(request, "achats_delete")
    _g50_call(tiers.delete, code, kind, item_id)
    audit.record(
        action=f"TIER_DEL_{kind.upper()}",
        category="tiers",
        description=f"Suppression fiche {kind} (ID #{item_id})",
        request=request,
        dossier=code,
        status="warning",
    )
    return {"message": "Supprimé"}


# ------------------------------------------------------------------ factures de vente (Unit40/43/44)
@router.get("/dossiers/{code}/ventes/{annee}")
def ventes_list(code: str, annee: str, mois: str = "", q: str = ""):
    return ventes.list_(code, annee, mois, q)


@router.post("/dossiers/{code}/ventes", status_code=201)
def ventes_add(code: str, body: dict, request: Request):
    users.require_permission(request, "ventes_edit")
    res = _g50_call(ventes.save, code, body)
    nfact = body.get("nfacture", "")
    client = body.get("ClientsVente", "")
    ht = body.get("ht", 0)
    audit.record(
        action="VENTE_ADD",
        category="ventes",
        description=f"Ajout facture de vente N° {nfact} ({client}) — HT: {ht:,.2f} DA",
        request=request,
        dossier=code,
        status="success",
        details={"nfacture": nfact, "client": client, "ht": ht},
    )
    return res


@router.put("/dossiers/{code}/ventes/{item_id}")
def ventes_update(code: str, item_id: int, body: dict, request: Request):
    users.require_permission(request, "ventes_edit")
    res = _g50_call(ventes.save, code, body, item_id)
    nfact = body.get("nfacture", "")
    audit.record(
        action="VENTE_MOD",
        category="ventes",
        description=f"Modification facture de vente N° {nfact} (ID #{item_id})",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.delete("/dossiers/{code}/ventes/{item_id}")
def ventes_delete(code: str, item_id: int, request: Request):
    users.require_permission(request, "ventes_delete")
    ventes.delete(code, item_id)
    audit.record(
        action="VENTE_DEL",
        category="ventes",
        description=f"Suppression facture de vente (ID #{item_id})",
        request=request,
        dossier=code,
        status="warning",
    )
    return {"message": "Facture supprimée"}


# ------------------------------------------------------------------ État 104 des clients (G N° 3 & G N° 3 Bis)
@router.get("/dossiers/{code}/etat104/{annee}")
def etat104_get(code: str, annee: str):
    return etat104.get_etat104_data(code, annee)


@router.get("/dossiers/{code}/etat104/{annee}/html", response_class=HTMLResponse)
def etat104_html(code: str, annee: str):
    return etat104.generate_etat104_html(code, annee)


@router.get("/dossiers/{code}/etat104/{annee}/export-excel")
def etat104_excel(code: str, annee: str):
    content = etat104.export_etat104_excel(code, annee)
    headers = {
        "Content-Disposition": f'attachment; filename="G3_Etat104_Clients_{annee}_{code}.xlsx"',
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }
    return Response(content=content, headers=headers)


# ------------------------------------------------------------------ Bilan Fiscal SCF & Audit
@router.get("/dossiers/{code}/bilan/{annee}")
def bilan_get(code: str, annee: str):
    from ..core import config
    dossier_dir = config.SOCIETES_DIR / code
    bilan_file = dossier_dir / f"BilanFiscal_{annee}.xls"
    has_custom = bilan_file.is_file()
    if has_custom:
        parsed = bilan_fiscal.parse_bilan_xls(str(bilan_file))
    else:
        soc_meta = dossiers.societe(code)
        parsed = bilan_fiscal.build_year_specific_bilan(code, annee, soc_meta)

    sig = bilan_fiscal.compute_sig_and_ratios(parsed) if parsed else {}
    audit_res = bilan_fiscal.run_fiscal_audit(code, annee, parsed) if parsed else {}
    return {
        "parsed": parsed,
        "sig": sig,
        "audit": audit_res,
        "has_custom_file": has_custom,
    }


@router.get("/dossiers/{code}/bilan/{annee}/exists")
def bilan_check_exists(code: str, annee: str):
    from ..core import config
    dossier_dir = config.SOCIETES_DIR / code
    bilan_file = dossier_dir / f"BilanFiscal_{annee}.xls"
    exists = bilan_file.is_file()
    return {
        "exists": exists,
        "annee": annee,
        "filename": bilan_file.name if exists else None,
        "size": bilan_file.stat().st_size if exists else 0,
    }


@router.post("/dossiers/{code}/bilan/{annee}/upload")
async def bilan_upload(code: str, annee: str, file: UploadFile = File(...)):
    from ..core import config
    content = await file.read()
    dossier_dir = config.SOCIETES_DIR / code
    dossier_dir.mkdir(parents=True, exist_ok=True)
    target = dossier_dir / f"BilanFiscal_{annee}.xls"
    target.write_bytes(content)

    # Sync into Dossier Numerique documents table so it appears cleanly in both places without duplicate IDs
    try:
        from ..services import fiscal_advisory_service
        fiscal_advisory_service.create_dossier_document(
            dossier=code,
            data={
                "categorie": "comptable",
                "type_document": "bilan",
                "exercice": annee,
                "titre": f"الميزانية والحزمة الجبائية السنوية {annee}",
                "reference": f"Exercice {annee}",
                "source_capture": "upload",
                "notes": "Synchronisé automatiquement depuis Bilan Fiscal & Audit Cockpit",
                "overwrite": True,
            },
            file_bytes=content,
            original_filename=file.filename or f"BilanFiscal_{annee}.xls",
            mime_type="application/vnd.ms-excel",
            overwrite=True,
        )
    except Exception as e:
        print(f"Notice: bilan document sync: {e}")

    parsed = bilan_fiscal.parse_bilan_xls(content)
    sig = bilan_fiscal.compute_sig_and_ratios(parsed)
    audit_res = bilan_fiscal.run_fiscal_audit(code, annee, parsed)
    return {
        "success": True,
        "filename": file.filename,
        "parsed": parsed,
        "sig": sig,
        "audit": audit_res,
    }


@router.get("/dossiers/{code}/bilan/{annee}/audit-html", response_class=HTMLResponse)
def bilan_audit_html(code: str, annee: str):
    from ..core import config
    dossier_dir = config.SOCIETES_DIR / code
    bilan_file = dossier_dir / f"BilanFiscal_{annee}.xls"
    if bilan_file.is_file():
        parsed = bilan_fiscal.parse_bilan_xls(str(bilan_file))
    else:
        soc_meta = dossiers.societe(code)
        parsed = bilan_fiscal.build_year_specific_bilan(code, annee, soc_meta)

    audit_res = bilan_fiscal.run_fiscal_audit(code, annee, parsed) if parsed else {}
    return bilan_fiscal.generate_audit_report_html(code, annee, audit_res)


@router.get("/dossiers/{code}/bilan/{annee}/export-excel")
def bilan_export_excel(code: str, annee: str):
    from ..core import config
    dossier_dir = config.SOCIETES_DIR / code
    bilan_file = dossier_dir / f"BilanFiscal_{annee}.xls"
    if bilan_file.is_file():
        content = bilan_file.read_bytes()
        filename = f"BilanFiscal_SCF_{annee}_{code}.xls"
        content_type = "application/vnd.ms-excel"
    else:
        soc_meta = dossiers.societe(code)
        parsed = bilan_fiscal.build_year_specific_bilan(code, annee, soc_meta)
        content = bilan_fiscal.export_year_bilan_excel_bytes(code, annee, parsed)
        filename = f"BilanFiscal_SCF_{annee}_{code}.xlsx"
        content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    headers = {
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Content-Type": content_type,
        "Access-Control-Expose-Headers": "Content-Disposition",
    }
    return Response(content=content, headers=headers)



# ------------------------------------------------------------------ Factures récurrentes (Modèles)
@router.get("/dossiers/{code}/ventes-recurrentes/modeles")
def modeles_list(code: str):
    return {"items": ventes_recurrentes.list_modeles(code)}


@router.post("/dossiers/{code}/ventes-recurrentes/modeles")
def modeles_save(code: str, body: dict):
    return ventes_recurrentes.save_modele(code, body)


@router.put("/dossiers/{code}/ventes-recurrentes/modeles/{item_id}")
def modeles_update(code: str, item_id: int, body: dict):
    return ventes_recurrentes.save_modele(code, body, item_id)


@router.delete("/dossiers/{code}/ventes-recurrentes/modeles/{item_id}")
def modeles_del(code: str, item_id: int):
    ventes_recurrentes.delete_modele(code, item_id)
    return {"message": "Modèle supprimé"}


@router.post("/dossiers/{code}/ventes-recurrentes/generer")
def modeles_generate(code: str, body: dict):
    return ventes_recurrentes.generer_factures(code, body)


# ------------------------------------------------------------------ Excel & Tableurs (Inspection & Import Ventes)
@router.post("/dossiers/{code}/excel/inspect")
async def excel_inspect(code: str, file: UploadFile = File(...)):
    content = await file.read()
    return excel_service.inspect_excel_file(content, file.filename or "tableur.xlsx")


@router.post("/dossiers/{code}/excel/import-ventes")
async def excel_import_ventes(
    code: str,
    file: UploadFile = File(...),
    sheet_name: str = Form(""),
    col_date: int = Form(0),
    col_num: int = Form(1),
    col_client: int = Form(2),
    col_ht: int = Form(3),
    col_tva: int = Form(-1),
    taux_defaut: int = Form(19),
    has_header: bool = Form(True),
):
    content = await file.read()
    mapping = {
        "sheet_name": sheet_name,
        "col_date": col_date,
        "col_num": col_num,
        "col_client": col_client,
        "col_ht": col_ht,
        "col_tva": col_tva,
        "taux_defaut": taux_defaut,
        "has_header": has_header,
    }
    return excel_service.import_excel_to_ventes(code, content, file.filename or "import.xlsx", mapping)



# ------------------------------------------------------------------ station-service (Unit14/5/21/39)
@router.get("/dossiers/{code}/station/annee/{annee}")
def station_year(code: str, annee: str):
    return station.year(code, annee)


@router.put("/dossiers/{code}/station/prix")
def station_prices(code: str, body: dict):
    return station.set_prices(code, body)


@router.post("/dossiers/{code}/station", status_code=201)
def station_create(code: str, body: G50New):
    return _g50_call(station.create, code, body.annee, body.mois)


@router.get("/dossiers/{code}/station/{sid}")
def station_detail(code: str, sid: int):
    return station.detail(code, sid)


@router.delete("/dossiers/{code}/station/{sid}")
def station_delete(code: str, sid: int):
    station.delete(code, sid)
    return {"message": "Déclaration supprimée"}


@router.post("/dossiers/{code}/station/{sid}/lines/{kind}", status_code=201)
def station_line_add(code: str, sid: int, kind: str, body: dict):
    return _g50_call(station.save_line, code, sid, kind, body)


@router.put("/dossiers/{code}/station/{sid}/lines/{kind}/{line_id}")
def station_line_update(code: str, sid: int, kind: str, line_id: int, body: dict):
    return _g50_call(station.save_line, code, sid, kind, body, line_id)


@router.delete("/dossiers/{code}/station/{sid}/lines/{kind}/{line_id}")
def station_line_delete(code: str, sid: int, kind: str, line_id: int):
    return station.delete_line(code, sid, kind, line_id)


# ------------------------------------------------------------------ promotion immobilière (Unit17/18/19)
@router.get("/dossiers/{code}/promotion/projets")
def promo_projets(code: str):
    return promotion.projets(code)


@router.post("/dossiers/{code}/promotion/projets", status_code=201)
def promo_projet_add(code: str, body: dict):
    return _g50_call(promotion.save_projet, code, body.get("projet"))


@router.put("/dossiers/{code}/promotion/projets/{pid}")
def promo_projet_update(code: str, pid: int, body: dict):
    return _g50_call(promotion.save_projet, code, body.get("projet"), pid)


@router.delete("/dossiers/{code}/promotion/projets/{pid}")
def promo_projet_delete(code: str, pid: int):
    _g50_call(promotion.delete_projet, code, pid)
    return {"message": "Projet supprimé"}


# Blocs & Bâtiments
@router.get("/dossiers/{code}/promotion/projets/{pid}/blocs")
def promo_blocs_list(code: str, pid: int):
    return promotion.blocs(code, pid)


@router.post("/dossiers/{code}/promotion/projets/{pid}/blocs", status_code=201)
def promo_bloc_add(code: str, pid: int, body: dict):
    return _g50_call(promotion.save_bloc, code, pid, body)


@router.put("/dossiers/{code}/promotion/projets/{pid}/blocs/{bid}")
def promo_bloc_update(code: str, pid: int, bid: int, body: dict):
    return _g50_call(promotion.save_bloc, code, pid, body, bid)


@router.delete("/dossiers/{code}/promotion/projets/{pid}/blocs/{bid}")
def promo_bloc_delete(code: str, pid: int, bid: int):
    promotion.delete_bloc(code, bid)
    return {"message": "Bloc supprimé"}


@router.post("/dossiers/{code}/promotion/projets/{pid}/generate-bloc", status_code=201)
def promo_generate_bloc(code: str, pid: int, body: dict):
    return _g50_call(promotion.generate_bloc, code, pid, body)


# Unités (Logements, Locaux, Garages) & Élévation 2D
@router.get("/dossiers/{code}/promotion/projets/{pid}/unites")
def promo_unites_list(code: str, pid: int, bid: Optional[int] = None, type_unite: str = "", statut: str = "", q: str = ""):
    return promotion.unites(code, pid, bid=bid, type_unite=type_unite, statut=statut, q=q)


@router.get("/dossiers/{code}/promotion/unites/{uid}")
def promo_unite_get(code: str, uid: int):
    return promotion.unite_detail(code, uid)


@router.post("/dossiers/{code}/promotion/projets/{pid}/unites", status_code=201)
def promo_unite_add(code: str, pid: int, body: dict):
    return _g50_call(promotion.save_unite, code, pid, body)


@router.put("/dossiers/{code}/promotion/unites/{uid}")
def promo_unite_update(code: str, uid: int, body: dict):
    pid = int(body.get("IdProjet") or 0)
    return _g50_call(promotion.save_unite, code, pid, body, uid)


@router.delete("/dossiers/{code}/promotion/unites/{uid}")
def promo_unite_delete(code: str, uid: int):
    promotion.delete_unite(code, uid)
    return {"message": "Unité supprimée"}


@router.post("/dossiers/{code}/promotion/unites/{uid}/versements", status_code=201)
def promo_unite_versement_add(code: str, uid: int, body: dict):
    return _g50_call(promotion.save_unite_versement, code, uid, body)


@router.get("/dossiers/{code}/promotion/projets/{pid}/situation")
def promo_situation(code: str, pid: int):
    return promotion.situation(code, pid)


# Versements globaux par année fiscale (paramètre entier strict pour éviter toute collision)
@router.get("/dossiers/{code}/promotion/{annee:int}")
def promo_list(code: str, annee: int, projet: str = "", mois: str = "", mode: str = "", q: str = ""):
    return promotion.list_(code, str(annee), projet, mois=mois, mode=mode, q=q)


@router.post("/dossiers/{code}/promotion/{annee:int}", status_code=201)
def promo_add(code: str, annee: int, body: dict):
    return _g50_call(promotion.save, code, str(annee), body)


@router.put("/dossiers/{code}/promotion/{annee:int}/{item_id:int}")
def promo_update(code: str, annee: int, item_id: int, body: dict):
    return _g50_call(promotion.save, code, str(annee), body, item_id)


@router.delete("/dossiers/{code}/promotion/{annee:int}/{item_id:int}")
def promo_delete(code: str, annee: int, item_id: int):
    promotion.delete(code, item_id)
    return {"message": "Versement supprimé"}




# ------------------------------------------------------------------ lotissement (uForm3…17_Lotis, Unit36)
@router.get("/dossiers/{code}/lotissements")
def lotis_list(code: str, q: str = ""):
    return {"items": lotissement.studies(code, q), "defaults": lotissement.defaults(code)}


@router.post("/dossiers/{code}/lotissements", status_code=201)
def lotis_add(code: str, body: dict):
    return _g50_call(lotissement.save_study, code, body)


@router.put("/dossiers/{code}/lotissements/{lid}")
def lotis_update(code: str, lid: int, body: dict):
    return _g50_call(lotissement.save_study, code, body, lid)


@router.post("/dossiers/{code}/lotissements/calcul")
def lotis_preview(code: str, body: dict):
    """Live preview of the study calculation (Bcalc) without saving."""
    return _g50_call(lotissement._calc_study, {**lotissement.defaults(code), **body})


@router.delete("/dossiers/{code}/lotissements/{lid}")
def lotis_delete(code: str, lid: int):
    lotissement.delete_study(code, lid)
    return {"message": "Lotissement supprimé"}


@router.get("/dossiers/{code}/lotissements/{lid}/lots")
def lotis_lots(code: str, lid: int, q: str = ""):
    return lotissement.lots(code, lid, q)


@router.get("/dossiers/{code}/lotissements/{lid}/situation")
def lotis_situation(code: str, lid: int, annee: str = "", mois: str = "", mode: str = "", q: str = ""):
    return {
        "versements": lotissement.versements(code, lid, annee=annee, mois=mois, mode=mode, q=q),
        "creances": lotissement.creances(code, lid),
        "tcr": lotissement.tcr(code, lid),
        "encaissements": lotissement.encaissements_mensuels(code, lid, annee=annee, mode=mode, q=q),
        "facturation": lotissement.ca_facture(code, lid, annee=annee, mois=mois, q=q),
    }


@router.post("/dossiers/{code}/lotissements/{lid}/lots", status_code=201)
def lotis_lot_add(code: str, lid: int, body: dict):
    return _g50_call(lotissement.save_lot, code, lid, body)


@router.put("/dossiers/{code}/lotissements/{lid}/lots/{lot_id}")
def lotis_lot_update(code: str, lid: int, lot_id: int, body: dict):
    return _g50_call(lotissement.save_lot, code, lid, body, lot_id)


@router.get("/dossiers/{code}/lots/{lot_id}")
def lotis_lot(code: str, lot_id: int):
    return lotissement.lot_detail(code, lot_id)


@router.delete("/dossiers/{code}/lots/{lot_id}")
def lotis_lot_delete(code: str, lot_id: int):
    lotissement.delete_lot(code, lot_id)
    return {"message": "Lot supprimé"}


@router.post("/dossiers/{code}/lots/{lot_id}/versements", status_code=201)
def lotis_vers_add(code: str, lot_id: int, body: dict):
    return _g50_call(lotissement.save_versement, code, lot_id, body)


@router.put("/dossiers/{code}/lots/{lot_id}/versements/{vid}")
def lotis_vers_update(code: str, lot_id: int, vid: int, body: dict):
    return _g50_call(lotissement.save_versement, code, lot_id, body, vid)


@router.delete("/dossiers/{code}/lots/{lot_id}/versements/{vid}")
def lotis_vers_delete(code: str, lot_id: int, vid: int):
    return lotissement.delete_versement(code, lot_id, vid)


@router.post("/dossiers/{code}/lotissements/{lid}/import/lecture")
def lotis_import_read(code: str, lid: int, body: dict):
    return {"rows": _g50_call(lotissement.read_import, str(body.get("filename") or ""), str(body.get("content") or ""))}


@router.post("/dossiers/{code}/lotissements/{lid}/import")
def lotis_import(code: str, lid: int, body: dict):
    return _g50_call(lotissement.import_lots, code, lid, list(body.get("rows") or []))


@router.post("/dossiers/{code}/lotissements/{lid}/lots/batch")
def lotis_batch_create(code: str, lid: int, body: dict):
    count = int(body.get("count") or 10)
    default_sup = float(body.get("default_sup") or 150.0)
    default_pvu = float(body.get("default_pvu") or 0.0)
    return _g50_call(lotissement.generate_batch_lots, code, lid, count, default_sup, default_pvu)


@router.get("/dossiers/{code}/lotissements/{lid}/encaissements")
def lotis_encaissements(code: str, lid: int):
    return lotissement.encaissements_mensuels(code, lid)



# ------------------------------------------------------------------ salariés & contrats (uEmployes, uContrats)
@router.get("/dossiers/{code}/salaries")
def sal_list(code: str, q: str = ""):
    return {"items": salaries.employees(code, q), "defaults": salaries.employee_defaults(),
            "types": [{"id": k, "label": f"{k} - {v[0]}"} for k, v in salaries.TYPES.items()]}


@router.post("/dossiers/{code}/salaries", status_code=201)
def sal_add(code: str, body: dict, request: Request):
    users.require_permission(request, "salaries_edit")
    res = _g50_call(salaries.save_employee, code, body)
    nom = f"{body.get('Nom', '')} {body.get('Prenom', '')}".strip()
    audit.record(
        action="SALARIE_ADD",
        category="tiers",
        description=f"Ajout d'un salarié : « {nom} »",
        request=request,
        dossier=code,
        status="success",
        details={"nom": nom, "id": res.get("_id")},
    )
    return res


@router.put("/dossiers/{code}/salaries/{eid}")
def sal_update(code: str, eid: int, body: dict, request: Request):
    users.require_permission(request, "salaries_edit")
    res = _g50_call(salaries.save_employee, code, body, eid)
    nom = f"{body.get('Nom', '')} {body.get('Prenom', '')}".strip()
    audit.record(
        action="SALARIE_MOD",
        category="tiers",
        description=f"Modification salarié : « {nom} » (ID #{eid})",
        request=request,
        dossier=code,
        status="success",
        details={"nom": nom, "eid": eid},
    )
    return res


@router.delete("/dossiers/{code}/salaries/{eid}")
def sal_delete(code: str, eid: int, request: Request):
    users.require_permission(request, "salaries_delete")
    salaries.delete_employee(code, eid)
    audit.record(
        action="SALARIE_DEL",
        category="tiers",
        description=f"Suppression salarié (ID #{eid})",
        request=request,
        dossier=code,
        status="warning",
        details={"eid": eid},
    )
    return {"message": "Salarié supprimé"}


@router.get("/dossiers/{code}/contrats")
def ctr_list(code: str, salarie: Optional[int] = None):
    return {"items": salaries.contracts(code, salarie)}


@router.get("/dossiers/{code}/salaries/{eid}/contrats/nouveau")
def ctr_defaults(code: str, eid: int, type: int = 2):
    return _g50_call(salaries.contract_defaults, code, eid, type)


@router.post("/dossiers/{code}/contrats/type/{ctype}")
def ctr_apply_type(code: str, ctype: int, body: dict):
    return _g50_call(salaries.apply_type, body, ctype)


@router.post("/dossiers/{code}/salaries/{eid}/contrats", status_code=201)
def ctr_add(code: str, eid: int, body: dict, request: Request):
    users.require_permission(request, "contracts_manage")
    res = _g50_call(salaries.save_contract, code, eid, body)
    audit.record(
        action="CONTRAT_ADD",
        category="tiers",
        description=f"Création contrat salarié (ID #{eid})",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.put("/dossiers/{code}/salaries/{eid}/contrats/{cid}")
def ctr_update(code: str, eid: int, cid: int, body: dict, request: Request):
    users.require_permission(request, "contracts_manage")
    res = _g50_call(salaries.save_contract, code, eid, body, cid)
    audit.record(
        action="CONTRAT_MOD",
        category="tiers",
        description=f"Modification contrat #{cid} salarié (ID #{eid})",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.get("/dossiers/{code}/contrats/dashboard")
def ctr_dashboard(code: str):
    return salaries.contracts_dashboard(code)


@router.get("/dossiers/{code}/contrats/{cid}/custom")
def ctr_get_custom(code: str, cid: int):
    c = salaries.get_contrat_custom(code, cid)
    return {"has_custom": bool(c and c.get("CustomHTML")), "custom": c}


@router.post("/dossiers/{code}/contrats/{cid}/custom")
def ctr_save_custom(code: str, cid: int, body: dict, request: Request):
    users.require_permission(request, "contracts_edit_text")
    custom_html = body.get("custom_html", "")
    custom_clauses = body.get("custom_clauses", "")
    res = salaries.save_contrat_custom(code, cid, custom_html, custom_clauses)
    audit.record(
        action="CONTRAT_CUSTOM_SAVE",
        category="tiers",
        description=f"Personnalisation du texte du contrat #{cid}",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.delete("/dossiers/{code}/contrats/{cid}/custom")
def ctr_reset_custom(code: str, cid: int, request: Request):
    users.require_permission(request, "contracts_edit_text")
    res = salaries.delete_contrat_custom(code, cid)
    audit.record(
        action="CONTRAT_CUSTOM_RESET",
        category="tiers",
        description=f"Rétablissement du modèle initial du contrat #{cid}",
        request=request,
        dossier=code,
        status="info",
    )
    return res


@router.delete("/dossiers/{code}/contrats/{cid}")
def ctr_delete(code: str, cid: int, request: Request):
    users.require_permission(request, "salaries_delete")
    salaries.delete_contract(code, cid)
    audit.record(
        action="CONTRAT_DEL",
        category="tiers",
        description=f"Suppression contrat #{cid}",
        request=request,
        dossier=code,
        status="warning",
    )
    return {"message": "Contrat supprimé"}


# ------------------------------------------------------------------ bénéficiaires effectifs (uBeneficiaireEffectif)
@router.get("/dossiers/{code}/beneficiaires")
def benef_list(code: str):
    return beneficiaires.list_(code)


@router.get("/dossiers/{code}/beneficiaires/nouveau/{annee}")
def benef_new(code: str, annee: int):
    return _g50_call(beneficiaires.new, code, annee)


@router.post("/dossiers/{code}/beneficiaires", status_code=201)
def benef_add(code: str, body: dict):
    return _g50_call(beneficiaires.save, code, body)


@router.put("/dossiers/{code}/beneficiaires/{bid}")
def benef_update(code: str, bid: int, body: dict):
    return _g50_call(beneficiaires.save, code, body, bid)


@router.post("/dossiers/{code}/beneficiaires/{bid}/modele")
def benef_default(code: str, bid: int):
    beneficiaires.set_default(code, bid)
    return {"message": "Modèle par défaut enregistré"}


@router.delete("/dossiers/{code}/beneficiaires/{bid}")
def benef_delete(code: str, bid: int):
    beneficiaires.delete(code, bid)
    return {"message": "Déclaration supprimée"}


# ------------------------------------------------------------------ déclarations manquantes (uMissing*)
@router.get("/tableau-de-bord")
def dashboard(user: Optional[str] = None):
    return manquantes.dashboard(filter_user=user)


@router.get("/manquantes/{kind}")
def missing(kind: str, annee: str, periode: str = "", user: Optional[str] = None):
    return _g50_call(manquantes.search, kind, annee, periode, user)


# ------------------------------------------------------------------ sauvegarde & restauration (Unit1)
@router.get("/sauvegardes")
def backups(folder: str = ""):
    return sauvegarde.history_with_folder(custom_dir=folder)


@router.post("/sauvegardes", status_code=201)
def backup_now(body: Optional[dict] = None, request: Request = None):
    if request:
        users.require_permission(request, "backup_create")
    target_dir = str((body or {}).get("target_dir") or "")
    return _g50_call(sauvegarde.backup, target_dir=target_dir)


@router.post("/sauvegardes/parcourir-dossier")
def backup_browse_folder(body: dict):
    return {"folder": sauvegarde.pick_folder(str((body or {}).get("initial") or ""))}


@router.post("/sauvegardes/parcourir-fichier")
def backup_browse_file(body: dict):
    return {"file": sauvegarde.pick_file(str((body or {}).get("initial") or ""))}


@router.post("/sauvegardes/inspecter")
def backup_inspect(body: dict):
    return _g50_call(sauvegarde.inspect_file, str((body or {}).get("path") or ""))


@router.post("/sauvegardes/ouvrir-dossier")
def backup_open_folder(body: dict):
    return {"folder": sauvegarde.open_folder(str((body or {}).get("folder") or ""))}


@router.get("/sauvegardes/{name}")
def backup_download(name: str):
    p = _g50_call(sauvegarde.file_path, name)
    return FileResponse(p, media_type="application/zip", filename=p.name)


@router.post("/sauvegardes/{name}/restaurer")
def backup_restore(name: str, request: Request = None):
    if request:
        users.require_permission(request, "backup_restore")
    return _g50_call(sauvegarde.restore, name)


@router.post("/sauvegardes/restaurer-fichier")
def backup_restore_direct_path(body: dict, request: Request = None):
    if request:
        users.require_permission(request, "backup_restore")
    return _g50_call(sauvegarde.restore, str((body or {}).get("path") or ""))


@router.post("/restauration")
def backup_restore_upload(body: dict, request: Request = None):
    if request:
        users.require_permission(request, "backup_restore")
    return _g50_call(sauvegarde.restore_upload, str(body.get("filename") or ""), str(body.get("content") or ""))


# ------------------------------------------------------------------ dossiers sociétés (Unit10, Unit29, P1, FoExercice, Répertoire)
@router.post("/societes", status_code=201)
def societe_create(body: dict, request: Request):
    users.require_permission(request, "dossier_create")
    tok = request.cookies.get(access.COOKIE)
    curr_s = access.SESSIONS.get(tok) if tok else None
    creator = curr_s.username if curr_s else "admin"
    res = _g50_call(societes.create, body, creator)
    code = res.get("code") or body.get("code", "")
    rs = body.get("rs", "")
    audit.record(
        action="SOCIETE_CREATE",
        category="system",
        description=f"Création nouveau dossier {code} : « {rs} » (par {creator})",
        request=request,
        dossier=code,
        status="success",
        details={"code": code, "rs": rs, "creator": creator},
    )
    return res


@router.post("/societes/importer", status_code=201)
def societe_import(body: dict, request: Request):
    users.require_permission(request, "dossier_create")
    if "content" in body and body["content"]:
        res = _g50_call(societes.import_uploaded_db, str(body.get("filename") or "G50.sqlite"), str(body.get("content") or ""))
    else:
        res = _g50_call(societes.open_or_import_dossier, str(body.get("path") or ""))
    code = res.get("code", "")
    audit.record(
        action="SOCIETE_IMPORT",
        category="system",
        description=f"Importation / ouverture base dossier {code}",
        request=request,
        dossier=code,
        status="success",
    )
    return res


@router.get("/dossiers/{code}/fiche")
def societe_fiche(code: str):
    return societes.fiche(code)


@router.put("/dossiers/{code}/fiche")
def societe_fiche_update(code: str, body: dict, request: Request):
    users.require_permission(request, "dossier_edit")
    res = _g50_call(societes.update_fiche, code, body)
    rs = body.get("rs", "")
    audit.record(
        action="SOCIETE_UPDATE",
        category="system",
        description=f"Mise à jour fiche dossier {code} : « {rs} »",
        request=request,
        dossier=code,
        status="success",
        details={"code": code, "rs": rs},
    )
    return res


@router.get("/dossiers/{code}/exercices")
def exercices_list(code: str):
    return {"items": societes.exercices(code)}


@router.post("/dossiers/{code}/exercices", status_code=201)
def exercices_add(code: str, body: dict):
    annee = body.get("annee")
    res = _g50_call(societes.add_exercice, code, annee)
    try:
        if annee:
            obligations.auto_generate_for_exercice(code, str(annee))
    except Exception:
        pass
    return {"items": res}


# ------------------------------------------------------------------ obligations & échéancier
@router.get("/obligations/ref")
def get_ref_obligations():
    return obligations.get_ref_obligations()


@router.put("/obligations/ref/{code}")
def update_ref_obligation(code: str, body: dict):
    return obligations.update_ref_obligation(code, body)


@router.post("/obligations/ref")
def add_ref_obligation(body: dict):
    return obligations.add_ref_obligation(body)


@router.get("/obligations/matrice")
def get_matrice_obligations(annee: str):
    return obligations.matrice_consolidee(annee)


@router.get("/dossiers/{code}/obligations")
def get_dossier_obligations(code: str, annee: str):
    return obligations.list_dossier_obligations(code, annee)


@router.put("/dossiers/{code}/obligations/{item_id}")
def update_dossier_obligation(code: str, item_id: int, body: dict, request: Request):
    res = obligations.update_dossier_obligation(code, item_id, body)
    try:
        audit.record(
            action="OBLIGATION_UPDATE",
            category="declaration",
            description=f"Mise à jour obligation {res.get('code_obligation')} ({res.get('statut')})",
            request=request,
            dossier=code,
            status="info",
            details={"obligation": res.get("code_obligation"), "statut": res.get("statut"), "quittance": res.get("ref_quittance")},
        )
    except Exception:
        pass
    return res


@router.delete("/dossiers/{code}/exercices/{annee}")
def exercices_delete(code: str, annee: str):
    return {"items": societes.delete_exercice(code, annee)}


@router.post("/dossiers/{code}/repertoire")
def societe_folder(code: str):
    return {"path": societes.open_folder(code)}


@router.delete("/dossiers/{code}")
def dossier_delete(code: str, request: Request):
    users.require_permission(request, "dossier_delete")
    res = societes.delete_dossier(code)
    audit.record(
        action="DOSSIER_DELETE",
        category="system",
        description=f"Suppression complète du dossier {code}",
        request=request,
        dossier=code,
        status="warning",
        details={"code": code},
    )
    return res


@router.post("/dossiers/{code}/synchroniser")
def dossier_sync(code: str):
    return societes.sync_schema(code)


@router.put("/dossiers/{code}/exercices/{annee}")
def exercices_rename(code: str, annee: str, body: dict):
    return {"items": _g50_call(societes.rename_exercice, code, annee, body.get("annee"))}


# ------------------------------------------------------------------ génération massive (uBatchGen)
@router.get("/batch")
def batch_info():
    return batch.central_info()


@router.post("/batch/windev")
def batch_windev(body: dict):
    return _g50_call(batch.import_windev, str(body.get("folder") or ""))


@router.get("/batch/windev/detect")
def batch_windev_detect():
    return batch.detect_windev()


@router.post("/batch/windev/parcourir")
def batch_windev_browse(request: Request, body: dict):
    from ..core import access
    if not access.is_desktop(request):
        raise HTTPException(403, "Sélection de dossier disponible uniquement sur le poste principal")
    return {"folder": batch.pick_folder(str(body.get("initial") or ""))}


@router.post("/batch/mdb")
def batch_mdb(body: dict):
    return _g50_call(batch.import_mdb, str(body.get("path") or ""))


@router.post("/batch/generer")
def batch_generate(body: dict):
    return _g50_call(batch.generate, bool(body.get("replace")), body.get("only") or None)


# ------------------------------------------------------------------ OCR & Scan Facture
from .ocr_routes import router as _ocr_router
router.include_router(_ocr_router)

# ------------------------------------------------------------------ Cabinet Profile (fallback for WhatsApp / communications)
@router.get("/honoraires/cabinet")
def get_cabinet_profile():
    return {
        "nom_cabinet": "Cabinet d'Expertise Comptable & Commissariat aux Comptes",
        "expert_comptable": "L'Expert-Comptable",
        "titre": "Comptable Agréé",
        "telephone": "",
        "email": "",
    }


