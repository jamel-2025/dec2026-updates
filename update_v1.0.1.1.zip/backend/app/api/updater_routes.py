"""Routes API pour le système de mise à jour (Cloud & Offline Updater)."""
from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel

from ..core import config
from ..services import updater_service

router = APIRouter(prefix="/api/updater", tags=["updater"])


class CheckUpdatePayload(BaseModel):
    custom_url: Optional[str] = None


class ApplyRemotePayload(BaseModel):
    download_url: str
    sha256: Optional[str] = ""
    new_version: Optional[str] = ""


@router.get("/version")
def get_version():
    """Retourne la version installée actuelle."""
    return updater_service.get_current_version_info()


@router.post("/check")
def check_update(payload: Optional[CheckUpdatePayload] = None):
    """Vérifie si une mise à jour est disponible sur le cloud."""
    custom_url = payload.custom_url if payload else None
    return updater_service.check_for_updates(custom_url)


@router.post("/apply-cloud")
def apply_cloud_update(payload: ApplyRemotePayload):
    """Télécharge et installe la mise à jour depuis le lien distant."""
    if not payload.download_url:
        raise HTTPException(status_code=400, detail="URL de téléchargement requise.")
    res = updater_service.download_and_apply_update(
        payload.download_url,
        payload.sha256 or "",
        new_version=payload.new_version or ""
    )
    if not res.get("success"):
        raise HTTPException(status_code=500, detail=res.get("error", "Erreur lors de la mise à jour"))
    return res


@router.post("/apply-file")
async def apply_file_update(file: UploadFile = File(...)):
    """Applique une mise à jour manuelle via un fichier ZIP ou PATCH importé."""
    if not file.filename.endswith((".zip", ".patch")):
        raise HTTPException(status_code=400, detail="Format de fichier non pris en charge (.zip ou .patch requis).")

    # Détection automatique du numéro de version depuis le nom du fichier (ex: update_v1.0.2.zip -> 1.0.2)
    detected_ver = ""
    clean_name = file.filename.lower()
    if "_v" in clean_name:
        parts = clean_name.split("_v")[-1].replace(".zip", "").replace(".patch", "").strip()
        if parts:
            detected_ver = parts

    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
        tmp_path = Path(tmp.name)
        shutil.copyfileobj(file.file, tmp)

    try:
        res = updater_service.apply_zip_update(tmp_path, new_version=detected_ver)
        if not res.get("success"):
            raise HTTPException(status_code=500, detail=res.get("error", "Erreur"))
        return res
    finally:
        tmp_path.unlink(missing_ok=True)


@router.get("/test-cloud/version.json")
def get_test_cloud_manifest(request: Request):
    """Sert le manifest version.json local pour tester la mise à jour cloud sans dépendre d'Internet."""
    candidates = [
        config.PROJECT_ROOT / "dist_updates" / "version.json",
        Path("G:/Dec2026F/dist_updates/version.json"),
    ]
    manifest_p = next((p for p in candidates if p.is_file()), None)
    if not manifest_p:
        raise HTTPException(status_code=404, detail="Manifeste de mise à jour test non trouvé.")

    with open(manifest_p, "r", encoding="utf-8") as f:
        data = json.load(f)

    host = request.headers.get("host", "127.0.0.1:8790")
    ver = data.get("version", "1.0.2")
    zip_name = f"update_v{ver}.zip"
    data["download_url"] = f"http://{host}/api/updater/test-cloud/download/{zip_name}"
    return data


@router.get("/test-cloud/download/{filename}")
def download_test_cloud_package(filename: str):
    """Télécharge l'archive ZIP de test."""
    candidates = [
        config.PROJECT_ROOT / "dist_updates" / filename,
        Path("G:/Dec2026F/dist_updates") / filename,
    ]
    pkg_p = next((p for p in candidates if p.is_file()), None)
    if not pkg_p:
        raise HTTPException(status_code=404, detail=f"Archive {filename} introuvable.")
    return FileResponse(pkg_p, media_type="application/zip", filename=filename)


@router.post("/test-cloud/reset")
def reset_version_for_test(target_version: str = "1.0.1"):
    """Réinitialise la version installée pour permettre de retester la mise à jour."""
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    vfile = config.DATA_DIR / "app_version.json"
    with open(vfile, "w", encoding="utf-8") as f:
        json.dump({"version": target_version}, f, indent=2)
    return {"success": True, "message": f"Version réinitialisée à {target_version}"}

