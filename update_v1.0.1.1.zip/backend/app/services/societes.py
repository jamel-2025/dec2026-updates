"""Dossiers sociétés — Delphi Unit10 (Nouveau dossier), Unit29 (Fiche société), uMain.P1Click (Parcourir),
FoExercice / Unit22 (table des exercices), uMain.SpeedButton16 (Répertoire).

Rules:
  * Nouveau dossier (Unit10): raison sociale, activité, adresse, NIF, NIF2, article, RC, forme juridique,
    wilaya, commune, service gestionnaire et recette obligatoires; the folder is the next free S<n>;
    the database is the empty model (G50Model.mdb: tables + Mois + PPu).
  * Fiche société (Unit29): French data, Arabic data (contrats, déclarations), activity flags.
  * Exercices (Unit22): year > 2020, no duplicate; deleting an exercice deletes its G50.
  * Parcourir: opens an existing Delphi dossier (G50.mdb) — here imported as a new S<n>.
Logical correction: G50Model.mdb carries the clients row of a real company; a new dossier contains
only the new company (Delphi appended a second row).
"""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Optional

from fastapi import HTTPException

from ..core import config
from ..core.db import connect, dossier_path
from . import dates, g50
from .g50 import Conflict, G50Error

FJ = ["Personne Physique", "Sarl", "Eurl", "Snc", "Spa"]
SECTEURS = ["Ventes de marchandises", "Produits  fabriqués", "Prestations de services", "Vente de travaux"]
FLAGS = ("Pharma", "StationServices", "Promotion", "Lotissement", "Fventes")
TEXT_FIELDS = ("rs", "activité", "adresse", "NIF", "NIF2", "article", "RCP", "fj", "cbilan", "NumeroCB", "direction",
               "commune", "inspection", "recette", "UserJibayatic", "PWJI", "NIN", "TelelWatsapp",
               "RS_AR", "Activite_AR", "Adresse_AR", "Gerant_AR", "QualiteGerant_AR")
REQUIRED = [("rs", "Raison Sociale (RS)"), ("activité", "Activité"), ("adresse", "Adresse"), ("NIF", "Nif"), ("NIF2", "Nif2"),
            ("article", "Article d’imposition"), ("RCP", "Numéro de RC"), ("fj", "Forme juridique"), ("direction", "Wilaya"),
            ("commune", "Commune"), ("inspection", "Service gestionnaire"), ("recette", "Recette")]


_SYNCED_DOSSIERS: set[str] = set()


# ------------------------------------------------------------------ fiche société (Unit29)
def fiche(code: str) -> dict:
    ensure_dossier_synced(code)
    with connect(code) as c:
        r = c.execute("SELECT * FROM clients LIMIT 1").fetchone()
    if r is None:
        raise HTTPException(404, "Fiche société introuvable")
    d = {k: v for k, v in dict(r).items() if k != "photo"}
    d["datedebut_display"] = dates.to_display(d.get("datedebut"))
    for k in FLAGS:
        d[k] = 1 if d.get(k) in (1, True, "1", -1, "True") else 0
    return {"fiche": d, "fj": FJ, "secteurs": SECTEURS, "folder": str(config.SOCIETES_DIR / code)}


def _values(data: dict) -> dict:
    v = {k: str(data.get(k) or "").strip() for k in TEXT_FIELDS if k in data}
    for k in FLAGS:
        if k in data:
            v[k] = 1 if data[k] in (1, True, "1", "true") else 0
    if "datedebut" in data:
        v["datedebut"] = dates.to_storage(data["datedebut"]) if data.get("datedebut") else None
    return v


def update_fiche(code: str, data: dict) -> dict:
    if "rs" in data and not str(data.get("rs") or "").strip():
        raise G50Error("Le champ Raison Sociale (RS) est obligatoire.")
    v = _values(data)
    with connect(code) as c:
        rid = c.execute("SELECT IDclients FROM clients LIMIT 1").fetchone()
        if rid is None:
            raise HTTPException(404, "Fiche société introuvable")
        cols = {r[1] for r in c.execute("PRAGMA table_info(clients)")}
        v = {k: x for k, x in v.items() if k in cols}
        if v:
            c.execute(f'UPDATE clients SET {", ".join(chr(34) + k + chr(34) + " = ?" for k in v)} WHERE IDclients = ?', (*v.values(), rid[0]))
    return fiche(code)


# ------------------------------------------------------------------ nouveau dossier (Unit10)
def _next_code() -> str:
    config.SOCIETES_DIR.mkdir(parents=True, exist_ok=True)
    i = 1
    while (config.SOCIETES_DIR / f"S{i}").exists():
        i += 1
    return f"S{i}"


def _create_db(path: Path) -> sqlite3.Connection:
    schema = (config.SPEC_DIR / "dossier_schema.sql").read_text(encoding="utf-8")
    c = sqlite3.connect(path)
    c.executescript(schema)
    seed = json.loads((config.SPEC_DIR / "dossier_seed.json").read_text(encoding="utf-8"))
    for table, rows in seed.items():
        for r in rows:
            c.execute(f'INSERT INTO "{table}" ({", ".join(chr(34) + k + chr(34) for k in r)}) VALUES ({", ".join("?" for _ in r)})',
                      tuple(r.values()))
    return c


def _check_nif(nif: str) -> None:
    from . import dossiers
    nif = (nif or "").strip()
    for d in dossiers.list_dossiers():
        if nif and (d.get("nif") or "").strip() == nif:
            raise Conflict(f"Une société avec le NIF {nif} existe déjà : dossier {d['code']} ({d.get('rs')})")


def create(data: dict, creator: Optional[str] = None) -> dict:
    from ..core import assignments
    for k, label in REQUIRED:
        if not str(data.get(k) or "").strip():
            raise G50Error(f"Le champ {label} est obligatoire.")
    if data["fj"] not in FJ:
        raise G50Error("Forme juridique inconnue")
    _check_nif(data["NIF"])
    code = _next_code()
    folder = config.SOCIETES_DIR / code
    folder.mkdir(parents=True)
    try:
        c = _create_db(folder / config.DB_FILENAME)
        v = _values({**{f: 1 if data.get(f) else 0 for f in FLAGS}, **data})
        v["datedebut"] = v.get("datedebut") or dates.to_storage(date.today())
        v.update({"IDclients": 1, "NatureRC": "Principal", "RSnature": "Principal", "idclientPrincipal": 1})
        c.execute(f'INSERT INTO clients ({", ".join(chr(34) + k + chr(34) for k in v)}) VALUES ({", ".join("?" for _ in v)})', tuple(v.values()))
        c.execute('INSERT INTO Exercices (IDclients, "Année") VALUES (1, ?)', (str(date.today().year),))
        c.commit()
        c.close()

        # Link dossier ownership and assigned agent
        assignments.on_dossier_created(code, creator or "admin")
    except Exception:
        for p in folder.glob("*"):
            p.unlink()
        folder.rmdir()
        raise
    return {"code": code, "rs": v["rs"]}


# ------------------------------------------------------------------ Parcourir : import d'un dossier Delphi (G50.mdb)
def _plain(v):
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, datetime):
        return v.isoformat(timespec="seconds")
    if isinstance(v, date):
        return datetime(v.year, v.month, v.day).isoformat()
    if isinstance(v, bool):
        return 1 if v else 0
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    return v


# ------------------------------------------------------------------ Parcourir : ouverture / import d'un dossier (G50.sqlite ou G50.mdb)
def _open_or_import_sqlite(p: Path) -> dict:
    resolved_p = p.resolve()
    # 1. Valider la base SQLite et extraire les informations de la société
    try:
        conn = sqlite3.connect(f"file:{resolved_p}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT rs, NIF, fj FROM clients LIMIT 1").fetchone()
        if not row:
            raise G50Error("Ce fichier SQLite ne contient aucune fiche société (table clients vide).")
        rs = str(row["rs"] or "Société sans nom").strip()
        nif = str(row["NIF"] or "").strip()
        conn.close()
    except Exception as e:
        if isinstance(e, G50Error):
            raise
        raise G50Error(f"Impossible de lire la base de données SQLite {p.name} : {e}") from e

    config.SOCIETES_DIR.mkdir(parents=True, exist_ok=True)
    resolved_societes = config.SOCIETES_DIR.resolve()

    # 2. Vérifier si ce dossier est déjà présent dans data/societes/<code>
    try:
        rel = resolved_p.relative_to(resolved_societes)
        if len(rel.parts) >= 2:
            code = rel.parts[0]
            return {"code": code, "rs": rs, "status": "existing", "message": f"Dossier {rs} ouvert directement ({code})"}
    except ValueError:
        pass

    # 3. Dossier externe (provenant d'une clé USB, d'un autre PC ou d'un autre répertoire)
    from . import dossiers
    existing = dossiers.list_dossiers()
    matched = next((d for d in existing if nif and (d.get("nif") or "").strip() == nif), None)

    parent_name = p.parent.name
    import shutil
    if matched:
        code = matched["code"]
        target_folder = config.SOCIETES_DIR / code
    elif parent_name.startswith("S") and parent_name[1:].isdigit() and not (config.SOCIETES_DIR / parent_name).exists():
        code = parent_name
        target_folder = config.SOCIETES_DIR / code
        target_folder.mkdir(parents=True, exist_ok=True)
    else:
        code = _next_code()
        target_folder = config.SOCIETES_DIR / code
        target_folder.mkdir(parents=True, exist_ok=True)

    target_db = target_folder / config.DB_FILENAME
    if target_db.exists() and target_db.resolve() != resolved_p:
        backup_dir = config.PROJECT_ROOT / "data" / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_file = backup_dir / f"{code}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite"
        try:
            shutil.copy2(target_db, backup_file)
        except Exception:
            pass

    if target_db.resolve() != resolved_p:
        shutil.copy2(resolved_p, target_db)
        for sfx in ("-wal", "-shm"):
            dst_aux = target_folder / f"{config.DB_FILENAME}{sfx}"
            if dst_aux.exists():
                try:
                    dst_aux.unlink()
                except Exception:
                    pass

    return {"code": code, "rs": rs, "status": "imported", "message": f"Dossier {rs} chargé avec succès dans {code}"}


def open_or_import_dossier(path: str) -> dict:
    raw = str(path or "").strip().strip('"').strip("'")
    if not raw:
        raise G50Error("Veuillez spécifier le chemin d’un dossier ou d’un fichier G50.sqlite.")
    p = Path(raw)
    if not p.exists():
        raise G50Error(f"Le chemin spécifié est introuvable : {raw}")

    if p.is_dir():
        if (p / config.DB_FILENAME).is_file():
            p = p / config.DB_FILENAME
        elif (p / "G50.sqlite").is_file():
            p = p / "G50.sqlite"
        else:
            candidates = list(p.glob("*.sqlite")) + list(p.glob("*.db"))
            if candidates:
                p = candidates[0]
            elif (p / "G50.mdb").is_file():
                p = p / "G50.mdb"
            else:
                raise G50Error(f"Aucune base de données de société (G50.sqlite) trouvée dans le dossier : {raw}")

    suffix = p.suffix.lower()
    if suffix in (".sqlite", ".db", ".sqlite3"):
        return _open_or_import_sqlite(p)
    elif suffix == ".mdb":
        return import_mdb(str(p))
    else:
        raise G50Error(f"Format de fichier non supporté ({p.name}). Veuillez sélectionner un fichier G50.sqlite ou un dossier de société.")


def import_uploaded_db(filename: str, content_b64: str) -> dict:
    import base64
    import tempfile
    data = base64.b64decode(content_b64)
    with tempfile.NamedTemporaryFile(delete=False, suffix=".sqlite") as tmp:
        tmp.write(data)
        tmp_path = Path(tmp.name)
    try:
        return _open_or_import_sqlite(tmp_path)
    finally:
        try:
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass


def import_mdb(path: str) -> dict:
    p = Path(str(path or "").strip().strip('"'))
    if p.is_dir():
        p = p / "G50.mdb"
    if p.suffix.lower() != ".mdb" or not p.is_file():
        raise G50Error("Fichier de base de données non valide ou introuvable.")
    try:
        import pyodbc
        src = pyodbc.connect(rf"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={p};ReadOnly=1")
    except Exception as e:  # noqa: BLE001 — driver / file errors are reported to the user
        raise G50Error(f"Impossible d’ouvrir {p} : {e}") from e
    try:
        row = src.cursor().execute("SELECT rs, NIF FROM clients").fetchone()
        if row is None:
            raise G50Error("Ce fichier ne contient aucune fiche société")
        _check_nif(row[1] or "")
        code = _next_code()
        folder = config.SOCIETES_DIR / code
        folder.mkdir(parents=True)
        dst = _create_db(folder / config.DB_FILENAME)
        try:
            for t in ("Mois", "PPu"):
                dst.execute(f'DELETE FROM "{t}"')
            tables = {r[0] for r in dst.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
            counts = {}
            for t in [r.table_name for r in src.cursor().tables(tableType="TABLE")]:
                if t not in tables:
                    continue
                cols_dst = {r[1] for r in dst.execute(f'PRAGMA table_info("{t}")')}
                cur = src.cursor().execute(f"SELECT * FROM [{t}]")
                cols = [d[0] for d in cur.description if d[0] in cols_dst]
                idx = [i for i, d in enumerate(cur.description) if d[0] in cols_dst]
                rows = [tuple(_plain(r[i]) for i in idx) for r in cur.fetchall()]
                if rows:
                    dst.executemany(f'INSERT INTO "{t}" ({", ".join(chr(34) + k + chr(34) for k in cols)}) VALUES ({", ".join("?" for _ in cols)})', rows)
                counts[t] = len(rows)
            dst.commit()
        finally:
            dst.close()
    finally:
        src.close()
    return {"code": code, "rs": row[0], "tables": counts}


# ------------------------------------------------------------------ exercices (FoExercice / Unit22)
def exercices(code: str) -> list[dict]:
    with connect(code) as c:
        rows = [r[0] for r in c.execute('SELECT DISTINCT "Année" FROM Exercices WHERE TRIM(COALESCE("Année", \'\')) <> \'\' ORDER BY CAST("Année" AS INTEGER)')]
        return [{"annee": a, "_id": a, "g50": c.execute('SELECT COUNT(*) FROM G50 WHERE TRIM("Année") = ?', (a,)).fetchone()[0]} for a in rows]


def add_exercice(code: str, annee) -> list[dict]:
    a = str(annee or "").strip()
    if not a:
        raise G50Error("Veuillez saisir une année valide.")
    if not a.isdigit() or int(a) <= 2020:
        raise G50Error("L’année doit être supérieure à 2020.")
    with connect(code) as c:
        if c.execute('SELECT 1 FROM Exercices WHERE "Année" = ?', (a,)).fetchone():
            raise Conflict(f"L’exercice {a} existe déjà.")
        cid = c.execute("SELECT IDclients FROM clients LIMIT 1").fetchone()
        c.execute('INSERT INTO Exercices (IDclients, "Année") VALUES (?, ?)', (cid[0] if cid else 1, a))
    return exercices(code)


def delete_exercice(code: str, annee: str) -> list[dict]:
    """« Tous les G50 de cet exercice seront supprimés »."""
    with connect(code) as c:
        ids = [r[0] for r in c.execute('SELECT idg50 FROM G50 WHERE TRIM("Année") = ?', (str(annee),))]
    for i in ids:
        g50.delete(code, i)
    with connect(code) as c:
        if not c.execute('DELETE FROM Exercices WHERE "Année" = ?', (str(annee),)).rowcount:
            raise HTTPException(404, "Exercice introuvable")
    return exercices(code)


# ------------------------------------------------------------------ Répertoire (SpeedButton16)
def open_folder(code: str) -> str:
    import subprocess
    import sys
    folder = dossier_path(code).parent.resolve()
    folder.mkdir(parents=True, exist_ok=True)
    folder_str = str(folder).replace('/', '\\')

    if sys.platform == "win32":
        try:
            os.startfile(folder_str)  # noqa: S606
        except Exception:
            pass
        try:
            subprocess.Popen(["explorer.exe", folder_str])
        except Exception:
            try:
                subprocess.Popen(f'explorer.exe "{folder_str}"', shell=True)
            except Exception:
                pass
    else:
        try:
            subprocess.Popen(["xdg-open", str(folder)])
        except Exception:
            pass

    return folder_str


# ------------------------------------------------------------------ uOpenSociete: Supp Dossier · Mettre à jour & synchroniser
def delete_dossier(code: str) -> dict:
    """AdvGlowButton4Click — « supprimer définitivement le dossier ». Logical safeguard: an archive of the
    dossier is written to data/backups before deletion (Delphi deleted without copy)."""
    import shutil
    import zipfile
    db = dossier_path(code)
    config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    archive = config.BACKUP_DIR / f"Supprime_{code}_{datetime.now():%d%m%Y_%H%M%S}.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        tmp = db.parent / "_copie.sqlite"
        src, dst = sqlite3.connect(f"file:{db}?mode=ro", uri=True), sqlite3.connect(tmp)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        z.write(tmp, f"{code}/{config.DB_FILENAME}")
        tmp.unlink()
    shutil.rmtree(db.parent)
    return {"code": code, "archive": archive.name}


def sync_schema(code: str) -> dict:
    """miSyncDbClick « Mettre à jour & synchroniser la base de données (G50Model) »: adds the tables and
    columns of the model missing from the dossier, without touching the data."""
    import re as _re
    schema = (config.SPEC_DIR / "dossier_schema.sql").read_text(encoding="utf-8")
    tables_added, columns_added = [], []
    with connect(code) as c:
        existing = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        for stmt in _re.findall(r"CREATE TABLE[^;]+;", schema):
            name = _re.match(r'CREATE TABLE\s+"?([^"\s(]+)"?', stmt).group(1)
            if name not in existing:
                try:
                    c.execute(stmt)
                    tables_added.append(name)
                except Exception:
                    pass
                continue
            cols = {r[1] for r in c.execute(f'PRAGMA table_info("{name}")')}
            body = stmt[stmt.index("(") + 1: stmt.rindex(")")]
            for part in _re.split(r",\s*(?![^()]*\))", body):
                m = _re.match(r'\s*"?([^"\s]+)"?\s*([A-Za-z]*)', part)
                if m and m.group(1).upper() not in ("PRIMARY", "FOREIGN", "UNIQUE", "CONSTRAINT", "CHECK") and m.group(1) not in cols:
                    try:
                        c.execute(f'ALTER TABLE "{name}" ADD COLUMN "{m.group(1)}" {m.group(2)}')
                        columns_added.append(f"{name}.{m.group(1)}")
                    except Exception:
                        pass
    _SYNCED_DOSSIERS.add(code.upper())
    return {"tables": tables_added, "columns": columns_added}


def ensure_dossier_synced(code: str) -> None:
    """Synchronise la base d'un dossier automatiquement s'il ne l'a pas été."""
    clean = str(code or "").strip().upper()
    if not clean or clean in _SYNCED_DOSSIERS:
        return
    try:
        sync_schema(code)
    except Exception:
        pass


def auto_sync_all_dossiers() -> int:
    """Vérifie et met à jour automatiquement tous les dossiers existants au démarrage."""
    count = 0
    if not config.SOCIETES_DIR.is_dir():
        return 0
    for p in config.SOCIETES_DIR.iterdir():
        if p.is_dir() and (p / config.DB_FILENAME).is_file():
            try:
                sync_schema(p.name)
                count += 1
            except Exception:
                pass
    return count


def rename_exercice(code: str, old: str, new) -> list[dict]:
    """FoExercice « Modifier ». Logical safeguard: an exercice that already has G50 cannot be renamed
    (its declarations would be detached from it)."""
    new = str(new or "").strip()
    if not new.isdigit() or int(new) <= 2020:
        raise G50Error("L’année doit être supérieure à 2020.")
    with connect(code) as c:
        if c.execute('SELECT COUNT(*) FROM G50 WHERE TRIM("Année") = ?', (old,)).fetchone()[0]:
            raise Conflict(f"L’exercice {old} contient des G50 : il ne peut pas être renommé")
        if c.execute('SELECT 1 FROM Exercices WHERE "Année" = ?', (new,)).fetchone():
            raise Conflict(f"L’exercice {new} existe déjà.")
        c.execute('UPDATE Exercices SET "Année" = ? WHERE "Année" = ?', (new, old))
    return exercices(code)
