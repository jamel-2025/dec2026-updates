"""Service de mise à jour sécurisée (Cloud & Offline Auto-Updater) pour Dec2026."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Dict, Any, Optional

from ..core import config

VERSION_FILE = config.DATA_DIR / "app_version.json"

def get_installed_version() -> str:
    """Lit la version installée dynamiquement depuis le fichier local s'il existe."""
    if VERSION_FILE.exists():
        try:
            with open(VERSION_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("version", "1.0.1")
        except Exception:
            pass
    return "1.0.1"

# URL officielle GitHub Releases de jamel-2025
DEFAULT_UPDATE_URL = os.environ.get(
    "DEC_UPDATE_URL",
    "https://raw.githubusercontent.com/jamel-2025/dec2026-updates/main/version.json"
)


def get_current_version_info() -> Dict[str, Any]:
    """Retourne la version actuelle de l'application et les métadonnées système."""
    v = get_installed_version()
    return {
        "version": v,
        "app_name": "Dec2026 G50 Multi-Sociétés",
        "system": os.name,
        "is_portable": True
    }


def parse_version_tuple(v_str: str) -> tuple:
    """Transforme '1.0.1' en (1, 0, 1) pour une comparaison fiable."""
    try:
        clean = v_str.strip().lstrip("v").split("-")[0]
        return tuple(int(x) for x in clean.split("."))
    except Exception:
        return (0, 0, 0)


def _create_ssl_context():
    """Crée un contexte SSL compatible avec toutes les versions de Windows (y compris Win7)."""
    import ssl
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    except Exception:
        return None


def check_for_updates(custom_url: Optional[str] = None) -> Dict[str, Any]:
    """Vérifie auprès du serveur distant s'il existe une version plus récente."""
    target_url = custom_url or DEFAULT_UPDATE_URL
    current_ver = get_installed_version()
    current_tuple = parse_version_tuple(current_ver)

    try:
        req = urllib.request.Request(
            target_url,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Dec2026-Updater"}
        )
        ctx = _create_ssl_context()
        kwargs = {"timeout": 15}
        if ctx:
            kwargs["context"] = ctx

        with urllib.request.urlopen(req, **kwargs) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        remote_version = data.get("version", "1.0.0")
        remote_tuple = parse_version_tuple(remote_version)

        has_update = remote_tuple > current_tuple

        return {
            "success": True,
            "has_update": has_update,
            "current_version": current_ver,
            "latest_version": remote_version,
            "release_date": data.get("release_date", ""),
            "title": data.get("title", f"Mise à jour v{remote_version}"),
            "changelog": data.get("changelog", []),
            "changelog_ar": data.get("changelog_ar", []),
            "changelog_fr": data.get("changelog_fr", []),
            "download_url": data.get("download_url", ""),
            "sha256": data.get("sha256", ""),
            "critical": data.get("critical", False)
        }
    except Exception:
        # Aucun fichier de mise à jour distant (serveur vide ou hors-ligne) -> l'application est considérée à jour
        return {
            "success": True,
            "has_update": False,
            "current_version": current_ver,
            "latest_version": current_ver,
            "message": "Votre application est à jour."
        }


def apply_zip_update(zip_path: Path, new_version: str = "") -> Dict[str, Any]:
    """Applique en toute sécurité une archive de mise à jour sans toucher aux données."""
    if not zip_path.is_file():
        return {"success": False, "error": "Fichier de mise à jour introuvable."}

    backup_folder = None
    try:
        # 1. Sauvegarde préventive (Snapshot)
        ts = int(os.path.getmtime(zip_path))
        backup_folder = config.BACKUP_DIR / f"pre_update_snapshot_{ts}"
        backup_folder.mkdir(parents=True, exist_ok=True)
        if config.DATA_DIR.exists():
            for item in config.DATA_DIR.glob("*.sqlite*"):
                shutil.copy2(item, backup_folder)
            if config.LICENCE_FILE.exists():
                shutil.copy2(config.LICENCE_FILE, backup_folder)

        # 2. Extraction sécurisée
        updated_files = []
        with zipfile.ZipFile(zip_path, 'r') as zf:
            for member in zf.infolist():
                filename = member.filename
                # INTERDIT: écraser data/, licence, backups ou dossiers clients
                if filename.startswith("data/") or "licence.key" in filename or "g50.sqlite" in filename.lower():
                    continue
                target_dest = config.PROJECT_ROOT / filename
                if member.is_dir():
                    if target_dest.is_file():
                        target_dest.unlink(missing_ok=True)
                    target_dest.mkdir(parents=True, exist_ok=True)
                else:
                    parent_dir = target_dest.parent
                    # Résoudre le conflit si un fichier bloquant porte le même nom qu'un sous-dossier
                    curr = config.PROJECT_ROOT
                    for part in filename.split("/")[:-1]:
                        curr = curr / part
                        if curr.is_file():
                            curr.unlink(missing_ok=True)
                    parent_dir.mkdir(parents=True, exist_ok=True)
                    if target_dest.is_dir():
                        shutil.rmtree(target_dest, ignore_errors=True)
                    with zf.open(member) as source, open(target_dest, "wb") as target:
                        shutil.copyfileobj(source, target)
                    updated_files.append(filename)

                    # Miroir automatique dans _internal si présent (mode portable PyInstaller)
                    internal_dir = config.PROJECT_ROOT / "_internal"
                    if internal_dir.is_dir():
                        internal_dest = None
                        if filename.startswith("backend/app/"):
                            internal_dest = internal_dir / "app" / filename[len("backend/app/"):]
                        elif filename.startswith("frontend/dist/"):
                            internal_dest = internal_dir / "frontend" / "dist" / filename[len("frontend/dist/"):]
                        elif filename.startswith("Rapports/"):
                            internal_dest = internal_dir / "Rapports" / filename[len("Rapports/"):]
                        elif filename.startswith("spec/"):
                            internal_dest = internal_dir / "spec" / filename[len("spec/"):]
                        if internal_dest:
                            internal_dest.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(target_dest, internal_dest)

        # 3. Enregistrer la nouvelle version si fournie
        if new_version:
            config.DATA_DIR.mkdir(parents=True, exist_ok=True)
            with open(VERSION_FILE, "w", encoding="utf-8") as f:
                json.dump({"version": new_version}, f, indent=2)

        return {
            "success": True,
            "message": f"Mise à jour appliquée avec succès ({len(updated_files)} fichiers mis à jour).",
            "updated_files_count": len(updated_files),
            "new_version": new_version or get_installed_version(),
            "snapshot_backup": str(backup_folder)
        }
    except Exception as exc:
        return {
            "success": False,
            "error": f"Erreur lors de l'application de la mise à jour: {str(exc)}"
        }


def download_and_apply_update(download_url: str, expected_sha256: str = "", new_version: str = "") -> Dict[str, Any]:
    """Télécharge la mise à jour depuis le cloud et l'applique avec auto-fallback multi-sources."""
    # Préparer les URLs alternatives au cas où l'URL originale retourne 404 (ex: Release vs Raw repo)
    urls_to_try = [download_url]
    if "releases/download" in download_url:
        # Convertir https://github.com/jamel-2025/dec2026-updates/releases/download/v1.0.2/update_v1.0.2.zip
        # vers https://raw.githubusercontent.com/jamel-2025/dec2026-updates/main/update_v1.0.2.zip
        filename = download_url.rstrip("/").split("/")[-1]
        parts = download_url.split("/")
        if len(parts) >= 5:
            owner = parts[3]
            repo = parts[4]
            urls_to_try.append(f"https://raw.githubusercontent.com/{owner}/{repo}/main/{filename}")
            urls_to_try.append(f"https://github.com/{owner}/{repo}/raw/main/{filename}")
    elif "raw.githubusercontent.com" in download_url:
        filename = download_url.rstrip("/").split("/")[-1]
        parts = download_url.split("/")
        if len(parts) >= 5:
            owner = parts[3]
            repo = parts[4]
            if new_version:
                urls_to_try.append(f"https://github.com/{owner}/{repo}/releases/download/v{new_version}/{filename}")

    last_error = ""
    download_success = False
    tmp_path = None

    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp_file:
            tmp_path = Path(tmp_file.name)

        ctx = _create_ssl_context()
        for attempt_url in urls_to_try:
            try:
                req = urllib.request.Request(
                    attempt_url,
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Dec2026-Updater"}
                )
                kwargs = {"timeout": 45}
                if ctx:
                    kwargs["context"] = ctx

                with urllib.request.urlopen(req, **kwargs) as resp, open(tmp_path, "wb") as out_file:
                    shutil.copyfileobj(resp, out_file)

                # Si le téléchargement a réussi et que le fichier a une taille valide (> 1KB)
                if tmp_path.exists() and tmp_path.stat().st_size > 1024:
                    download_success = True
                    break
            except Exception as err:
                last_error = str(err)
                continue

        if not download_success:
            raise RuntimeError(last_error or "Échec de téléchargement depuis toutes les URLs miroir")

        # Vérification d'intégrité si SHA-256 fourni
        if expected_sha256:
            hasher = hashlib.sha256()
            with open(tmp_path, "rb") as f:
                while chunk := f.read(65536):
                    hasher.update(chunk)
            if hasher.hexdigest().lower() != expected_sha256.lower():
                tmp_path.unlink(missing_ok=True)
                return {"success": False, "error": "Échec de vérification d'intégrité (SHA256 non conforme)."}

        result = apply_zip_update(tmp_path, new_version=new_version)
        tmp_path.unlink(missing_ok=True)
        return result
    except Exception as exc:
        if tmp_path and tmp_path.exists():
            tmp_path.unlink(missing_ok=True)
        # Fallback de secours si le téléchargement distant échoue (ex: GitHub Releases 404)
        candidates = [
            config.PROJECT_ROOT / "dist_updates" / f"update_v{new_version}.zip",
            Path(f"G:/Dec2026F/dist_updates/update_v{new_version}.zip"),
        ]
        local_fallback = next((p for p in candidates if p.is_file()), None)
        if local_fallback:
            return apply_zip_update(local_fallback, new_version=new_version)
        return {"success": False, "error": f"Échec du téléchargement: {str(exc)}"}
