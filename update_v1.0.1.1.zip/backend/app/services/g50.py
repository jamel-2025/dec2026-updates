"""Déclaration mensuelle G50 — logic ported from the Delphi sources:

  uMain page 1 ............ list, recap of the 6 tables, delete
  Unit23 (Nouveau G50) .... creation: next month, duplicate check, carried-over précompte
  Unit2  (Form2) .......... editor; CalcTVA (B/C block), RecalcEtatTVA (lines 91/92/95)
  UnitaP / UnitTsl ........ TAP / TLS lines   (ref TAPRef / TlsRef)
  Unit24 .................. IRG / retenues    (ref IRGIBSRef)
  Unit25 .................. droit de timbre   (defaults of Form20.TtimbreNewRecord)
  Unit27 .................. autres taxes      (ref AutresTaxesRef)
  Unit26 .................. TVA collectée     (ref TVAref)
  Unit4  .................. TVA déductible: factures fournisseurs (DetailEtatTVA)
"""
from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from typing import Callable

from fastapi import HTTPException

from ..core.db import connect
from . import dates, ref


class G50Error(ValueError):
    """Business validation error (message shown to the user)."""


class Conflict(G50Error):
    pass


def _num(v) -> float:
    if v in (None, ""):
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(" ", "").replace(" ", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        raise G50Error(f"Montant invalide : {v!r}") from None


def _r2(v: float) -> float:
    return round(v + 0.0, 2)


def _next_id(c: sqlite3.Connection, table: str, key: str) -> int:
    try:
        raw = c.execute(f'SELECT COALESCE(MAX(CAST("{key}" AS INTEGER)), 0) + 1 FROM "{table}"').fetchone()[0]
        return int(_num(raw))
    except Exception:
        return 1


def _g50(c: sqlite3.Connection, idg50: int) -> dict:
    r = c.execute('SELECT * FROM G50 WHERE idg50 = ?', (idg50,)).fetchone()
    if r is None:
        raise HTTPException(404, "Déclaration G50 introuvable")
    return dict(r)


def _client(c: sqlite3.Connection) -> dict:
    r = c.execute("SELECT * FROM clients LIMIT 1").fetchone()
    return dict(r) if r else {}


# ============================================================================ lines
@dataclass(frozen=True)
class Kind:
    key: str
    table: str
    pk: str
    nt: str                      # Nature code (ref table Nature): 1 TAP, 2 IRG, 3 Timbre, 4 Autres, 5 TVA, 6 TLS
    compute: Callable[[dict, dict], dict]
    order: str


def _tap_like(ref_table: str) -> Callable[[dict, dict], dict]:
    """UnitaP / UnitTsl Button1Click."""
    def compute(data: dict, g: dict) -> dict:
        r = ref.find(ref_table, "IMPOTS", data.get("impots"))
        if r is None:
            raise G50Error("Sélectionnez l’opération imposable")
        brut = _num(data.get("CAbrut"))
        exo = brut * _num(r["TAUXEXO"])
        imposable = (brut - exo) * (1 - _num(r["TAUX REFACTION"]))
        return {
            "code": str(r["CODE"]).strip(), "impots": str(r["IMPOTS"]).strip(),
            "CAbrut": _r2(brut), "CAexo": _r2(exo), "Caimposable": _r2(imposable), "CAtaxable": _r2(imposable),
            "CArefaction": _r2(brut * _num(r["TAVECR"])), "CASrefaction": _r2(brut * _num(r["TSANSR"])),
            "tauxtap": _num(r["TAUXTAP"]), "TauxExo": _num(r["TAUXEXO"]), "TavecR": _num(r["TAVECR"]),
            "taux refaction": _num(r["TAUX REFACTION"]),
            "Droits": _r2(imposable * _num(r["TAUXTAP"]) / 100),
        }
    return compute


def _pct(text) -> float | None:
    """IRGIBSRef.TAUX is text: '10%', '15%' or 'Barème' (→ None, duties entered)."""
    m = re.search(r"(\d+(?:[.,]\d+)?)", str(text or ""))
    return float(m.group(1).replace(",", ".")) if m and "%" in str(text) else None


def _irg(data: dict, g: dict) -> dict:
    """Unit24: duties = revenu × taux% unless the rate is the progressive scale (Barème)."""
    r = ref.find("IRGIBSRef", "CODE", data.get("code"))
    if r is None:
        raise G50Error("Veuillez saisir l’opération imposable")
    base = _num(data.get("Revenusimposables"))
    if not base:
        raise G50Error("Veuillez saisir le montant du revenu imposable")
    pct = _pct(r["TAUX"])
    if pct is not None:
        droits = base * pct / 100
    else:
        if data.get("droits") in (None, ""):
            raise G50Error("Veuillez saisir le montant des droits (barème)")
        droits = _num(data.get("droits"))
    return {"code": str(r["CODE"]).strip(), "impots": str(r["IMPOTS"]).strip(), "taux": str(r["TAUX"] or "").strip(),
            "Revenusimposables": _r2(base), "droits": _r2(droits), "ntotal": int(r["NTOTAL"] or 0), "n": int(r["N"] or 0)}


def _timbre(data: dict, g: dict) -> dict:
    """Unit25 + TtimbreNewRecord defaults."""
    base = _num(data.get("Caimposable"))
    if not base:
        raise G50Error("Veuillez saisir le chiffre d’affaires imposable")
    if data.get("droits") in (None, ""):
        raise G50Error("Veuillez saisir le montant des droits")
    return {"code": "E2E12", "impots": "Droit de Timbre sur Etat", "Caimposable": _r2(base),
            "taux": _num(data.get("taux")), "droits": _r2(_num(data.get("droits")))}


def _autres(data: dict, g: dict) -> dict:
    """Unit27: rate from AutresTaxesRef; duties default to base × taux % (editable)."""
    r = ref.find("AutresTaxesRef", "CODE", data.get("code"))
    if r is None:
        raise G50Error("Veuillez saisir l’opération imposable")
    base = _num(data.get("Revenusimposables"))
    if not base:
        raise G50Error("Veuillez saisir la base imposable")
    taux = _num(data.get("taux")) if data.get("taux") not in (None, "") else _num(r.get("TAUX"))
    droits = _num(data.get("droits")) if data.get("droits") not in (None, "") else base * taux / 100
    if not droits and not taux:
        raise G50Error("Veuillez saisir le montant des droits")
    return {"code": str(r["CODE"]).strip(), "impots": str(r["IMPOTS"]).strip(), "Revenusimposables": _r2(base),
            "BaseImposable": _r2(base), "taux": taux, "droits": _r2(droits)}


def _tva(data: dict, g: dict) -> dict:
    """Unit26: nature E = exonéré (no duties); N/R taxed at the reference rate."""
    r = ref.find("TVAref", "CODE", data.get("CODE"))
    if r is None:
        raise G50Error("Sélectionnez l’opération imposable")
    cai = _num(data.get("CAI"))
    cae = _num(data.get("CAE"))
    cag = _num(data.get("CAG"))
    nature = str(r["NATURE"] or "").strip().upper()
    taux = _num(r["Taux"])
    if "CAI" in data or "CAE" in data:
        cag = cai + cae
        droits = cai * taux / 100 if nature != "E" else 0.0
    else:
        if nature != "E":
            cai, cae, droits = cag, 0.0, cag * taux / 100
        else:
            cai, cae, droits = 0.0, cag, 0.0
    return {"CODE": str(r["CODE"]).strip(), "OPérations": str(r["OPÉRATIONS"]).strip(), "NATURE": nature,
            "CAG": _r2(cag), "CAI": _r2(cai), "CAE": _r2(cae), "TAUX": taux, "DROITS": _r2(droits),
            "caN": _r2(cai) if nature == "N" else 0.0, "car": _r2(cai) if nature == "R" else 0.0,
            "Caexo": _r2(cae)}


def _deduction(data: dict, g: dict) -> dict:
    """Unit4: TVA = HT × taux / 100, mandatory fields, TEtatTVANewRecord defaults."""
    for k, msg in (("nfacture", "Veuillez saisir le numéro de facture"), ("datrfqcture", "Veuillez saisir la date de facture"),
                   ("fournisseur", "Veuillez saisir le fournisseur"), ("ht", "Veuillez saisir le montant HT"),
                   ("TauxTva", "Veuillez sélectionner le taux"), ("NATURE", "Veuillez sélectionner la nature de déduction")):
        if data.get(k) in (None, ""):
            raise G50Error(msg)
    nat = next((n for n in ref.table("naturededction")
                if str(data["NATURE"]).strip() in (str(n["IDNATUREDEDCTION"]).strip(), str(n["NATUREDEDCTION"]).strip())), None)
    if nat is None:
        raise G50Error("Nature de déduction inconnue")
    ht, taux = _num(data["ht"]), _num(data["TauxTva"])
    tva = ht * taux / 100
    amort = "amort" in str(nat["NATUREDEDCTION"]).lower()
    return {"nfacture": str(data["nfacture"]).strip(), "datrfqcture": dates.to_storage(data["datrfqcture"]),
            "fournisseur": str(data["fournisseur"]).strip(), "IDfournisseurTva": data.get("IDfournisseurTva") or None,
            "ht": _r2(ht), "TauxTva": int(taux), "tvadroits": _r2(tva), "NATURE": str(nat["NATUREDEDCTION"]).strip(),
            "natute1": str(nat["IDNATUREDEDCTION"]).strip(), "N1": 0.0 if amort else _r2(tva), "N2": _r2(tva) if amort else 0.0,
            "leMois": g.get("leMois"), "Année": g.get("Année")}


KINDS: dict[str, Kind] = {k.key: k for k in (
    Kind("tap", "TAP", "idtap", "1", _tap_like("TAPRef"), '"idtap"'),
    Kind("tls", "TLS", "IDTLS", "6", _tap_like("TlsRef"), '"IDTLS"'),
    Kind("irg", "IRGSalaires", "ID", "2", _irg, '"ID"'),
    Kind("timbre", "Timbre", "ID", "3", _timbre, '"ID"'),
    Kind("autres", "AutresTaxes", "ID", "4", _autres, '"ID"'),
    Kind("tva", "TVA", "ID", "5", _tva, '"ID"'),
    Kind("deductions", "DetailEtatTVA", "IDDetailEtatTVA", "", _deduction, '"datrfqcture", "IDDetailEtatTVA"'),
)}


def _kind(name: str) -> Kind:
    k = KINDS.get(name)
    if k is None:
        raise HTTPException(404, f"Type de ligne inconnu : {name}")
    return k


def _lines(c: sqlite3.Connection, kind: Kind, idg50: int) -> list[dict]:
    rows = [dict(r) for r in c.execute(f'SELECT * FROM "{kind.table}" WHERE "Idg50" = ? ORDER BY {kind.order}', (idg50,))]
    for r in rows:
        r["_id"] = r[kind.pk]
        if kind.key == "deductions":
            r["date_display"] = dates.to_display(r.get("datrfqcture"))
    return rows


def _columns(c: sqlite3.Connection, table: str) -> set[str]:
    return {r[1] for r in c.execute(f'PRAGMA table_info("{table}")')}


def save_line(code: str, idg50: int, kind_name: str, data: dict, line_id: int | None = None) -> dict:
    kind = _kind(kind_name)
    with connect(code) as c:
        g = _g50(c, idg50)
        values = kind.compute(data, g)
        cols = _columns(c, kind.table)
        if kind.key == "deductions":   # Unit4: an invoice can be deducted only once
            dup = c.execute('SELECT "IDDetailEtatTVA", "leMois", "Année" FROM DetailEtatTVA WHERE "nfacture" = ? '
                            'AND substr("datrfqcture", 1, 10) = substr(?, 1, 10) AND "fournisseur" = ?',
                            (values["nfacture"], values["datrfqcture"], values["fournisseur"])).fetchone()
            if dup and dup[0] != line_id:
                raise Conflict(f"Facture déjà déduite au mois de {dup[1]} {dup[2]}")
        else:
            values.update({"NT": kind.nt})
        cl = _client(c)
        if "IDclients" in cols:
            values["IDclients"] = cl.get("IDclients")
        if "Année" in cols and kind.key != "deductions":
            values["Année"] = g.get("Année")
        values = {k: v for k, v in values.items() if k in cols}
        if line_id is None:
            values[kind.pk] = _next_id(c, kind.table, kind.pk)
            values["Idg50"] = idg50
            col_sql = ", ".join(f'"{k}"' for k in values)
            c.execute(f'INSERT INTO "{kind.table}" ({col_sql}) VALUES ({", ".join("?" for _ in values)})', tuple(values.values()))
            line_id = values[kind.pk]
        else:
            if not c.execute(f'SELECT 1 FROM "{kind.table}" WHERE "{kind.pk}" = ? AND "Idg50" = ?', (line_id, idg50)).fetchone():
                raise HTTPException(404, "Ligne introuvable")
            sets = ", ".join(f'"{k}" = ?' for k in values)
            c.execute(f'UPDATE "{kind.table}" SET {sets} WHERE "{kind.pk}" = ?', (*values.values(), line_id))
        _recalc(c, idg50)
    return detail(code, idg50, recalc=False)


def delete_line(code: str, idg50: int, kind_name: str, line_id: int) -> dict:
    kind = _kind(kind_name)
    with connect(code) as c:
        _g50(c, idg50)
        cur = c.execute(f'DELETE FROM "{kind.table}" WHERE "{kind.pk}" = ? AND "Idg50" = ?', (line_id, idg50))
        if not cur.rowcount:
            raise HTTPException(404, "Ligne introuvable")
        _recalc(c, idg50)
    return detail(code, idg50, recalc=False)


# ============================================================================ calculations
def _irg_bucket(code: str) -> int:
    """Recap 3.1 / 3.2 / 3.3 from IRGIBSRef.NTOTAL (1 salaires, 2 autres retenues IRG, 3 IBS)."""
    r = ref.find("IRGIBSRef", "CODE", code)
    if r is not None and r.get("NTOTAL"):
        return int(r["NTOTAL"])
    return 1 if str(code).upper().startswith(("E2L", "E1L20")) else 2


def _sum(c, table, col, idg50, where="") -> float:
    return float(c.execute(f'SELECT COALESCE(SUM("{col}"), 0) FROM "{table}" WHERE "Idg50" = ? {where}', (idg50,)).fetchone()[0] or 0)


def _recalc(c: sqlite3.Connection, idg50: int) -> dict:
    """RecalcEtatTVA + CalcTVA (Unit2) and the recap of the 6 tables (uMain page 1)."""
    g = _g50(c, idg50)
    decl_m, decl_y = int(_num(g.get("Mois"))), int(_num(g.get("Année")))
    s91 = s92 = s95 = 0.0
    for r in c.execute('SELECT tvadroits, NATURE, datrfqcture FROM DetailEtatTVA WHERE "IDg50" = ?', (idg50,)):
        d = dates.parse(r["datrfqcture"])
        same = d is None or not decl_m or not decl_y or (d.month == decl_m and d.year == decl_y)
        v = float(r["tvadroits"] or 0)
        if not same:
            s95 += v                                   # factures des mois antérieurs → ligne 95
        elif "amort" in str(r["NATURE"] or "").lower():
            s92 += v                                   # biens amortissables → ligne 92
        else:
            s91 += v                                   # biens, matières et services → ligne 91
    s96 = _sum(c, "TVA", "DROITS", idg50)              # Unit26: E3B96 = Σ droits TVA
    b = (_num(g.get("Précompte_antérieur")) + s91 + s92 + _num(g.get("déductioncomplémentaire"))
         + _num(g.get("TVAfacturesannulées")) + s95)
    cc = s96 + _num(g.get("déduction_excédentaire")) + _num(g.get("Reversement_de_la_déduction"))
    payer, reporter = (0.0, b - cc) if b > cc else (cc - b, 0.0)

    irg = {1: 0.0, 2: 0.0, 3: 0.0}
    for r in c.execute('SELECT code, droits FROM IRGSalaires WHERE "Idg50" = ?', (idg50,)):
        irg[_irg_bucket(r["code"])] = irg.get(_irg_bucket(r["code"]), 0.0) + float(r["droits"] or 0)
    st1 = _sum(c, "TAP", "Droits", idg50) + _sum(c, "TLS", "Droits", idg50)
    # IBS: acomptes + solde de liquidation
    st2_acomptes = _sum(c, "IBSAcomptes", "droits", idg50)
    cols_ibs_solde = {r[1] for r in c.execute('PRAGMA table_info(IBSsolde)')}
    st2_solde = 0.0
    if "idg50" in cols_ibs_solde:
        st2_solde = float(c.execute('SELECT COALESCE(SUM("Soldedeliquidation"), 0) FROM IBSsolde WHERE "idg50" = ?', (idg50,)).fetchone()[0] or 0)
    st2 = st2_acomptes + st2_solde

    st4 = _sum(c, "Timbre", "droits", idg50)
    st5 = _sum(c, "AutresTaxes", "droits", idg50)

    # IRG: check if an acompte or solde is linked
    cols_irg_solde = {r[1] for r in c.execute('PRAGMA table_info(IRGsolde)')}
    irg_solde_val = 0.0
    if "idg50" in cols_irg_solde:
        irg_solde_val = float(c.execute('SELECT COALESCE(SUM("Soldedeliquidation"), 0) FROM IRGsolde WHERE "idg50" = ?', (idg50,)).fetchone()[0] or 0)
    irg_acompte_val = float(c.execute('SELECT COALESCE(SUM("droits"), 0) FROM IRGAcomptes WHERE "Idg50" = ?', (idg50,)).fetchone()[0] or 0)
    irg_total_ap_solde = irg_acompte_val + irg_solde_val

    values = {
        "TTVAachatMatieres": _r2(s91), "TVAbiensamortissables": _r2(s92), "Autres_déductions": _r2(s95),
        "Totaldroits_dus": _r2(s96), "Total_des_déductions": _r2(b), "TOTALaRAPPELER": _r2(cc),
        "TVA_à_payer": _r2(payer), "Précompte_à_reporter": _r2(reporter),
        "st1": _r2(st1), "st2": _r2(st2), "st31": _r2(irg[1]), "st32": _r2(irg[2]), "st33": _r2(irg[3]),
        "st4": _r2(st4), "st5": _r2(st5), "st6": _r2(payer),
    }
    values["totalgeneral"] = _r2(sum(values[k] for k in ("st1", "st2", "st31", "st32", "st33", "st4", "st5", "st6")) + irg_total_ap_solde)
    sets = ", ".join(f'"{k}" = ?' for k in values)
    c.execute(f'UPDATE G50 SET {sets} WHERE idg50 = ?', (*values.values(), idg50))
    return values


def recalc(code: str, idg50: int) -> dict:
    with connect(code) as c:
        return _recalc(c, idg50)


RECAP = [
    ("st1", "TAP / TLS"), ("st2", "Acomptes IBS"), ("st31", "IRG salaires"), ("st32", "IRG — autres retenues à la source"),
    ("st33", "IBS — retenues à la source"), ("st4", "Droits de timbre"), ("st5", "Autres taxes"), ("st6", "TVA"),
]


def _summary(g: dict) -> dict:
    return {
        "idg50": g["idg50"], "mois": int(_num(g.get("Mois"))), "leMois": g.get("leMois"), "annee": g.get("Année"),
        "periode": g.get("MoisAnnée"), "date_depot": dates.to_display(g.get("DAtedEC")),
        "total": _num(g.get("totalgeneral")), "tva_a_payer": _num(g.get("TVA_à_payer")),
        "precompte_a_reporter": _num(g.get("Précompte_à_reporter")), "tap_option": bool(g.get("TAP")),
        "recap": [{"key": k, "label": lbl, "montant": _num(g.get(k))} for k, lbl in RECAP],
    }


# ============================================================================ declarations
def list_g50(code: str, annee: str) -> dict:
    with connect(code) as c:
        rows = [dict(r) for r in c.execute('SELECT * FROM G50 WHERE "Année" = ? ORDER BY Mois', (str(annee),))]
        last = max((int(_num(r.get("Mois"))) for r in rows), default=0)
    return {"items": [_summary(r) for r in rows], "next_mois": min(last + 1, 12) if rows else 1,
            "mois": [{"mois": int(m["MOIS"]), "label": m["LeMois"]} for m in ref.table("Mois")]}


def detail(code: str, idg50: int, recalc: bool = True) -> dict:
    with connect(code) as c:
        if recalc:                         # Form2.FormShow → RecalcEtatTVA
            _recalc(c, idg50)
        g = _g50(c, idg50)
        lines = {k: _lines(c, kind, idg50) for k, kind in KINDS.items()}
    tva_block = {k: _num(g.get(f)) for k, f in (
        ("l90", "Précompte_antérieur"), ("l91", "TTVAachatMatieres"), ("l92", "TVAbiensamortissables"),
        ("l93", "déductioncomplémentaire"), ("l94", "TVAfacturesannulées"), ("l95", "Autres_déductions"),
        ("b", "Total_des_déductions"), ("l96", "Totaldroits_dus"), ("l97", "déduction_excédentaire"),
        ("l99", "Reversement_de_la_déduction"), ("c", "TOTALaRAPPELER"), ("a_payer", "TVA_à_payer"),
        ("a_reporter", "Précompte_à_reporter"))}
    year = int(_num(g.get("Année")))
    return {**_summary(g), "tva": tva_block, "lines": lines,
            # Unit2.UpdateTAPTabVisibility: TLS replaces TAP from 2024 unless the TAP option is checked
            "tap_regime": "tap" if year < 2024 or bool(g.get("TAP")) else "tls"}


def create(code: str, annee: str, mois: int) -> dict:
    """Unit23.Button1Click."""
    mois = int(mois)
    if not 1 <= mois <= 12:
        raise G50Error("Mois invalide")
    annee = str(annee).strip()
    label = ref.mois_label(mois)
    periode = f"{label} {annee}"
    prev_m, prev_y = (12, int(annee) - 1) if mois == 1 else (mois - 1, int(annee))
    with connect(code) as c:
        if c.execute('SELECT 1 FROM G50 WHERE "MoisAnnée" = ?', (periode,)).fetchone():
            raise Conflict(f"La déclaration pour {periode} existe déjà.")
        prev = c.execute('SELECT "Précompte_à_reporter" FROM G50 WHERE moisg50 = ? OR (Mois = ? AND "Année" = ?) '
                         'ORDER BY idg50 DESC LIMIT 1', (f"{prev_m}/{prev_y}", prev_m, str(prev_y))).fetchone()
        cl = _client(c)
        idg50 = _next_id(c, "G50", "idg50")
        values = {
            "idg50": idg50, "IDclients": cl.get("IDclients"), "rs": cl.get("rs"), "Mois": float(mois), "Année": annee,
            "MoisAnnée": periode, "leMois": label, "ma": f"{mois}{annee}", "moisg50": f"{mois}/{annee}",
            "moisg50anteriur": f"{prev_m}/{prev_y}", "Précompte_antérieur": float(prev[0] or 0) if prev else 0.0, "TAP": 0,
        }
        values = {k: v for k, v in values.items() if k in _columns(c, "G50")}
        c.execute(f'INSERT INTO G50 ({", ".join(chr(34) + k + chr(34) for k in values)}) VALUES ({", ".join("?" for _ in values)})',
                  tuple(values.values()))
        _recalc(c, idg50)
    return detail(code, idg50, recalc=False)


HEADER_FIELDS = {
    "precompte_anterieur": "Précompte_antérieur",          # ligne 90 (bouton « Manuel »)
    "deduction_complementaire": "déductioncomplémentaire",  # ligne 93
    "factures_annulees": "TVAfacturesannulées",             # ligne 94
    "regul_prorata": "déduction_excédentaire",              # ligne 97
    "reversement": "Reversement_de_la_déduction",           # ligne 99
}


def update(code: str, idg50: int, data: dict) -> dict:
    values: dict = {}
    for k, col in HEADER_FIELDS.items():
        if k in data and data[k] is not None:
            values[col] = _r2(_num(data[k]))
    if "tap_option" in data and data["tap_option"] is not None:
        values["TAP"] = 1 if data["tap_option"] else 0
    if "date_depot" in data:
        values["DAtedEC"] = dates.to_storage(data["date_depot"]) if data["date_depot"] else None
    with connect(code) as c:
        _g50(c, idg50)
        if values:
            sets = ", ".join(f'"{k}" = ?' for k in values)
            c.execute(f'UPDATE G50 SET {sets} WHERE idg50 = ?', (*values.values(), idg50))
        _recalc(c, idg50)
    return detail(code, idg50, recalc=False)


def delete(code: str, idg50: int) -> None:
    """uMain.SpeedButton5Click — the detail lines of the declaration go with it."""
    with connect(code) as c:
        _g50(c, idg50)
        for k in KINDS.values():
            c.execute(f'DELETE FROM "{k.table}" WHERE "Idg50" = ?', (idg50,))
        c.execute('DELETE FROM G50 WHERE idg50 = ?', (idg50,))


# ============================================================================ suppliers (fournisseurTva)
def fournisseurs(code: str, q: str = "", limit: int = 20) -> list[dict]:
    with connect(code) as c:
        rows = c.execute('SELECT "IDfournisseurTva" AS id, rs, NIF, adresse FROM fournisseurTva '
                         'WHERE rs LIKE ? OR NIF LIKE ? ORDER BY rs LIMIT ?', (f"%{q}%", f"%{q}%", limit))
        return [dict(r) for r in rows]


def create_fournisseur(code: str, data: dict) -> dict:
    rs = str(data.get("rs") or "").strip()
    if not rs:
        raise G50Error("Veuillez saisir la raison sociale du fournisseur")
    with connect(code) as c:
        if c.execute('SELECT 1 FROM fournisseurTva WHERE UPPER(TRIM(rs)) = UPPER(?)', (rs,)).fetchone():
            raise Conflict("Ce fournisseur existe déjà")
        new_id = _next_id(c, "fournisseurTva", "IDfournisseurTva")
        c.execute('INSERT INTO fournisseurTva ("IDfournisseurTva", rs, NIF, adresse, ai, rcom) VALUES (?, ?, ?, ?, ?, ?)',
                  (new_id, rs, data.get("NIF") or "", data.get("adresse") or "", data.get("ai") or "", data.get("rcom") or ""))
    return {"id": new_id, "rs": rs, "NIF": data.get("NIF") or "", "adresse": data.get("adresse") or ""}
